/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.popupMenus;

import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUIMessages;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUiPlugin;
import fr.obeo.acceleo.tools.log.AcceleoException;
import fr.obeo.acceleo.tools.resources.Resources;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.codegen.ecore.genmodel.GenModelFactory;
import org.eclipse.emf.codegen.ecore.genmodel.GenPackage;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

/**
 * The operation which generates the EMF java files for the current selected
 * metamodel. EMF model, edit, and editor files can be generated.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenMetamodelOperation extends WorkspaceModifyOperation {

	/**
	 * The shell.
	 */
	protected Shell shell;

	/**
	 * Selected metamodel file.
	 */
	protected ISelection selection;

	/**
	 * Indicate if it generates model files.
	 */
	protected boolean model;

	/**
	 * Indicate if it generates edit and editor files.
	 */
	protected boolean edit;

	/**
	 * Constructor.
	 * 
	 * @param shell
	 *            is the shell
	 * @param selection
	 *            is the selected metamodel file
	 * @param model
	 *            indicate if it generates model files
	 * @param edit
	 *            indicate if it generates edit and editor files
	 */
	public AcceleoGenMetamodelOperation(Shell shell, ISelection selection, boolean model, boolean edit) {
		super();
		this.shell = shell;
		this.selection = selection;
		this.model = model;
		this.edit = edit;
	}

	/**
	 * Ecore metamodel resource.
	 */
	protected Resource ecoreModelResource = null;

	/**
	 * Ecore metamodel file.
	 */
	protected String ecoreModelFile = null;

	/**
	 * Ecore metamodel URI.
	 */
	protected URI ecoreModelURI = null;

	/* (non-Javadoc) */
	protected void execute(IProgressMonitor progressMonitor) {
		IWorkspaceRunnable runnable = new IWorkspaceRunnable() {
			public void run(IProgressMonitor progressMonitor) throws CoreException {
				try {
					final int totalWork = ((edit) ? 11 : 7);
					progressMonitor.beginTask(AcceleoEcoreUIMessages.getString("AcceleoGenMetamodelOperation.Monitor.TaskName"), totalWork); //$NON-NLS-1$

					/** * 1 : Metamodel selected ** */

					IFile file = (IFile) ((StructuredSelection) selection).getFirstElement();

					if (createEcoreResource(file)) {
						progressMonitor.worked(1);
					} else {
						progressMonitor.done();
						return;
					}

					/** * 2 : GenModel ** */

					String projectName = file.getProject().getName();
					IPath genModelFilePath = new Path(ecoreModelFile).removeFileExtension().addFileExtension("genmodel"); //$NON-NLS-1$
					ResourceSet genModelResourceSet = new ResourceSetImpl();

					// Create GenModel
					URI genModelURI = Resources.createPlatformResourceURI(genModelFilePath.toString());
					Resource genModelResource = genModelResourceSet.createResource(genModelURI);
					GenModelFactory genModelFactory = GenModelFactory.eINSTANCE;
					GenModel genModel = genModelFactory.createGenModel();
					genModelResource.getContents().add(genModel);

					// Initialize GenModel
					List ePackages = new ArrayList();
					EPackage ePackage = (ecoreModelResource.getContents().size() > 0) ? (EPackage) ecoreModelResource.getContents().get(0) : null;
					ePackage = (EPackage) ETools.validate(ePackage, true, AcceleoEcoreUIMessages.getString(
							"AcceleoGenMetamodelOperation.EcoreValidationNeeded", new Object[] { file.getFullPath().toString(), })); //$NON-NLS-1$
					if (ePackage != null) {
						ePackages.add(ePackage);
					}
					genModel.initialize(ePackages);

					String qualifier = projectName;
					if (!genModel.getGenPackages().isEmpty()) {
						traverseGenPackages(genModel.getGenPackages());
						GenPackage genPackage = (GenPackage) genModel.getGenPackages().get(0);
						genPackage.setBasePackage(getBasePackage());
						while (genPackage.getGenClassifiers().isEmpty() && !genPackage.getNestedGenPackages().isEmpty()) {
							genPackage = (GenPackage) genPackage.getNestedGenPackages().get(0);
						}
						qualifier = genPackage.getInterfacePackageName();
					}

					String modelName = new Path(ecoreModelFile).removeFileExtension().lastSegment();
					modelName = Character.toUpperCase(modelName.charAt(0)) + modelName.substring(1);
					genModel.setCodeFormatting(true);
					genModel.setModelName(modelName);
					genModel.setModelPluginID(projectName);
					genModel.setEditPluginClass(qualifier + ".provider." + modelName + "EditPlugin"); //$NON-NLS-1$  //$NON-NLS-2$
					genModel.setEditorPluginClass(qualifier + ".presentation." + modelName + "EditorPlugin"); //$NON-NLS-1$ //$NON-NLS-2$
					genModel.setModelDirectory('/' + projectName + "/src-gen"); //$NON-NLS-1$
					genModel.setEditDirectory('/' + projectName + ".edit/src-gen"); //$NON-NLS-1$
					genModel.setEditorDirectory('/' + projectName + ".editor/src-gen"); //$NON-NLS-1$
					genModel.setTestsDirectory('/' + projectName + ".tests/src-gen"); //$NON-NLS-1$

					genModel.getForeignModel().add(makeRelative(ecoreModelURI, genModelURI).toString());

					updateGenModel(genModel);
					// Save GenModel
					genModelResource.save(Collections.EMPTY_MAP);
					progressMonitor.worked(2);

					/** * 3 : Generate model ** */

					if (model) {
						genModel.setCanGenerate(true);
						genModel.generate(progressMonitor);
					}
					progressMonitor.worked(2);

					/** * 4 : Generate edit and editor ** */

					if (edit) {
						genModel.generateEdit(progressMonitor);
						progressMonitor.worked(2);
						genModel.generateEditor(progressMonitor);
						progressMonitor.worked(2);
					}

					/** * 5 : Generate icons folders ** */
					IPath icons = new Path("icons"); //$NON-NLS-1$
					if (getBasePackage() != null && getBasePackage().length() > 0) {
						icons = icons.append(new Path(getBasePackage().replaceAll("\\.", "/"))); //$NON-NLS-1$ //$NON-NLS-2$
					}
					IFolder parentFolder = Resources.getOrCreateFolder(file.getParent(), icons, progressMonitor);
					if (ePackage != null) {
						generateIconFolders(ePackage, parentFolder, progressMonitor);
					}
					progressMonitor.worked(1);

				} catch (Exception e) {
					AcceleoEcoreUiPlugin.getDefault().log(e, true);
				} finally {
					progressMonitor.done();
				}
			}
		};
		try {
			ResourcesPlugin.getWorkspace().run(runnable, progressMonitor);
		} catch (CoreException e) {
			AcceleoEcoreUiPlugin.getDefault().log(e, true);
		}
	}

	/**
	 * Update the .genmodel informations
	 * 
	 * @param genModel
	 *            the .genmodel to update
	 */
	protected void updateGenModel(GenModel genModel) {
		genModel.setContainmentProxies(false);
	}

	/**
	 * It creates an ecore resource. It indicates if this resource has been
	 * really created.
	 * 
	 * @param file
	 *            is the selected metamodel
	 * @return true if the resource has been created.
	 * @throws IOException
	 */
	protected boolean createEcoreResource(IFile file) throws IOException {
		String ext = file.getProjectRelativePath().getFileExtension();
		if (ext.equals("ecore")) { //$NON-NLS-1$
			ecoreModelFile = file.getFullPath().toString();
			ecoreModelURI = Resources.createPlatformResourceURI(ecoreModelFile);
			Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
			reg.getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl()); //$NON-NLS-1$
			ResourceSet ecoreModelResourceSet = new ResourceSetImpl();
			ecoreModelResource = ecoreModelResourceSet.getResource(ecoreModelURI, true);
			// EcoreUtil.resolveAll(ecoreModelResourceSet);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Sets the value of the 'Prefix' attribute for all packages.
	 * 
	 * @param genPackages
	 *            is the list of packages
	 * @throws AcceleoException
	 */
	protected void traverseGenPackages(List genPackages) throws AcceleoException {
		for (Iterator i = genPackages.iterator(); i.hasNext();) {
			GenPackage genPackage = (GenPackage) i.next();
			EPackage ePackage = genPackage.getEcorePackage();
			if (ePackage.getEClassifiers().size() > 0 && (ePackage.getNsURI() == null || ePackage.getNsURI().trim().length() == 0)) {
				throw new AcceleoException(AcceleoEcoreUIMessages.getString("AcceleoGenMetamodelOperation.NsURINeeded", new Object[] { ePackage.getName(), })); //$NON-NLS-1$
			}
			if (genPackage.getPrefix() == null || genPackage.getPrefix().length() == 0) {
				String name = ePackage.getName();
				genPackage.setPrefix(Character.toUpperCase(name.charAt(0)) + name.substring(1));
			}
			if (genPackage.getNSURI() != null && genPackage.getNSURI().length() > 0) {
				EPackage.Registry.INSTANCE.remove(genPackage.getNSURI());
			}
			traverseGenPackages(genPackage.getNestedGenPackages());
		}
	}

	private String getBasePackage() throws AcceleoException {
		if (basePackage == null) {
			basePackage = ""; //$NON-NLS-1$
			IFile file = (IFile) ((StructuredSelection) selection).getFirstElement();
			if ("ecore".equals(file.getFileExtension())) { //$NON-NLS-1$
				InputDialog dialog = new InputDialog(shell, AcceleoEcoreUIMessages.getString("AcceleoGenMetamodelOperation.Dialog.BasePackageTitle"), //$NON-NLS-1$
						AcceleoEcoreUIMessages.getString("AcceleoGenMetamodelOperation.Dialog.BasePackageMessage"), //$NON-NLS-1$
						"", //$NON-NLS-1$
						null);
				if (dialog.open() == InputDialog.OK) {
					String value = dialog.getValue();
					if (value != null) {
						basePackage = value;
					}
				} else {
					throw new AcceleoException(AcceleoEcoreUIMessages.getString("AcceleoGenMetamodelOperation.Dialog.BasePackageCancel")); //$NON-NLS-1$
				}
			}
		}
		return basePackage;
	}

	private String basePackage = null;

	/**
	 * It calculates the relative URI between the 2 URI.
	 * 
	 * @param uri
	 *            is the first URI
	 * @param relativeTo
	 *            is the second URI
	 * @return the relative URI
	 */
	protected static URI makeRelative(URI uri, URI relativeTo) {
		if ("file".equals(uri.scheme())) { //$NON-NLS-1$
			IFile file = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(uri.toFileString()));
			if (file != null) {
				URI platformURI = Resources.createPlatformResourceURI(file.getFullPath().toString());
				URI result = platformURI.deresolve(relativeTo, false, true, false);
				if (result.isRelative()) {
					return result;
				}
			}
		}
		URI result = uri.deresolve(relativeTo, true, true, false);
		if (result.isRelative()) {
			return result;
		}
		return uri;
	}

	/**
	 * It generates icons folders hierarchy. The hierarchy of folders
	 * corresponds to the hierarchy of packages in the metamodel.
	 * 
	 * @param ePackage
	 *            is the root node of the metamodel resource
	 * @param parentFolder
	 *            is the target folder
	 * @param progressMonitor
	 *            is the progress monitor
	 * @throws CoreException
	 */
	protected void generateIconFolders(EPackage ePackage, IFolder parentFolder, IProgressMonitor progressMonitor) throws CoreException {
		parentFolder = Resources.getOrCreateFolder(parentFolder, new Path(ePackage.getName()), progressMonitor);
		Iterator packages = ePackage.getESubpackages().iterator();
		while (packages.hasNext()) {
			EPackage eSubPackage = (EPackage) packages.next();
			generateIconFolders(eSubPackage, parentFolder, progressMonitor);
		}
	}

}
