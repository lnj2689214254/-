/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.wizards;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUIMessages;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUiPlugin;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * The wizard which generates a new project with a new metamodel. It's an
 * abstract base implementation. Subclasses must implement the method
 * 'createMetamodelFile'.
 * 
 * @author www.obeo.fr
 * 
 */
public abstract class NewMetamodelProjectWizard extends Wizard implements INewWizard {

	/**
	 * The default name of the metamodel folder.
	 */
	private static final String DEFAULT_METAMODEL_FOLDER_NAME = "model"; //$NON-NLS-1$

	/**
	 * Wizard page.
	 */
	protected NewMetamodelProjectWizardPage page;

	/**
	 * Metamodel file extension : ecore...
	 */
	protected String extension;

	/**
	 * Constructor.
	 * 
	 * @param extension
	 *            is the metamodel file extension
	 */
	public NewMetamodelProjectWizard(String extension) {
		super();
		setNeedsProgressMonitor(true);
		this.extension = extension;
	}

	/* (non-Javadoc) */
	public void addPages() {
		page = new NewMetamodelProjectWizardPage(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizard.PageTitle"), extension); //$NON-NLS-1$
		addPage(page);
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String projectName = page.getProjectName();
		final String fileName = page.getFileName();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(projectName, fileName, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			Throwable realException = e.getTargetException();
			AcceleoEcoreUiPlugin.getDefault().log(realException, true);
			return false;
		}
		return true;
	}

	/**
	 * It creates a new project with a new metamodel.
	 * 
	 * @param projectName
	 *            is the name of the project
	 * @param fileName
	 *            is the metamodel file name
	 * @param monitor
	 *            is the progress monitor
	 * @throws CoreException
	 */
	private void doFinish(String projectName, String fileName, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizard.Monitor.TaskCreation", new Object[] { fileName }), 2); //$NON-NLS-1$
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IPath projectPath = new Path(projectName);
		if (projectPath.segmentCount() != 1) {
			throwCoreException(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizard.Error.InvalidProjectName", new Object[] { projectName })); //$NON-NLS-1$
		}
		IResource resource = root.findMember(projectPath);
		if (resource != null && resource.exists()) {
			throwCoreException(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizard.Error.ExistingProject", new Object[] { projectName })); //$NON-NLS-1$
		}
		// Create project
		IProject project = Resources.createJavaProject(projectName, monitor).getProject();
		// Create folders
		IFolder modelFolder = Resources.getOrCreateFolder(project, new Path(DEFAULT_METAMODEL_FOLDER_NAME), monitor);
		Resources.getOrCreateFolder(project, new Path(DEFAULT_METAMODEL_FOLDER_NAME + "/icons"), monitor); //$NON-NLS-1$
		// Create metamodel file
		final IFile file = createMetamodelFile(modelFolder, fileName, monitor);
		monitor.worked(1);
		if (file != null && file.exists()) {
			monitor.setTaskName(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizard.Monitor.TaskOpening")); //$NON-NLS-1$
			getShell().getDisplay().asyncExec(new Runnable() {
				public void run() {
					IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
					try {
						IDE.openEditor(page, file, true);
					} catch (PartInitException e) {
					}
				}
			});
		}
		monitor.worked(1);
	}

	/**
	 * Creates the metamodel file.
	 * 
	 * @param folder
	 *            is the target folder
	 * @param fileName
	 *            is the metamodel file name
	 * @param monitor
	 *            is the progress monitor
	 * @return the newly created metamodel file
	 */
	protected abstract IFile createMetamodelFile(IFolder folder, String fileName, IProgressMonitor monitor);

	/**
	 * Throw CoreException with the given message.
	 * 
	 * @param message
	 * @throws CoreException
	 */
	protected abstract void throwCoreException(String message) throws CoreException;

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		setWindowTitle(AcceleoEcoreUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

}
