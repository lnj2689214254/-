/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import fr.obeo.acceleo.tools.ui.resources.JarFactory;

/**
 * This action generates the jar for the current selected metamodel.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenJarAction implements IObjectActionDelegate {

	/**
	 * Selected metamodel file.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoGenJarAction() {
		super();
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		IFile modelFile = (IFile) ((StructuredSelection) selection).getFirstElement();
		IPath rootFolder = modelFile.getProject().getFolder(new Path("/src")).getFullPath(); //$NON-NLS-1$
		IPath jarLocation = new Path(modelFile.getFullPath().toString()).removeFileExtension().addFileExtension("jar"); //$NON-NLS-1$
		JarFactory.createJar(rootFolder, jarLocation);
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
