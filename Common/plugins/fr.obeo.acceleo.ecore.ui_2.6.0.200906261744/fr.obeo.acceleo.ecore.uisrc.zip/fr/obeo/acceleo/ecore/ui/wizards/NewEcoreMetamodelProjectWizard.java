/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.ecore.ui.wizards;

import java.io.IOException;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;

import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUiPlugin;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * The wizard which generates a new project with a new ecore metamodel. The
 * metamodel is put in folder "/model".
 * 
 * @author www.obeo.fr
 * 
 */
public class NewEcoreMetamodelProjectWizard extends NewMetamodelProjectWizard {

	/**
	 * Constructor.
	 */
	public NewEcoreMetamodelProjectWizard() {
		super("ecore"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	protected IFile createMetamodelFile(IFolder folder, String fileName, IProgressMonitor monitor) {
		try {
			IFile ecoreModelFile = folder.getFile(fileName);
			IPath ecoreModelFilePath = ecoreModelFile.getFullPath();
			String ecoreModelFileS = ecoreModelFilePath.toString();
			URI ecoreModelURI = Resources.createPlatformResourceURI(ecoreModelFileS);
			Resource ecoreModelResource = new EcoreResourceFactoryImpl().createResource(ecoreModelURI);
			// Add the initial object to the ecore model contents
			String shortName = Resources.getFileShortName(ecoreModelFile);
			EPackage ePackage = ETools.createPackageHierarchy(shortName);
			ecoreModelResource.getContents().add(ePackage);
			ecoreModelResource.save(Collections.EMPTY_MAP);
			ecoreModelResource.unload();
			return ecoreModelFile;
		} catch (IOException e) {
			return null;
		}
	}

	/* (non-Javadoc) */
	protected void throwCoreException(String message) throws CoreException {
		throw new CoreException(new Status(IStatus.ERROR, AcceleoEcoreUiPlugin.getDefault().getID(), IStatus.OK, message, null));
	}

}
