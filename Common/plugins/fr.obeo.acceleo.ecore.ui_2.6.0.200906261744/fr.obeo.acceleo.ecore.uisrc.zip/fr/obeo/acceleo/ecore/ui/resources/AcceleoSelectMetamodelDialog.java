/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.SelectionDialog;
import org.eclipse.ui.internal.ide.IIDEHelpContextIds;

import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUIMessages;
import fr.obeo.acceleo.tools.ui.resources.FileSelectionDialog;

/**
 * The role of this dialog is to select an ecore metamodel, in the workspace or
 * in the registry (EPackage).
 * 
 * @author www.obeo.fr
 */

public class AcceleoSelectMetamodelDialog extends SelectionDialog {

	/**
	 * The metamodel URI.
	 */
	private Text metamodelURI;

	/**
	 * The input URI.
	 */
	private String input;

	/**
	 * The extensions.
	 */
	private String[] extensions;

	/**
	 * Constructor.
	 * 
	 * @param shell
	 *            is the parent shell
	 * @param input
	 *            is the input URI
	 * @param extensions
	 *            is a table of extensions
	 */
	public AcceleoSelectMetamodelDialog(Shell shell, String input, String[] extensions) {
		super(shell);
		setTitle(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.Title")); //$NON-NLS-1$
		setMessage(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.Message")); //$NON-NLS-1$
		this.input = input;
		setShellStyle(getShellStyle() | SWT.RESIZE);
		this.extensions = extensions;
	}

	/* (non-Javadoc) */
	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		PlatformUI.getWorkbench().getHelpSystem().setHelp(shell, IIDEHelpContextIds.RESOURCE_SELECTION_DIALOG);
	}

	/* (non-Javadoc) */
	protected void okPressed() {
		List result = new ArrayList();
		result.add(getMetamodelURI());
		setResult(result);
		super.okPressed();
	}

	/* (non-Javadoc) */
	protected Control createDialogArea(Composite parent) {
		Composite composite = (Composite) super.createDialogArea(parent);
		createMessageArea(composite);
		Composite rootContainer = new Composite(composite, SWT.NULL);
		GridLayout rootContainerLayout = new GridLayout();
		rootContainerLayout.numColumns = 1;
		rootContainerLayout.marginTop = 14;
		rootContainerLayout.verticalSpacing = 9;
		rootContainerLayout.marginLeft = 7;
		rootContainerLayout.marginRight = 7;
		rootContainer.setLayout(rootContainerLayout);

		Composite registryContainer = new Composite(rootContainer, SWT.NULL);
		GridLayout registryContainerLayout = new GridLayout();
		registryContainerLayout.numColumns = 3;
		registryContainerLayout.verticalSpacing = 9;
		registryContainer.setLayout(registryContainerLayout);

		Label registryLabel = new Label(registryContainer, SWT.NULL);
		registryLabel.setText(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.registry.label") + ':'); //$NON-NLS-1$

		Set registryValues = new TreeSet(EPackage.Registry.INSTANCE.keySet());
		final String[] valueLabels = (String[]) registryValues.toArray(new String[registryValues.size()]);
		Combo comboBox = new Combo(registryContainer, SWT.READ_ONLY);
		comboBox.setItems(valueLabels);
		int visibleItemCount = 15;
		if (valueLabels.length < visibleItemCount) {
			comboBox.setVisibleItemCount(valueLabels.length);
		} else {
			comboBox.setVisibleItemCount(visibleItemCount);
		}
		comboBox.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				metamodelURI.setText(valueLabels[((Combo) e.widget).getSelectionIndex()]);
			}
		});

		Button button = new Button(registryContainer, SWT.PUSH);
		button.setText(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.BrowseButtonLabel")); //$NON-NLS-1$
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleBrowse();
			}
		});

		Composite uriContainer = new Composite(rootContainer, SWT.NULL);
		GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.horizontalSpan = 4;
		uriContainer.setLayoutData(gridData);
		GridLayout uriContainerLayout = new GridLayout();
		uriContainerLayout.numColumns = 1;
		uriContainer.setLayout(uriContainerLayout);

		Label uriLabel = new Label(uriContainer, SWT.NULL);
		uriLabel.setText(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.URILabel") + ':'); //$NON-NLS-1$

		metamodelURI = new Text(uriContainer, SWT.BORDER | SWT.SINGLE);
		gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.horizontalSpan = 4;
		metamodelURI.setLayoutData(gridData);
		metamodelURI.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		if (input != null) {
			metamodelURI.setText(input);
		}

		dialogChanged();
		return rootContainer;
	}

	private void handleBrowse() {
		FileSelectionDialog dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), AcceleoEcoreUIMessages
				.getString("AcceleoSelectMetamodelDialog.MetamodelSelectionTitle"), 1, extensions, true); //$NON-NLS-1$
		if (input != null) {
			IPath path = new Path(input);
			dialog.setInitialSelections(new Object[] { path });
		}
		dialog.open();
		if (dialog.getResult() != null && dialog.getResult().length > 0 && dialog.getResult()[0] instanceof IPath) {
			metamodelURI.setText(((IPath) dialog.getResult()[0]).toString());
		}
	}

	/**
	 * Validates the changes on the dialog.
	 */
	private void dialogChanged() {
		input = getMetamodelURI();
		if (input.length() == 0) {
			updateStatus(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.Error.EmptyMetamodelURI")); //$NON-NLS-1$
			return;
		}
		if (ETools.uri2EPackage(input) == null) {
			updateStatus(AcceleoEcoreUIMessages.getString("AcceleoSelectMetamodelDialog.Error.InvalidMetamodel")); //$NON-NLS-1$
			return;
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the dialog.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		if (getOkButton() != null) {
			getOkButton().setEnabled(message == null);
		}
	}

	/**
	 * Returns the metamodel URI.
	 * 
	 * @return the metamodel URI
	 */
	private String getMetamodelURI() {
		if (metamodelURI != null) {
			return metamodelURI.getText();
		} else {
			return ""; //$NON-NLS-1$
		}
	}

}
