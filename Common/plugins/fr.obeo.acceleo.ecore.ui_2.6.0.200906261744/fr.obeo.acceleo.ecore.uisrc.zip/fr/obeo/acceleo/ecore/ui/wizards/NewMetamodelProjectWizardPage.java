/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.wizards;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUIMessages;

/**
 * The wizard page which generates a new project with a new metamodel.
 * 
 * @author www.obeo.fr
 * 
 */
public class NewMetamodelProjectWizardPage extends WizardPage {

	/**
	 * Default metamodel name.
	 */
	protected static final String DEFAULT_METAMODEL_NAME = "default"; //$NON-NLS-1$

	/**
	 * Text for new project name.
	 */
	private Text projectName;

	/**
	 * Text for new metamodel file name.
	 */
	private Text fileName;

	/**
	 * Metamodel file extension.
	 */
	private String extension;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param extension
	 *            is the metamodel file extension
	 */
	public NewMetamodelProjectWizardPage(String pageName, String extension) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Description")); //$NON-NLS-1$
		this.extension = extension;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 2;
		layout.verticalSpacing = 9;

		Label label = new Label(container, SWT.NULL);
		label.setText(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.ProjectLabel") + ':'); //$NON-NLS-1$

		projectName = new Text(container, SWT.BORDER | SWT.SINGLE);
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		projectName.setLayoutData(gd);
		projectName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		label = new Label(container, SWT.NULL);
		label.setText(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.FileLabel") + ':'); //$NON-NLS-1$

		fileName = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		fileName.setLayoutData(gd);
		fileName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		initialize();
		dialogChanged();
		setControl(container);
	}

	/**
	 * Initialize page.
	 */
	private void initialize() {
		projectName.setText(""); //$NON-NLS-1$
		fileName.setText(DEFAULT_METAMODEL_NAME + '.' + extension);
	}

	/**
	 * Validate the changes on the page.
	 */
	private void dialogChanged() {
		IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(getProjectName()));
		String fileName = getFileName();
		if (getProjectName().length() == 0) {
			updateStatus(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Error.EmptyProject")); //$NON-NLS-1$
			return;
		}
		if (resource != null && resource.exists()) {
			updateStatus(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Error.ExistingProject")); //$NON-NLS-1$
			return;
		}
		if (fileName.length() == 0) {
			updateStatus(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Error.EmptyFile")); //$NON-NLS-1$
			return;
		}
		if (fileName.replace('\\', '/').indexOf('/', 1) > 0) {
			updateStatus(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Error.InvalidPath")); //$NON-NLS-1$
			return;
		}
		int dotLoc = fileName.lastIndexOf('.');
		String ext = (dotLoc > -1) ? fileName.substring(dotLoc + 1) : ""; //$NON-NLS-1$
		if (!ext.equals(extension)) {
			updateStatus(AcceleoEcoreUIMessages.getString("NewMetamodelProjectWizardPage.Error.InvalidExtension", new Object[] { extension, })); //$NON-NLS-1$
			return;
		}
		updateStatus(null);
	}

	/**
	 * Update page status.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

	/**
	 * Get text for new project name.
	 * 
	 * @return project name
	 */
	public String getProjectName() {
		return projectName.getText();
	}

	/**
	 * Get text for new metamodel file name.
	 * 
	 * @return metamodel file name
	 */
	public String getFileName() {
		return fileName.getText();
	}

}