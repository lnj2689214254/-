/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.ecore.ui.popupMenus;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUIMessages;
import fr.obeo.acceleo.ecore.ui.AcceleoEcoreUiPlugin;

/**
 * This action generates the EMF java files for the current selected metamodel.
 * Model files only.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenMetamodelAction implements IObjectActionDelegate {

	/**
	 * Selected metamodel file.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoGenMetamodelAction() {
		super();
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		IWorkbenchWindow container = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
		final Shell shell = container.getShell();
		try {
			AcceleoGenMetamodelOperation operation = new AcceleoGenMetamodelOperation(shell, selection, true, false);
			PlatformUI.getWorkbench().getProgressService().run(false, true, operation);
		} catch (InvocationTargetException e) {
			AcceleoEcoreUiPlugin.getDefault().log(e, true);
		} catch (InterruptedException e) {
			AcceleoEcoreUiPlugin.getDefault().log(AcceleoEcoreUIMessages.getString("InterruptedAction"), true); //$NON-NLS-1$
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
