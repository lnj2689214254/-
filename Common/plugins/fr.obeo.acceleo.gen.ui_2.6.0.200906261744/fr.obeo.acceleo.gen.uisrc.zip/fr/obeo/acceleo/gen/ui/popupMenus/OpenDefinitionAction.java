/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.texteditor.AbstractTextEditor;

import fr.obeo.acceleo.gen.phantom.PhantomResources;
import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateCompletionEntry;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateCompletionProcessor;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * Action opening the element declaration
 * 
 * @author www.obeo.fr
 * 
 */
public class OpenDefinitionAction extends Action implements IWorkbenchWindowActionDelegate, IObjectActionDelegate {

	/**
	 * The action id
	 */
	public final static String ACTION_ID = "fr.obeo.gen.ui.actions.Open"; //$NON-NLS-1$

	/**
	 * The virtual editor phantom path.
	 */
	private static final String VIRTUAL_TEMPLATE_EDITOR_FOLDER = PhantomResources.getRootName() + "/plugins/templates"; //$NON-NLS-1$

	/**
	 * The associated command ID
	 */
	public final static String COMMAND_ID = "fr.obeo.gen.ui.edit.open.editor"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public void dispose() {
		// nothing to do

	}

	/* (non-Javadoc) */
	public void init(IWorkbenchWindow window) {
		// nothing to do
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		super.run();
		if (PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null
				&& PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor() instanceof AcceleoTemplateEditor) {
			AcceleoTemplateEditor editor = (AcceleoTemplateEditor) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
			if (editor.getSelectionProvider() != null) {
				ITextSelection selection = (ITextSelection) editor.getSelectionProvider().getSelection();
				if (selection != null) {
					int offset = selection.getOffset() + selection.getLength();
					IFile currentFile = editor.getFile();
					IDocument document = editor.getDocumentProvider().getDocument(editor.getEditorInput());
					if (currentFile != null && document != null) {
						String text = document.get();
						TemplateConstants.initConstants(text);
						while (offset < text.length() && Character.isJavaIdentifierPart(text.charAt(offset))) {
							offset++;
						}
						int countArguments = 0;
						if (offset < text.length()) {
							Int2 bArgs = TextSearch.getRegexSearch().indexOf(text, "[ \t\r\n]*\\(", offset); //$NON-NLS-1$
							if (bArgs.b() == offset) {
								Int2 eArgs = TextSearch.getDefaultSearch().indexOf(text, ")", bArgs.e(), TemplateConstants.SPEC, TemplateConstants.INHIBS_EXPRESSION); //$NON-NLS-1$
								if (eArgs.b() > -1 && text.substring(bArgs.e(), eArgs.b()).trim().length() > 0) {
									countArguments = TextSearch.getDefaultSearch().countIn(text, ",", bArgs.e(), eArgs.b(), TemplateConstants.SPEC, TemplateConstants.INHIBS_EXPRESSION) + 1; //$NON-NLS-1$
								}
							}
						}
						if (editor.sourceViewer() != null) {
							AcceleoTemplateCompletionProcessor p = new AcceleoTemplateCompletionProcessor(editor);
							AcceleoTemplateCompletionEntry[] entries = p.computeCompletionEntries(editor.sourceViewer(), offset);
							if (entries.length > 0) {
								AcceleoTemplateCompletionEntry entry = entries[0];
								if (entry.getObject() instanceof Map.Entry) {
									Template template = (Template) ((Map.Entry) entry.getObject()).getValue();
									if (template != null) {
										File script = template.getScript().getFile();
										if (script != null) {
											IFile file = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(script.getAbsolutePath()));
											if (file == null || !file.isAccessible()) {
												if (currentFile.getProject().getFolder(new Path(PhantomResources.getRootName())).exists()) {
													StringBuffer content = Resources.getFileContent(script);
													try {
														file = Resources.createFile(currentFile.getProject(), new Path(VIRTUAL_TEMPLATE_EDITOR_FOLDER).append(script.getName()), content.toString(),
																new NullProgressMonitor());
														file.setReadOnly(true);
													} catch (CoreException e) {
														AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
													}
												}
											}
											if (file != null && file.isAccessible()) {
												IWorkbench workbench = PlatformUI.getWorkbench();
												IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
												if (workbenchWindow != null) {
													IWorkbenchPage page = workbenchWindow.getActivePage();
													if (page != null) {
														IEditorDescriptor descriptor = workbench.getEditorRegistry().getDefaultEditor(file.getName());
														if (descriptor != null) {
															try {
																IEditorPart part = page.openEditor(new FileEditorInput(file), descriptor.getId(), false);
																if (part instanceof AcceleoTemplateEditor) {
																	document = ((AcceleoTemplateEditor) part).getDocumentProvider().getDocument(((AcceleoTemplateEditor) part).getEditorInput());
																	if (document != null) {
																		text = document.get();
																		TemplateConstants.initConstants(text);
																		Int2 posE = TextSearch.getDefaultSearch().lastIndexIn(text, "\n", 0, template.getPos().b()); //$NON-NLS-1$
																		if (posE.b() > -1) {
																			Int2 posB = TextSearch.getDefaultSearch().lastIndexIn(text, "\n", 0, posE.b()); //$NON-NLS-1$
																			if (posB.e() > -1) {
																				((AcceleoTemplateEditor) part).selectAndReveal(posB.e(), posE.b() - posB.e());
																			}
																		}
																	}
																}
															} catch (PartInitException e) {
																AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
															}
														}
													}
												}
											}
										}
									}
								} else if (entry.getObject() instanceof Method) {
									Method method = (Method) entry.getObject();
									IPath path = new Path(currentFile.getProject().getName());
									String src = currentFile.getProjectRelativePath().segment(0);
									if (src != null) {
										path = path.append(src);
									}
									String className = method.getDeclaringClass().getName();
									StringTokenizer st = new StringTokenizer(className, "."); //$NON-NLS-1$
									while (st.hasMoreTokens()) {
										path = path.append(st.nextToken());
									}
									path = path.addFileExtension("java"); //$NON-NLS-1$
									IFile file = Resources.findFile(path);
									if (file != null) {
										try {
											IEditorPart part = IDE.openEditor(editor.getEditorSite().getPage(), file);
											if (part instanceof AbstractTextEditor) {
												IDocument javaDocument = ((AbstractTextEditor) part).getDocumentProvider().getDocument(((AbstractTextEditor) part).getEditorInput());
												if (javaDocument != null) {
													String javaText = javaDocument.get();
													String regexDecla = "public [a-zA-Z0-9_]+[ \t\r\n]+" + method.getName() + "[ \t\r\n]*\\("; //$NON-NLS-1$ //$NON-NLS-2$
													Int2 bDecla = TextSearch.getRegexSearch().indexOf(javaText, regexDecla);
													while (bDecla.e() > -1) {
														Int2 eDecla = TextSearch.getDefaultSearch().indexOf(javaText, ")", bDecla.e()); //$NON-NLS-1$
														if (eDecla.b() > -1) {
															int countParameters = 0;
															if (javaText.substring(bDecla.e(), eDecla.b()).trim().length() > 0) {
																countParameters = TextSearch.getDefaultSearch().countIn(javaText, ",", bDecla.e(), eDecla.b()) + 1; //$NON-NLS-1$
															}
															if ((countArguments + 1) == countParameters) {
																((AbstractTextEditor) part).selectAndReveal(bDecla.b(), eDecla.e() - bDecla.b());
																break;
															}
														}
														bDecla = TextSearch.getRegexSearch().indexOf(javaText, regexDecla, bDecla.e());
													}
												}
											}
										} catch (PartInitException e) {
											AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart part) {
	}

	/**
	 * Get the declaration file of the selected identifier in a template editor.
	 * This method should only work if the editor and the selection are
	 * available
	 * 
	 * @param editor
	 *            is the current opened editor containing the selection
	 * @return the file where the identifier is declared
	 */
	public static IFile getDeclarationFile(AcceleoTemplateEditor editor) {
		IFile file = null;

		if (editor != null && editor.getSelectionProvider() != null) {
			ITextSelection selection = (ITextSelection) editor.getSelectionProvider().getSelection();
			if (selection != null) {
				int offset = selection.getOffset() + selection.getLength();
				IFile currentFile = editor.getFile();
				IDocument document = editor.getDocumentProvider().getDocument(editor.getEditorInput());
				if (currentFile != null && document != null) {
					String text = document.get();
					TemplateConstants.initConstants(text);
					while (offset < text.length() && Character.isJavaIdentifierPart(text.charAt(offset))) {
						offset++;
					}

					if (editor.sourceViewer() != null) {
						AcceleoTemplateCompletionProcessor p = new AcceleoTemplateCompletionProcessor(editor);
						AcceleoTemplateCompletionEntry[] entries = p.computeCompletionEntries(editor.sourceViewer(), offset);
						if (entries.length > 0) {
							AcceleoTemplateCompletionEntry entry = entries[0];
							if (entry.getObject() instanceof Map.Entry) {
								Template template = (Template) ((Map.Entry) entry.getObject()).getValue();
								if (template != null) {
									File script = template.getScript().getFile();
									if (script != null) {
										file = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(script.getAbsolutePath()));
										if (file == null || !file.isAccessible()) {
											if (currentFile.getProject().getFolder(new Path(PhantomResources.getRootName())).exists()) {
												StringBuffer content = Resources.getFileContent(script);
												try {
													file = Resources.createFile(currentFile.getProject(), new Path(VIRTUAL_TEMPLATE_EDITOR_FOLDER).append(script.getName()), content.toString(),
															new NullProgressMonitor());
													file.setReadOnly(true);
												} catch (CoreException e) {
													AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
												}
											}
										}
									}
								}
							} else if (entry.getObject() instanceof Method) {
								Method method = (Method) entry.getObject();
								IPath path = new Path(currentFile.getProject().getName());
								String src = currentFile.getProjectRelativePath().segment(0);
								if (src != null) {
									path = path.append(src);
								}
								String className = method.getDeclaringClass().getName();
								StringTokenizer st = new StringTokenizer(className, "."); //$NON-NLS-1$
								while (st.hasMoreTokens()) {
									path = path.append(st.nextToken());
								}
								path = path.addFileExtension("java"); //$NON-NLS-1$
								file = Resources.findFile(path);
							}
						}
					}
				}
			}

		}
		return file;
	}
}
