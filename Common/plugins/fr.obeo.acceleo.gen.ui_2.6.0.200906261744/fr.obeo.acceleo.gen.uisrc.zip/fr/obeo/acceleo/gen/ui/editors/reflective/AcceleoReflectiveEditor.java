/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import java.util.ArrayList;
import java.util.EventObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.common.command.CommandStack;
import org.eclipse.emf.common.command.CommandStackListener;
import org.eclipse.emf.common.ui.ViewerPane;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.presentation.EcoreEditor;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.celleditor.AdapterFactoryTreeEditor;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

import fr.obeo.acceleo.ecore.tools.ELoaderUtils;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.preview.RequestLoaderManager;
import fr.obeo.acceleo.gen.ui.editors.source.AcceleoSourceEditor;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * This is the reflective model editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoReflectiveEditor extends EcoreEditor implements IResourceChangeListener {

	/**
	 * Message to increase the memory settings of eclipse.
	 */
	public static final String ACTIVE_PREVIEW_NOT_FOUND_MESSAGE = AcceleoGenUIMessages.getString("AcceleoReflectiveEditor.EditorNotFound"); //$NON-NLS-1$

	/**
	 * The current page index.
	 */
	protected int pageIndex = 0;

	/**
	 * The source editor on the second page.
	 */
	protected IPreviewPart[] previewEditors = null;

	/**
	 * Root object of the model.
	 */
	protected EObject root;

	/**
	 * Indicates if type is displayed.
	 */
	protected boolean showType = false;

	/**
	 * Constructor.
	 */
	public AcceleoReflectiveEditor() {
		super();
		ResourcesPlugin.getWorkspace().addResourceChangeListener(this);

		// Create an adapter factory that yields item providers.
		List factories = new ArrayList();
		factories.add(createReflectiveItemProviderAdapterFactory());
		// factories.add(new UML2ItemProviderAdapterFactory());
		factories.add(new ResourceItemProviderAdapterFactory());
		factories.add(new EcoreItemProviderAdapterFactory());
		factories.add(new ReflectiveItemProviderAdapterFactory());
		adapterFactory = new ComposedAdapterFactory(factories);

		// Create the command stack that will notify this editor as commands are
		// executed.
		BasicCommandStack commandStack = new BasicCommandStack();

		// Add a listener to set the most recent command's affected objects to
		// be the selection of the viewer with focus.
		commandStack.addCommandStackListener(new CommandStackListener() {
			public void commandStackChanged(final EventObject event) {
				getContainer().getDisplay().asyncExec(new Runnable() {
					public void run() {
						firePropertyChange(IEditorPart.PROP_DIRTY);

						// Try to select the affected objects.
						Command mostRecentCommand = ((CommandStack) event.getSource()).getMostRecentCommand();
						if (mostRecentCommand != null) {
							setSelectionToViewer(mostRecentCommand.getAffectedObjects());
						}
						if (propertySheetPage != null) {
							propertySheetPage.refresh();
						}
					}
				});
			}
		});

		// Create the editing domain with a special command stack.
		editingDomain = new AdapterFactoryEditingDomain(adapterFactory, commandStack, new HashMap());
	}

	/**
	 * Creates a specific item provider adapter factory for the reflective
	 * editor.
	 * 
	 * @return the factory
	 */
	protected AcceleoReflectiveItemProviderAdapterFactory createReflectiveItemProviderAdapterFactory() {
		return new AcceleoReflectiveItemProviderAdapterFactory(this);
	}

	/**
	 * @return the root object of the model.
	 */
	public EObject getRoot() {
		return root;
	}

	/**
	 * @return preview editors
	 */
	public IPreviewPart[] getPreviewEditors() {
		return previewEditors;
	}

	/**
	 * @return source editor
	 */
	public AcceleoSourceEditor getSourceEditor() {
		if (previewEditors != null && previewEditors.length > 0) {
			return (AcceleoSourceEditor) previewEditors[0];
		} else {
			return null;
		}
	}

	/**
	 * @return preview editors
	 */
	public IPreviewPart getActivePreviewEditor() {
		if (previewEditors != null && previewEditors.length > 0) {
			if (pageIndex > 0 && (pageIndex - 1) < previewEditors.length) {
				return previewEditors[pageIndex - 1];
			} else {
				return getSourceEditor();
			}
		} else {
			return null;
		}
	}

	/**
	 * The class for reflective content outline pages. It is based on
	 * EcoreEditor code.
	 */
	protected class AcceleoReflectiveContentOutlinePage extends ContentOutlinePage {

		/* (non-Javadoc) */
		public void createControl(Composite parent) {
			super.createControl(parent);
			contentOutlineViewer = getTreeViewer();
			contentOutlineViewer.addSelectionChangedListener(this);
			contentOutlineViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory));
			contentOutlineViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
			contentOutlineViewer.setInput(editingDomain.getResourceSet());
			createContextMenuFor(contentOutlineViewer);
			if (!editingDomain.getResourceSet().getResources().isEmpty() && ((Resource) editingDomain.getResourceSet().getResources().get(0)).getContents().size() > 0) {
				ArrayList selection = new ArrayList();
				selection.add(((Resource) editingDomain.getResourceSet().getResources().get(0)).getContents().get(0));
				contentOutlineViewer.setSelection(new StructuredSelection(selection), true);
			}
			contentOutlineViewer.addDoubleClickListener(new IDoubleClickListener() {
				public void doubleClick(DoubleClickEvent event) {
					ISelection selection = event.getSelection();
					if (selection instanceof StructuredSelection) {
						Object object = ((StructuredSelection) selection).getFirstElement();
						if (object instanceof EObject) {
							expandAllGenerated((EObject) object);
						}
					}
				}
			});
		}

		private void expandAllGenerated(EObject object) {
			if (getActivePreviewEditor() != null) {
				if (getActivePreviewEditor().getSettings().getScript().isGenerated(object)) {
					contentOutlineViewer.expandToLevel(object, 0);
				} else {
					Iterator it = object.eContents().iterator();
					while (it.hasNext()) {
						expandAllGenerated((EObject) it.next());
					}
				}
			} else {
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoReflectiveEditor.ACTIVE_PREVIEW_NOT_FOUND_MESSAGE, true);
			}
		}

		/* (non-Javadoc) */
		public void makeContributions(IMenuManager menuManager, IToolBarManager toolBarManager, IStatusLineManager statusLineManager) {
			super.makeContributions(menuManager, toolBarManager, statusLineManager);
			contentOutlineStatusLineManager = statusLineManager;
		}

		/* (non-Javadoc) */
		public void setActionBars(IActionBars actionBars) {
			super.setActionBars(actionBars);
			getActionBarContributor().shareGlobalActions(this, actionBars);
		}

		/**
		 * Refresh the outline.
		 */
		public void refresh() {
			if (getTreeViewer() != null) {
				getTreeViewer().refresh();
			}
		}

	}

	/* (non-Javadoc) */
	public Object getAdapter(Class adapter) {
		if (adapter.equals(IContentOutlinePage.class)) {
			return getContentOutlinePage();
		}
		return super.getAdapter(adapter);
	}

	/* (non-Javadoc) */
	public IContentOutlinePage getContentOutlinePage() {
		if (contentOutlinePage == null) {
			contentOutlinePage = new AcceleoReflectiveContentOutlinePage();
			contentOutlinePage.addSelectionChangedListener(new ISelectionChangedListener() {
				public void selectionChanged(SelectionChangedEvent event) {
					handleContentOutlineSelection(event.getSelection());
				}
			});
		}
		return contentOutlinePage;
	}

	/**
	 * Refresh the viewers.
	 */
	public void refresh() {
		if (getViewer() != null && !getViewer().getControl().isDisposed()) {
			if (getContentOutlinePage() != null && getContentOutlinePage() instanceof AcceleoReflectiveContentOutlinePage) {
				((AcceleoReflectiveContentOutlinePage) getContentOutlinePage()).refresh();
			}
		}
	}

	/**
	 * Get the input file for this editor.
	 * 
	 * @return the editor input file
	 */
	public IFile getFile() {
		return (IFile) getEditorInput().getAdapter(IFile.class);
	}

	/* (non-Javadoc) */
	public void setSelection(ISelection selection) {
		super.setSelection(selection);
		if (!selection.isEmpty() && contentOutlineViewer != null && (contentOutlineViewer.getSelection() == null || !contentOutlineViewer.getSelection().equals(selection))) {
			contentOutlineViewer.setSelection(selection, true);
		}
	}

	/* (non-Javadoc) */
	public void createPages() {
		ELoaderUtils.initModelFactories(getFile(), AcceleoReflectiveEditor.class.getClassLoader());
		super.createPages();
		Resource modelResource = editingDomain.loadResource(Resources.createPlatformResourceURI(getFile().getFullPath().toString()).toString());
		Object object = (modelResource.getContents().size() > 0) ? modelResource.getContents().get(0) : null;
		if (object != null && object instanceof EObject) {
			root = (EObject) object;
		} else {
			root = null;
		}
		createPreviewPages();
		createPageRequest();
	}

	/**
	 * Creates preview pages.
	 */
	protected void createPreviewPages() {
		if (getRoot() != null) {
			// Create the source editor on the second page
			previewEditors = createPreviewEditors();
			for (int i = 0; i < previewEditors.length; i++) {
				IPreviewPart previewEditor = previewEditors[i];
				if (previewEditor instanceof IEditorPart) {
					try {
						int index = addPage((IEditorPart) previewEditors[i], getEditorInput());
						setPageText(index, previewEditors[i].getName());
					} catch (PartInitException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					}
				} else {
					int index = addPage(((org.eclipse.jface.viewers.TreeViewer) previewEditors[i]).getControl().getParent());
					setPageText(index, previewEditors[i].getName());
				}
			}
		}
	}

	/**
	 * Creates preview editors.
	 * 
	 * @return preview editors
	 */
	protected IPreviewPart[] createPreviewEditors() {
		return new IPreviewPart[] { new AcceleoSourceEditor(this, getFile()) };
	}

	/**
	 * Creates request preview page.
	 */
	protected void createPageRequest() {
		if (getRoot() != null) {
			RequestLoaderManager requestManager = new RequestLoaderManager();
			ViewerPane viewerPane = requestManager.getRequestLoader().createRequestPane(this, getContainer());
			if (viewerPane != null) {
				TreeViewer requestViewer = (TreeViewer) viewerPane.getViewer();
				requestViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
				requestViewer.setInput(editingDomain.getResourceSet());
				viewerPane.setTitle(editingDomain.getResourceSet());
				new AdapterFactoryTreeEditor(requestViewer.getTree(), adapterFactory);
				createContextMenuFor(requestViewer);
				int pageIndex = addPage(viewerPane.getControl());
				setPageText(pageIndex, AcceleoGenUIMessages.getString("AcceleoReflectiveEditor.RequestTabLabel")); //$NON-NLS-1$
			}
		}
	}

	/* (non-Javadoc) */
	protected void pageChange(int pageIndex) {
		this.pageIndex = pageIndex;
		try {
			super.pageChange(pageIndex);
		} catch (Exception e) {
			// catch ClassCastException : Eclipse 3.1
		}
	}

	/* (non-Javadoc) */
	public void resourceChanged(final IResourceChangeEvent event) {
		if (event.getType() == IResourceChangeEvent.PRE_CLOSE) {
			Display.getDefault().asyncExec(new Runnable() {
				public void run() {
					IWorkbenchPage[] pages = getSite().getWorkbenchWindow().getPages();
					for (int i = 0; i < pages.length; i++) {
						if (getFile().getProject().equals(event.getResource())) {
							IEditorPart editorPart = pages[i].findEditor(getEditorInput());
							pages[i].closeEditor(editorPart, true);
						}
					}
				}
			});
		}
	}

	/* (non-Javadoc) */
	public void doSave(IProgressMonitor progressMonitor) {
		super.doSave(progressMonitor);
	}

	/* (non-Javadoc) */
	public void doSaveAs() {
		super.doSaveAs();
	}

	/* (non-Javadoc) */
	public void dispose() {
		super.dispose();
		ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
	}

	/**
	 * Returns the object currently selected.
	 * 
	 * @return the object currently selected
	 */
	public EObject getSelectedEObject() {
		if (getContentOutlinePage().getSelection() instanceof StructuredSelection) {
			Object object = ((StructuredSelection) getContentOutlinePage().getSelection()).getFirstElement();
			if (object instanceof EObject) {
				return (EObject) object;
			}
		} else if (getSelection() instanceof StructuredSelection) {
			Object object = ((StructuredSelection) getSelection()).getFirstElement();
			if (object instanceof EObject) {
				return (EObject) object;
			}
		}
		return null;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.emf.ecore.presentation.EcoreEditor#handleChangedResources()
	 */
	protected void handleChangedResources() {
		Object[] expandedObjects = null;
		if (getViewer() instanceof TreeViewer)
			expandedObjects = ((TreeViewer) getViewer()).getExpandedElements();
		super.handleChangedResources();
		if (expandedObjects != null) {
			// we've saved the previous state of collapsed/expanded
			// elements. Restore it now.
			for (int i = 0; i < expandedObjects.length; i++) {
				if (expandedObjects[i] instanceof EObject) {
					final URI objectURI = EcoreUtil.getURI(((EObject) expandedObjects[i]));
					if (objectURI != null) {
						final Resource resource = getChangedResource(objectURI.trimFragment());
						if (resource != null) {
							final EObject newObject = resource.getEObject(objectURI.fragment());
							if (newObject != null)
								expandedObjects[i] = newObject;
						}
					}
				}
			}
			((TreeViewer) getViewer()).refresh();
			((TreeViewer) getViewer()).setExpandedElements(expandedObjects);
		}
	}

	private Resource getChangedResource(URI resourceURI) {
		final Iterator resourcesIterator = changedResources.iterator();
		while (resourcesIterator.hasNext()) {
			final Resource next = (Resource) resourcesIterator.next();
			if (next.getURI().equals(resourceURI))
				return next;
		}
		return null;
	}
}
