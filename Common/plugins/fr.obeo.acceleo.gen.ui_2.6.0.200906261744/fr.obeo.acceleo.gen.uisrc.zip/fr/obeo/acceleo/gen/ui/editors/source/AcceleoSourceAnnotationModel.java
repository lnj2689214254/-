/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.ui.texteditor.MarkerAnnotation;
import org.eclipse.ui.texteditor.ResourceMarkerAnnotationModel;

import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.template.eval.ENode;
import fr.obeo.acceleo.gen.template.eval.log.EvalFailure;
import fr.obeo.acceleo.tools.strings.Int2;

/**
 * A marker annotation model for a source editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceAnnotationModel extends ResourceMarkerAnnotationModel {

	/**
	 * The source editor.
	 */
	protected AcceleoSourceEditor editor;

	/**
	 * The current resource.
	 */
	protected IResource resource;

	/**
	 * All annotations.
	 */
	protected List annotations = new ArrayList();

	/**
	 * Indicate if the source logs must be annotated.
	 */
	protected boolean acceptSourceLog = true;

	/**
	 * Marker ID.
	 */
	public final static String MARKER_PROBLEM = "org.eclipse.core.resources.problemmarker"; //$NON-NLS-1$

	/**
	 * Creates a marker annotation model with the given resource as the source
	 * of the markers.
	 * 
	 * @param editor
	 * @param resource
	 */
	public AcceleoSourceAnnotationModel(AcceleoSourceEditor editor, IResource resource) {
		super(resource);
		this.editor = editor;
		this.resource = resource;
	}

	/**
	 * Indicate if the source logs must be annotated.
	 * 
	 * @param acceptSourceLog
	 */
	public void setAcceptSourceLog(boolean acceptSourceLog) {
		this.acceptSourceLog = acceptSourceLog;
	}

	/**
	 * Update the annotations list with an evaluation node.
	 * 
	 * @param eval
	 *            is the current node of generation for the source editor
	 */
	public void acceptProblems(ENode eval) {
		List problems = new ArrayList();
		try {
			if (eval != null) {
				EObject object = eval.getContainerEObject();
				if (object != null && EFactory.eInstanceOf(object, "resources.File")) { //$NON-NLS-1$
					// Marker for model logs
					EObject fileLog = EFactory.eGetAsEObject(object, "log"); //$NON-NLS-1$
					List logs = (fileLog != null) ? EFactory.eGetAsList(fileLog, "logs") : null; //$NON-NLS-1$
					if (logs != null) {
						Iterator it = logs.iterator();
						while (it.hasNext()) {
							EObject log = (EObject) it.next();
							if (acceptSourceLog && EFactory.eInstanceOf(log, "resources.SourceLog")) { //$NON-NLS-1$
								try {
									int begin = Integer.parseInt(EFactory.eGetAsString(log, "position")); //$NON-NLS-1$
									int end = begin + Integer.parseInt(EFactory.eGetAsString(log, "size")); //$NON-NLS-1$
									if (begin > -1 && end > -1)
										problems.add(new AcceleoSourceProblem(EFactory.eGetAsString(log, "message"), EFactory.eGetAsString(log, "token"), begin, end)); //$NON-NLS-1$ //$NON-NLS-2$
								} catch (NumberFormatException e) {
								}
							} else if (EFactory.eInstanceOf(log, "resources.ModelLog")) { //$NON-NLS-1$
								EObject objectWithError = EFactory.eGetAsEObject(log, "object"); //$NON-NLS-1$
								if (eval.getTextModelMapping() != null) {
									Int2[] positions = eval.getTextModelMapping().eObject2Positions(objectWithError);
									for (int i = 0; i < positions.length; i++) {
										Int2 pos = positions[i];
										if (pos.b() > -1) {
											Int2 posComment = eval.getTextModelMapping().eObject2CommentPositionIn(objectWithError, pos);
											if (posComment.e() > -1) {
												problems
														.add(new AcceleoSourceProblem(EFactory.eGetAsString(log, "message"), EFactory.eGetAsString(log, "message"), posComment.e(), posComment.e() + 1)); //$NON-NLS-1$ //$NON-NLS-2$
											} else {
												problems.add(new AcceleoSourceProblem(EFactory.eGetAsString(log, "message"), EFactory.eGetAsString(log, "message"), pos.b(), pos.b() + 1)); //$NON-NLS-1$ //$NON-NLS-2$
											}
										}
									}
								}
							}
						}
					}
				}
				// Marker for current node of generation
				Iterator it = eval.log().allOrderedErrorsAndSevereWarnings();
				while (it.hasNext()) {
					EvalFailure failure = (EvalFailure) it.next();
					int pos = failure.position();
					problems.add(new AcceleoSourceProblem(failure.getMessage(), "", pos, pos + 1)); //$NON-NLS-1$
				}
			}
		} catch (FactoryException e) {
		}
		createAnnotations(problems);
	}

	/**
	 * Update the annotations with a list of problems
	 * 
	 * @param problems
	 *            is the list of problems
	 */
	protected void createAnnotations(List problems) {
		boolean changed = false;
		if (annotations.size() > 0) {
			removeAnnotations(annotations, true, true);
			changed = true;
			annotations.clear();
		}
		if (problems.size() > 0) {
			Iterator it = problems.iterator();
			while (it.hasNext()) {
				AcceleoSourceProblem problem = (AcceleoSourceProblem) it.next();
				int length = problem.getEnd() - problem.getStart() + 1;
				Position position = new Position(problem.getStart(), length);
				Annotation annotation = new AcceleoSourceErrorAnnotation(problem);
				annotations.add(annotation);
				addAnnotation(annotation, position);
			}
			changed = true;
		}
		if (changed)
			fireModelChanged();
	}

	/* (non-Javadoc) */
	protected MarkerAnnotation createMarkerAnnotation(IMarker marker) {
		return super.createMarkerAnnotation(marker);
	}

}
