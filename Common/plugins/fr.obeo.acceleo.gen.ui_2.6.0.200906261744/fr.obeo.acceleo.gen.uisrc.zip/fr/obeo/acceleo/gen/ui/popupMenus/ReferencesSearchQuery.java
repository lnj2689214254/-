/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.AcceleoToolsPlugin;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.ISearchResult;
import org.eclipse.search.ui.text.Match;

/**
 * This class is the query looking for References in Acceleo templates
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferencesSearchQuery implements ISearchQuery {
	/**
	 * The result where to store matches
	 */
	private ReferencesSearchResult searchResult;

	/**
	 * the project where the query is running
	 */
	private IProject project;

	/**
	 * the identifier to look for
	 */
	private String identifier;

	/**
	 * the base name of the template containing the identifier
	 */
	private String templateImportString;

	/**
	 * Constructor
	 * 
	 * @param project
	 *            the project where the query is running
	 * @param identifier
	 *            the identifier to look for
	 * @param templateImportString
	 *            the base name of the template containing the identifier
	 */
	public ReferencesSearchQuery(IProject project, String identifier, String templateImportString) {
		this.project = project;
		this.identifier = identifier;
		this.templateImportString = templateImportString;
	}

	/* (non-Javadoc) */
	public boolean canRerun() {
		return true;
	}

	/* (non-Javadoc) */
	public boolean canRunInBackground() {
		return true;
	}

	/* (non-Javadoc) */
	public String getLabel() {
		return AcceleoGenUIMessages.getString("AcceleoGenReferencesSearch.Query.Label"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public ISearchResult getSearchResult() {
		if (searchResult == null) {
			searchResult = new ReferencesSearchResult(this);
		}
		return searchResult;
	}

	/* (non-Javadoc) */
	public IStatus run(IProgressMonitor monitor) throws OperationCanceledException {
		int idLength = identifier.length();

		List fileSet = new ArrayList();
		try {
			fileSet.addAll(listFiles(project, Resources.getOutputFolder(project)));
			IProject[] refs = project.getReferencingProjects();
			for (int i = 0; i < refs.length; i++) {
				fileSet.addAll(listFiles(refs[i], Resources.getOutputFolder(refs[i])));
			}
		} catch (CoreException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
		IFile mtFiles[] = (IFile[]) fileSet.toArray(new IFile[fileSet.size()]);

		for (int j = 0; j < mtFiles.length && identifier.length() > 0; j++) {
			if (isValidFile(mtFiles[j], templateImportString)) {
				String buffer = Resources.getFileContent(mtFiles[j]).toString();

				Int2[] positions = TextSearch.getDefaultSearch().allIndexOf(buffer, identifier, null, TemplateConstants.INHIBS_COMMENT);
				for (int k = 0; k < positions.length; k++) {
					if (positions[k] != Int2.NOT_FOUND) {
						// checking that the identifier found is not a sub part
						// of an other identifier
						if ((positions[k].b() - 1 < 0 || !Character.isJavaIdentifierPart(buffer.charAt(positions[k].b() - 1)))
								&& (positions[k].e() >= buffer.length() || !Character.isJavaIdentifierPart(buffer.charAt(positions[k].e()))) && isValidMatch(mtFiles[j], buffer, positions[k].b())) {
							String message = getScriptDeclaration(buffer, positions[k].b());
							if (message == null) {
								message = identifier;
							}
							searchResult.addMatch(new Match(new ReferenceEntry(mtFiles[j], positions[k], message), positions[k].b(), idLength));
						}
					}
				}
			}
		}
		return Status.OK_STATUS;
	}

	/**
	 * Give the declaration of the script where offset is.
	 * 
	 * @param buffer
	 *            the template to scan
	 * @param offset
	 *            the offset to use
	 * @return the string declaring the script
	 */
	private String getScriptDeclaration(String buffer, int offset) {
		Int2 scriptBegin = TextSearch.getDefaultSearch().lastIndexIn(buffer, TemplateConstants.SCRIPT_BEGIN, 0, offset, null, TemplateConstants.INHIBS_COMMENT);
		Int2 scriptEnd = TextSearch.getDefaultSearch().blockIndexEndIn(buffer, TemplateConstants.FEATURE_BEGIN, TemplateConstants.FEATURE_END, scriptBegin.b(), offset, true, null,
				TemplateConstants.INHIBS_COMMENT);
		if (scriptBegin != Int2.NOT_FOUND && scriptEnd != Int2.NOT_FOUND) {
			return buffer.substring(scriptBegin.b(), scriptEnd.e());
		} else {
			return null;
		}
	}

	private boolean isValidFile(IFile file, String templateImportString) {
		String text = Resources.getFileContent(file).toString();
		TemplateConstants.initConstants(text);
		boolean imported = templateImportString.equals(fileToImportString(file));

		if (!imported) {
			Int2 posBeginImports = TextSearch.getDefaultSearch().indexOf(text, TemplateConstants.IMPORT_BEGIN, 0, null, TemplateConstants.INHIBS_COMMENT);
			// while we get a comment begin
			while (posBeginImports.b() + TemplateConstants.COMMENT_BEGIN.length() < text.length()
					&& text.substring(posBeginImports.b(), posBeginImports.b() + TemplateConstants.COMMENT_BEGIN.length()).equals(TemplateConstants.COMMENT_BEGIN)) {
				// find the corresponding comment end
				posBeginImports = TextSearch.getDefaultSearch().indexOf(text, TemplateConstants.COMMENT_END, posBeginImports.b());
				// try to find import begin
				posBeginImports = TextSearch.getDefaultSearch().indexOf(text, TemplateConstants.IMPORT_BEGIN, posBeginImports.b(), null, TemplateConstants.INHIBS_COMMENT);
			}

			Int2 posEndImports = TextSearch.getDefaultSearch().blockIndexEndOf(text, TemplateConstants.IMPORT_BEGIN, TemplateConstants.IMPORT_END, posBeginImports.b(), true,
					TemplateConstants.COMMENT_END, TemplateConstants.INHIBS_COMMENT);

			Int2[] imports = TextSearch.getDefaultSearch().allIndexIn(text, TemplateConstants.IMPORT_WORD, posBeginImports.b(), posEndImports.e(), null, TemplateConstants.INHIBS_COMMENT);

			for (int i = 0; i < imports.length && !imported; i++) {
				int endLineOffset = TextSearch.getRegexSearch().indexOf(text, "[\\r\\n]+", imports[i].e()).b(); //$NON-NLS-1$
				imported = text.substring(imports[i].e(), endLineOffset).trim().equals(templateImportString);
			}
		}
		return imported;
	}

	/**
	 * Tell if the match should be kept in the result (the match is in a feature
	 * region).
	 * 
	 * @param file
	 *            the template
	 * @param text
	 *            the text of the template
	 * @param idOffset
	 *            offset of the matching identifier
	 * @return true if we keep the match
	 */
	protected boolean isValidMatch(IFile file, String text, int idOffset) {
		Int2 posFeatBegin = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.FEATURE_BEGIN, 0, idOffset, null, TemplateConstants.INHIBS_COMMENT);
		Int2 posFeatEnd = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.FEATURE_END, posFeatBegin.b(), idOffset, null, TemplateConstants.INHIBS_COMMENT);
		if (posFeatEnd != Int2.NOT_FOUND) { // the last feature block is closed
			// before our identifier
			return false;
		}

		// identifier must not be a literal
		boolean literal = TextSearch.getDefaultSearch().countIn(text, TemplateConstants.LITERAL[0], posFeatBegin.b(), idOffset, TemplateConstants.LITERAL_SPEC, TemplateConstants.INHIBS_COMMENT) % 2 != 0;

		if (literal) {
			return false; // literals are not identifiers outside of script
			// region and in script region it's a declaration not a reference
		}
		return true;
	}

	/**
	 * List all templates of the container recursively. It ignore default output
	 * folder
	 * 
	 * @param root
	 *            the root container
	 * @param output
	 *            the output folder of the project
	 * @return a list of IFile
	 * @throws CoreException
	 */
	protected List listFiles(IContainer root, IFolder output) throws CoreException {
		List result = new ArrayList();
		IResource[] members = root.members();
		for (int j = 0; j < members.length; j++) {
			if (members[j] instanceof IContainer && !members[j].equals(output)) {
				result.addAll(listFiles((IContainer) members[j], output));
			} else if (members[j] instanceof IFile && ((IFile) members[j]).getName().endsWith("." + SpecificScript.GENERATORS_EXTENSION)) { //$NON-NLS-1$
				result.add(members[j]);
			}
		}
		return result;
	}

	/**
	 * Gets the class name corresponding to the file. example :
	 * MyProject/src/fr/obeo/acceleo/gen.mt -> fr.obeo.acceleo.gen
	 * 
	 * @param file
	 *            is the template or the java service file (relative to the
	 *            workspace)
	 * @return the class name
	 */
	public static String fileToImportString(IFile file) {
		if (file == null) {
			return null;
		}
		IJavaProject javaProject = JavaCore.create(file.getProject());
		try {
			IClasspathEntry[] entries = javaProject.getResolvedClasspath(true);
			for (int i = 0; i < entries.length; i++) {
				IClasspathEntry entry = entries[i];
				if (entry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
					IFolder sourceFolder = ResourcesPlugin.getWorkspace().getRoot().getFolder(entry.getPath());
					if (sourceFolder.exists()) {
						return file.getFullPath().removeFileExtension().removeFirstSegments(sourceFolder.getFullPath().segmentCount()).toString().replaceAll("/", "."); //$NON-NLS-1$ //$NON-NLS-2$
					}
				}
			}
		} catch (JavaModelException e) {
			AcceleoToolsPlugin.getDefault().log(e, false);
		}
		return null;
	}

}
