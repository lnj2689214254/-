/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.scripts.EmptyScript;
import fr.obeo.acceleo.gen.template.scripts.IScript;

/**
 * Reflective editor settings that know current generator and other available
 * generators.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoReflectiveSettings {

	/**
	 * Current generator.
	 */
	protected IScript script;

	/**
	 * Default generator.
	 */
	protected IScript defaultScript;

	/**
	 * Constructor.
	 */
	public AcceleoReflectiveSettings() {
		init(null);
	}

	/**
	 * Initialize settings with a default generator.
	 * 
	 * @param defaultScript
	 */
	public void init(IScript defaultScript) {
		if (defaultScript != null) {
			this.defaultScript = defaultScript;
		} else {
			this.defaultScript = new EmptyScript();
		}
		this.script = this.defaultScript;
	}

	/**
	 * @return current generator
	 */
	public IScript getScript() {
		return script;
	}

	/**
	 * Set current generator. The default generator becomes the current
	 * generator if the generator given is null.
	 * 
	 * @param script
	 *            is the new current generator
	 */
	public void setScript(IScript script) {
		if (script != null) {
			this.script = script;
			if (this.script != defaultScript) {
				this.script.addImport(defaultScript);
				defaultScript.setSpecific(this.script);
			}
		} else {
			this.script = defaultScript;
			defaultScript.setSpecific(null);
		}
	}

	/**
	 * Reset the current generator.
	 * 
	 * @throws TemplateSyntaxExceptions
	 */
	public void resetScript() throws TemplateSyntaxExceptions {
		this.script.reset();
		if (this.script != defaultScript) {
			this.script.addImport(defaultScript);
			defaultScript.setSpecific(this.script);
		}
	}

	/**
	 * The default generator becomes the current generator
	 */
	public void reloadDefaultScript() {
		this.script = defaultScript;
		defaultScript.setSpecific(null);
	}

}
