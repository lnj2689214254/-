/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.builders;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.template.TemplateSyntaxException;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * The operation that compiles the scripts in a background task. Compilation
 * errors are put in the problems view when it is necessary.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenCompileOperation implements IWorkspaceRunnable {

	/**
	 * The delta to compile.
	 */
	protected List delta = new ArrayList();

	/**
	 * The full names of the imports to search.
	 */
	protected String[] deltaImports;

	/**
	 * Indicates that this class is used to delete markers.
	 */
	public static final int CLEAN = 1;

	/**
	 * Indicates that this class is used to compile scripts and create markers.
	 */
	public static final int INCREMENTAL_BUILD = 2;

	/**
	 * Indicates that this class is used to compile all scripts and create
	 * markers.
	 */
	public static final int FULL_BUILD = 3;

	/**
	 * It is the kind of operation : CLEAN or INCREMENTAL_BUILD or FULL_BUILD
	 */
	protected int kind;

	/**
	 * The detected scripts.
	 */
	protected List files = new ArrayList();

	/**
	 * Constructor.
	 * 
	 * @param delta
	 *            is the delta to compile
	 * @param containers
	 *            are the root containers to build
	 * @param kind
	 *            is the kind of operation : DELETE_MARKERS or COMPILE
	 * @throws CoreException
	 */
	public AcceleoGenCompileOperation(IFile[] delta, List containers, int kind) throws CoreException {
		this.deltaImports = new String[delta.length];
		for (int i = 0; i < delta.length; i++) {
			this.delta.add(delta[i]);
			IResource current = delta[i];
			StringBuffer buffer = new StringBuffer();
			while (current != null && !containers.contains(current)) {
				if (buffer.length() > 0) {
					buffer.insert(0, "."); //$NON-NLS-1$
				}
				buffer.insert(0, current.getFullPath().removeFileExtension().lastSegment());
				current = current.getParent();
			}
			deltaImports[i] = buffer.toString().toLowerCase();
		}
		this.kind = kind;
		Iterator it = containers.iterator();
		while (it.hasNext()) {
			Object container = it.next();
			if (container instanceof IContainer && ((IContainer) container).exists()) {
				files((IContainer) container);
			}
		}
	}

	/**
	 * Considers all the files of a container and all it's members.
	 * 
	 * @param container
	 *            is the container
	 * @throws CoreException
	 */
	protected void files(IContainer container) throws CoreException {
		IResource[] children = container.members();
		if (children != null) {
			for (int i = 0; i < children.length; ++i) {
				IResource resource = children[i];
				if (resource instanceof IFile) {
					files((IFile) resource);
				} else if (resource instanceof IContainer) {
					files((IContainer) resource);
				}
			}
		}
	}

	private void files(IFile file) {
		if (file.getFileExtension() != null && file.getFileExtension().equals(getFileExtension())) {
			if (delta.size() == 0 || delta.contains(file)) {
				if (file.equals(AcceleoTemplateEditor.getFirstGeneratorToBuild())) {
					files.add(0, file);
					file2Script.remove(file.getFullPath().toString());
				} else {
					files.add(file);
				}
			} else {
				for (int i = 0; i < deltaImports.length; i++) {
					if (Resources.getFileContent(file).toString().toLowerCase().indexOf(deltaImports[i]) > -1) {
						files.add(file);
					}
				}
			}
		}
	}

	/**
	 * Gets the extension of the file to compile.
	 * 
	 * @return the extension of the file to compile
	 */
	protected String getFileExtension() {
		return SpecificScript.GENERATORS_EXTENSION;
	}

	/**
	 * Indicates if there are files to compile.
	 * 
	 * @return true if there are files to compile
	 */
	public boolean shouldCompile() {
		return files.size() > 0;
	}

	/* (non-Javadoc) */
	public void run(IProgressMonitor progressMonitor) throws CoreException {
		progressMonitor.beginTask("", files.size()); //$NON-NLS-1$
		progressMonitor.subTask(AcceleoGenUIMessages.getString("AcceleoGenCompileOperation.Monitor.TaskCompile")); //$NON-NLS-1$
		Iterator it = files.iterator();
		while (it.hasNext()) {
			IFile file = (IFile) it.next();
			progressMonitor.subTask(AcceleoGenUIMessages.getString("AcceleoGenCompileOperation.Monitor.SubTaskCompile", new Object[] { file.getName(), })); //$NON-NLS-1$
			if (kind == CLEAN) {
				doDeleteMarkers(file);
				file2Script.remove(file.getFullPath().toString());
			} else if (kind == INCREMENTAL_BUILD) {
				doDeleteMarkers(file);
				doCompileResource(file);
			} else if (kind == FULL_BUILD) {
				doDeleteMarkers(file);
				doCompileResource(file);
			}
		}
		progressMonitor.done();
	}

	private void doDeleteMarkers(IFile file) throws CoreException {
		file.deleteMarkers(IMarker.PROBLEM, true, IResource.DEPTH_INFINITE);
		file.deleteMarkers(ENodeException.RUNTIME_ERROR_MARKER_ID, true, IResource.DEPTH_INFINITE);
	}

	/**
	 * Creates the script for the given file.
	 * 
	 * @param file
	 *            is the file
	 * @return the new script
	 */
	protected SpecificScript createScript(File file) {
		SpecificScript result = AcceleoEcoreGenPlugin.getDefault().getGlobalScriptContext().getScript(file, null);
		if (result == null) {
			result = new SpecificScript(file, null, AcceleoEcoreGenPlugin.getDefault().getGlobalScriptContext());
		}
		return result;
	}

	private void doCompileResource(IFile file) throws CoreException {
		List problems;
		try {
			SpecificScript genScript = (SpecificScript) file2Script.get(file.getFullPath().toString());
			if (genScript == null) {
				genScript = createScript(file.getLocation().toFile());
				file2Script.put(file.getFullPath().toString(), genScript);
			}
			genScript.reset();
			problems = new ArrayList();
		} catch (TemplateSyntaxExceptions e) {
			problems = e.getProblems();
		}
		Iterator it = problems.iterator();
		while (it.hasNext()) {
			TemplateSyntaxException e = (TemplateSyntaxException) it.next();
			int line = TextSearch.getDefaultSearch().lineNumber(file.getLocation().toFile(), e.getPos().b());
			reportError(file, line, e.getPos(), e.getMessage());
		}
	}

	/**
	 * Gets the file to script mappings for incremental build.
	 * 
	 * @return the file to script mappings
	 */
	public static Map getFile2ScriptMap() {
		return file2Script;
	}

	private static Map file2Script = new WeakHashMap();

	private void reportError(IResource resource, int line, Int2 pos, String message) throws CoreException {
		IMarker m = resource.createMarker(IMarker.PROBLEM);
		m.setAttribute(IMarker.LINE_NUMBER, line);
		m.setAttribute(IMarker.CHAR_START, pos.b());
		m.setAttribute(IMarker.CHAR_END, pos.e());
		m.setAttribute(IMarker.MESSAGE, message);
		m.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_HIGH);
		m.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
	}

}
