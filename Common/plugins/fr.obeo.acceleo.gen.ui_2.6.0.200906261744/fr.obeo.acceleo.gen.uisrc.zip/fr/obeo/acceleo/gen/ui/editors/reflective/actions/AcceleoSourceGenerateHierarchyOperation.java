/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;

/**
 * The operation which generates the files for the current selected object.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceGenerateHierarchyOperation extends WorkspaceModifyOperation {

	/**
	 * The reflective editor
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * The target container.
	 */
	protected IContainer target;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 * @param target
	 *            is target container
	 */
	public AcceleoSourceGenerateHierarchyOperation(AcceleoReflectiveEditor reflectiveEditor, IContainer target) {
		super();
		this.reflectiveEditor = reflectiveEditor;
		this.target = target;
	}

	/* (non-Javadoc) */
	protected void execute(IProgressMonitor progressMonitor) {
		IWorkspaceRunnable runnable = new IWorkspaceRunnable() {
			public void run(IProgressMonitor progressMonitor) throws CoreException {
				try {
					if (target != null) {
						if (reflectiveEditor.getActivePreviewEditor() != null) {
							EObject object = reflectiveEditor.getActivePreviewEditor().getSelectedEObject();
							if (object != null) {
								reflectiveEditor.getActivePreviewEditor().generate(target, progressMonitor);
							}
						} else {
							AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoReflectiveEditor.ACTIVE_PREVIEW_NOT_FOUND_MESSAGE, true);
						}
					}
				} catch (Exception e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}
		};
		try {
			ResourcesPlugin.getWorkspace().run(runnable, progressMonitor);
		} catch (CoreException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}

	}

}
