package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductAboutPropertiesWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductAboutPropertiesWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductAboutPropertiesWriter result = new CreateModuleProductAboutPropertiesWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "abouttext=Acceleo Module Product\\n\\" + NL + "\\n\\" + NL + "Version {featureVersion}\\n\\" + NL + "\\n\\" + NL + "(c) Copyright (c) 2005-2009 Obeo. All Rights Reserved.\\n\\" + NL + "Acceleo is a code generator, made for customers who want to get the most of MDA technologies in order to increase their productivity.\\n\\" + NL + "Visit http://www.acceleo.org";
  protected final String TEXT_2 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    return stringBuffer.toString();
  }
}
