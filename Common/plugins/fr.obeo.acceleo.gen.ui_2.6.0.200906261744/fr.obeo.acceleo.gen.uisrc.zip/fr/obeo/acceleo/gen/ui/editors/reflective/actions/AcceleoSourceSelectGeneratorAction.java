/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import java.io.File;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.ui.resources.FileSelectionDialog;

/**
 * Select a file which describes a new generator.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceSelectGeneratorAction extends Action {

	/**
	 * The reflective editor.
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * The extensions of the templates.
	 */
	protected String[] extensions;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 * @param extensions
	 *            are the extensions of the templates
	 */
	public AcceleoSourceSelectGeneratorAction(AcceleoReflectiveEditor reflectiveEditor, String[] extensions) {
		super(AcceleoGenUIMessages.getString("Editors.SelectGeneratorAction.label")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("Editors.SelectGeneratorAction.label")); //$NON-NLS-1$
		setToolTipText(AcceleoGenUIMessages.getString("Editors.SelectGeneratorAction.label")); //$NON-NLS-1$
		this.reflectiveEditor = reflectiveEditor;
		this.extensions = extensions;
	}

	/* (non-Javadoc) */
	public void run() {
		try {
			if (reflectiveEditor.getActivePreviewEditor() != null) {
				FileSelectionDialog dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), AcceleoGenUIMessages
						.getString("AcceleoSourceSelectGeneratorAction.TemplateSelectionTitle"), 1, extensions, true); //$NON-NLS-1$
				if (reflectiveEditor.getActivePreviewEditor().getSettings().getScript() != null && reflectiveEditor.getActivePreviewEditor().getSettings().getScript().getFile() != null) {
					IFile file = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(reflectiveEditor.getActivePreviewEditor().getSettings().getScript().getFile().getAbsolutePath()));
					if (file != null && file.isAccessible()) {
						dialog.setInitialSelections(new Object[] { file.getFullPath() });
					} else {
						File scriptFile = reflectiveEditor.getActivePreviewEditor().getSettings().getScript().getFile();
						if (scriptFile != null) {
							String relativePath = AcceleoModuleProvider.getDefault().getRelativePath(scriptFile);
							if (relativePath != null) {
								String pluginId = AcceleoModuleProvider.getDefault().getPluginId(scriptFile);
								if (pluginId != null) {
									dialog.setInitialSelections(new Object[] { new Path(pluginId).append(relativePath) });
								}
							}
						}
					}
				}
				dialog.open();
				Object[] result = dialog.getResult();
				if (result != null && result.length > 0 && result[0] instanceof IPath) {
					File file = AcceleoModuleProvider.getDefault().getFile((IPath) result[0]);
					if (file != null && file.exists()) {
						reflectiveEditor.getActivePreviewEditor().selectGenerator(file, null);
					}
				}
			} else {
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoReflectiveEditor.ACTIVE_PREVIEW_NOT_FOUND_MESSAGE, true);
			}
		} catch (Exception e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/template_editor.gif"); //$NON-NLS-1$
	}

}
