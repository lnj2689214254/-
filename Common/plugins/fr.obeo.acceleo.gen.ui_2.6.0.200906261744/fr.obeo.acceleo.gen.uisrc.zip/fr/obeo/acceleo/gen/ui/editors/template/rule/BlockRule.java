/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.rule;

import org.eclipse.jface.text.rules.ICharacterScanner;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.Token;

/**
 * Creates a rule for the given starting and ending sequence which, if detected,
 * will return the specified token. It can also return the specified token if
 * the rule breaks on the end of the line, or if the EOF character is read.
 * 
 * @author www.obeo.fr
 * 
 */
public class BlockRule implements IPredicateRule {

	/**
	 * The pattern's start sequence.
	 */
	protected String begin;

	/**
	 * The pattern's end sequence.
	 */
	protected String end;

	/**
	 * The recursive mode.
	 */
	protected boolean recursive;

	/**
	 * Indicates whether end of line terminates the pattern.
	 */
	protected boolean EOL;

	/**
	 * Indicates whether end of file terminates the pattern.
	 */
	protected boolean EOF;

	/**
	 * The pattern's escape character.
	 */
	protected String spec;

	/**
	 * Ignored sub-blocks.
	 */
	protected BlockRule[] ignoredBlocks;

	/**
	 * The token to be returned on success.
	 */
	protected IToken token;

	/**
	 * Constructor.
	 * 
	 * @param begin
	 *            is the pattern's start sequence
	 * @param end
	 *            is the pattern's end sequence
	 * @param spec
	 *            is the pattern's escape character
	 * @param token
	 *            is the token to be returned on success
	 */
	public BlockRule(String begin, String end, String spec, IToken token) {
		this(begin, end, false, false, false, spec, new BlockRule[] {}, token);
	}

	/**
	 * Constructor.
	 * 
	 * @param begin
	 *            is the pattern's start sequence
	 * @param end
	 *            is the pattern's end sequence
	 * @param ignoredBlocks
	 *            are the ignored sub-blocks
	 * @param token
	 *            is the token to be returned on success
	 */
	public BlockRule(String begin, String end, BlockRule[] ignoredBlocks, IToken token) {
		this(begin, end, true, false, false, "", ignoredBlocks, token); //$NON-NLS-1$
	}

	/**
	 * Constructor.
	 * 
	 * @param begin
	 *            is the pattern's start sequence
	 * @param end
	 *            is the pattern's end sequence
	 * @param recursive
	 *            is the recursive mode
	 * @param EOL
	 *            indicates whether end of line terminates the pattern
	 * @param EOF
	 *            indicates whether end of file terminates the pattern
	 * @param spec
	 *            is the pattern's escape character
	 * @param ignoredBlocks
	 *            are the ignored sub-blocks
	 * @param token
	 *            is the token to be returned on success
	 */
	public BlockRule(String begin, String end, boolean recursive, boolean EOL, boolean EOF, String spec, BlockRule[] ignoredBlocks, IToken token) {
		this.begin = begin;
		this.end = end;
		this.recursive = recursive;
		this.EOL = EOL;
		this.EOF = EOF;
		this.spec = spec;
		this.ignoredBlocks = ignoredBlocks;
		this.token = token;
	}

	/* (non-Javadoc) */
	public IToken getSuccessToken() {
		return token;
	}

	/* (non-Javadoc) */
	public IToken evaluate(ICharacterScanner scanner) {
		if (read(scanner) > 0) {
			return token;
		} else {
			return Token.UNDEFINED;
		}
	}

	/**
	 * Evaluates the rule by examining the characters available from the
	 * provided character scanner.
	 * 
	 * @param scanner
	 *            is the character scanner to be used by this rule
	 * @return the number of examined characters
	 */
	public int read(ICharacterScanner scanner) {
		if (read(begin, scanner) == 0)
			return 0;
		int shift = 0;
		int opened = 0;
		Boolean valid = null;
		while (valid == null) {
			int n = read(spec, scanner);
			if (n == 0) {
				n = read(end, scanner);
				if (n > 0) {
					if (recursive == false || opened == 0) {
						valid = Boolean.TRUE;
					} else {
						opened--;
					}
				} else {
					n = read(begin, scanner);
					if (n > 0) {
						opened++;
					} else {
						for (int i = 0; i < ignoredBlocks.length && n == 0; i++) {
							BlockRule ignoredBlock = ignoredBlocks[i];
							n = ignoredBlock.read(scanner);
						}
						if (n == 0) {
							int c = scanner.read();
							n = 1;
							if (c == '\n') {
								if (EOL) {
									valid = Boolean.TRUE;
								}
							} else if (c == ICharacterScanner.EOF) {
								if (EOF) {
									valid = Boolean.TRUE;
								} else {
									valid = Boolean.FALSE;
								}
							}
						}
					}
				}
			}
			shift += n;
		}
		if (valid == Boolean.FALSE) {
			while (shift > 0) {
				scanner.unread();
				shift--;
			}
		}
		return shift;
	}

	private int read(String string, ICharacterScanner scanner) {
		if (string.length() > 0) {
			for (int i = 0; i < string.length(); i++) {
				int c = scanner.read();
				if (c == ICharacterScanner.EOF || c != string.charAt(i)) {
					while (i >= 0) {
						scanner.unread();
						i--;
					}
					return 0;
				}
			}
			return string.length();
		} else {
			return 0;
		}
	}

	/* (non-Javadoc) */
	public IToken evaluate(ICharacterScanner scanner, boolean resume) {
		return evaluate(scanner);
	}

}