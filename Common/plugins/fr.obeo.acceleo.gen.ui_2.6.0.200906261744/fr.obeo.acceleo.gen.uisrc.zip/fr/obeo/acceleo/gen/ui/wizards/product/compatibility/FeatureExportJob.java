/*******************************************************************************
 * Copyright (c) 2000, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package fr.obeo.acceleo.gen.ui.wizards.product.compatibility;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.IWizardContainer;
import org.eclipse.osgi.util.NLS;
import org.eclipse.pde.internal.core.exports.FeatureExportInfo;
import org.eclipse.pde.internal.core.exports.FeatureExportOperation;
import org.eclipse.pde.internal.core.exports.ProductExportOperation;
import org.eclipse.pde.internal.core.iproduct.IProduct;
import org.eclipse.pde.internal.ui.PDEPlugin;
import org.eclipse.pde.internal.ui.PDEUIMessages;
import org.eclipse.swt.widgets.Display;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

public class FeatureExportJob extends Job {
	
	class SchedulingRule implements ISchedulingRule {
		public boolean contains(ISchedulingRule rule) {
			return rule instanceof SchedulingRule || rule instanceof IResource;
		}

		public boolean isConflicting(ISchedulingRule rule) {
			return rule instanceof SchedulingRule;
		}
	}

	protected FeatureExportInfo fInfo;
	protected IWizardContainer container;

	protected FeatureExportJob(FeatureExportInfo info, String name, IWizardContainer container) {
		super(name);
		fInfo = info;
		setRule(ResourcesPlugin.getWorkspace().getRoot());
		this.container = container;
	}

	protected IStatus run(IProgressMonitor monitor) {
		String errorMessage = null;
		FeatureExportOperation op = (FeatureExportOperation)createOperation();
		try {
			Method method = null;
			try {
				method = FeatureExportOperation.class.getMethod("run", new Class[] { IProgressMonitor.class }); //$NON-NLS-1$
				method.invoke(op, new Object[] { monitor });
			} catch (NoSuchMethodException e) {
				try {
					method = FeatureExportOperation.class.getMethod("schedule", null); //$NON-NLS-1$
					method.invoke(op, null);
				} catch (NoSuchMethodException e1) {
					MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
							AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
					return Job.ASYNC_FINISH;
				}
			}
			method = null;
			try {
				method = FeatureExportOperation.class.getMethod("hasErrors", null); //$NON-NLS-1$
			} catch (NoSuchMethodException e) {
				try {
					method = FeatureExportOperation.class.getMethod("hasAntErrors", null); //$NON-NLS-1$
				} catch (NoSuchMethodException e1) {
					MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
							AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
				}
			}
			
			if (errorMessage == null && method != null && ((Boolean)method.invoke(op, null)).booleanValue())
				errorMessage = getLogFoundMessage();
		} catch (SecurityException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
			return Job.ASYNC_FINISH;
		} catch (IllegalArgumentException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
			return Job.ASYNC_FINISH;
		} catch (IllegalAccessException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
			return Job.ASYNC_FINISH;
		} catch (InvocationTargetException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
			return Job.ASYNC_FINISH;
		}
		
		if (errorMessage != null) {
			final String em = errorMessage;
			getStandardDisplay().asyncExec(new Runnable() {
				public void run() {
					asyncNotifyExportException(em);
				}
			});
			return Job.ASYNC_FINISH;
		}
		return new Status(IStatus.OK, PDEPlugin.getPluginId(), IStatus.OK, "", null); //$NON-NLS-1$
	}
	
	protected FeatureExportOperation createOperation() {
		try {
			FeatureExportOperation instance;
			try {
				instance = (FeatureExportOperation)FeatureExportOperation.class.getConstructor(new Class[] { FeatureExportInfo.class }).newInstance(new Object[] { fInfo });
			} catch (NoSuchMethodException e) {
				instance = (FeatureExportOperation)FeatureExportOperation.class.getConstructor(new Class[] { FeatureExportInfo.class, String.class }).newInstance(new Object[] { fInfo, "Export Acceleo Product" });//$NON-NLS-1$
			}
			return instance;
		} catch (IllegalArgumentException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (SecurityException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (InstantiationException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (IllegalAccessException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (InvocationTargetException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (NoSuchMethodException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		}
		return null;
	}
	
	/**
	 * Returns the standard display to be used. The method first checks, if the
	 * thread calling this method has an associated disaply. If so, this display
	 * is returned. Otherwise the method returns the default display.
	 */
	public static Display getStandardDisplay() {
		Display display = Display.getCurrent();
		if (display == null)
			display = Display.getDefault();
		return display;
	}

	private void asyncNotifyExportException(String errorMessage) {
		getStandardDisplay().beep();
		MessageDialog.openError(PDEPlugin.getActiveWorkbenchShell(), AcceleoGenUIMessages.getString("FeatureExportJob.FeatureExportJob_error"), errorMessage); //$NON-NLS-1$
		done(new Status(IStatus.OK, PDEPlugin.getPluginId(), IStatus.OK, "", null)); //$NON-NLS-1$
	}

	protected String getLogFoundMessage() {
		return NLS.bind(AcceleoGenUIMessages.getString("FeatureExportJob.ExportJob_error_message"), fInfo.destinationDirectory); //$NON-NLS-1$
	} 

}
