/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import org.eclipse.compare.rangedifferencer.RangeDifference;
import org.eclipse.compare.rangedifferencer.RangeDifferencer;
import org.eclipse.jface.text.IDocument;

import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.ui.resources.AcceleoTokenComparator;

/**
 * It compares the current input of an editor with the last saved input.
 * 
 * @author www.obeo.fr
 * 
 */
public class LastSaveComparator {

	/**
	 * The editor to compare.
	 */
	private AcceleoTemplateEditor editor;

	/**
	 * The save comparator.
	 */
	private AcceleoTokenComparator saveComparator;

	/**
	 * The current comparator.
	 */
	private AcceleoTokenComparator currentComparator;

	/**
	 * Range differences.
	 */
	private RangeDifference[] ranges;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the editor to compare
	 */
	public LastSaveComparator(AcceleoTemplateEditor editor) {
		this.editor = editor;
	}

	/**
	 * Marks the last saved input.
	 */
	public void markAsSave() {
		saveComparator = new AcceleoTokenComparator(getDocument().get());
		markAsCurrent();
	}

	/**
	 * Marks the current input.
	 */
	private void markAsCurrent() {
		String content = getDocument().get();
		if (this.content == null || !this.content.equals(content)) {
			this.content = content;
			currentComparator = new AcceleoTokenComparator(getDocument().get());
			ranges = RangeDifferencer.findRanges(currentComparator, saveComparator);
		}

	}

	private String content = null;

	private IDocument getDocument() {
		return editor.getDocumentProvider().getDocument(editor.getEditorInput());
	}

	/**
	 * An indexed position.
	 */
	private static class IndexedPos {

		/**
		 * Number of the range.
		 */
		protected int rangeIndex;

		/**
		 * Position.
		 */
		protected int position;

		/**
		 * Constructor.
		 * 
		 * @param rangeIndex
		 * @param position
		 */
		protected IndexedPos(int rangeIndex, int position) {
			this.rangeIndex = rangeIndex;
			this.position = position;
		}

	}

	/**
	 * Gets the current position for the save position.
	 * 
	 * @param save
	 *            is the save position
	 * @return the current position
	 */
	public Int2 save2currentPosition(Int2 save) {
		markAsCurrent();
		if (save.b() > -1) {
			IndexedPos b = save2currentPosition(save.b(), null);
			IndexedPos e = save2currentPosition(save.e(), b);
			return new Int2(b.position, e.position);
		} else {
			return Int2.NOT_FOUND;
		}
	}

	private IndexedPos save2currentPosition(int saveIndex, IndexedPos first) {
		int begin = (first != null) ? first.rangeIndex : 0;
		for (int i = begin; i < ranges.length; i++) {
			RangeDifference range = ranges[i];
			int saveStart = saveComparator.getTokenStart(range.rightStart());
			int saveEnd = saveComparator.getTokenStart(range.rightEnd());
			if (saveIndex >= saveStart && saveIndex < saveEnd) {
				int currentStart = currentComparator.getTokenStart(range.leftStart());
				int currentEnd = currentComparator.getTokenStart(range.leftEnd());
				int diff = saveIndex - saveStart;
				if ((currentStart + diff) < currentEnd) {
					return new IndexedPos(i, currentStart + diff);
				} else {
					return new IndexedPos(i, currentEnd);
				}
			}
		}
		return new IndexedPos(ranges.length, -1);
	}

	/**
	 * Gets the save position for the current position.
	 * 
	 * @param current
	 *            is the current position
	 * @return the save position
	 */
	public Int2 current2savePosition(Int2 current) {
		markAsCurrent();
		if (current.b() > -1) {
			IndexedPos b = current2savePosition(current.b(), null);
			IndexedPos e = current2savePosition(current.e(), b);
			return new Int2(b.position, e.position);
		} else {
			return Int2.NOT_FOUND;
		}
	}

	private IndexedPos current2savePosition(int currentIndex, IndexedPos first) {
		int begin = (first != null) ? first.rangeIndex : 0;
		for (int i = begin; i < ranges.length; i++) {
			RangeDifference range = ranges[i];
			int currentStart = currentComparator.getTokenStart(range.leftStart());
			int currentEnd = currentComparator.getTokenStart(range.leftEnd());
			if (currentIndex >= currentStart && currentIndex < currentEnd) {
				int saveStart = saveComparator.getTokenStart(range.rightStart());
				int saveEnd = saveComparator.getTokenStart(range.rightEnd());
				int diff = currentIndex - currentStart;
				if ((saveStart + diff) < saveEnd) {
					return new IndexedPos(i, saveStart + diff);
				} else {
					return new IndexedPos(i, saveEnd);
				}
			}
		}
		return new IndexedPos(ranges.length, -1);
	}

}
