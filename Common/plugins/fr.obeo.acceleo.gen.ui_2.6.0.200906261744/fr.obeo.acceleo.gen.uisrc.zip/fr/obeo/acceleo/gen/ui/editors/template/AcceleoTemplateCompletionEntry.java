/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import org.eclipse.jface.text.contentassist.ICompletionProposal;

/**
 * A completion entry that contains an optional object and a completion
 * proposal.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateCompletionEntry {

	/**
	 * The completion proposal.
	 */
	private ICompletionProposal proposal;

	/**
	 * The optional object, can be null
	 */
	private Object object;

	/**
	 * Constructor.
	 * 
	 * @param proposal
	 *            is the completion proposal
	 * @param object
	 *            is the optional object, can be null
	 */
	public AcceleoTemplateCompletionEntry(ICompletionProposal proposal, Object object) {
		super();
		this.proposal = proposal;
		this.object = object;
	}

	/**
	 * @return the completion proposal
	 */
	public Object getObject() {
		return object;
	}

	/**
	 * @return optional object
	 */
	public ICompletionProposal getProposal() {
		return proposal;
	}

}
