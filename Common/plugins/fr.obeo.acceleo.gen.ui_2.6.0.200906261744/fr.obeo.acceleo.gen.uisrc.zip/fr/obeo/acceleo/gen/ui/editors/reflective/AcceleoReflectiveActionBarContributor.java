/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.presentation.EcoreActionBarContributor;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;

import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceDeleteGeneratorAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceGenerateHierarchyAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceReGenerateHierarchyAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceReloadGeneratorAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceSelectGeneratorAction;

/**
 * This is the action bar contributor for the reflective model editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoReflectiveActionBarContributor extends EcoreActionBarContributor {

	/**
	 * Constructor.
	 */
	public AcceleoReflectiveActionBarContributor() {
		super();
	}

	/* (non-Javadoc) */
	public void menuAboutToShow(IMenuManager menu) {
		super.menuAboutToShow(menu);
		menu.insertBefore("additions", new Separator("generator")); //$NON-NLS-1$ //$NON-NLS-2$
		// Generator
		MenuManager submenu = new MenuManager("Acceleo"); //$NON-NLS-1$
		List generateActions = new ArrayList();
		generateActions.add(new AcceleoSourceSelectGeneratorAction((AcceleoReflectiveEditor) activeEditor, extensions()));
		generateActions.add(new AcceleoSourceReloadGeneratorAction((AcceleoReflectiveEditor) activeEditor));
		generateActions.add(new AcceleoSourceDeleteGeneratorAction((AcceleoReflectiveEditor) activeEditor));
		generateActions.add(new AcceleoSourceGenerateHierarchyAction((AcceleoReflectiveEditor) activeEditor));
		generateActions.add(new AcceleoSourceReGenerateHierarchyAction((AcceleoReflectiveEditor) activeEditor));
		generateActions.add(new AcceleoShowTypesAction((AcceleoReflectiveEditor) activeEditor));
		populateManager(submenu, generateActions, null);
		menu.insertBefore("additions", submenu); //$NON-NLS-1$
	}

	/**
	 * Returns the extensions of the generators.
	 * 
	 * @return the extensions of the generators
	 */
	protected String[] extensions() {
		return new String[] { SpecificScript.GENERATORS_EXTENSION };
	}

}
