/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.gen.ui.wizards;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IImportWizard;
import org.eclipse.ui.IWorkbench;

import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENode;
import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.gen.template.scripts.IScript;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Wizard to create some templates from an EMF model.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoImportFromModelWizard extends Wizard implements IImportWizard {

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * The page to select the templates.
	 */
	protected AcceleoSelectFilesWizardPage pageSelectFiles;

	/**
	 * The page to select the container.
	 */
	protected AcceleoSelectContainerWizardPage pageContainer;

	/**
	 * Create the wizard.
	 */
	public AcceleoImportFromModelWizard() {
	}

	/* non-javadoc */
	public boolean performFinish() {
		final IContainer container = pageContainer.getSelection();
		final IPath[] models = pageSelectFiles.getSelection();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(container, models, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e.getTargetException(), true);
			return false;
		}
		return true;
	}

	private void doFinish(IContainer container, IPath[] models, IProgressMonitor monitor) throws CoreException {
		if (container != null && container.isAccessible() && models != null && models.length == 1 && models[0] != null) {
			EObject object = ETools.loadXMI(models[0].toString());
			if (object != null) {
				File script = AcceleoModuleProvider.getDefault().getFile(new Path("/fr.obeo.acceleo.template.gen/src/fr/obeo/acceleo/template/gen/template.mt")); //$NON-NLS-1$
				if (script != null && script.exists()) {
					try {
						SpecificScript aScript = new SpecificScript(script, null, null);
						aScript.reset();
						generate(aScript, container, object, monitor, LaunchManager.create("run", false)); //$NON-NLS-1$
					} catch (TemplateSyntaxExceptions e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (FactoryException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (ENodeException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					}
				}
			}
		}
	}

	/* non-javadoc */
	public void addPages() {
		addPage(pageSelectFiles = new AcceleoSelectFilesWizardPage(AcceleoGenUIMessages.getString("AcceleoImportFromModelWizard.SelectModel"), 1, 1, new String[] { "emt" }, true)); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageContainer = new AcceleoSelectContainerWizardPage(AcceleoGenUIMessages.getString("AcceleoImportFromModelWizard.SelectContainer"))); //$NON-NLS-1$
	}

	/* non-javadoc */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		setWindowTitle(AcceleoGenUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

	private List generate(IScript aScript, IContainer target, EObject object, IProgressMonitor monitor, LaunchManager mode) throws FactoryException, ENodeException, CoreException {
		if (monitor.isCanceled()) {
			throw new OperationCanceledException();
		}
		List result = new ArrayList();
		if (aScript.isGenerated(object)) {
			IPath path = aScript.getFilePath(object, true);
			// path != null => Generate file
			if (path != null && path.segmentCount() > 0) {
				ENode eval = evaluate(aScript, object, mode);
				Resources.createFile(target, path, eval.asString(), monitor);
			}
		}
		result.addAll(generateSub(aScript, target, object, monitor, mode));
		return result;
	}

	private List generateSub(IScript aScript, IContainer target, EObject object, IProgressMonitor monitor, LaunchManager mode) throws FactoryException, ENodeException, CoreException {
		List result = new ArrayList();
		Iterator contents = object.eContents().iterator();
		while (contents.hasNext()) {
			EObject content = (EObject) contents.next();
			result.addAll(generate(aScript, target, content, monitor, mode));
		}
		return result;
	}

	private ENode evaluate(IScript aScript, EObject object, LaunchManager mode) throws FactoryException, ENodeException {
		Template template = aScript.getRootTemplate(object, true);
		if (template != null) {
			boolean withComment = aScript.isDefault() || !aScript.hasFileTemplate();
			if (withComment) {
				return template.evaluateWithComment(object, mode);
			} else {
				return template.evaluate(object, mode);
			}
		} else {
			return new ENode(ENode.EMPTY, object, Template.EMPTY, mode.isSynchronize());
		}
	}

}
