/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IContainer;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;
import fr.obeo.acceleo.tools.ui.resources.FolderSelectionDialog;

/**
 * The action which generates the files for the current selected object.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceGenerateHierarchyAction extends Action {

	/**
	 * The reflective editor
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 */
	public AcceleoSourceGenerateHierarchyAction(AcceleoReflectiveEditor reflectiveEditor) {
		this(reflectiveEditor, "Editors.GenerateHierarchyAction.label"); //$NON-NLS-1$
	}

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 * @param key
	 *            is the label key
	 */
	public AcceleoSourceGenerateHierarchyAction(AcceleoReflectiveEditor reflectiveEditor, String key) {
		super(AcceleoGenUIMessages.getString(key));
		setDescription(AcceleoGenUIMessages.getString(key));
		setToolTipText(AcceleoGenUIMessages.getString(key));
		this.reflectiveEditor = reflectiveEditor;
	}

	/* (non-Javadoc) */
	public void run() {
		try {
			IContainer target = null;
			if (!forceOpenDialog()) {
				if (reflectiveEditor.getActivePreviewEditor() != null) {
					target = reflectiveEditor.getActivePreviewEditor().getLastGenerateHierarchyContainer();
				} else {
					AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoReflectiveEditor.ACTIVE_PREVIEW_NOT_FOUND_MESSAGE, true);
				}
			}
			if (target == null) {
				FolderSelectionDialog dialog = new FolderSelectionDialog(AcceleoGenUIMessages.getString("AcceleoSourceGenerateHierarchyAction.FolderSelectionTitle")); //$NON-NLS-1$
				dialog.open();
				if (dialog.getResult() != null && dialog.getResult().length > 0 && dialog.getResult()[0] instanceof IContainer) {
					target = (IContainer) dialog.getResult()[0];
				}
			}
			AcceleoSourceGenerateHierarchyOperation operation = new AcceleoSourceGenerateHierarchyOperation(reflectiveEditor, target);
			PlatformUI.getWorkbench().getProgressService().run(false, true, operation);
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		} catch (InterruptedException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoSourceGenerateHierarchyAction.GenerationInterrupted"), true); //$NON-NLS-1$
		}
	}

	/**
	 * Indicates if the folder dialog has to be opened.
	 */
	protected boolean forceOpenDialog() {
		return true;
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/actions/generate_hierarchy.gif"); //$NON-NLS-1$
	}

}
