/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import fr.obeo.acceleo.tools.strings.Int2;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdaptable;

/**
 * This class store the reference position.
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferenceEntry implements IAdaptable {
	/**
	 * The template file
	 */
	private IFile templateFile;

	/**
	 * The position
	 */
	private Int2 position;

	/**
	 * A message to display
	 */
	private String message;

	/**
	 * Constructor
	 * 
	 * @param templateFile
	 *            the template file
	 * @param position
	 *            the position in the template
	 */
	public ReferenceEntry(IFile templateFile, Int2 position) {
		this(templateFile, position, ""); //$NON-NLS-1$
	}

	/**
	 * Constructor
	 * 
	 * @param templateFile
	 *            the template file
	 * @param position
	 *            the position
	 * @param message
	 *            the message
	 */
	public ReferenceEntry(IFile templateFile, Int2 position, String message) {
		this.templateFile = templateFile;
		this.position = position;
		this.message = message;
	}

	/* (non-Javadoc) */
	public Object getAdapter(Class adapter) {
		if (IResource.class.equals(adapter)) {
			return templateFile;
		}
		return null;
	}

	/**
	 * Getter for the template file.
	 * 
	 * @return the template file
	 */
	public IFile getTemplateFile() {
		return templateFile;
	}

	/**
	 * Getter for the position.
	 * 
	 * @return the position
	 */
	public Int2 getPosition() {
		return position;
	}

	/**
	 * Getter for the message.
	 * 
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/* (non-Javadoc) */
	public String toString() {
		return templateFile.getName() + ": " + message; //$NON-NLS-1$
	}
}
