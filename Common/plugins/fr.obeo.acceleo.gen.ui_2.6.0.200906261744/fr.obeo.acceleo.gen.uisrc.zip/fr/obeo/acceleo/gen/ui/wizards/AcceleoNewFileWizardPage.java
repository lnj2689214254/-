/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * It allows setting the container for the new file as well as the file name.
 * 
 * @author www.obeo.fr
 */

public class AcceleoNewFileWizardPage extends WizardPage {

	/**
	 * Default file name.
	 */
	protected static final String DEFAULT_FILE_NAME = "default"; //$NON-NLS-1$

	/**
	 * The container full path.
	 */
	protected Text containerText;

	/**
	 * The new file name.
	 */
	protected Text fileText;

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * The extension of the new file.
	 */
	protected String extension;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param selection
	 *            is the current selection
	 * @param extension
	 *            is the extension of the new file
	 */
	public AcceleoNewFileWizardPage(String pageName, ISelection selection, String extension) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Description", new Object[] { extension })); //$NON-NLS-1$
		this.selection = selection;
		this.extension = extension;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 3;
		layout.verticalSpacing = 9;

		Label label = new Label(container, SWT.NULL);
		label.setText(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.ContainerLabel") + ':'); //$NON-NLS-1$

		containerText = new Text(container, SWT.BORDER | SWT.SINGLE);
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		containerText.setLayoutData(gd);
		containerText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		Button button = new Button(container, SWT.PUSH);
		button.setText(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.BrowseButtonLabel")); //$NON-NLS-1$
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleBrowse();
			}
		});

		label = new Label(container, SWT.NULL);
		label.setText(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.FileLabel") + ':'); //$NON-NLS-1$

		fileText = new Text(container, SWT.BORDER | SWT.SINGLE);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		fileText.setLayoutData(gd);
		fileText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});

		initialize();
		dialogChanged();
		setControl(container);
	}

	private void initialize() {
		if (selection != null && selection.isEmpty() == false && selection instanceof IStructuredSelection) {
			Object object = ((IStructuredSelection) selection).getFirstElement();
			IContainer container = Resources.getContainer(object);
			if (container != null) {
				containerText.setText(container.getFullPath().toString());
			}
		}
		fileText.setText(DEFAULT_FILE_NAME + '.' + extension);
	}

	private void handleBrowse() {
		ContainerSelectionDialog dialog = new ContainerSelectionDialog(getShell(), ResourcesPlugin.getWorkspace().getRoot(), false, AcceleoGenUIMessages
				.getString("AcceleoNewFileWizardPage.ContainerSelectionTitle")); //$NON-NLS-1$
		if (dialog.open() == ContainerSelectionDialog.OK) {
			Object[] result = dialog.getResult();
			if (result.length == 1) {
				containerText.setText(((Path) result[0]).toString());
			}
		}
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		IResource container = ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(getContainerName()));
		String fileName = getFileName();
		if (getContainerName().length() == 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.EmptyContainer")); //$NON-NLS-1$
			return;
		}
		if (container == null || (container.getType() & (IResource.PROJECT | IResource.FOLDER)) == 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.InexistantContainer")); //$NON-NLS-1$
			return;
		}
		if (!container.isAccessible()) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.UnwritebleContainer")); //$NON-NLS-1$
			return;
		}
		if (fileName.length() == 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.EmptyFile")); //$NON-NLS-1$
			return;
		}
		if (container instanceof IContainer && ((IContainer) container).exists(new Path(getFileName()))) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.ExistingFile")); //$NON-NLS-1$
			return;
		}
		if (fileName.replace('\\', '/').indexOf('/', 1) > 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.InvalidPath")); //$NON-NLS-1$
			return;
		}
		int dotLoc = fileName.lastIndexOf('.');
		String ext = (dotLoc > -1) ? fileName.substring(dotLoc + 1) : ""; //$NON-NLS-1$
		if (!ext.equals(extension)) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewFileWizardPage.Error.InvalidExtension", new Object[] { extension, })); //$NON-NLS-1$ 
			return;
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

	/**
	 * Returns the container full path.
	 * 
	 * @return the container full path
	 */
	public String getContainerName() {
		return containerText.getText();
	}

	/**
	 * Returns the new file name.
	 * 
	 * @return the new file name
	 */
	public String getFileName() {
		return fileText.getText();
	}

}
