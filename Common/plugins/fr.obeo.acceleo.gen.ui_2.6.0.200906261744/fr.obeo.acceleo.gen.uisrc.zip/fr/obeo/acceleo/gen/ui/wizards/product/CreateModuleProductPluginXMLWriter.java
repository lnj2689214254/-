package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductPluginXMLWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductPluginXMLWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductPluginXMLWriter result = new CreateModuleProductPluginXMLWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<?eclipse version=\"3.2\"?>" + NL + "<plugin>" + NL + "" + NL + "   <extension id=\"acceleoModule\" point=\"org.eclipse.core.runtime.products\"> " + NL + "      <product name=\"Acceleo Module Product\" application=\"";
  protected final String TEXT_2 = ".launch\" description=\"Acceleo Module Product\"> " + NL + "          <property name=\"windowImage\" value=\"default.gif\"/> " + NL + "          <property name=\"aboutImage\" value=\"default.gif\"/> " + NL + "          <property name=\"aboutText\" value=\"%aboutText\"/> " + NL + "          <property name=\"appName\" value=\"Acceleo Module Application\"/> " + NL + "      </product> " + NL + "   </extension>" + NL + "   " + NL + "    <extension" + NL + "          id=\"launch\"" + NL + "          point=\"org.eclipse.core.runtime.applications\">" + NL + "       <application>" + NL + "          <run class=\"";
  protected final String TEXT_3 = ".runner.GenRunner\"/>" + NL + "       </application>" + NL + "    </extension>" + NL + "" + NL + "</plugin>";
  protected final String TEXT_4 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_3);
    stringBuffer.append(TEXT_4);
    return stringBuffer.toString();
  }
}
