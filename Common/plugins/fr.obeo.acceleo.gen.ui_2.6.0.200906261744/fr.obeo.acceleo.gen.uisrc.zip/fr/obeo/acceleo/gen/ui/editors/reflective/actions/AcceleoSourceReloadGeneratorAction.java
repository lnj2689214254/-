/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;

/**
 * Reload current generator.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceReloadGeneratorAction extends Action {

	/**
	 * The reflective editor
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 */
	public AcceleoSourceReloadGeneratorAction(AcceleoReflectiveEditor reflectiveEditor) {
		super(AcceleoGenUIMessages.getString("Editors.ReloadGeneratorAction.label")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("Editors.ReloadGeneratorAction.label")); //$NON-NLS-1$
		setToolTipText(AcceleoGenUIMessages.getString("Editors.ReloadGeneratorAction.label")); //$NON-NLS-1$
		this.reflectiveEditor = reflectiveEditor;
	}

	/* (non-Javadoc) */
	public void run() {
		try {
			if (reflectiveEditor.getActivePreviewEditor() != null) {
				reflectiveEditor.getActivePreviewEditor().reloadGenerator();
			} else {
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoReflectiveEditor.ACTIVE_PREVIEW_NOT_FOUND_MESSAGE, true);
			}
		} catch (Exception e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/actions/refresh.gif"); //$NON-NLS-1$
	}

}
