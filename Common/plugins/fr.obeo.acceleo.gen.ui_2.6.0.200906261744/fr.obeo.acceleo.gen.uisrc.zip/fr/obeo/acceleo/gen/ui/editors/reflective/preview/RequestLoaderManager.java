/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.preview;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * A manager to create a request view on the reflective editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class RequestLoaderManager {

	/**
	 * The identifier of the internal extension point specifying the
	 * implementation to use with a request loader.
	 */
	public static final String REQUEST_LOADER_EXTENSION_ID = "fr.obeo.acceleo.gen.ui.requestloader"; //$NON-NLS-1$

	/**
	 * Returns the request loader
	 * 
	 * @return the request loader
	 */
	public IRequestLoader getRequestLoader() {
		if (requestLoader == null) {
			IExtensionRegistry registry = Platform.getExtensionRegistry();
			IExtensionPoint extensionPoint = registry.getExtensionPoint(REQUEST_LOADER_EXTENSION_ID);
			if (extensionPoint == null) {
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("RequestLoaderManager.UnresolvedExtensionPoint", new Object[] { REQUEST_LOADER_EXTENSION_ID, }), true); //$NON-NLS-1$
			} else {
				String theRequestLoader = null;
				int thePriority = -1;
				Bundle theBundle = null;
				IExtension[] extensions = extensionPoint.getExtensions();
				for (int i = 0; i < extensions.length; i++) {
					IExtension extension = extensions[i];
					IConfigurationElement[] members = extension.getConfigurationElements();
					for (int j = 0; j < members.length; j++) {
						IConfigurationElement member = members[j];
						String reverseLoader = member.getAttribute("requestLoader"); //$NON-NLS-1$
						String priority = member.getAttribute("priority"); //$NON-NLS-1$
						if (reverseLoader != null && (thePriority == -1 || (priority != null && Integer.parseInt(priority) > thePriority))) {
							theRequestLoader = reverseLoader;
							if (priority != null) {
								thePriority = Integer.parseInt(priority);
							} else {
								thePriority = 0;
							}
							theBundle = Platform.getBundle(member.getNamespace());
							if (theBundle == null) {
								theBundle = AcceleoEcoreGenUiPlugin.getDefault().getBundle();
							}
						}
					}
				}
				if (theRequestLoader != null) {
					try {
						Class c = theBundle.loadClass(theRequestLoader);
						Object instance = c.newInstance();
						if (instance instanceof IRequestLoader) {
							requestLoader = (IRequestLoader) instance;
						}
					} catch (ClassNotFoundException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (InstantiationException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (IllegalAccessException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					}
				}
			}
		}
		return requestLoader;
	}

	private IRequestLoader requestLoader = null;

}
