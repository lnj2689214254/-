/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.scanner;

import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WhitespaceRule;
import org.eclipse.swt.SWT;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.editors.template.ColorManager;
import fr.obeo.acceleo.gen.ui.editors.template.rule.BlockRule;

/**
 * A scanner for detecting 'script' sequences.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateScriptScanner extends AcceleoTemplateBasedScanner {

	/**
	 * Constructor.
	 * 
	 * @param manager
	 *            is the color manager
	 */
	public AcceleoTemplateScriptScanner(ColorManager manager) {
		IRule[] rules = new IRule[2];
		rules[0] = new BlockRule(TemplateConstants.LITERAL[0], TemplateConstants.LITERAL[1], TemplateConstants.LITERAL_SPEC, new Token(new TextAttribute(manager
				.getColor(IAcceleoTemplateColorConstants.LITERAL_1))));
		rules[1] = new WhitespaceRule(new AcceleoTemplateWhitespaceDetector());
		setRules(rules);
		setDefaultReturnToken(new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.SCRIPT), null, SWT.BOLD)));
	}

	/* (non-Javadoc) */
	public String getConfiguredContentType() {
		return AcceleoTemplatePartitionScanner.TEMPLATE_SCRIPT;
	}

}
