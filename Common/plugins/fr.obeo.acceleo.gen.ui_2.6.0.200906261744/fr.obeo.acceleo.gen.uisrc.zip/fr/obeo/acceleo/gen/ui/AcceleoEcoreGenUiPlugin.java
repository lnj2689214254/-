/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.preferences.InstanceScope;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.ui.preferences.ScopedPreferenceStore;
import org.osgi.framework.BundleContext;

import fr.obeo.acceleo.tools.ui.resources.AcceleoUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoEcoreGenUiPlugin extends AcceleoUIPlugin {

	/* (non-Javadoc) */
	public String getID() {
		return "fr.obeo.acceleo.gen.ui"; //$NON-NLS-1$
	}

	/**
	 * The shared instance.
	 */
	private static AcceleoEcoreGenUiPlugin plugin;

	/**
	 * Resource bundle.
	 */
	private ResourceBundle resourceBundle;

	/**
	 * The images.
	 */
	private Map imageMap = new HashMap();

	/**
	 * The constructor.
	 */
	public AcceleoEcoreGenUiPlugin() {
		super();
		plugin = this;
	}

	/* (non-Javadoc) */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/* (non-Javadoc) */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
		resourceBundle = null;
		Iterator imageIterator = imageMap.values().iterator();
		while (imageIterator.hasNext()) {
			Image image = (Image) imageIterator.next();
			image.dispose();
		}
		imageMap.clear();
	}

	/**
	 * @return the shared instance
	 */
	public static AcceleoEcoreGenUiPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 * 
	 * @param key
	 *            identifies the string
	 * @return the string from the plugin's resource bundle, or 'key' if not
	 *         found
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = AcceleoEcoreGenUiPlugin.getDefault().getResourceBundle();
		try {
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle.
	 * 
	 * @return the plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		try {
			if (resourceBundle == null)
				resourceBundle = ResourceBundle.getBundle("fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPluginResources"); //$NON-NLS-1$
		} catch (MissingResourceException x) {
			resourceBundle = null;
		}
		return resourceBundle;
	}

	/**
	 * Returns an image at the given plug-in relative path.
	 * 
	 * @param path
	 *            is a plug-in relative path
	 * @return the image
	 */
	public Image getImage(String path) {
		Image result = (Image) imageMap.get(path);
		if (result == null) {
			result = getImageDescriptor(path).createImage();
			imageMap.put(path, result);
		}
		return result;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            is a plug-in relative path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin("fr.obeo.acceleo.gen.ui", path); //$NON-NLS-1$
	}

	/**
	 * Storage for preferences.
	 */
	private ScopedPreferenceStore preferenceStore;

	/**
	 * Returns the preference store for this UI plug-in. This preference store
	 * is used to hold persistent settings for this plug-in in the context of a
	 * workbench. Some of these settings will be user controlled, whereas others
	 * may be internal setting that are never exposed to the user.
	 * <p>
	 * If an error occurs reading the preference store, an empty preference
	 * store is quietly created, initialized with defaults, and returned.
	 * </p>
	 * <p>
	 * <strong>NOTE:</strong> As of Eclipse 3.1 this method is no longer
	 * referring to the core runtime compatibility layer and so plug-ins relying
	 * on Plugin#initializeDefaultPreferences will have to access the
	 * compatibility layer themselves.
	 * </p>
	 * 
	 * @return the preference store
	 */
	public IPreferenceStore getPreferenceStore() {
		// Create the preference store lazily.
		if (preferenceStore == null) {
			preferenceStore = new ScopedPreferenceStore(new InstanceScope(), getBundle().getSymbolicName());

		}
		return preferenceStore;
	}

}
