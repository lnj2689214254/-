/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * Refresh and show types on editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoShowTypesAction extends Action {

	/**
	 * The reflective editor.
	 */
	protected AcceleoReflectiveEditor editor;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the reflective editor
	 */
	public AcceleoShowTypesAction(AcceleoReflectiveEditor editor) {
		super(AcceleoGenUIMessages.getString("Editors.ShowTypesAction.label")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("Editors.ShowTypesAction.label")); //$NON-NLS-1$
		setToolTipText(AcceleoGenUIMessages.getString("Editors.ShowTypesAction.label")); //$NON-NLS-1$
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public void run() {
		editor.showType = !editor.showType;
		editor.getViewer().refresh();
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/actions/show_types.gif"); //$NON-NLS-1$
	}

}
