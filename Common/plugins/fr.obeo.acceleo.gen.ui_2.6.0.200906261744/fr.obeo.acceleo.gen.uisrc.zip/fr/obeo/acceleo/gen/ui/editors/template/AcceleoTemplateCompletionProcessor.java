/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.template.TemplateSyntaxException;
import fr.obeo.acceleo.gen.template.expressions.TemplateCallExpression;
import fr.obeo.acceleo.gen.template.expressions.TemplateCallSetExpression;
import fr.obeo.acceleo.gen.template.expressions.TemplateExpression;
import fr.obeo.acceleo.gen.template.scripts.ScriptDescriptor;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.template.scripts.imports.EvalJavaService;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.EMFEditorUtil;
import fr.obeo.acceleo.gen.ui.editors.reflective.IGeneratorProvider;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EParameter;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.swt.graphics.Image;

/**
 * A completion processor for the template editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateCompletionProcessor implements IContentAssistProcessor {

	/**
	 * Indicates if the current syntax is the alternative syntax.
	 */
	protected boolean isAlternativeSyntax = false;

	/**
	 * The auto activation characters for completion proposal.
	 */
	protected static final char[] AUTO_ACTIVATION_CHARACTERS = new char[] { ' ', '.', '%' }; // Unless

	/**
	 * The activation characters for completion proposal.
	 */
	protected static final char[] ACTIVATION_CHARACTERS = new char[] { ' ', '\t', '\n', '|', '&', '=', '(', ',', '-', '+', '*', '/', '!', '{', '[' };

	/**
	 * The parenthesis characters.
	 */
	protected static final char[] PARENTHESIS = new char[] { '(', ')' };

	/**
	 * The brackets characters.
	 */
	protected static final char[] BRACKETS = new char[] { '[', ']' };

	/**
	 * The generator provider.
	 */
	protected IGeneratorProvider provider;

	/**
	 * Constructor.
	 * 
	 * @param provider
	 *            is the generator provider
	 */
	public AcceleoTemplateCompletionProcessor(IGeneratorProvider provider) {
		super();
		this.provider = provider;
	}

	/**
	 * Gets the generator.
	 * 
	 * @return the generator
	 */
	protected SpecificScript getGenerator() {
		return provider.getGenerator();
	}

	/**
	 * Returns the image at the given plug-in relative path.
	 * 
	 * @param path
	 *            is a plug-in relative path
	 * @return the image
	 */
	protected Image getImage(String path) {
		return AcceleoEcoreGenUiPlugin.getDefault().getImage(path);
	}

	/* (non-Javadoc) */
	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {
		AcceleoTemplateCompletionEntry[] entries = computeCompletionEntries(viewer, offset);
		ICompletionProposal[] proposals = new ICompletionProposal[entries.length];
		for (int i = 0; i < entries.length; i++) {
			proposals[i] = entries[i].getProposal();
		}
		return proposals;
	}

	/**
	 * Returns a list of completion entries based on the specified location
	 * within the document that corresponds to the current cursor position
	 * within the text viewer.
	 * 
	 * @param viewer
	 *            the viewer whose document is used to compute the proposals
	 * @param offset
	 *            an offset within the document for which completions should be
	 *            computed
	 * @return an array of completion entries
	 */
	public AcceleoTemplateCompletionEntry[] computeCompletionEntries(ITextViewer viewer, int offset) {
		ITextSelection selection = (ITextSelection) viewer.getSelectionProvider().getSelection();
		if (selection.getOffset() == offset) {
			offset = selection.getOffset() + selection.getLength();
		}
		String documentText = viewer.getDocument().get();
		isAlternativeSyntax = documentText.length() > 0 && documentText.charAt(0) == '[';
		String text;
		if (isAlternativeSyntax) {
			text = documentText.replaceAll("\\[%", "<%").replaceAll("%]", "%>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
		} else {
			text = documentText;
		}
		TemplateConstants.initConstants(text);
		try {
			List matches = new ArrayList();
			// Step 1 : Completion for templates and imported elements :
			// metamodel,
			// services...
			String id = ""; //$NON-NLS-1$
			Object resolvedType = getDefaultType(text, offset);
			if (resolvedType != null) {
				String literalStart = asLiteralStart(text, offset);
				if (literalStart != null) {
					matches = computeMetamodelTypesProposals(getGenerator().getMetamodel(), literalStart, offset, false);
					return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
				}
			} else if (resolvedType == null && getGenerator() != null && getGenerator().getMetamodel() != null) {
				if (offset <= text.length()) {
					Int2 bScript = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.SCRIPT_BEGIN, 0, offset, null, TemplateConstants.INHIBS_SCRIPT_CONTENT);
					if (bScript.e() > -1) {
						// Get the identifier for the type of the current
						// template
						int i = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.SCRIPT_TYPE, bScript.e(), offset).e();
						if (i > -1) {
							i = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.LITERAL[0], i, offset).e();
							if (i > -1) {
								int j = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.LITERAL[1], i, offset).b();
								if (j > -1) {
									id = text.substring(i, j);
								} else {
									matches = computeMetamodelTypesProposals(getGenerator().getMetamodel(), text.substring(i, offset), offset, false);
									return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
								}
							}
						}
						Int2 eScript = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.SCRIPT_END, bScript.e(), offset, null, TemplateConstants.INHIBS_SCRIPT_CONTENT);
						if (eScript.b() == -1) {
							matches.addAll(computeScriptAttributeProposals(text, offset));
						}
					}
					String literalStart = asLiteralStart(text, offset);
					if (literalStart != null) {
						matches = computeMetamodelTypesProposals(getGenerator().getMetamodel(), literalStart, offset, false);
						return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
					}
				}
				if (id.length() > 0) {
					// Get the classifier for the identifier
					Object currentType = ETools.getEClassifier(getGenerator().getMetamodel(), id);
					resolvedType = getForResolvedType(text, offset, currentType);
				}
			}
			if (id.length() == 0 && offset > 0
					&& TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.IMPORT_END, 0, offset, TemplateConstants.COMMENT_END, new String[][] { TemplateConstants.LITERAL }).b() == -1) {
				int endLineOffset = TextSearch.getRegexSearch().indexOf(text, "[\\r\\n]+", offset).b(); //$NON-NLS-1$
				if (endLineOffset == -1) {
					endLineOffset = text.length();
				}
				String mmURIStart = asMetamodelURIStart(text, offset);
				if (mmURIStart != null) {
					matches = computeMetamodelURIsProposals(mmURIStart, offset, endLineOffset);
					return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
				}
				String importStart = asImportStart(text, offset);
				if (importStart != null) {
					matches = computeImportProposals(importStart, offset, endLineOffset);
					return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
				}
				matches.addAll(computeHeaderProposals(text, offset));
			}
			resolvedType = getFilterResolvedType(text, offset, resolvedType);
			resolvedType = getFeatureResolvedType(text, offset, resolvedType);
			// Get the proposals for the resolved type
			if (resolvedType != null && getGenerator() != null) {
				Object[] proposals = getGenerator().getCompletionProposals(resolvedType);
				matches.addAll(computeResolvedTypesProposals(proposals, text, offset));
			}
			// Step 2 : Completion for statements and predefined links
			String prefix = extractPrefix(extractEndStart(text, offset));
			if (prefix == null) {
				matches.addAll(computeScriptProposals(text, offset));
				matches.addAll(computeForStatementProposals(text, offset));
				matches.addAll(computeStatementsProposals(text, offset));
				matches.addAll(computePredefinedLinksProposals(text, offset));
			}
			// Step 3 : Delete duplicated proposals
			matches = deleteDuplicatedProposals(matches);
			return (AcceleoTemplateCompletionEntry[]) matches.toArray(new AcceleoTemplateCompletionEntry[matches.size()]);
		} finally {
			if (isAlternativeSyntax) {
				TemplateConstants.initConstants(documentText);
			}
		}
	}

	/**
	 * Gets the completion's start in literal.
	 * <p>
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start or null if the offset doesn't start a
	 *         literal
	 */
	protected String asLiteralStart(String text, int offset) {
		String start = ""; //$NON-NLS-1$
		if (offset > 0) {
			int i = offset - 1;
			while (i >= 0) {
				char c = text.charAt(i);
				if (Character.isLetterOrDigit(c) || c == '.') {
					i--;
					start = c + start;
				} else if (c == '"') {
					return start;
				} else {
					return null;
				}
			}
		}
		return null;
	}

	/**
	 * Gets the completion's start in metamodel URI.
	 * <p>
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start or null if the offset doesn't start a
	 *         literal
	 */
	protected String asMetamodelURIStart(String text, int offset) {
		String start = ""; //$NON-NLS-1$
		if (offset > 0) {
			int i = offset - 1;
			while (i >= 0) {
				char c = text.charAt(i);
				if (c == ' ' || c == '\n') {
					// remove spaces
					while (i > 0 && text.charAt(i - 1) == ' ') {
						i--;
					}
					if (i >= TemplateConstants.MODELTYPE_WORD.length() - 1 && text.substring(i - TemplateConstants.MODELTYPE_WORD.length(), i).equals(TemplateConstants.MODELTYPE_WORD)) {
						return start;
					} else {
						return null;
					}
				} else {
					i--;
					start = c + start;
				}
			}
		}
		return null;
	}

	/**
	 * Gets the completion's start for an import.
	 * <p>
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start or null if the offset doesn't start a
	 *         literal
	 */
	protected String asImportStart(String text, int offset) {
		String start = ""; //$NON-NLS-1$
		if (offset > 0) {
			int i = offset - 1;
			while (i >= 0) {
				char c = text.charAt(i);
				if (c == ' ' || c == '\n') {
					// remove spaces
					while (i > 0 && text.charAt(i - 1) == ' ') {
						i--;
					}
					if (i >= TemplateConstants.IMPORT_WORD.length() - 1 && text.substring(i - TemplateConstants.IMPORT_WORD.length(), i).equals(TemplateConstants.IMPORT_WORD)) {
						return start;
					} else {
						return null;
					}
				} else {
					i--;
					start = c + start;
				}
			}
		}
		return null;
	}

	/**
	 * Gets the completion's start, before the last dot.
	 * <p>
	 * Sample : "a.b.c.DDD" is the text before the offset -> "a.b.c"
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start, before the last dot
	 */
	protected String extractBeginStart(String text, int offset) {
		String extractStart = extractStart(text, offset);
		Int2 iSep = TextSearch.getDefaultSearch().lastIndexOf(extractStart, TemplateConstants.CALL_SEP, TemplateConstants.SPEC, TemplateConstants.INHIBS_EXPRESSION);
		Int2 iBracket = getLastIndexOfOpenBracket(extractStart, ((iSep.e() == -1) ? 0 : iSep.e()));
		if (iBracket.b() > -1) {
			return extractStart.substring(0, iBracket.b());
		} else if (iSep.b() > -1) {
			return extractStart.substring(0, iSep.b());
		} else {
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * Gets the completion's start, after the last dot.
	 * <p>
	 * Sample : "a.b.c.DDD" -> "DDD"
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start, after the last dot
	 */
	protected String extractEndStart(String text, int offset) {
		String extractStart = extractStart(text, offset);
		Int2 iSep = TextSearch.getDefaultSearch().lastIndexOf(extractStart, TemplateConstants.CALL_SEP, TemplateConstants.SPEC, TemplateConstants.INHIBS_EXPRESSION);
		Int2 iBracket = getLastIndexOfOpenBracket(extractStart, ((iSep.e() == -1) ? 0 : iSep.e()));
		if (iBracket.e() > -1) {
			return extractStart.substring(iBracket.e());
		} else if (iSep.e() > -1) {
			return extractStart.substring(iSep.e());
		} else {
			return extractStart;
		}
	}

	private Int2 getLastIndexOfOpenBracket(String extractStart, int start) {
		Int2 end = TextSearch.getDefaultSearch().lastIndexOf(extractStart, TemplateConstants.BRACKETS[1], start, TemplateConstants.SPEC, new String[][] { TemplateConstants.LITERAL });
		Int2 begin = TextSearch.getDefaultSearch().lastIndexOf(extractStart, TemplateConstants.BRACKETS[0], ((end.e() == -1) ? start : end.e()), TemplateConstants.SPEC,
				new String[][] { TemplateConstants.LITERAL });
		if (begin.b() > -1) {
			return begin;
		}
		return Int2.NOT_FOUND;
	}

	/**
	 * Gets the completion's start.
	 * <p>
	 * Sample : "a.b.c.DDD" -> "a.b.c.DDD"
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the completion's start
	 */
	protected String extractStart(String text, int offset) {
		if (offset <= text.length()) {
			String prefix = "  "; //$NON-NLS-1$
			text = prefix + text;
			offset = prefix.length() + offset;
			int i = offset;
			while (i >= 2) {
				char c = text.charAt(i - 1);
				if (TemplateConstants.FEATURE_BEGIN.equals(text.substring(i - TemplateConstants.FEATURE_BEGIN.length(), i))) {
					return TemplateConstants.FEATURE_BEGIN + text.substring(i, offset);
				} else if (c == PARENTHESIS[1]) { // ( ... ) is a block to
					// ignore
					int level = 0;
					do {
						i--;
						c = text.charAt(i - 1);
						if (c == '"') {
							do {
								i--;
								c = text.charAt(i - 1);
								if (c == '"' && (i < 2 || text.charAt(i - 2) != '\\')) {
									break;
								}
							} while (i > 1);
						} else if (c == PARENTHESIS[1]) {
							level++;
						} else if (c == PARENTHESIS[0]) {
							if (level == 0) {
								break;
							} else {
								level--;
							}
						}
					} while (i > 1);
				} else if (c == BRACKETS[1]) { // [ ... ] is a block to
					int level = 0;
					do {
						i--;
						c = text.charAt(i - 1);
						if (c == '"') {
							do {
								i--;
								c = text.charAt(i - 1);
								if (c == '"' && (i < 2 || text.charAt(i - 2) != '\\')) {
									break;
								}
							} while (i > 1);
						} else if (c == BRACKETS[1]) {
							level++;
						} else if (c == BRACKETS[0]) {
							if (level == 0) {
								break;
							} else {
								level--;
							}
						}
					} while (i > 1);
				} else {
					for (int j = 0; j < ACTIVATION_CHARACTERS.length; j++) {
						if (c == ACTIVATION_CHARACTERS[j]) {
							return text.substring(i, offset);
						}
					}
				}
				i--;
			}
		}
		return ""; //$NON-NLS-1$
	}

	/**
	 * Computes valid metamodel types proposals.
	 * 
	 * @param metamodel
	 *            is the metamodel root element
	 * @param start
	 *            is the start of the proposal
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param classOnly
	 *            indicates that only the classes are kept
	 * @return the proposals
	 */
	protected List computeMetamodelTypesProposals(EPackage metamodel, String start, int offset, boolean classOnly) {
		String prefix = extractPrefix(start);
		if (prefix == null) {
			Collection classifiers = new TreeSet(new Comparator() {
				public int compare(Object arg0, Object arg1) {
					EClassifier c0 = ((EClassifier) arg0);
					EClassifier c1 = ((EClassifier) arg1);
					return ETools.getEClassifierShortPath(c0).compareTo(ETools.getEClassifierShortPath(c1));
				}
			});
			classifiers.addAll(ETools.computeAllClassifiersList(metamodel, classOnly));
			/*
			 * Add EObject as a default type
			 */
			classifiers.add(EcorePackage.eINSTANCE.getEObject());
			EClassifier[] proposals = (EClassifier[]) classifiers.toArray(new EClassifier[classifiers.size()]);
			String[] replacementStrings = new String[proposals.length * 2];
			String[] displayStrings = new String[proposals.length * 2];
			String[] informationStrings = new String[proposals.length * 2];
			int[] cursorPositions = new int[proposals.length * 2];
			Image[] images = new Image[proposals.length * 2];

			for (int i = 0; i < proposals.length; i++) {
				// Name only
				EClassifier currentProposal = proposals[i];
				replacementStrings[i] = currentProposal.getName();
				cursorPositions[i] = replacementStrings[i].length();
				displayStrings[i] = currentProposal.getName();
				informationStrings[i] = getDescription(currentProposal);
				// icon
				images[i] = EMFEditorUtil.findImageFromClassifier(currentProposal, true);

				// Short path
				int j = proposals.length + i;
				replacementStrings[j] = ETools.getEClassifierShortPath(currentProposal);
				cursorPositions[j] = replacementStrings[j].length();
				displayStrings[j] = replacementStrings[j];
				informationStrings[j] = informationStrings[i];
				// icon
				images[j] = images[i];
			}
			return computeValidProposals(null, replacementStrings, displayStrings, informationStrings, cursorPositions, start, offset, images);
		} else {
			return new ArrayList();
		}
	}

	private String getDescription(EClassifier eClassifier) {
		String desc = null;
		// Information come from GenModel.
		// As the metamodel object of Acceleo loose this information, it doesn't
		// do anything. Need to be fix.
		EAnnotation eAnno = eClassifier.getEAnnotation("http://www.eclipse.org/emf/2002/GenModel"); //$NON-NLS-1$
		if (eAnno != null) {
			desc = (String) eAnno.getDetails().get("documentation"); //$NON-NLS-1$
		}
		if (desc == null) {
			desc = eClassifier.getName();
		}
		StringBuffer result = new StringBuffer(""); //$NON-NLS-1$
		result.append(desc);
		if (eClassifier instanceof EClass) {
			EClass eClass = (EClass) eClassifier;
			if (eClass.getEAllSuperTypes().size() > 0) {
				result.append("\n\n"); //$NON-NLS-1$
				result.append("Super-Types : \n - "); //$NON-NLS-1$
				List eAllSuperTypes = eClass.getEAllSuperTypes();
				for (int i = eAllSuperTypes.size() - 1; i >= 0; i--) {
					EClass eSuperType = (EClass) eAllSuperTypes.get(i);
					result.append(eSuperType.getName());
					if (i > 0) {
						result.append(",\n - "); //$NON-NLS-1$
					}
				}
			}
		}
		return result.toString();
	}

	/**
	 * Computes valid metamodel URI proposals.
	 * 
	 * @param start
	 *            is the start of the proposal
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param endLineOffset
	 *            is the offset of the end of the line
	 * @return the proposals
	 */
	protected List computeMetamodelURIsProposals(String start, int offset, int endLineOffset) {
		Set registryValues = new TreeSet(EPackage.Registry.INSTANCE.keySet());
		List availableURIs = new ArrayList();
		Image imageEcore = getImage("icons/proposals/EcoreModelFile.gif"); //$NON-NLS-1$
		Image imageURI = getImage("icons/proposals/url.gif"); //$NON-NLS-1$
		for (Iterator iter = registryValues.iterator(); iter.hasNext();) {
			String element = (String) iter.next();
			String name = null; // description
			int slashIdx = element.lastIndexOf("/"); //$NON-NLS-1$
			if (slashIdx != -1) {
				name = AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.MetamodelURIProposal", new Object[] { element.substring(slashIdx), }); //$NON-NLS-1$
			}
			Image image;
			if (element.startsWith("http://")) { //$NON-NLS-1$
				image = imageURI;
			} else {
				image = imageEcore;
			}
			if (element.startsWith(start)) {
				ICompletionProposal proposal = new CompletionProposal(element, offset - start.length(), endLineOffset - offset + start.length(), element.length(), image, element, null, name);
				availableURIs.add(new AcceleoTemplateCompletionEntry(proposal, element));
			}
		}
		IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			IProject project = projects[i];
			IFile[] files;
			try {
				files = Resources.members(project, new String[] { "ecore", "rules" }); //$NON-NLS-1$ //$NON-NLS-2$
			} catch (CoreException e) {
				files = new IFile[] {};
			}
			for (int j = 0; j < files.length; j++) {
				String element = files[j].getFullPath().toString();
				String name = null; // description
				int slashIdx = element.lastIndexOf("/"); //$NON-NLS-1$
				if (slashIdx != -1) {
					name = AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.MetamodelURIProposal", new Object[] { element.substring(slashIdx), }); //$NON-NLS-1$
				}
				Image image = imageEcore;
				ICompletionProposal proposal = new CompletionProposal(element, offset - start.length(), endLineOffset - offset + start.length(), element.length(), image, element, null, name);
				availableURIs.add(new AcceleoTemplateCompletionEntry(proposal, element));
			}
		}
		return availableURIs;

	}

	/**
	 * Computes valid import proposals.
	 * 
	 * @param start
	 *            is the start of the proposal
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param endLineOffset
	 *            is the offset of the end of the line
	 * @return the proposals
	 */
	protected List computeImportProposals(String start, int offset, int endLineOffset) {
		List availableImports = new ArrayList();
		if (provider != null && provider.getGenerator() != null && provider.getGenerator().getFile() != null) {
			IFile file = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(new Path(provider.getGenerator().getFile().getAbsolutePath()));
			if (file != null && file.isAccessible()) {
				IJavaProject javaProject = JavaCore.create(file.getProject());
				try {
					IClasspathEntry[] entries = javaProject.getResolvedClasspath(true);
					for (int i = 0; i < entries.length; i++) {
						IClasspathEntry entry = entries[i];
						if (entry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
							availableImports.addAll(computeImportProposalsForSourceEntry(start, offset, endLineOffset, entry));
						} else if (entry.getEntryKind() == IClasspathEntry.CPE_PROJECT) {
							IJavaProject javaSubProject = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot().getProject(entry.getPath().toString()).getProject());
							IClasspathEntry[] subEntries = javaSubProject.getResolvedClasspath(true);
							for (int j = 0; j < subEntries.length; j++) {
								IClasspathEntry subEntry = subEntries[j];
								if (subEntry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
									availableImports.addAll(computeImportProposalsForSourceEntry(start, offset, endLineOffset, subEntry));
								}
							}
						}
					}
				} catch (JavaModelException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, false);
				}
			}
		}
		return availableImports;
	}

	/**
	 * Computes valid import proposals for a source entry. entry.getEntryKind()
	 * MUST equals IClasspathEntry.CPE_SOURCE.
	 * 
	 * @param start
	 *            is the start of the proposal
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param endLineOffset
	 *            is the offset of the end of the line
	 * @return the proposals
	 */
	private List computeImportProposalsForSourceEntry(String start, int offset, int endLineOffset, IClasspathEntry entry) {
		Image imageMt = getImage("icons/proposals/template.gif"); //$NON-NLS-1$
		Image imageJava = getImage("icons/proposals/service.gif"); //$NON-NLS-1$
		List availableImports = new ArrayList();
		IFolder sourceFolder = ResourcesPlugin.getWorkspace().getRoot().getFolder(entry.getPath());
		if (sourceFolder.exists()) {
			IFile[] files;
			try {
				files = Resources.members(sourceFolder, new String[] { "mt" }); //$NON-NLS-1$
			} catch (CoreException e) {
				files = new IFile[] {};
			}
			for (int j = 0; j < files.length; j++) {
				String element = files[j].getFullPath().removeFileExtension().removeFirstSegments(sourceFolder.getFullPath().segmentCount()).toString().replaceAll("/", "."); //$NON-NLS-1$ //$NON-NLS-2$
				if (element.startsWith(start)) {
					ICompletionProposal proposal = new CompletionProposal(element, offset - start.length(), endLineOffset - offset + start.length(), element.length(), imageMt, element, null,
							AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.TemplateProposal", new Object[] { files[j].getName(), })); //$NON-NLS-1$
					availableImports.add(new AcceleoTemplateCompletionEntry(proposal, element));
				}
			}
			try {
				files = Resources.members(sourceFolder, new String[] { "java" }); //$NON-NLS-1$
			} catch (CoreException e) {
				files = new IFile[] {};
			}
			for (int j = 0; j < files.length; j++) {
				String element = files[j].getFullPath().removeFileExtension().removeFirstSegments(sourceFolder.getFullPath().segmentCount()).toString().replaceAll("/", "."); //$NON-NLS-1$ //$NON-NLS-2$
				if (element.startsWith(start)) {
					ICompletionProposal proposal = new CompletionProposal(element, offset - start.length(), endLineOffset - offset + start.length(), element.length(), imageJava, element, null,
							AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ServiceProposal", new Object[] { files[j].getName(), })); //$NON-NLS-1$
					availableImports.add(new AcceleoTemplateCompletionEntry(proposal, element));
				}
			}
		}
		return availableImports;
	}

	/**
	 * Gets the path of the script icon.
	 * 
	 * @param descriptor
	 *            is the descriptor of the script
	 * @return path of the icon
	 */
	protected String getTemplateIcon(ScriptDescriptor descriptor) {
		return "icons/proposals/template.gif"; //$NON-NLS-1$
	}

	/**
	 * Computes valid proposals for the objects detected.
	 * 
	 * @param proposals
	 *            are the objects detected for the current resolved type
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeResolvedTypesProposals(Object[] proposals, String text, int offset) {
		String endStart = extractEndStart(text, offset);
		String prefix = extractPrefix(endStart);
		String[] replacementStrings = new String[proposals.length];
		String[] displayStrings = new String[proposals.length];
		String[] informationStrings = new String[proposals.length];
		int[] cursorPositions = new int[proposals.length];
		Image[] images = new Image[proposals.length];
		Image serviceImage = getImage("icons/proposals/service.gif"); //$NON-NLS-1$
		Image deprecatedServiceImage = getImage("icons/proposals/deprecatedService.gif"); //$NON-NLS-1$
		Image modelAttributeImage = getImage("icons/proposals/model_attribute.gif"); //$NON-NLS-1$
		Image modelReferenceImage = getImage("icons/proposals/model_reference.gif"); //$NON-NLS-1$
		Image modelOperationImage = getImage("icons/proposals/model_operation.gif"); //$NON-NLS-1$
		Map conflictFilter = new HashMap();
		Integer CONFLICT_FALSE = new Integer(0);
		Integer CONFLICT_TRUE = new Integer(1);
		Integer CONFLICT_SCRIPT_ONLY = new Integer(2);
		if (prefix == null) {
			for (int i = 0; i < proposals.length; i++) {
				String conflictString;
				if (proposals[i] instanceof Map.Entry) {
					Map.Entry entry = (Map.Entry) proposals[i];
					conflictString = ((ScriptDescriptor) entry.getKey()).getName();
				} else if (proposals[i] instanceof Method) {
					Method method = (Method) proposals[i];
					Class[] paramTypes = method.getParameterTypes();
					if (paramTypes.length > 1) {
						conflictString = null;
					} else {
						conflictString = method.getName();
					}
				} else if (proposals[i] instanceof EAttribute) {
					EAttribute attribute = (EAttribute) proposals[i];
					conflictString = attribute.getName();
				} else if (proposals[i] instanceof EReference) {
					EReference reference = (EReference) proposals[i];
					conflictString = reference.getName();
				} else if (proposals[i] instanceof EOperation) {
					EOperation operation = (EOperation) proposals[i];
					conflictString = operation.getName();
				} else {
					conflictString = null;
				}
				if (conflictString != null) {
					Integer conflictType = (Integer) conflictFilter.get(conflictString);
					if (conflictType == null) {
						conflictFilter.put(conflictString, (proposals[i] instanceof Map.Entry) ? CONFLICT_SCRIPT_ONLY : CONFLICT_FALSE);
					} else if (conflictType == CONFLICT_FALSE) {
						conflictFilter.put(conflictString, CONFLICT_TRUE);
					} else if (conflictType == CONFLICT_SCRIPT_ONLY) {
						if (!(proposals[i] instanceof Map.Entry)) {
							conflictFilter.put(conflictString, CONFLICT_TRUE);
						}
					}
				}
			}
		}
		for (int i = 0; i < replacementStrings.length; i++) {
			replacementStrings[i] = null;
			if (proposals[i] instanceof Map.Entry) {
				if (prefix == null || isScriptPrefix(prefix)) {
					Map.Entry entry = (Map.Entry) proposals[i];
					Integer conflictType = (Integer) conflictFilter.get(((ScriptDescriptor) entry.getKey()).getName());
					if (conflictType == CONFLICT_TRUE) {
						// Script has the best priority -> doesn't need a prefix
						replacementStrings[i] = ((ScriptDescriptor) entry.getKey()).getName();
					} else {
						replacementStrings[i] = ((ScriptDescriptor) entry.getKey()).getName();
					}
					String type = ((ScriptDescriptor) entry.getKey()).getType();
					int jDot = type.lastIndexOf("."); //$NON-NLS-1$
					if (jDot > -1)
						type = type.substring(jDot + 1);
					displayStrings[i] = ((ScriptDescriptor) entry.getKey()).getName() + " : " + type; //$NON-NLS-1$
					informationStrings[i] = ((ScriptDescriptor) entry.getKey()).toString();
					if (((ScriptDescriptor) entry.getKey()).getDescription() != null && ((ScriptDescriptor) entry.getKey()).getDescription().length() > 0) {
						informationStrings[i] = informationStrings[i] + "\n\n" + ((ScriptDescriptor) entry.getKey()).getDescription(); //$NON-NLS-1$
					}
					cursorPositions[i] = replacementStrings[i].length();
					images[i] = getImage(getTemplateIcon((ScriptDescriptor) entry.getKey()));
				}
			} else if (proposals[i] instanceof Method) {
				if (prefix == null || isJavaPrefix(prefix)) {
					Method method = (Method) proposals[i];
					Integer conflictType = (Integer) conflictFilter.get(method.getName());
					String replacementString;
					if (conflictType == CONFLICT_TRUE) {
						replacementString = TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR + method.getName() + '(';
					} else {
						replacementString = method.getName() + '(';
					}
					cursorPositions[i] = replacementString.length();
					String displayString = method.getName() + " ("; //$NON-NLS-1$
					Class[] paramTypes = method.getParameterTypes();
					for (int j = 1; j < paramTypes.length; j++) { // The first
						// parameter is
						// ignored
						Class paramType = paramTypes[j];
						displayString += EvalJavaService.getSimpleName(paramType);
						if (j + 1 < paramTypes.length) {
							replacementString += ", "; //$NON-NLS-1$
							displayString += ", "; //$NON-NLS-1$
						}
					}
					replacementString += ')';
					displayString += ')';
					if (method.getReturnType() != null) {
						displayString += ' ' + EvalJavaService.getSimpleName(method.getReturnType());
					}
					displayString += " - " + EvalJavaService.getSimpleName(method.getDeclaringClass()); //$NON-NLS-1$
					replacementStrings[i] = replacementString;
					displayStrings[i] = displayString;
					informationStrings[i] = method.toString();
					boolean isDeprecated = false;
					String className = EvalJavaService.getSimpleName(method.getDeclaringClass());
					if (className.equals("ENodeServices")) { //$NON-NLS-1$
						isDeprecated = ",cast,sepStr,until,minimize,reverse,sort,".indexOf(',' + method.getName() + ',') > -1; //$NON-NLS-1$
					} else if (className.equals("ContextServices")) { //$NON-NLS-1$
						isDeprecated = ",nGet,nPut,nPush,nPop,nPeek,".indexOf(',' + method.getName() + ',') > -1; //$NON-NLS-1$
					} else if (className.equals("RequestServices")) { //$NON-NLS-1$
						isDeprecated = "select,delete".indexOf(method.getName()) > -1; //$NON-NLS-1$
					}
					if (isDeprecated) {
						images[i] = deprecatedServiceImage;
					} else {
						images[i] = serviceImage;
					}
				}
			} else if (proposals[i] instanceof EAttribute) {
				if (prefix == null || isMetamodelPrefix(prefix)) {
					EAttribute attribute = (EAttribute) proposals[i];
					Integer conflictType = (Integer) conflictFilter.get(attribute.getName());
					if (conflictType == CONFLICT_TRUE) {
						replacementStrings[i] = TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR + attribute.getName();
					} else {
						replacementStrings[i] = attribute.getName();
					}
					cursorPositions[i] = replacementStrings[i].length();
					String displayString = attribute.getName();
					if (attribute.getEType() != null) {
						displayString += " : " + attribute.getEType().getName(); //$NON-NLS-1$
					}
					displayStrings[i] = displayString;
					informationStrings[i] = displayString;
					if (attribute.getEContainingClass() != null) {
						informationStrings[i] = informationStrings[i] + " - " + attribute.getEContainingClass().getName(); //$NON-NLS-1$
					}
					images[i] = modelAttributeImage;
				}
			} else if (proposals[i] instanceof EReference) {
				if (prefix == null || isMetamodelPrefix(prefix)) {
					EReference reference = (EReference) proposals[i];
					Integer conflictType = (Integer) conflictFilter.get(reference.getName());
					if (conflictType == CONFLICT_TRUE) {
						replacementStrings[i] = TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR + reference.getName();
					} else {
						replacementStrings[i] = reference.getName();
					}
					cursorPositions[i] = replacementStrings[i].length();
					String displayString = reference.getName();
					if (reference.getEType() != null) {
						int lowerBound = reference.getLowerBound();
						int upperBound = reference.getUpperBound();
						String bounds;
						if (lowerBound == upperBound) {
							bounds = String.valueOf(lowerBound);
						} else {
							bounds = lowerBound + ((upperBound != -1) ? ".." + upperBound : "..*"); //$NON-NLS-1$ //$NON-NLS-2$
						}
						if (reference.isContainment()) {
							bounds = '[' + bounds + ']';
						} else {
							bounds = '{' + bounds + '}';

						}
						if (reference.isDerived()) {
							bounds += " - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.DerivedReference"); //$NON-NLS-1$ //$NON-NLS-2$
						}
						displayString += " : " + reference.getEType().getName() + ' ' + bounds; //$NON-NLS-1$
					}
					displayStrings[i] = displayString;
					informationStrings[i] = displayString;
					if (reference.getEContainingClass() != null) {
						informationStrings[i] = informationStrings[i] + " - " + reference.getEContainingClass().getName(); //$NON-NLS-1$
					}
					images[i] = modelReferenceImage;
				}
			} else if (proposals[i] instanceof EOperation) {
				if (prefix == null || isMetamodelPrefix(prefix)) {
					EOperation operation = (EOperation) proposals[i];
					Integer conflictType = (Integer) conflictFilter.get(operation.getName());
					String replacementString = ""; //$NON-NLS-1$
					if (conflictType == CONFLICT_TRUE) {
						replacementString += TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR + operation.getName() + '(';
					} else {
						replacementString += operation.getName() + '(';
					}
					cursorPositions[i] = replacementString.length();
					String displayString = operation.getName() + " ("; //$NON-NLS-1$

					int paramSize = operation.getEParameters().size();
					for (int j = 0; j < paramSize; j++) {
						displayString += ((EParameter) operation.getEParameters().get(j)).getEType().getName();
						if (j + 1 < paramSize) {
							replacementString += ", "; //$NON-NLS-1$
							displayString += ", "; //$NON-NLS-1$
						}
					}
					displayString += ')';
					replacementString += ')';

					if (operation.getEType() != null) {
						displayString += ' ';
						if (operation.getUpperBound() == -1) {
							displayString += "EList <" + operation.getEType().getName() + ">"; //$NON-NLS-1$ //$NON-NLS-2$
						} else {
							displayString += operation.getEType().getName();
						}
					}
					displayString += " - " + operation.getEContainingClass().getName(); //$NON-NLS-1$

					replacementStrings[i] = replacementString;
					displayStrings[i] = displayString;
					informationStrings[i] = displayString;
					images[i] = modelOperationImage;
				}
			} else {
				replacementStrings[i] = proposals[i].toString();
				displayStrings[i] = proposals[i].toString();
				informationStrings[i] = proposals[i].toString();
				cursorPositions[i] = replacementStrings[i].length();
				images[i] = null;
			}
			if (endStart.startsWith(TemplateConstants.FEATURE_BEGIN) && replacementStrings[i] != null) {
				// For '<%link' proposals
				replacementStrings[i] = TemplateConstants.FEATURE_BEGIN + replacementStrings[i];
				cursorPositions[i] += TemplateConstants.FEATURE_BEGIN.length();
			}
		}
		return computeValidProposals(proposals, replacementStrings, displayStrings, informationStrings, cursorPositions, endStart, offset, images);
	}

	/**
	 * Computes predefined links proposals : i, args, startUserCode,
	 * endUserCode...
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computePredefinedLinksProposals(String text, int offset) {
		Image predefinedImage = getImage("icons/proposals/predefined.gif"); //$NON-NLS-1$
		String endStart = extractEndStart(text, offset);
		if (endStart.startsWith(TemplateConstants.FEATURE_BEGIN)) {
			String tab = extractTab(text, offset);
			final String[] PREDEFINED_REPLACE = { TemplateConstants.USER_BEGIN + '\n' + tab + '\n' + tab + TemplateConstants.USER_END + '\n' + tab, TemplateConstants.USER_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0] + 0 + TemplateConstants.PARENTH[1] + TemplateConstants.FEATURE_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.FEATURE_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR };
			final String[] PREDEFINED_DISPLAY = {
					TemplateConstants.USER_BEGIN_NAME + " - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.UserCodeStart"), TemplateConstants.USER_END_NAME + " - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.UserCodeEnd"), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
					TemplateConstants.LINK_NAME_ARGS + "(?) - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.TemplateArgument"), TemplateConstants.LINK_NAME_INDEX + " - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.CurrentIteration"), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
					TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR
							+ "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceMetamodel"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR + "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceScript"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR + "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceService") }; //$NON-NLS-1$ //$NON-NLS-2$
			final String[] PREDEFINED_INFORMATION = { TemplateConstants.USER_BEGIN + '\n' + '\n' + TemplateConstants.USER_END + '\n', TemplateConstants.USER_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0] + 0 + TemplateConstants.PARENTH[1] + TemplateConstants.FEATURE_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.FEATURE_END,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR };
			final int[] PREDEFINED_CURSOR = { (TemplateConstants.USER_BEGIN + '\n' + tab).length(), (TemplateConstants.USER_END).length(),
					(TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0]).length(),
					(TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1]).length(),
					(TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR).length(),
					(TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR).length(),
					(TemplateConstants.FEATURE_BEGIN + TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR).length() };
			Image[] images = new Image[PREDEFINED_REPLACE.length];
			for (int i = 0; i < images.length; i++) {
				images[i] = predefinedImage;
			}
			return computeValidProposals(null, PREDEFINED_REPLACE, PREDEFINED_DISPLAY, PREDEFINED_INFORMATION, PREDEFINED_CURSOR, endStart, offset, images);
		} else {
			final String[] PREDEFINED_REPLACE = { TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0] + 0 + TemplateConstants.PARENTH[1],
					TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1], TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR, TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR,
					"null", "true", "false" }; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
			final String[] PREDEFINED_DISPLAY = {
					TemplateConstants.LINK_NAME_ARGS + "(?) - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.TemplateArgument"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_NAME_INDEX + " - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.CurrentIteration"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR
							+ "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceMetamodel"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR + "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceScript"), //$NON-NLS-1$ //$NON-NLS-2$
					TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR + "? - " + AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.NamespaceService"), //$NON-NLS-1$ //$NON-NLS-2$
					"null", "true", "false" }; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
			final String[] PREDEFINED_INFORMATION = { TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0] + 0 + TemplateConstants.PARENTH[1],
					TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1], TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR,
					TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR, TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR,
					"null", "true", "false" }; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
			final int[] PREDEFINED_CURSOR = { (TemplateConstants.LINK_NAME_ARGS + TemplateConstants.PARENTH[0]).length(),
					(TemplateConstants.LINK_NAME_INDEX + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1]).length(),
					(TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR).length(),
					(TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR).length(), (TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR).length(),
					"null".length(), "true".length(), "false".length() }; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
			Image[] images = new Image[PREDEFINED_REPLACE.length];
			for (int i = 0; i < images.length; i++) {
				images[i] = predefinedImage;
			}
			return computeValidProposals(null, PREDEFINED_REPLACE, PREDEFINED_DISPLAY, PREDEFINED_INFORMATION, PREDEFINED_CURSOR, endStart, offset, images);
		}
	}

	/**
	 * Computes script declaration proposals.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeScriptProposals(String text, int offset) {
		String endStart = extractEndStart(text, offset);
		final String[] SCRIPT_REPLACE = { TemplateConstants.SCRIPT_BEGIN + TemplateConstants.SCRIPT_TYPE + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + TemplateConstants.LITERAL[0]
				+ TemplateConstants.LITERAL[1] + ' ' + TemplateConstants.SCRIPT_NAME + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + TemplateConstants.LITERAL[0] + TemplateConstants.LITERAL[1]
				+ TemplateConstants.SCRIPT_END };
		final String[] SCRIPT_DISPLAY = { AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptProposal") }; //$NON-NLS-1$
		final String[] SCRIPT_INFORMATION = { TemplateConstants.SCRIPT_BEGIN + TemplateConstants.SCRIPT_TYPE + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + TemplateConstants.LITERAL[0]
				+ TemplateConstants.LITERAL[1] + ' ' + TemplateConstants.SCRIPT_NAME + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + TemplateConstants.LITERAL[0] + TemplateConstants.LITERAL[1]
				+ TemplateConstants.SCRIPT_END };
		final int[] SCRIPT_CURSOR = { (TemplateConstants.SCRIPT_BEGIN + TemplateConstants.SCRIPT_TYPE + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + TemplateConstants.LITERAL[0]).length() };
		Image[] images = new Image[] { getImage("icons/proposals/statement.gif") }; //$NON-NLS-1$
		return computeValidProposals(null, SCRIPT_REPLACE, SCRIPT_DISPLAY, SCRIPT_INFORMATION, SCRIPT_CURSOR, endStart, offset, images);
	}

	/**
	 * Computes for statement proposals.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeForStatementProposals(String text, int offset) {
		String endStart = extractEndStart(text, offset);
		String tab = extractTab(text, offset);
		final String[] STATEMENT_REPLACE = { TemplateConstants.FOR_BEGIN + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.FOR_THEN + '\n' + tab
				+ TemplateConstants.FOR_END + '\n' + tab };
		final String[] STATEMENT_DISPLAY = { AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ForLoopProposal") }; //$NON-NLS-1$
		final String[] STATEMENT_INFORMATION = { TemplateConstants.FOR_BEGIN + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.FOR_THEN + '\n'
				+ TemplateConstants.FOR_END + '\n' };
		final int[] STATEMENT_CURSOR = { (TemplateConstants.FOR_BEGIN + TemplateConstants.PARENTH[0]).length() };
		Image[] images = new Image[] { getImage("icons/proposals/statement.gif") }; //$NON-NLS-1$
		return computeValidProposals(null, STATEMENT_REPLACE, STATEMENT_DISPLAY, STATEMENT_INFORMATION, STATEMENT_CURSOR, endStart, offset, images);
	}

	/**
	 * Gets the current tabulate text.
	 * <p>
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset
	 * @return the current tabulate text
	 */
	protected String extractTab(String text, int offset) {
		StringBuffer tab = new StringBuffer(""); //$NON-NLS-1$
		if (offset <= text.length()) {
			int iLine = text.substring(0, offset).lastIndexOf("\n"); //$NON-NLS-1$
			String s = text.substring(iLine + 1, offset);
			for (int i = 0; i < s.length(); i++) {
				char c = s.charAt(i);
				if (c == ' ' || c == '\t') {
					tab.append(c);
				}
			}
		}
		return tab.toString();
	}

	/**
	 * Computes other statements proposals.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeStatementsProposals(String text, int offset) {
		String endStart = extractEndStart(text, offset);
		String tab = extractTab(text, offset);
		final String[] STATEMENTS_REPLACE = {
				TemplateConstants.IF_BEGIN + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.IF_THEN + '\n' + tab + TemplateConstants.IF_ELSE + '\n' + tab
						+ TemplateConstants.IF_END + '\n' + tab, TemplateConstants.IF_ELSE, TemplateConstants.IF_END, TemplateConstants.COMMENT_BEGIN + "  " + TemplateConstants.COMMENT_END }; //$NON-NLS-1$
		final String[] STATEMENTS_DISPLAY = {
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.IfProposal"), AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ElseProposal"), AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.EndProposal"), AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.CommentProposal") }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
		final String[] STATEMENTS_INFORMATION = {
				TemplateConstants.IF_BEGIN + TemplateConstants.PARENTH[0] + TemplateConstants.PARENTH[1] + TemplateConstants.IF_THEN + '\n' + TemplateConstants.IF_ELSE + '\n'
						+ TemplateConstants.IF_END + '\n', TemplateConstants.IF_ELSE, TemplateConstants.IF_END, TemplateConstants.COMMENT_BEGIN + "  " + TemplateConstants.COMMENT_END }; //$NON-NLS-1$
		final int[] STATEMENTS_CURSOR = { (TemplateConstants.IF_BEGIN + TemplateConstants.PARENTH[0]).length(), TemplateConstants.IF_ELSE.length(), TemplateConstants.IF_END.length(),
				TemplateConstants.COMMENT_BEGIN.length() + 1 };
		Image[] images = new Image[STATEMENTS_REPLACE.length];
		Image statementImage = getImage("icons/proposals/statement.gif"); //$NON-NLS-1$
		for (int i = 0; i < images.length; i++) {
			images[i] = statementImage;
		}
		return computeValidProposals(null, STATEMENTS_REPLACE, STATEMENTS_DISPLAY, STATEMENTS_INFORMATION, STATEMENTS_CURSOR, endStart, offset, images);
	}

	/**
	 * Computes valid proposals (CompletionProposal).
	 * 
	 * @param objects
	 *            are the optional objects
	 * @param replacementStrings
	 *            are the replacement strings
	 * @param displayStrings
	 *            are the display strings
	 * @param informationStrings
	 *            are the information strings
	 * @param cursorPositions
	 *            are the cursor positions after the replacement
	 * @param start
	 *            is the start of the proposal
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param images
	 *            are the icons
	 * @return the proposals (CompletionProposal)
	 */
	protected List computeValidProposals(Object[] objects, String[] replacementStrings, String[] displayStrings, String[] informationStrings, int[] cursorPositions, String start, int offset,
			Image[] images) {
		List proposals = new ArrayList();
		String prefix = extractPrefix(start);
		if (prefix != null) {
			start = start.substring(prefix.length());
		}
		String startToLowerCase = start.toLowerCase();
		for (int i = 0; i < replacementStrings.length; i++) {
			String replacementString = replacementStrings[i];
			if (replacementString != null) {
				int cursorPosition = cursorPositions[i];
				if (prefix != null) {
					if (replacementString.startsWith(TemplateConstants.FEATURE_BEGIN)) {
						replacementString = replacementString.substring(TemplateConstants.FEATURE_BEGIN.length());
						cursorPosition = cursorPosition - TemplateConstants.FEATURE_BEGIN.length();
					}
				}
				String displayString = displayStrings[i];
				String informationString = informationStrings[i]; // ignore
				// informationStrings[i];
				Image image = images[i];
				String replacementStringL = replacementString.toLowerCase();
				if (start.length() == 0
						|| replacementStringL.startsWith(startToLowerCase)
						|| replacementStringL.indexOf(TemplateConstants.LINK_PREFIX_SEPARATOR
								+ ((startToLowerCase.startsWith(TemplateConstants.FEATURE_BEGIN)) ? startToLowerCase.substring(TemplateConstants.FEATURE_BEGIN.length()) : startToLowerCase)) > -1) {
					if (isAlternativeSyntax) {
						replacementString = replacementString.replaceAll("<%", "[%").replaceAll("%>", "%]"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
					}
					ICompletionProposal proposal = new CompletionProposal(replacementString, offset - start.length(), start.length(), cursorPosition, image, displayString, null, informationString);
					proposals.add(new AcceleoTemplateCompletionEntry(proposal, (objects != null) ? objects[i] : null));
				}
			}
		}
		return proposals;
	}

	/**
	 * Computes script header proposals : import and metamodel keywords...
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeHeaderProposals(String text, int offset) {
		String endStart = extractEndStart(text, offset);
		final String[] HEADER_REPLACE = { TemplateConstants.MODELTYPE_WORD + " ", TemplateConstants.IMPORT_BEGIN + TemplateConstants.MODELTYPE_WORD + " ", TemplateConstants.IMPORT_WORD + " " }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		final String[] HEADER_DISPLAY = { TemplateConstants.MODELTYPE_WORD, TemplateConstants.MODELTYPE_WORD, TemplateConstants.IMPORT_WORD };
		final String[] HEADER_INFORMATION = { TemplateConstants.MODELTYPE_WORD, TemplateConstants.MODELTYPE_WORD, TemplateConstants.IMPORT_WORD };
		final int[] HEADER_CURSOR = { TemplateConstants.MODELTYPE_WORD.length() + 1, (TemplateConstants.IMPORT_BEGIN + TemplateConstants.MODELTYPE_WORD).length() + 1,
				TemplateConstants.IMPORT_WORD.length() + 1 };
		Image[] images = new Image[HEADER_REPLACE.length];
		Image statementImage = getImage("icons/proposals/statement.gif"); //$NON-NLS-1$
		for (int i = 0; i < images.length; i++) {
			images[i] = statementImage;
		}
		return computeValidProposals(null, HEADER_REPLACE, HEADER_DISPLAY, HEADER_INFORMATION, HEADER_CURSOR, endStart, offset, images);
	}

	/**
	 * Computes script attribute proposals : name, type, desc, post and file
	 * keywords...
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the proposals
	 */
	protected List computeScriptAttributeProposals(String text, int offset) {
		String endStart = extractEndStart(text, offset);
		final String[] SCRIPT_ATTRIBUTE_REPLACE = {
				TemplateConstants.SCRIPT_NAME + "=\"\" ", TemplateConstants.SCRIPT_TYPE + "=\"\" ", TemplateConstants.SCRIPT_FILE + "=\"" + TemplateConstants.FEATURE_BEGIN + TemplateConstants.FEATURE_END + ".txt\" ", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
				TemplateConstants.SCRIPT_DESC + "=\"\" ", TemplateConstants.SCRIPT_POST + "=\"\" " }; //$NON-NLS-1$ //$NON-NLS-2$
		final String[] SCRIPT_ATTRIBUTE_DISPLAY = { AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptNameProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptTypeProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptFileProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptDescProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptPostProposal") }; //$NON-NLS-1$
		final String[] SCRIPT_ATTRIBUTE_INFORMATION = { AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptNameProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptTypeProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptFileProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptDescProposal"), //$NON-NLS-1$
				AcceleoGenUIMessages.getString("AcceleoTemplateCompletionProcessor.ScriptPostProposal") }; //$NON-NLS-1$
		final int[] SCRIPT_ATTRIBUTE_CURSOR = { TemplateConstants.SCRIPT_NAME.length() + 2, TemplateConstants.SCRIPT_TYPE.length() + 2, TemplateConstants.SCRIPT_FILE.length() + 4,
				TemplateConstants.SCRIPT_DESC.length() + 2, TemplateConstants.SCRIPT_POST.length() + 2 };
		Image[] images = new Image[SCRIPT_ATTRIBUTE_REPLACE.length];
		Image predefinedImage = getImage("icons/proposals/predefined.gif"); //$NON-NLS-1$
		for (int i = 0; i < images.length; i++) {
			images[i] = predefinedImage;
		}
		return computeValidProposals(null, SCRIPT_ATTRIBUTE_REPLACE, SCRIPT_ATTRIBUTE_DISPLAY, SCRIPT_ATTRIBUTE_INFORMATION, SCRIPT_ATTRIBUTE_CURSOR, endStart, offset, images);
	}

	/**
	 * Gets the prefix in the completion
	 * 
	 * @param start
	 *            is the start
	 * @return the prefix
	 */
	protected String extractPrefix(String start) {
		String prefix = null;
		if (start != null) {
			int prefixIndex = start.indexOf(TemplateConstants.LINK_PREFIX_SEPARATOR);
			if (prefixIndex > -1) {
				prefix = start.substring(0, prefixIndex + TemplateConstants.LINK_PREFIX_SEPARATOR.length());
			}
		}
		return prefix;
	}

	private boolean isScriptPrefix(String prefix) {
		String test = TemplateConstants.LINK_PREFIX_SCRIPT + TemplateConstants.LINK_PREFIX_SEPARATOR;
		return test.equals(prefix) || (TemplateConstants.FEATURE_BEGIN + test).equals(prefix);
	}

	private boolean isMetamodelPrefix(String prefix) {
		String test = TemplateConstants.LINK_PREFIX_METAMODEL + TemplateConstants.LINK_PREFIX_SEPARATOR;
		return test.equals(prefix) || (TemplateConstants.FEATURE_BEGIN + test).equals(prefix);
	}

	private boolean isJavaPrefix(String prefix) {
		String test = TemplateConstants.LINK_PREFIX_JAVA + TemplateConstants.LINK_PREFIX_SEPARATOR;
		return test.equals(prefix) || (TemplateConstants.FEATURE_BEGIN + test).equals(prefix);
	}

	/**
	 * Gets the default resolved type.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @return the default resolved type
	 */
	protected Object getDefaultType(String text, int offset) {
		return null;
	}

	/**
	 * Gets the "for" resolved type at the given position.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param currentType
	 *            is the current type of the metamodel
	 * @return the resolved type
	 */
	protected Object getForResolvedType(String text, int offset, Object currentType) {
		if (currentType != null && getGenerator() != null) {
			// Resolve 'for' statements at the offset of the current
			// template
			List forResolvers = getForResolvers(text, offset);
			if (forResolvers.size() > 0) {
				Iterator it = forResolvers.iterator();
				while (it.hasNext()) {
					TemplateCallSetExpression callSetResolver = (TemplateCallSetExpression) it.next();
					Iterator calls = callSetResolver.iterator();
					while (currentType != null && calls.hasNext()) {
						TemplateCallExpression call = (TemplateCallExpression) calls.next();
						currentType = getGenerator().resolveType(currentType, call);
					}
				}
			}
		}
		return currentType;
	}

	/**
	 * Gets the context for the current filter : [...]
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param currentType
	 *            is the current type of the metamodel
	 * @return the resolved type
	 */
	protected Object getFilterResolvedType(String text, int offset, Object currentType) {
		if (currentType != null) {
			int iFeature = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.FEATURE_BEGIN, 0, offset).e();
			if (iFeature > -1
					&& TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.FEATURE_END, iFeature, offset, TemplateConstants.SPEC, new String[][] { TemplateConstants.LITERAL }).b() == -1) {
				String feature = text.substring(iFeature, offset);
				int iOpenBracket = getOpenBracket(feature);
				if (iOpenBracket > -1) {
					while (iOpenBracket > 0 && Character.isSpaceChar(feature.charAt(iOpenBracket - 1))) {
						iOpenBracket--;
					}
					currentType = getFeatureResolvedType(feature.substring(0, iOpenBracket) + '.', iOpenBracket + 1, currentType);
				}
			}
		}
		return currentType;
	}

	/**
	 * Gets the "feature link" resolved type at the given position.
	 * 
	 * @param text
	 *            is the text
	 * @param offset
	 *            is the offset within the text for which completions should be
	 *            computed
	 * @param currentType
	 *            is the current type of the metamodel
	 * @return the resolved type
	 */
	protected Object getFeatureResolvedType(String text, int offset, Object currentType) {
		if (currentType != null && getGenerator() != null) {
			try {
				String beginStart = extractBeginStart(text, offset);
				String beginStartTmp = (beginStart.startsWith(TemplateConstants.FEATURE_BEGIN)) ? beginStart.substring(TemplateConstants.FEATURE_BEGIN.length()) : beginStart;
				TemplateCallSetExpression callSet = (TemplateCallSetExpression) TemplateCallSetExpression.fromString(beginStartTmp, new Int2(0, beginStartTmp.length()), getGenerator());
				if (callSet != null) {
					currentType = callSet.getRootResolver(currentType, getGenerator());
					Iterator calls = callSet.iterator();
					while (currentType != null && calls.hasNext()) {
						TemplateCallExpression call = (TemplateCallExpression) calls.next();
						currentType = getGenerator().resolveType(currentType, call);
					}
				}
			} catch (TemplateSyntaxException e) {
				// nothing
			}
		}
		return currentType;
	}

	/**
	 * Gets the last opened bracket.
	 * 
	 * @param text
	 *            is the text
	 * @return the index of the bracket, or -1
	 */
	protected int getOpenBracket(String text) {
		if (text.length() > 0) {
			int i = text.length();
			int level = 0;
			do {
				i--;
				char c = text.charAt(i);
				if (c == '"') {
					do {
						i--;
						c = text.charAt(i);
						if (c == '"' && (i < 1 || text.charAt(i - 1) != '\\')) {
							break;
						}
					} while (i > 0);
				} else if (c == BRACKETS[1]) {
					level++;
				} else if (c == BRACKETS[0]) {
					if (level == 0) {
						return i;
					} else {
						level--;
					}
				}
			} while (i > 0);
		}
		return -1;
	}

	private List getForResolvers(String text, int offset) {
		List forResolvers = new ArrayList();
		try {
			if (offset <= text.length()) {
				Int2 bScript = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.SCRIPT_BEGIN, 0, offset, null, TemplateConstants.INHIBS_SCRIPT_CONTENT);
				if (bScript.e() > -1) {
					int eScript = TextSearch.getDefaultSearch().blockIndexEndIn(text, TemplateConstants.SCRIPT_BEGIN, TemplateConstants.SCRIPT_END, bScript.b(), offset, false, TemplateConstants.SPEC,
							TemplateConstants.INHIBS_SCRIPT_DECLA).e();
					if (eScript > -1) {
						Int2 iFor = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.FOR_BEGIN, eScript, offset);
						while (iFor.e() > -1) {
							Int2 iThen = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.FOR_THEN, iFor.e(), offset, TemplateConstants.SPEC, TemplateConstants.INHIBS_EXPRESSION);
							if (iThen.b() > -1) {
								TemplateExpression condition = TemplateExpression.fromString(text, new Int2(iFor.e(), iThen.b()), getGenerator());
								// It is a for resolver only if index of FOR_END
								// is -1
								Int2 iEnd = TextSearch.getDefaultSearch().blockIndexEndIn(text, TemplateConstants.FOR_BEGIN, TemplateConstants.FOR_END, iFor.b(), offset, true, null,
										TemplateConstants.INHIBS_STATEMENT);
								if (iEnd.b() == -1) {
									List conditionParts = condition.getAllElements(TemplateCallSetExpression.class);
									if (conditionParts.size() > 0) {
										forResolvers.add(conditionParts.get(0));
									}
								}
								iFor = TextSearch.getDefaultSearch().indexIn(text, TemplateConstants.FOR_BEGIN, iThen.b(), offset);
							} else {
								iFor = Int2.NOT_FOUND;
							}
						}
					}
				}
			}
		} catch (TemplateSyntaxException e) {
			forResolvers.clear();
		}
		return forResolvers;
	}

	/**
	 * Removes the duplicated proposals.
	 * 
	 * @param matches
	 *            are the initial proposals
	 * @return the valid proposals
	 */
	protected List deleteDuplicatedProposals(List matches) {
		List resultCompletionProposals = new ArrayList();
		List resultDisplayStrings = new ArrayList();
		Iterator it = matches.iterator();
		while (it.hasNext()) {
			AcceleoTemplateCompletionEntry entry = (AcceleoTemplateCompletionEntry) it.next();
			if (!resultDisplayStrings.contains(entry.getProposal().getDisplayString())) {
				resultDisplayStrings.add(entry.getProposal().getDisplayString());
				resultCompletionProposals.add(entry);
			}
		}
		return resultCompletionProposals;
	}

	/* (non-Javadoc) */
	public IContextInformation[] computeContextInformation(ITextViewer viewer, int documentOffset) {
		return null;
	}

	/* (non-Javadoc) */
	public char[] getCompletionProposalAutoActivationCharacters() {
		return AUTO_ACTIVATION_CHARACTERS;
	}

	/* (non-Javadoc) */
	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	/* (non-Javadoc) */
	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

	/* (non-Javadoc) */
	public String getErrorMessage() {
		return null;
	}

}
