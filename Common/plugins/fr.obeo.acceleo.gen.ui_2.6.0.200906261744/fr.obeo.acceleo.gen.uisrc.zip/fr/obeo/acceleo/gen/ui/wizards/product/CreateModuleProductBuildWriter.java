package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductBuildWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductBuildWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductBuildWriter result = new CreateModuleProductBuildWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "source.. = src/" + NL + "output.. = bin/" + NL + "bin.includes = META-INF/,\\" + NL + "               .,\\" + NL + "               plugin.xml,\\" + NL + "               icons/,\\" + NL + "               about.html,\\" + NL + "               about.ini,\\" + NL + "               about.properties,\\" + NL + "               acceleoModule.product";
  protected final String TEXT_2 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    return stringBuffer.toString();
  }
}
