/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards.product;

import java.io.File;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.pde.internal.ui.util.SWTUtil;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Text;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * A page to configure a product export.
 * 
 * @author <a href="mailto:jonathan.musset@obeo.fr">Jonathan Musset</a>
 * 
 */
public class ProductExportWizardPage extends WizardPage {

	/**
	 * The destination folder.
	 */
	protected Text directoryText;

	/**
	 * A button to select the destination folder.
	 */
	protected Button browseDirectory;

	/**
	 * Constructor.
	 * 
	 * @param selection
	 *            is the current workbench selection
	 */
	public ProductExportWizardPage(IStructuredSelection selection) {
		super(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExport")); //$NON-NLS-1$
		setTitle(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardPageTitle")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardPageDesc")); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.verticalSpacing = 10;
		container.setLayout(layout);

		createDestinationGroup(container);

		pageChanged();
		if (getErrorMessage() != null) {
			setMessage(getErrorMessage());
			setErrorMessage(null);
		}
		setControl(container);
		Dialog.applyDialogFont(container);
	}

	/**
	 * Creates the destination group for this dialog page under the given parent
	 * composite.
	 * 
	 * @param parent
	 *            is the parent composite
	 */
	private void createDestinationGroup(Composite parent) {
		Composite composite = new Composite(parent, SWT.NONE);
		composite.setLayout(new GridLayout(2, false));
		composite.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		directoryText = new Text(composite, SWT.BORDER);
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		gd.horizontalIndent = 15;
		directoryText.setLayoutData(gd);
		directoryText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				pageChanged();
			}
		});

		browseDirectory = new Button(composite, SWT.PUSH);
		browseDirectory.setText(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ExportWizardBrowse")); //$NON-NLS-1$
		browseDirectory.setLayoutData(new GridData());
		SWTUtil.setButtonDimensionHint(browseDirectory);
		browseDirectory.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				chooseDestination();
			}
		});
	}

	/**
	 * Choose the destination folder.
	 */
	private void chooseDestination() {
		DirectoryDialog dialog = new DirectoryDialog(getShell(), SWT.SAVE);
		String path = directoryText.getText();
		if (path.trim().length() == 0)
			path = ResourcesPlugin.getWorkspace().getRoot().getLocation().toString();
		dialog.setFilterPath(path);
		dialog.setText(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ExportWizardDialogTitle")); //$NON-NLS-1$
		dialog.setMessage(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ExportWizardDialogMessage")); //$NON-NLS-1$
		String res = dialog.open();
		if (res != null) {
			directoryText.setText(res);
		}
	}

	/**
	 * This method is called when a widget has changed. It is typically used by
	 * the wizard to decide when it is okay to move on to the next page or
	 * finish up.
	 */
	protected void pageChanged() {
		String error;
		if (directoryText.getText().trim().length() == 0) {
			error = AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ExportWizardStatusNodirectory"); //$NON-NLS-1$
		} else {
			error = null;
		}
		setErrorMessage(error);
		setPageComplete(error == null);
	}

	/**
	 * Gets the destination folder.
	 * 
	 * @return the destination folder
	 */
	public String getDestination() {
		File dir = new File(directoryText.getText().trim());
		return dir.getAbsolutePath();
	}

}
