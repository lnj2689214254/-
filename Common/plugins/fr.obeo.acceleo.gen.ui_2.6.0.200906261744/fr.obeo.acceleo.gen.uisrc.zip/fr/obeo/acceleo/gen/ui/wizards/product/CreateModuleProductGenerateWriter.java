package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductGenerateWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductGenerateWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductGenerateWriter result = new CreateModuleProductGenerateWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "/*******************************************************************************" + NL + " * Copyright (c) 2008 Obeo." + NL + " * All rights reserved. This program and the accompanying materials" + NL + " * are made available under the terms of the Eclipse Public License v1.0" + NL + " * which accompanies this distribution, and is available at" + NL + " * http://www.eclipse.org/legal/epl-v10.html" + NL + " * " + NL + " * Contributors:" + NL + " *     Obeo - initial API and implementation" + NL + " *******************************************************************************/" + NL + "package ";
  protected final String TEXT_2 = ".runner;" + NL + "" + NL + "import java.io.File;" + NL + "" + NL + "import org.eclipse.core.resources.IContainer;" + NL + "import org.eclipse.core.runtime.CoreException;" + NL + "import org.eclipse.core.runtime.IProgressMonitor;" + NL + "import org.eclipse.emf.ecore.EObject;" + NL + "" + NL + "/**" + NL + " * This class provides a utility method to launch the module generation." + NL + " * " + NL + " * @author <a href=\"mailto:jonathan.musset@obeo.fr\">Jonathan Musset</a>" + NL + " * " + NL + " */" + NL + "public class AcceleoGenerate extends fr.obeo.acceleo.gen.runner.AcceleoGenerate {" + NL + "" + NL + "\t/**" + NL + "\t * Constructor." + NL + "\t *" + NL + "\t * @param templateID" + NL + "\t *            the plugin relative path of the template" + NL + "\t */" + NL + "\tpublic AcceleoGenerate(String templateID) {" + NL + "\t\tsuper(templateID);" + NL + "\t}" + NL + "\t" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see fr.obeo.acceleo.gen.runner.AcceleoGenerate#generate(org.eclipse.emf.ecore.EObject, org.eclipse.core.resources.IContainer, java.io.File, java.lang.StringBuffer, org.eclipse.core.runtime.IProgressMonitor)" + NL + "\t */" + NL + "\tpublic void generate(EObject model, IContainer target, File propertiesContainer, StringBuffer report, IProgressMonitor monitor) throws CoreException {" + NL + "\t\tsuper.generate(model, target, propertiesContainer, report, monitor);" + NL + "\t}" + NL + "" + NL + "}" + NL;
  protected final String TEXT_3 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    return stringBuffer.toString();
  }
}
