package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductMANIFESTWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductMANIFESTWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductMANIFESTWriter result = new CreateModuleProductMANIFESTWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "Manifest-Version: 1.0" + NL + "Bundle-ManifestVersion: 2" + NL + "Bundle-Name: Acceleo Module Product Plug-in" + NL + "Bundle-SymbolicName: ";
  protected final String TEXT_2 = ";singleton:=true" + NL + "Bundle-Version: 1.0.0.qualifier" + NL + "Bundle-Activator: ";
  protected final String TEXT_3 = ".Activator" + NL + "Bundle-Vendor: Eclipse.org" + NL + "Require-Bundle: org.eclipse.core.runtime," + NL + " org.eclipse.core.resources," + NL + " fr.obeo.acceleo.gen, ";
  protected final String TEXT_4 = NL + " ";
  protected final String TEXT_5 = ",";
  protected final String TEXT_6 = NL + " org.eclipse.emf.ecore" + NL + "Bundle-ActivationPolicy: lazy";
  protected final String TEXT_7 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_3);
    
 for (int i = 0; i < content.getPluginDependencies().size(); i++) {
    stringBuffer.append(TEXT_4);
    stringBuffer.append(content.getPluginDependencies().get(i));
    stringBuffer.append(TEXT_5);
    }
    stringBuffer.append(TEXT_6);
    stringBuffer.append(TEXT_7);
    return stringBuffer.toString();
  }
}
