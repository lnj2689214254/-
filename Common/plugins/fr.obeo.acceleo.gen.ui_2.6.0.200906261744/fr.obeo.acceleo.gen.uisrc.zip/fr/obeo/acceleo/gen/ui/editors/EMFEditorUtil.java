/*
 * Copyright (c) 2005-2008 Obeo.
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.tools.ui.graphics.AdapterUtils;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.swt.graphics.Image;

public class EMFEditorUtil {

	private static Map iconMap = new HashMap();

	/**
	 * Get the icon for a Classifier ecore element
	 * 
	 * @param proposal
	 * @param resolveNotFound
	 *            Automaticly fix a not found image (with Ecore icons)
	 * @return
	 */
	public static Image findImageFromClassifier(EClassifier proposal, boolean resolveNotFound) {

		Image icon = null;
		if (iconMap.containsKey(proposal)) { // cache
			icon = (Image) iconMap.get(proposal);
		} else {
			AdapterFactory adFac = AdapterUtils.findAdapterFactory(proposal);
			if (adFac == null) {
				if (resolveNotFound) {
					icon = findImageFromClassifier(proposal.eClass(), resolveNotFound); // use
					// ecore
					// icons
				}
			} else {
				if (proposal == EcorePackage.eINSTANCE.getEObject()) {
					/*
					 * The ecore adapter factory label provider has a special
					 * behavior for EObject so that it can simulate new images.
					 * We just want a nice image.
					 */
					icon = AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/eobject.gif"); //$NON-NLS-1$ // never
				} else {
					AdapterFactoryLabelProvider labelProvider = new AdapterFactoryLabelProvider(adFac);
					if (labelProvider != null && proposal instanceof EClass) {
						if (!((EClass) proposal).isAbstract() && !((EClass) proposal).isInterface()) { // concret
							// class
							EObject emptyObj = EcoreUtil.create((EClass) proposal);
							try {
								icon = labelProvider.getImage(emptyObj);
							} catch (NullPointerException e) {
								icon = AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/eobject.gif"); //$NON-NLS-1$
							}
						} else {
							if (resolveNotFound) {
								icon = findImageFromClassifier(proposal.eClass(), resolveNotFound); // use
								// ecore
								// icons
							}
						}
					} else {
						icon = AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/model_class.gif"); //$NON-NLS-1$ // never
						// reach
					}
					if (labelProvider != null && adFac instanceof ComposedAdapterFactory) {
						((ComposedAdapterFactory) adFac).removeListener(labelProvider);
					}

				}
			}
		}
		if (icon != null) {
			iconMap.put(proposal, icon);
		}
		return icon;
	}
}
