/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import java.io.File;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;

import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENodeException;

/**
 * A preview page of the reflective editor.
 * 
 * @author www.obeo.fr
 * 
 */
public interface IPreviewPart {

	/**
	 * Returns the name of the page.
	 * 
	 * @return the name of the page
	 */
	public String getName();

	/**
	 * @return settings that know available generators
	 */
	public AcceleoReflectiveSettings getSettings();

	/**
	 * Reset settings and refresh viewer.
	 */
	public void refresh();

	/**
	 * Select generator made with the given file.
	 * 
	 * @param file
	 *            which describes the generator
	 * @param chain
	 *            is the optional chain file
	 * @throws TemplateSyntaxExceptions
	 * @throws CoreException
	 */
	public void selectGenerator(File file, IFile chain) throws TemplateSyntaxExceptions, CoreException;

	/**
	 * Reload current generator.
	 * 
	 * @throws TemplateSyntaxExceptions
	 * @throws CoreException
	 */
	public void reloadGenerator() throws TemplateSyntaxExceptions, CoreException;

	/**
	 * Delete current generator and reload default.
	 * 
	 * @throws CoreException
	 */
	public void deleteGenerator() throws CoreException;

	/**
	 * @return the last target container used to generate files for the selected
	 *         object
	 */
	public IContainer getLastGenerateHierarchyContainer();

	/**
	 * @param lastGenerateHierarchyContainer
	 *            is the last target container used to generate files for the
	 *            selected object
	 */
	public void setLastGenerateHierarchyContainer(IContainer lastGenerateHierarchyContainer);

	/**
	 * @return the object currently selected
	 */
	public EObject getSelectedEObject();

	/**
	 * Generate files for the selected object.
	 * 
	 * @param targetContainer
	 *            is the target container
	 * @param progressMonitor
	 *            is the progress monitor
	 * @throws FactoryException
	 * @throws ENodeException
	 * @throws CoreException
	 */
	public void generate(IContainer targetContainer, IProgressMonitor progressMonitor) throws FactoryException, ENodeException, CoreException;

	/**
	 * Try to get current file corresponding to the selected object.
	 * 
	 * @return the file or null if it isn't found
	 */
	public IFile tryToGetCurrentFile();

	/**
	 * Launch an open link action. Try to get the declaration of the selected
	 * text.
	 */
	public void openLink();

}
