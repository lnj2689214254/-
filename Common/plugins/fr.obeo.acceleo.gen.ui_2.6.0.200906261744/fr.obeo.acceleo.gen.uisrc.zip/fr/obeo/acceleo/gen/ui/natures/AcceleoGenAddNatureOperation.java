/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.natures;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * Adds the generator nature to projects.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenAddNatureOperation implements IRunnableWithProgress {

	/**
	 * The projects
	 */
	protected List projects = new ArrayList();

	/**
	 * Constructor.
	 * 
	 * @param project
	 *            is a project
	 */
	public AcceleoGenAddNatureOperation(IProject project) {
		projects.add(project);
	}

	/**
	 * Constructor.
	 * 
	 * @param projects
	 *            is a list of projects
	 */
	public AcceleoGenAddNatureOperation(List projects) {
		this.projects = new ArrayList();
		Iterator it = projects.iterator();
		while (it.hasNext()) {
			Object element = it.next();
			if (element instanceof IProject) {
				this.projects.add(element);
			}
		}
	}

	/* (non-Javadoc) */
	public void run(IProgressMonitor monitor) {
		if (projects.size() > 0) {
			try {
				monitor.beginTask("", projects.size()); //$NON-NLS-1$
				monitor.subTask(AcceleoGenUIMessages.getString("AcceleoGenAddNatureOperation.Monitor.TaskAddNature")); //$NON-NLS-1$
				Iterator it = projects.iterator();
				while (it.hasNext()) {
					IProject project = (IProject) it.next();
					monitor.subTask(AcceleoGenUIMessages.getString("AcceleoGenAddNatureOperation.Monitor.SubTaskAddNature", new Object[] { project.getName() })); //$NON-NLS-1$
					IProjectDescription description = project.getDescription();
					String[] oldNatures = description.getNatureIds();
					String[] newNatures = new String[oldNatures.length + 1];
					System.arraycopy(oldNatures, 0, newNatures, 1, oldNatures.length);
					newNatures[0] = IAcceleoGenNature.NATURE_ID;
					description.setNatureIds(newNatures);
					project.setDescription(description, new SubProgressMonitor(monitor, 1));
				}
			} catch (CoreException e) {
				AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			}
			monitor.done();
		}
	}

}
