/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.scanner;

import fr.obeo.acceleo.gen.ui.editors.template.ColorManager;

/**
 * A scanner for detecting 'if' sequences.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateIfScanner extends AcceleoTemplateFeatureScanner {

	/**
	 * Constructor.
	 * 
	 * @param manager
	 *            is the color manager
	 */
	public AcceleoTemplateIfScanner(ColorManager manager) {
		super(manager, true);
	}

	/* (non-Javadoc) */
	public String getConfiguredContentType() {
		return AcceleoTemplatePartitionScanner.TEMPLATE_IF;
	}

}
