/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.IOpenListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.OpenEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.ui.resources.AcceleoWorkbenchLabelProvider;
import fr.obeo.acceleo.tools.ui.resources.CheckboxTreeAndListGroup;

/**
 * The role of this wizard page is to make a collection of all of the checked
 * resources.
 * 
 * @author www.obeo.fr
 */

public class AcceleoSelectFilesWizardPage extends WizardPage {

	/**
	 * The module extension point.
	 */
	private final static String MODULE_EXTENSION_ID = "fr.obeo.acceleo.gen.module"; //$NON-NLS-1$

	/**
	 * The selection group.
	 */
	private CheckboxTreeAndListGroup checkboxGroup;

	/**
	 * The min length of the selection.
	 */
	private int lower;

	/**
	 * The max length of the selection.
	 */
	private int upper;

	/**
	 * The extensions.
	 */
	private String[] extensions;

	/**
	 * Indicates if the module's resources are included.
	 */
	private boolean includePlugins;

	// Constants
	private final static int SELECTION_WIDGET_WIDTH = 400;

	private final static int SELECTION_WIDGET_HEIGHT = 300;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param lower
	 *            is the min length of the selection
	 * @param upper
	 *            is the max length of the selection
	 * @param extensions
	 *            is a table of extensions
	 * @param includePlugins
	 *            indicates if the module's resources are included
	 */
	public AcceleoSelectFilesWizardPage(String pageName, int lower, int upper, String[] extensions, boolean includePlugins) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoGenUIMessages.getString("AcceleoSelectFilesWizardPage.Description")); //$NON-NLS-1$
		this.lower = lower;
		this.upper = upper;
		this.extensions = extensions;
		this.includePlugins = includePlugins;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout containerLayout = new GridLayout();
		containerLayout.numColumns = 1;
		containerLayout.marginTop = 14;
		containerLayout.verticalSpacing = 9;
		containerLayout.marginLeft = 7;
		containerLayout.marginRight = 7;
		container.setLayout(containerLayout);
		AcceleoWorkbenchLabelProvider treeLabelProvider = new AcceleoWorkbenchLabelProvider();
		AcceleoWorkbenchLabelProvider listLabelProvider = new AcceleoWorkbenchLabelProvider();
		checkboxGroup = new CheckboxTreeAndListGroup(container, ResourcesPlugin.getWorkspace().getRoot(), getContentProvider(IResource.FOLDER | IResource.PROJECT | IResource.ROOT), treeLabelProvider,
				getContentProvider(IResource.FILE), listLabelProvider, SWT.NONE, SELECTION_WIDGET_WIDTH, SELECTION_WIDGET_HEIGHT);
		checkboxGroup.addCheckStateListener(new ICheckStateListener() {
			public void checkStateChanged(CheckStateChangedEvent event) {
				dialogChanged();
			}
		});
		checkboxGroup.getTreeViewer().addOpenListener(new IOpenListener() {
			public void open(OpenEvent event) {
				ISelection selection = event.getSelection();
				if (!selection.isEmpty() && selection instanceof StructuredSelection) {
					checkboxGroup.getTreeViewer().expandToLevel(((StructuredSelection) selection).getFirstElement(), CheckboxTreeViewer.ALL_LEVELS);
				}
			}
		});

		container.addControlListener(new ControlListener() {
			public void controlMoved(ControlEvent e) {
			}

			public void controlResized(ControlEvent e) {
				TableColumn[] columns = checkboxGroup.getListTable().getColumns();
				for (int i = 0; i < columns.length; i++) {
					columns[i].pack();
				}
			}
		});

		dialogChanged();
		setControl(container);
	}

	/**
	 * Returns the content provider.
	 * 
	 * @param resourceType
	 *            is the type of the resource
	 * @return the content provider
	 */
	private ITreeContentProvider getContentProvider(final int resourceType) {
		return new WorkbenchContentProvider() {
			public Object[] getChildren(Object o) {
				if (resourceType != IResource.FILE && o instanceof IExtensionRegistry) {
					IExtensionRegistry registry = (IExtensionRegistry) o;
					Set result = new TreeSet(new Comparator() {
						public int compare(Object arg0, Object arg1) {
							Bundle bundle0 = (Bundle) arg0;
							Bundle bundle1 = (Bundle) arg1;
							return bundle0.getSymbolicName().compareTo(bundle1.getSymbolicName());
						}
					});
					IExtensionPoint extensionPoint = registry.getExtensionPoint(MODULE_EXTENSION_ID);
					if (extensionPoint != null) {
						IExtension[] extensions = extensionPoint.getExtensions();
						for (int i = 0; i < extensions.length; i++) {
							IExtension extension = extensions[i];
							Bundle bundle = Platform.getBundle(extension.getNamespaceIdentifier());
							if (!result.contains(bundle)) {
								result.add(bundle);
							}
						}
					}
					return result.toArray();
				} else if (resourceType == IResource.FILE && o instanceof Bundle) {
					Bundle bundle = (Bundle) o;
					List result = new ArrayList();
					for (int j = 0; j < extensions.length; j++) {
						if ("*".equals(extensions[j])) { //$NON-NLS-1$
							result.clear();
							Enumeration enumeration = bundle.findEntries("/", "*", true); //$NON-NLS-1$ //$NON-NLS-2$
							while (enumeration != null && enumeration.hasMoreElements()) {
								Object child = enumeration.nextElement();
								if (child instanceof URL) {
									result.add(new Path(bundle.getSymbolicName()).append(((URL) child).getPath()));
								}
							}
							break;
						} else {
							Enumeration enumeration = bundle.findEntries("/", "*." + extensions[j], true); //$NON-NLS-1$ //$NON-NLS-2$
							while (enumeration != null && enumeration.hasMoreElements()) {
								Object child = enumeration.nextElement();
								if (child instanceof URL) {
									result.add(new Path(bundle.getSymbolicName()).append(((URL) child).getPath()));
								}
							}
						}
					}
					return result.toArray();
				} else if (resourceType == IResource.FILE && o instanceof IPath) {
					return new Object[0];
				} else if (o instanceof IContainer) {
					IResource[] members = null;
					try {
						members = ((IContainer) o).members();
					} catch (CoreException e) {
						return new Object[0];
					}
					ArrayList results = new ArrayList();
					for (int i = 0; i < members.length; i++) {
						if ((members[i].getType() & resourceType) > 0 && isSignificant(members[i])) {
							if (members[i] instanceof IFile) {
								String extension = members[i].getFileExtension();
								if (extension == null) {
									extension = ""; //$NON-NLS-1$
								}
								for (int j = 0; j < extensions.length; j++) {
									if ("*".equals(extensions[j]) || extension.equals(extensions[j])) { //$NON-NLS-1$
										results.add(members[i]);
										break;
									}
								}
							} else if (members[i] instanceof IContainer && countMembers((IContainer) members[i]) > 0) {
								results.add(members[i]);
							}
						}
					}
					if (includePlugins && o instanceof IWorkspaceRoot) {
						IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(MODULE_EXTENSION_ID);
						if (extensionPoint != null) {
							IExtension[] extensions = extensionPoint.getExtensions();
							if (extensions.length > 0) {
								results.add(Platform.getExtensionRegistry());
							}
						}
					}
					return results.toArray();
				} else if (o instanceof List) {
					List result = new ArrayList();
					Iterator it = ((List) o).iterator();
					while (it.hasNext()) {
						Object element = it.next();
						if (element instanceof IContainer) {
							if (((IContainer) element).isAccessible() && countMembers((IContainer) element) > 0) {
								result.add(element);
							}
						} else {
							result.add(element);
						}
					}
					return result.toArray();
				} else {
					return new Object[0];
				}
			}
		};
	}

	private int countMembers(IContainer container) {
		try {
			IResource[] members = container.members();
			int result = 0;
			for (int i = 0; i < members.length; i++) {
				if (isSignificant(members[i])) {
					if (members[i] instanceof IFile) {
						String extension = members[i].getFileExtension();
						if (extension == null) {
							extension = ""; //$NON-NLS-1$
						}
						for (int j = 0; j < extensions.length; j++) {
							if ("*".equals(extensions[j]) || extension.equals(extensions[j])) { //$NON-NLS-1$
								result++;
								break;
							}
						}
					} else if (members[i] instanceof IContainer) {
						result += countMembers((IContainer) members[i]);
					}
				}
			}
			return result;
		} catch (CoreException e) {
			return 0;
		}
	}

	private boolean isSignificant(IResource resource) {
		return !(resource instanceof IFolder && (resource.equals(Resources.getOutputFolder(resource.getProject())) || resource.getName().startsWith("."))); //$NON-NLS-1$
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		List items = getAllCheckedListItems();
		if (items.size() < lower) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectFilesWizardPage.Error.NotEnoughFiles")); //$NON-NLS-1$
			return;
		} else if (items.size() > upper && upper != -1) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectFilesWizardPage.Error.TooManyFiles")); //$NON-NLS-1$
			return;
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

	/**
	 * Returns the selected files.
	 * 
	 * @return the selected files
	 */
	public IPath[] getSelection() {
		List items = getAllCheckedListItems();
		return (IPath[]) items.toArray(new IPath[items.size()]);
	}

	private List getAllCheckedListItems() {
		List items = new ArrayList();
		Iterator resultEnum = checkboxGroup.getAllCheckedListItems();
		while (resultEnum.hasNext()) {
			Object member = resultEnum.next();
			if (member instanceof IFile) {
				items.add(((IFile) member).getFullPath());
			} else if (member instanceof IPath) {
				items.add((IPath) member);
			}
		}
		return items;
	}

}
