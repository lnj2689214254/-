/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.natures;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Nature for a generator project.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenNature implements IAcceleoGenNature {

	/**
	 * Builder identifier.
	 */
	protected static final String BUILDER_ID = AcceleoEcoreGenUiPlugin.getDefault().getID() + ".acceleoGenBuilder"; //$NON-NLS-1$

	/**
	 * The project to which this project nature applies.
	 */
	protected IProject project = null;

	/**
	 * Get a AcceleoGenNature for the project.
	 * 
	 * @return the new nature
	 * @param project
	 *            is the project
	 */
	public static AcceleoGenNature getDefault(IProject project) {
		try {
			AcceleoGenNature nature = (AcceleoGenNature) project.getNature(IAcceleoGenNature.NATURE_ID);
			return nature;
		} catch (CoreException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			return null;
		}
	}

	/* (non-Javadoc) */
	public IProject getProject() {
		return project;
	}

	/* (non-Javadoc) */
	public void setProject(IProject project) {
		this.project = project;
	}

	/* (non-Javadoc) */
	public List getGeneratorContainers() {
		List containers = new ArrayList();
		if (project.exists()) {
			IJavaProject javaProject = JavaCore.create(project);
			try {
				IClasspathEntry[] entries = javaProject.getResolvedClasspath(true);
				for (int i = 0; i < entries.length; i++) {
					IClasspathEntry entry = entries[i];
					if (entry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
						IFolder sourceFolder = ResourcesPlugin.getWorkspace().getRoot().getFolder(entry.getPath());
						if (sourceFolder.exists()) {
							containers.add(sourceFolder);
						}
					}
				}
			} catch (JavaModelException e) {
				AcceleoEcoreGenUiPlugin.getDefault().log(e, false);
			}
		}
		return containers;
	}

	/* (non-Javadoc) */
	public void configure() throws CoreException {
		endOfBuildSpec(BUILDER_ID);
	}

	/**
	 * Adds the given builder identifier to the build spec.
	 * 
	 * @param builderID
	 *            is the identifier of the builder
	 * @throws CoreException
	 */
	protected void endOfBuildSpec(String builderID) throws CoreException {
		IProjectDescription description = getProject().getDescription();
		ICommand[] commands = description.getBuildSpec();
		boolean found = false;
		for (int i = 0; i < commands.length; ++i) {
			if (commands[i].getBuilderName().equals(builderID)) {
				found = true;
				break;
			}
		}
		if (!found) {
			ICommand command = description.newCommand();
			command.setBuilderName(builderID);
			ICommand[] newCommands = new ICommand[commands.length + 1];
			System.arraycopy(commands, 0, newCommands, 0, commands.length);
			newCommands[commands.length] = command;
			description.setBuildSpec(newCommands);
			getProject().setDescription(description, null);
		}
	}

	/* (non-Javadoc) */
	public void deconfigure() throws CoreException {
	}

}
