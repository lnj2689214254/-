/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;

/**
 * Reset settings and refresh viewer.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceRefreshAction extends Action {

	/**
	 * The reflective editor
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 */
	public AcceleoSourceRefreshAction(AcceleoReflectiveEditor reflectiveEditor) {
		super(AcceleoGenUIMessages.getString("Editors.RefreshAction.label")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("Editors.RefreshAction.label")); //$NON-NLS-1$
		setToolTipText(AcceleoGenUIMessages.getString("Editors.RefreshAction.label")); //$NON-NLS-1$
		this.reflectiveEditor = reflectiveEditor;
	}

	/* (non-Javadoc) */
	public void run() {
		if (reflectiveEditor.getActivePreviewEditor() != null) {
			reflectiveEditor.getActivePreviewEditor().refresh();
		}
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/actions/refresh.gif"); //$NON-NLS-1$
	}

}
