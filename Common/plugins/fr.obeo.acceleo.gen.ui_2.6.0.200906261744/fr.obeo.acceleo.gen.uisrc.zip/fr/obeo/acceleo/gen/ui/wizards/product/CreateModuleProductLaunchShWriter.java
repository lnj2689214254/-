package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductLaunchShWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductLaunchShWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductLaunchShWriter result = new CreateModuleProductLaunchShWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "#!/bin/sh" + NL + "" + NL + "cd acceleo" + NL + "./acceleo -application ";
  protected final String TEXT_2 = " -gen ../acceleo.ini" + NL + "cd .." + NL + NL;
  protected final String TEXT_3 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(content.getApplicationID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    return stringBuffer.toString();
  }
}
