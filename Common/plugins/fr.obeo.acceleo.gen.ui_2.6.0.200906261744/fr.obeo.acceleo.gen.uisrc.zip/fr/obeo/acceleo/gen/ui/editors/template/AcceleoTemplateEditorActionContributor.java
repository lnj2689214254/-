/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.ITextEditor;

import fr.obeo.acceleo.gen.ui.popupMenus.CommentAreaAction;
import fr.obeo.acceleo.gen.ui.popupMenus.OpenDefinitionAction;
import fr.obeo.acceleo.gen.ui.popupMenus.ReferencesSearchAction;

/**
 * This class contributes global actions for the template editor
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateEditorActionContributor extends BasicTextEditorActionContributor {

	/* (non-Javadoc) */
	public void setActiveEditor(IEditorPart part) {
		super.setActiveEditor(part);
		if (!(part instanceof ITextEditor))
			return;
		IActionBars actionBars = getActionBars();
		if (actionBars == null)
			return;
		// setting the binding for the open definition action
		Action openAction = new OpenDefinitionAction();
		openAction.setActionDefinitionId(OpenDefinitionAction.ACTION_ID);
		actionBars.setGlobalActionHandler(OpenDefinitionAction.COMMAND_ID, openAction);
		// setting the binding for the comment action
		Action commentAction = new CommentAreaAction();
		commentAction.setActionDefinitionId(CommentAreaAction.ACTION_ID);
		actionBars.setGlobalActionHandler(CommentAreaAction.COMMAND_ID, commentAction);
		// setting the binding for the search references action
		Action referencesAction = new ReferencesSearchAction();
		referencesAction.setActionDefinitionId(ReferencesSearchAction.ACTION_ID);
		actionBars.setGlobalActionHandler(ReferencesSearchAction.COMMAND_ID, referencesAction);
	}

}
