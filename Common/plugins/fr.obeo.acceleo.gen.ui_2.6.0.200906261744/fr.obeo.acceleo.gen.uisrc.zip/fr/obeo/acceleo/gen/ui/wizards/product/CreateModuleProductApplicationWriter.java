package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductApplicationWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductApplicationWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductApplicationWriter result = new CreateModuleProductApplicationWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "/*******************************************************************************" + NL + " * Copyright (c) 2008 Obeo." + NL + " * All rights reserved. This program and the accompanying materials" + NL + " * are made available under the terms of the Eclipse Public License v1.0" + NL + " * which accompanies this distribution, and is available at" + NL + " * http://www.eclipse.org/legal/epl-v10.html" + NL + " * " + NL + " * Contributors:" + NL + " *     Obeo - initial API and implementation" + NL + " *******************************************************************************/" + NL + "package ";
  protected final String TEXT_2 = ".runner;" + NL + "" + NL + "/**" + NL + " * Platform runnables represent executable entry points into" + NL + " * plug-ins. This class can be used to launch a module outside of eclipse." + NL + " * <p>" + NL + " * The command to launch a generation is : java -cp startup.jar" + NL + " * org.eclipse.core.launcher.Main -application ";
  protected final String TEXT_3 = ".launch -gen ./acceleo.ini" + NL + " * <p>" + NL + " * " + NL + " * @author <a href=\"mailto:jonathan.musset@obeo.fr\">Jonathan Musset</a>" + NL + " * " + NL + " */" + NL + "public class GenRunner extends fr.obeo.acceleo.gen.runner.GenRunner {" + NL + "" + NL + "\t/**" + NL + "\t * Constructor." + NL + "\t */" + NL + "\tpublic GenRunner() {" + NL + "\t\tsuper();" + NL + "\t}" + NL + "\t" + NL + "\t/* (non-Javadoc)" + NL + "\t * @see fr.obeo.acceleo.gen.runner.GenRunner#createGenerator(java.lang.String)" + NL + "\t */" + NL + "\tprotected fr.obeo.acceleo.gen.runner.AcceleoGenerate createGenerator(String templateID) {" + NL + "\t\treturn new AcceleoGenerate(templateID);" + NL + "\t}" + NL + "" + NL + "}";
  protected final String TEXT_4 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(content.getProductID());
    stringBuffer.append(TEXT_3);
    stringBuffer.append(TEXT_4);
    return stringBuffer.toString();
  }
}
