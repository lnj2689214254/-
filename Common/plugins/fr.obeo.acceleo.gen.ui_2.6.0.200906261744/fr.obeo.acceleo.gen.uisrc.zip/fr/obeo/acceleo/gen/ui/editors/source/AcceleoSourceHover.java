/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.texteditor.MarkerAnnotation;

import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.tools.strings.Int2;

/**
 * Source hover for text and annotation.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceHover implements ITextHover, IAnnotationHover {

	/**
	 * Source editor.
	 */
	protected AcceleoSourceEditor editor;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the source editor
	 */
	public AcceleoSourceHover(AcceleoSourceEditor editor) {
		this.editor = editor;
	}

	/**
	 * Hover text for an annotation at the given line.
	 * 
	 * @param model
	 *            is the annotation model
	 * @param document
	 *            is the current document
	 * @param lineNumber
	 *            is the line number
	 * @return hover text
	 */
	protected String getHoverText(IAnnotationModel model, IDocument document, int lineNumber) {
		StringBuffer text = null;
		Iterator annotations = findAnnotations(model, document, lineNumber).iterator();
		while (annotations.hasNext()) {
			Annotation annotation = (Annotation) annotations.next();
			String msg = null;
			if (annotation instanceof AcceleoSourceErrorAnnotation)
				msg = ((AcceleoSourceErrorAnnotation) annotation).getMessage();
			else if (annotation instanceof MarkerAnnotation) {
				try {
					msg = (String) ((MarkerAnnotation) annotation).getMarker().getAttribute(IMarker.MESSAGE);
				} catch (CoreException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}
			if (msg != null) {
				if (text == null)
					text = new StringBuffer(msg);
				else {
					text.append('\n');
					text.append(msg);
				}
			}
		}
		return text != null ? text.toString() : null;
	}

	private List findAnnotations(IAnnotationModel model, IDocument document, int lineNumber) {
		List annotations = new ArrayList();
		if (model == null) {
			if (editor != null) {
				model = editor.getDocumentProvider().getAnnotationModel(editor.getEditorInput());
			}
		}
		if (model == null)
			return annotations;
		for (Iterator it = model.getAnnotationIterator(); it.hasNext();) {
			Annotation annotation = (Annotation) it.next();
			Position position = model.getPosition(annotation);
			try {
				if (document != null && document.getLineOfOffset(position.offset) == lineNumber) {
					annotations.add(annotation);
				}
			} catch (BadLocationException e) {
			}
		}
		return annotations;
	}

	/**
	 * Hover text for a source region. Show template used to generate the
	 * current selected object.
	 * 
	 * @param region
	 *            of the document
	 * @param model
	 *            is the annotation model
	 * @param lineNumber
	 *            is the line number
	 * @return default template text for the current selected object
	 */
	protected String getHoverText(IRegion region, IAnnotationModel model, int lineNumber) {
		try {
			if (region == null)
				return null;
			if (editor.eval != null) {
				if (editor.eval.getTextTemplateElementMapping() != null) {
					TemplateElement element = editor.eval.getTextTemplateElementMapping().index2TemplateElement(region.getOffset());
					if (element != null) {
						String text = element.toString();
						if (text != null && text.length() > 0) {
							return text;
						}
					}
				}
				if (editor.eval.getTextModelMapping() != null) {
					EObject object = editor.eval.getTextModelMapping().index2EObject(region.getOffset());
					if (object != null) {
						String result = ""; //$NON-NLS-1$
						String elementId = EFactory.eGetAsString(object, "elementId"); //$NON-NLS-1$
						if (elementId != null) {
							result += "ID=" + elementId + '\n'; //$NON-NLS-1$
						}
						String write = EFactory.eGetAsString(object, "write"); //$NON-NLS-1$
						if (write != null) {
							result += TemplateConstants.SCRIPT_TYPE + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + object.eClass().getName() + '\n' + write;
						}
						return result;
					}
				}
			}
		} catch (FactoryException e) {
		}
		return null;
	}

	/* (non-Javadoc) */
	public String getHoverInfo(ISourceViewer sourceViewer, int lineNumber) {
		String text = getHoverText(sourceViewer.getAnnotationModel(), sourceViewer.getDocument(), lineNumber);
		return text;
	}

	/* (non-Javadoc) */
	public String getHoverInfo(ITextViewer textViewer, IRegion hoverRegion) {
		String text = getHoverText(hoverRegion, textViewer instanceof ISourceViewer ? ((ISourceViewer) textViewer).getAnnotationModel() : null, 0);
		return text;
	}

	/* (non-Javadoc) */
	public IRegion getHoverRegion(ITextViewer textViewer, int offset) {
		if (editor.eval != null && offset >= 0) {
			if (editor.eval.getTextTemplateElementMapping() != null) {
				TemplateElement element = editor.eval.getTextTemplateElementMapping().index2TemplateElement(offset);
				if (element != null) {
					Int2[] positions = editor.eval.getTextTemplateElementMapping().template2Positions(element);
					for (int i = 0; i < positions.length; i++) {
						Int2 pos = positions[i];
						if (pos != null && pos.b() > -1 && pos.b() <= offset && pos.e() > offset) {
							Int2 posComment = editor.eval.getTextTemplateElementMapping().template2CommentPositionIn(element, pos);
							if (posComment != null && posComment.e() > -1) {
								return new Region(posComment.e(), 1);
							} else {
								return new Region(pos.b(), 1);
							}
						}
					}
				}
			}
			if (editor.eval.getTextModelMapping() != null) {
				EObject object = editor.eval.getTextModelMapping().index2EObject(offset);
				if (object != null) {
					Int2[] positions = editor.eval.getTextModelMapping().eObject2Positions(object);
					for (int i = 0; i < positions.length; i++) {
						Int2 pos = positions[i];
						if (pos != null && pos.b() > -1 && pos.b() <= offset && pos.e() > offset) {
							Int2 posComment = editor.eval.getTextModelMapping().eObject2CommentPositionIn(object, pos);
							if (posComment != null && posComment.e() > -1) {
								return new Region(posComment.e(), 1);
							} else {
								return new Region(pos.b(), 1);
							}
						}
					}
				}
			}
		}
		return null;
	}

}
