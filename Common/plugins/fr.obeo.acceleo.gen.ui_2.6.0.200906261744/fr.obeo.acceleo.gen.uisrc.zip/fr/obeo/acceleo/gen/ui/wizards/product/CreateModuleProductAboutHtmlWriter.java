package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductAboutHtmlWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductAboutHtmlWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductAboutHtmlWriter result = new CreateModuleProductAboutHtmlWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\">" + NL + "<html>" + NL + "<head>" + NL + "<title>About Acceleo</title>" + NL + "<meta http-equiv=Content-Type content=\"text/html; charset=ISO-8859-1\">" + NL + "</head>" + NL + "<body lang=\"EN-US\">" + NL + "<h2>License</h2>" + NL + "" + NL + "<h3>Acceleo</h3>" + NL + "" + NL + "<p>This version of Acceleo and the accompanying materials" + NL + "are made available under the terms of the Eclipse Public License v1.0" + NL + "which accompanies this distribution, and is available at" + NL + "http://www.eclipse.org/legal/epl-v10.html</p>" + NL + "" + NL + "<h3>Copyright</h3>" + NL + "" + NL + "<p>All copyrights on Acceleo are owned by Obeo." + NL + "Acceleo is a trademark owned by Obeo.</p>" + NL + "" + NL + "<p>More informations can be found on the Acceleo web site : http://www.acceleo.org</p>" + NL + "</body>" + NL + "</html>";
  protected final String TEXT_2 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) argument;

    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    return stringBuffer.toString();
  }
}
