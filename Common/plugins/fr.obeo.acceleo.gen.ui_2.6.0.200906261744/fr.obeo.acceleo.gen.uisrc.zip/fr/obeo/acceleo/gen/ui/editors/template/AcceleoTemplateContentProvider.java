/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import java.util.Map;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateNodeElement;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.template.statements.TemplateFeatureStatement;
import fr.obeo.acceleo.gen.template.statements.TemplateForStatement;
import fr.obeo.acceleo.gen.template.statements.TemplateIfStatement;

/**
 * The content provider for the objects shown in the outline view of the
 * template editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateContentProvider implements ITreeContentProvider {

	/**
	 * Template editor.
	 */
	protected AcceleoTemplateEditor editor;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the template editor
	 */
	public AcceleoTemplateContentProvider(AcceleoTemplateEditor editor) {
		super();
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
	}

	/* (non-Javadoc) */
	public Object[] getChildren(Object parent) {
		if (parent instanceof Map.Entry) {
			return ((Template) ((Map.Entry) parent).getValue()).getChildren(new Class[] { TemplateForStatement.class, TemplateIfStatement.class, TemplateFeatureStatement.class },
					new Class[] { Template.class });
		} else if (parent instanceof TemplateIfStatement) {
			return ((TemplateIfStatement) parent).getChildren(new Class[] { Template.class }, new Class[] {});
		} else if (parent instanceof TemplateNodeElement) {
			return ((TemplateNodeElement) parent).getChildren(new Class[] { TemplateForStatement.class, TemplateIfStatement.class, TemplateFeatureStatement.class }, new Class[] { Template.class });
		} else {
			return new Object[] {};
		}
	}

	/* (non-Javadoc) */
	public Object getParent(Object element) {
		if (element instanceof Map.Entry) {
			return null;
		} else if (element instanceof TemplateNodeElement) {
			return ((TemplateNodeElement) element).getParent();
		} else {
			return null;
		}
	}

	/* (non-Javadoc) */
	public boolean hasChildren(Object element) {
		return getChildren(element).length > 0;
	}

	/* (non-Javadoc) */
	public Object[] getElements(Object inputElement) {
		SpecificScript model = editor.getGenerator();
		if (model != null) {
			return model.getTextTemplates().entrySet().toArray();
		} else {
			return new Object[] {};
		}
	}

	/* (non-Javadoc) */
	public void dispose() {
	}

}
