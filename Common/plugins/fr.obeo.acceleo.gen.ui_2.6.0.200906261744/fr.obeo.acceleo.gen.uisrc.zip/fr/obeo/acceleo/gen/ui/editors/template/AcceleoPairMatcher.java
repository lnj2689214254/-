/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITypedRegion;
import org.eclipse.jface.text.Region;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplatePartitionScanner;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * Helper class for match pairs of Acceleo special characters.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoPairMatcher extends DefaultCharacterPairMatcher {

	/**
	 * blocks used by aggregated the matcher
	 */
	protected final static char[] BLOCKS = { '(', ')', '[', ']' };

	/**
	 * The aggregated matcher, it is used for trivial block matching.
	 */
	protected DefaultCharacterPairMatcher aggregatedMatcher;

	/**
	 * Create a new Matcher for Acceleo blocks
	 */
	public AcceleoPairMatcher() {
		super(new char[0]);
		aggregatedMatcher = new DefaultCharacterPairMatcher(BLOCKS);

	}

	/* @see ICharacterPairMatcher#match(IDocument, int) */
	public IRegion match(IDocument document, int offset) {
		try {
			return performMatch(document, offset);
		} catch (BadLocationException ble) {
			return null;
		}
	}

	/*
	 * Performs the actual work of matching for #match(IDocument, int).
	 */
	private IRegion performMatch(IDocument document, int offset) throws BadLocationException {
		if (offset < 0 || document == null)
			return null;
		final char prevChar = document.getChar(Math.max(offset - 1, 0));
		if (isInStaticZone(document, offset)) {
			return null;
		}
		if (!isInStaticZone(document, offset) && prevChar != ')' && prevChar != '(') {
			{
				if (!isInIfZone(document, offset)) {
					if (!isInForZone(document, offset)) {
						ITypedRegion dynamicArea = document.getPartition(offset);
						return dynamicArea;
					} else {
						/*
						 * we are in a for
						 */
						ITypedRegion forRegion = document.getPartition(offset);
						String endContent = document.get();
						Int2 endIndex = getEndIndex(endContent, TemplateConstants.FOR_BEGIN, TemplateConstants.FOR_END, new Int2(forRegion.getOffset(), document.get().length()));
						if (endIndex != Int2.NOT_FOUND) {
							int start = forRegion.getOffset() + forRegion.getLength() - 3;
							int end = endIndex.e() - start - 2;
							IRegion result = new Region(start, end);
							return result;
						}
					}
				} else {
					/*
					 * we are in a if
					 */
					String content = document.get();

					ITypedRegion ifRegion = document.getPartition(offset);
					Int2 endIndex = Int2.NOT_FOUND;
					if (!isInElseIfZone(document, offset)) {
						endIndex = getEndIndex(content, TemplateConstants.IF_BEGIN, TemplateConstants.IF_END, new Int2(ifRegion.getOffset(), document.get().length()));
					} else {
						endIndex = getEndIndex(content, TemplateConstants.IF_ELSE_IF, TemplateConstants.IF_END, new Int2(ifRegion.getOffset(), document.get().length()));
					}
					if (endIndex != Int2.NOT_FOUND) {
						int start = ifRegion.getOffset() + ifRegion.getLength() - 3;
						int end = endIndex.e() - start - 2;
						IRegion result = new Region(start, end);
						return result;
					}
				}
			}
		}
		final IRegion region = aggregatedMatcher.match(document, offset);
		return region;
	}

	/**
	 * 
	 * @param document
	 *            current document.
	 * @param offset
	 *            current position in the document.
	 * @return true if the current position is in an "for" condition block,
	 *         false otherwise.
	 * @throws BadLocationException
	 */
	private boolean isInForZone(IDocument document, int offset) throws BadLocationException {
		ITypedRegion region = document.getPartition(offset);
		return (region.getType().equals(AcceleoTemplatePartitionScanner.TEMPLATE_FOR));
	}

	/**
	 * 
	 * @param document
	 *            current document.
	 * @param offset
	 *            current position in the document.
	 * @return true if the current position is in an "If" condition block, false
	 *         otherwise.
	 * @throws BadLocationException
	 */
	private boolean isInIfZone(IDocument document, int offset) {
		ITypedRegion region;
		try {
			region = document.getPartition(offset);
			return (region.getType().equals(AcceleoTemplatePartitionScanner.TEMPLATE_IF));
		} catch (BadLocationException e) {
		}
		return false;
	}

	/**
	 * 
	 * @param document
	 *            the current document.
	 * @param offset
	 *            the current offset.
	 * @return true if we are in an else if zone, false otherwhise.
	 */
	private boolean isInElseIfZone(IDocument document, int offset) {
		ITypedRegion region;
		try {
			region = document.getPartition(offset);
			return isInIfZone(document, offset) && document.get(region.getOffset(), region.getLength()).indexOf("else") != -1; //$NON-NLS-1$
		} catch (BadLocationException e) {
		}
		return false;
	}

	/**
	 * 
	 * @param document
	 *            current document.
	 * @param offset
	 *            current position in the document.
	 * @return true if the current position is in a static text block, false
	 *         otherwise.
	 * @throws BadLocationException
	 */
	private boolean isInStaticZone(IDocument document, int offset) {
		try {
			ITypedRegion region = document.getPartition(offset);
			return (region.getType().equals("__dftl_partition_content_type")); //$NON-NLS-1$
		} catch (BadLocationException e) {
		}
		return false;
	}

	/**
	 * 
	 * @param buffer
	 *            buffer in which you want to search.
	 * @param tagBegin
	 *            tag to start the search.
	 * @param tagEnd
	 *            tag to end the search.
	 * @param limits
	 *            limits to keep while searching.
	 * @return the position of the researched tag.
	 */
	private Int2 getEndIndex(String buffer, String tagBegin, String tagEnd, Int2 limits) {
		Int2 end = Int2.NOT_FOUND;
		Int2 begin = TextSearch.getDefaultSearch().indexIn(buffer, tagBegin, limits.b(), limits.e());
		end = TextSearch.getDefaultSearch().blockIndexEndIn(buffer, tagBegin, tagEnd, begin.b(), limits.e(), true, null, TemplateConstants.INHIBS_STATEMENT);
		return end;
	}

}
