/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.ui.internal.ide.misc.ContainerSelectionGroup;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * The page for choosing a container.
 * 
 * @author www.obeo.fr
 */

public class AcceleoSelectContainerWizardPage extends WizardPage {

	/**
	 * The widget group.
	 */
	protected ContainerSelectionGroup group;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 */
	public AcceleoSelectContainerWizardPage(String pageName) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoGenUIMessages.getString("AcceleoSelectContainerWizardPage.Description")); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 1;
		layout.verticalSpacing = 9;

		Listener listener = new Listener() {
			public void handleEvent(Event event) {
			}
		};

		group = new ContainerSelectionGroup(container, listener, false, getMessage(), false);

		dialogChanged();
		setControl(container);
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		IContainer container = getSelection();
		if (container == null) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectContainerWizardPage.Error.InvalidContainer")); //$NON-NLS-1$
			return;
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

	/**
	 * Returns the selected container.
	 * 
	 * @return the selected container
	 */
	public IContainer getSelection() {
		IPath path = group.getContainerFullPath();
		IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(path);
		if (resource != null && resource.exists() && resource instanceof IContainer) {
			return (IContainer) resource;
		} else {
			return null;
		}
	}

}
