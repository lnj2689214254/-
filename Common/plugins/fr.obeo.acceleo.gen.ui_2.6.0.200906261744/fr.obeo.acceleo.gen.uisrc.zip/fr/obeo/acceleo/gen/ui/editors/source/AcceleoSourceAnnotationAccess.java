/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import org.eclipse.jface.text.source.Annotation;
import org.eclipse.ui.texteditor.DefaultMarkerAnnotationAccess;

/**
 * Class for accessing marker annotation properties.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceAnnotationAccess extends DefaultMarkerAnnotationAccess {

	/**
	 * Constructor.
	 */
	public AcceleoSourceAnnotationAccess() {
		super();
	}

	/* (non-Javadoc) */
	public Object getType(Annotation annotation) {
		if (annotation instanceof AcceleoSourceErrorAnnotation) {
			return ((AcceleoSourceErrorAnnotation) annotation).getType();
		}
		return super.getType(annotation);
	}

	/* (non-Javadoc) */
	public boolean isMultiLine(Annotation annotation) {
		return true;
	}

	/* (non-Javadoc) */
	public boolean isTemporary(Annotation annotation) {
		return false;
	}

}
