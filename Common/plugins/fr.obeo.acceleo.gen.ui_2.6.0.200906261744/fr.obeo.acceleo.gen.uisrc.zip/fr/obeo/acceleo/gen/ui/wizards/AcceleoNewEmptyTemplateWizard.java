/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateSyntaxException;
import fr.obeo.acceleo.gen.template.scripts.ScriptDescriptor;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.template.scripts.imports.EvalModel;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.strings.Int2;

/**
 * The role of this wizard is to create an empty template.
 * 
 * @author www.obeo.fr
 */
public class AcceleoNewEmptyTemplateWizard extends Wizard implements INewWizard {

	/**
	 * The page to select a metamodel.
	 */
	protected AcceleoSelectMetamodelWizardPage pageSelectMetamodel;

	/**
	 * The page to create a new file.
	 */
	protected AcceleoNewFileWizardPage pageNewFile;

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoNewEmptyTemplateWizard() {
		super();
		setNeedsProgressMonitor(true);
		setDefaultPageImageDescriptor(AcceleoEcoreGenUiPlugin.getImageDescriptor("images/newTemplate.png")); //$NON-NLS-1$        
	}

	/* (non-Javadoc) */
	public void addPages() {
		addPage(pageSelectMetamodel = new AcceleoSelectMetamodelWizardPage(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Page1.Title"), new String[] { "ecore" }, true)); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageNewFile = new AcceleoNewFileWizardPage(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Page2.Title"), selection, SpecificScript.GENERATORS_EXTENSION)); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String metamodelURI = pageSelectMetamodel.getMetamodelURI();
		final String metamodelType = pageSelectMetamodel.getMetamodelType();
		final String containerName = pageNewFile.getContainerName();
		final String fileName = pageNewFile.getFileName();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(metamodelURI, metamodelType, containerName, fileName, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e.getTargetException(), true);
			return false;
		}
		return true;
	}

	private void doFinish(String metamodelURI, String metamodelType, String containerName, String fileName, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Monitor.TaskCreating", new Object[] { fileName }), 2); //$NON-NLS-1$
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IResource resource = root.findMember(new Path(containerName));
		if (resource == null || !resource.exists() || !(resource instanceof IContainer)) {
			AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Error.InvalidContainer", new Object[] { containerName }), true); //$NON-NLS-1$
		} else {
			IContainer container = (IContainer) resource;
			IPath filePath = new Path(fileName);
			final IFile file = container.getFile(filePath);
			try {
				InputStream stream = openContentStream(metamodelURI, metamodelType, filePath.removeFileExtension().lastSegment());
				if (file.exists()) {
					file.setContents(stream, true, true, monitor);
				} else {
					file.create(stream, true, monitor);
				}
				stream.close();
			} catch (TemplateSyntaxException e) {
				AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			} catch (IOException e) {
				AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			}
			monitor.worked(1);
			monitor.setTaskName(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Monitor.TaskOpening")); //$NON-NLS-1$
			getShell().getDisplay().asyncExec(new Runnable() {
				public void run() {
					IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
					try {
						IDE.openEditor(page, file, true);
					} catch (PartInitException e) {
					}
				}
			});
			IFolder result = null;
			try {
				IJavaProject javaProject = JavaCore.create(file.getProject());
				IClasspathEntry[] entries = javaProject.getResolvedClasspath(true);
				for (int i = 0; i < entries.length && result == null; i++) {
					IClasspathEntry entry = entries[i];
					if (entry.getEntryKind() == IClasspathEntry.CPE_SOURCE && entry.getPath().segmentCount() > 1) {
						IFolder src = ResourcesPlugin.getWorkspace().getRoot().getFolder(entry.getPath());
						if (src.exists() && file.getFullPath().toString().indexOf(src.getFullPath().toString()) > -1) {
							result = src;
						}
					}
				}
			} catch (JavaModelException e) {
				result = null;
			}
			if (result == null) {
				reportError(file, 0, new Int2(0, 0), AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.NotInSourceFolder")); //$NON-NLS-1$
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.NotInSourceFolder"), true); //$NON-NLS-1$
			}
			monitor.worked(1);
		}
	}

	/**
	 * Creates the content of the template.
	 * 
	 * @param metamodelURI
	 *            is the metamodel URI
	 * @param metamodelType
	 *            is the type of the root object
	 * @param scriptName
	 *            is the name of the script
	 * @return the content
	 * @throws TemplateSyntaxException
	 */
	private InputStream openContentStream(String metamodelURI, String metamodelType, String scriptName) throws TemplateSyntaxException {
		// Templates of the script
		SpecificScript script = createSpecificScript(metamodelURI, metamodelType, scriptName);
		script.addImport(new EvalModel(metamodelURI));
		String content = script.toString();
		return new ByteArrayInputStream(content.getBytes());
	}

	/**
	 * Creates the script to serialize.
	 * 
	 * @param metamodelURI
	 *            is the metamodel URI
	 * @param metamodelType
	 *            is the type of the root object
	 * @param scriptName
	 *            is the name of the script
	 * @return the default script
	 * @throws TemplateSyntaxException
	 */
	protected SpecificScript createSpecificScript(String metamodelURI, String metamodelType, String scriptName) throws TemplateSyntaxException {
		SpecificScript script = new SpecificScript();
		Template textTemplate = script.createTextTemplate(new ScriptDescriptor(metamodelType, scriptName));
		script.createFileTemplate(metamodelType, "<%name%>.txt", textTemplate); //$NON-NLS-1$
		return script;
	}

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		setWindowTitle(AcceleoGenUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

	private void reportError(IResource resource, int line, Int2 pos, String message) throws CoreException {
		IMarker m = resource.createMarker(IMarker.PROBLEM);
		m.setAttribute(IMarker.LINE_NUMBER, line);
		m.setAttribute(IMarker.CHAR_START, pos.b());
		m.setAttribute(IMarker.CHAR_END, pos.e());
		m.setAttribute(IMarker.MESSAGE, message);
		m.setAttribute(IMarker.PRIORITY, IMarker.PRIORITY_HIGH);
		m.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
	}

}
