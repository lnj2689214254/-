/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

/**
 * The wizard page which creates a new generator project.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoNewProjectWizardPage extends WizardPage {

	/**
	 * The new project name.
	 */
	private Text projectName;

	/**
	 * The initial project name to set.
	 */
	private String initialProjectName;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 */
	public AcceleoNewProjectWizardPage(String pageName) {
		this(pageName, ""); //$NON-NLS-1$
	}

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param initialProjectName
	 *            is the initial project name to set
	 */
	public AcceleoNewProjectWizardPage(String pageName, String initialProjectName) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoGenUIMessages.getString("AcceleoNewProjectWizardPage.Description")); //$NON-NLS-1$
		this.initialProjectName = initialProjectName;
	}

	/**
	 * Returns the new project name.
	 * 
	 * @return the new project name
	 */
	public String getProjectName() {
		return projectName.getText();
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 2;
		layout.verticalSpacing = 9;

		Label label = new Label(container, SWT.NULL);
		label.setText(AcceleoGenUIMessages.getString("AcceleoNewProjectWizardPage.ProjectLabel") + ':'); //$NON-NLS-1$

		projectName = new Text(container, SWT.BORDER | SWT.SINGLE);
		GridData gd = new GridData(GridData.FILL_HORIZONTAL);
		projectName.setLayoutData(gd);
		projectName.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				dialogChanged();
			}
		});
		projectName.setText(initialProjectName);

		dialogChanged();
		setControl(container);
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		if (getProjectName().length() == 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewProjectWizardPage.Error.EmptyProject")); //$NON-NLS-1$
			return;
		}
		IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(getProjectName()));
		if (resource != null && resource.exists()) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoNewProjectWizardPage.Error.ExistingProject")); //$NON-NLS-1$
			return;
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

}
