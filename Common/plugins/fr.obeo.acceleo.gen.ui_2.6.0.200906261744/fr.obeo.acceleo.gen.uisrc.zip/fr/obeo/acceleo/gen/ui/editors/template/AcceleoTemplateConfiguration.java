/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import fr.obeo.acceleo.gen.ui.editors.reflective.IGeneratorProvider;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateBasedScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateCommentScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateDefaultScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateFeatureScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateForScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateIfScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateScriptScanner;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplateUserScanner;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.internal.ui.text.java.JavaDoubleClickSelector;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.reconciler.MonoReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;

/**
 * This class bundles the configuration space of a template editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateConfiguration extends SourceViewerConfiguration {

	/**
	 * The generator provider.
	 */
	protected IGeneratorProvider provider;

	/**
	 * The color manager for the template editor.
	 */
	protected ColorManager colorManager;

	/**
	 * Constructor.
	 * 
	 * @param provider
	 *            is the generator provider
	 * @param colorManager
	 *            is the color manager for the template editor
	 */
	public AcceleoTemplateConfiguration(IGeneratorProvider provider, ColorManager colorManager) {
		this.provider = provider;
		this.colorManager = colorManager;
	}

	/**
	 * @return scanners
	 */
	protected AcceleoTemplateBasedScanner[] getTemplateScanners() {
		if (scanners == null) {
			List list = new ArrayList();
			list.add(new AcceleoTemplateCommentScanner(colorManager));
			list.add(new AcceleoTemplateScriptScanner(colorManager));
			list.add(new AcceleoTemplateUserScanner(colorManager));
			list.add(new AcceleoTemplateIfScanner(colorManager));
			list.add(new AcceleoTemplateForScanner(colorManager));
			list.add(new AcceleoTemplateFeatureScanner(colorManager));
			list.add(new AcceleoTemplateDefaultScanner(colorManager));
			scanners = (AcceleoTemplateBasedScanner[]) list.toArray(new AcceleoTemplateBasedScanner[list.size()]);
		}
		return scanners;
	}

	private AcceleoTemplateBasedScanner[] scanners = null;

	/* (non-Javadoc) */
	public String[] getConfiguredContentTypes(ISourceViewer sourceViewer) {
		AcceleoTemplateBasedScanner[] scanners = getTemplateScanners();
		String[] result = new String[scanners.length];
		for (int i = 0; i < scanners.length; i++) {
			AcceleoTemplateBasedScanner scanner = scanners[i];
			result[i] = scanner.getConfiguredContentType();
		}
		return result;
	}

	/* (non-Javadoc) */
	public ITextDoubleClickStrategy getDoubleClickStrategy(ISourceViewer sourceViewer, String contentType) {
		return new JavaDoubleClickSelector();
	}

	/* (non-Javadoc) */
	public IPresentationReconciler getPresentationReconciler(ISourceViewer sourceViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();
		AcceleoTemplateBasedScanner[] scanners = getTemplateScanners();
		for (int i = 0; i < scanners.length; i++) {
			AcceleoTemplateBasedScanner scanner = scanners[i];
			DefaultDamagerRepairer dr = new DefaultDamagerRepairer(scanner);
			reconciler.setDamager(dr, scanner.getConfiguredContentType());
			reconciler.setRepairer(dr, scanner.getConfiguredContentType());
		}
		return reconciler;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getReconciler(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public IReconciler getReconciler(ISourceViewer sourceViewer) {
		if (provider instanceof AcceleoTemplateEditor) {
			AcceleoTemplateReconcilingStrategy strategy = new AcceleoTemplateReconcilingStrategy((AcceleoTemplateEditor) provider);
			return new MonoReconciler(strategy, false);
		} else {
			return super.getReconciler(sourceViewer);
		}
	}

	/* (non-Javadoc) */
	public IContentAssistant getContentAssistant(ISourceViewer sourceViewer) {
		ContentAssistant assistant = new ContentAssistant();
		assistant.setDocumentPartitioning(getConfiguredDocumentPartitioning(sourceViewer));
		IContentAssistProcessor processor = new AcceleoTemplateCompletionProcessor(provider);
		AcceleoTemplateBasedScanner[] scanners = getTemplateScanners();
		for (int i = 0; i < scanners.length; i++) {
			AcceleoTemplateBasedScanner scanner = scanners[i];
			if (!(scanner instanceof AcceleoTemplateCommentScanner)) {
				assistant.setContentAssistProcessor(processor, scanner.getConfiguredContentType());
			}
		}
		assistant.enableAutoActivation(true);
		assistant.setAutoActivationDelay(500);
		assistant.setProposalPopupOrientation(IContentAssistant.PROPOSAL_OVERLAY);
		assistant.setInformationControlCreator(getInformationControlCreator(sourceViewer));
		return assistant;
	}

	/* (non-Javadoc) */
	public IAnnotationHover getAnnotationHover(ISourceViewer sourceViewer) {
		if (provider instanceof AcceleoTemplateEditor) {
			return new AcceleoTemplateHover((AcceleoTemplateEditor) provider);
		} else {
			return null;
		}
	}

}
