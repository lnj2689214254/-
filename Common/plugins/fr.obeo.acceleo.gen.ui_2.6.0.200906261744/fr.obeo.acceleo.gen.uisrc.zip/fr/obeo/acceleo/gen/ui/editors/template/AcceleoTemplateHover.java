/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.texteditor.MarkerAnnotation;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Template hover for an annotation.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateHover implements IAnnotationHover {

	/**
	 * Template editor.
	 */
	protected AcceleoTemplateEditor editor;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the template editor
	 */
	public AcceleoTemplateHover(AcceleoTemplateEditor editor) {
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public String getHoverInfo(ISourceViewer sourceViewer, int lineNumber) {
		return getHoverText(sourceViewer.getAnnotationModel(), sourceViewer.getDocument(), lineNumber);
	}

	/**
	 * Hover text for an annotation at the given line.
	 * 
	 * @param model
	 *            is the annotation model
	 * @param document
	 *            is the current document
	 * @param lineNumber
	 *            is the line number
	 * @return hover text
	 */
	protected String getHoverText(IAnnotationModel model, IDocument document, int lineNumber) {
		StringBuffer text = null;
		Iterator annotations = findAnnotations(model, document, lineNumber).iterator();
		while (annotations.hasNext()) {
			Annotation annotation = (Annotation) annotations.next();
			String msg = null;
			if (annotation instanceof MarkerAnnotation) {
				try {
					msg = (String) ((MarkerAnnotation) annotation).getMarker().getAttribute(IMarker.MESSAGE);
				} catch (CoreException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}
			if (msg != null) {
				if (text == null)
					text = new StringBuffer(msg);
				else {
					text.append('\n');
					text.append(msg);
				}
			}
		}
		return text != null ? text.toString() : null;
	}

	private List findAnnotations(IAnnotationModel model, IDocument document, int lineNumber) {
		List annotations = new ArrayList();
		if (model == null) {
			if (editor != null) {
				model = editor.getDocumentProvider().getAnnotationModel(editor.getEditorInput());
			}
		}
		if (model == null)
			return annotations;
		for (Iterator it = model.getAnnotationIterator(); it.hasNext();) {
			Annotation annotation = (Annotation) it.next();
			Position position = model.getPosition(annotation);
			try {
				if (document != null && document.getLineOfOffset(position.offset) == lineNumber) {
					annotations.add(annotation);
				}
			} catch (BadLocationException e) {
			}
		}
		return annotations;
	}

}
