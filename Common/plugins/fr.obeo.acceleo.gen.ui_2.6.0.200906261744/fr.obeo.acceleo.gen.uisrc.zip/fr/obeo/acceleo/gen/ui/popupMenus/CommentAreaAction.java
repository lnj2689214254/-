/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * Action adding comments
 * 
 * @author www.obeo.fr
 * 
 */
public class CommentAreaAction extends Action implements IWorkbenchWindowActionDelegate, IObjectActionDelegate {

	/**
	 * The action id
	 */
	public final static String ACTION_ID = "fr.obeo.gen.ui.actions.Comment"; //$NON-NLS-1$

	/**
	 * The associated command ID
	 */
	public final static String COMMAND_ID = "fr.obeo.gen.ui.edit.import.comment"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public void dispose() {
		// nothing to do

	}

	/* (non-Javadoc) */
	public void init(IWorkbenchWindow window) {
		// nothing to do
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		super.run();
		if (PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null
				&& PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor() instanceof AcceleoTemplateEditor) {
			AcceleoTemplateEditor editor = (AcceleoTemplateEditor) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
			if (editor.getSelectionProvider() != null) {
				ITextSelection selection = (ITextSelection) editor.getSelectionProvider().getSelection();
				if (selection != null) {
					int b = selection.getOffset();
					int e = selection.getOffset() + selection.getLength();
					IFile currentFile = editor.getFile();
					IDocument document = editor.getDocumentProvider().getDocument(editor.getEditorInput());
					if (currentFile != null && document != null) {
						String text = document.get();
						if (b < text.length()) {
							TemplateConstants.initConstants(text);
							Int2 trim = TextSearch.getDefaultSearch().trim(text, b, e);
							if (trim.b() > -1) {
								b = trim.b();
								e = trim.e();
							}
							if (b + TemplateConstants.COMMENT_BEGIN.length() < text.length() && TemplateConstants.COMMENT_BEGIN.equals(text.substring(b, b + TemplateConstants.COMMENT_BEGIN.length()))) {
								b = b + TemplateConstants.COMMENT_BEGIN.length();
								if (e < b) {
									e = b;
								}
							}
							if (e - TemplateConstants.COMMENT_END.length() >= 0 && TemplateConstants.COMMENT_END.equals(text.substring(e - TemplateConstants.COMMENT_END.length(), e))) {
								e = e - TemplateConstants.COMMENT_END.length();
								if (e < b) {
									b = e;
								}
							}
							Int2 beforeCommentBegin = TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.COMMENT_BEGIN, 0, b);
							Int2 beforeCommentEnd = (beforeCommentBegin.e() == -1) ? Int2.NOT_FOUND : TextSearch.getDefaultSearch().lastIndexIn(text, TemplateConstants.COMMENT_END,
									beforeCommentBegin.e(), b);
							if (beforeCommentBegin.b() > -1 && beforeCommentEnd.b() == -1) {
								b = beforeCommentBegin.b();
								Int2 eComment = TextSearch.getDefaultSearch().blockIndexEndIn(text, TemplateConstants.COMMENT_BEGIN, TemplateConstants.COMMENT_END, beforeCommentBegin.b(),
										text.length(), false);
								if (eComment.b() > -1) {
									e = eComment.e();
								} else {
									e = text.length();
								}
							}
							String textSelection = text.substring(b, e);
							String newText;
							if (textSelection.startsWith(TemplateConstants.COMMENT_BEGIN)) {
								if (textSelection.endsWith(TemplateConstants.COMMENT_END)) {
									newText = text.substring(b + TemplateConstants.COMMENT_BEGIN.length(), e - TemplateConstants.COMMENT_END.length());
								} else {
									newText = text.substring(b + TemplateConstants.COMMENT_BEGIN.length(), e);
								}
							} else {
								while (e < text.length() && text.charAt(e) != '\n') {
									e++;
								}
								if (e < text.length() && text.charAt(e) == '\n') {
									e++;
								}
								while (b > 0 && text.charAt(b) != '\n') {
									b--;
								}
								if (b < text.length() && text.charAt(b) == '\n') {
									b++;
								}
								newText = TemplateConstants.COMMENT_BEGIN + text.substring(b, e) + TemplateConstants.COMMENT_END;
							}
							try {
								document.replace(b, e - b, newText);
							} catch (BadLocationException ex) {
								AcceleoEcoreGenUiPlugin.getDefault().log(ex, true);
							}
						}
					}
				}
			}
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart part) {
	}

}
