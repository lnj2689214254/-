/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.natures;

import java.util.List;

import org.eclipse.core.resources.IProjectNature;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Interface for the nature of the generator project.
 * 
 * @author www.obeo.fr
 * 
 */
public interface IAcceleoGenNature extends IProjectNature {
	/**
	 * The identifier for the AcceleoGen nature.
	 */
	public static final String NATURE_ID = AcceleoEcoreGenUiPlugin.getDefault().getID() + ".acceleoGenNature"; //$NON-NLS-1$

	/**
	 * Returns the containers where the generators are located.
	 * 
	 * @return the containers where the generators are located.
	 */
	public List getGeneratorContainers();

}
