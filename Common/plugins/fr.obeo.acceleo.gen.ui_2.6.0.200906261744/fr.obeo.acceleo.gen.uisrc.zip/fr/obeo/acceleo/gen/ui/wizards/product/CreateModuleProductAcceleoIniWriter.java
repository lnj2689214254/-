package fr.obeo.acceleo.gen.ui.wizards.product;

public class CreateModuleProductAcceleoIniWriter
{
  protected static String nl;
  public static synchronized CreateModuleProductAcceleoIniWriter create(String lineSeparator)
  {
    nl = lineSeparator;
    CreateModuleProductAcceleoIniWriter result = new CreateModuleProductAcceleoIniWriter();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "# You have to modify the model and the folders" + NL + "model=./model/sample.uml" + NL + "properties=./model" + NL;
  protected final String TEXT_2 = NL + "folder=./src-gen/";
  protected final String TEXT_3 = NL + "generate=";
  protected final String TEXT_4 = NL;
  protected final String TEXT_5 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    
 AcceleoCreateModuleProductData content = (AcceleoCreateModuleProductData) ((Object[])argument)[0];
 String[] templateIDs = (String[]) ((Object[])argument)[1];
 String[] templateNames = (String[]) ((Object[])argument)[2];

    stringBuffer.append(TEXT_1);
    for (int i = 0; i < templateIDs.length; i ++) {
    stringBuffer.append(TEXT_2);
    stringBuffer.append(templateNames[i]);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(templateIDs[i]);
    stringBuffer.append(TEXT_4);
    }
    stringBuffer.append(TEXT_5);
    return stringBuffer.toString();
  }
}
