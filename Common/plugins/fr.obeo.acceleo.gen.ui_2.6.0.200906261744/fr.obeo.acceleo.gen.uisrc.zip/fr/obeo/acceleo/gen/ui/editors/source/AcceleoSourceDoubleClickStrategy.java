/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.swt.graphics.Point;

/**
 * This class is the double click configuration of a source editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceDoubleClickStrategy implements ITextDoubleClickStrategy {

	/**
	 * The source editor.
	 */
	protected AcceleoSourceEditor editor;

	/**
	 * Create a new double click configuration.
	 * 
	 * @param editor
	 *            is the source editor
	 */
	public AcceleoSourceDoubleClickStrategy(AcceleoSourceEditor editor) {
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public void doubleClicked(ITextViewer part) {
		Point point = part.getSelectedRange();
		if (point != null) {
			int pos = point.x;
			editor.updateSelection(pos);
		}
	}

}
