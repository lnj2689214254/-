/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.builders;

import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;

import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.natures.AcceleoGenNature;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * The builder that compiles the scripts in a background task. Compilation
 * errors are put in the problems view when it is necessary.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenBuilder extends IncrementalProjectBuilder {

	/**
	 * Constructor.
	 */
	public AcceleoGenBuilder() {
		super();
	}

	/* (non-Javadoc) */
	protected IProject[] build(int kind, Map arguments, IProgressMonitor monitor) throws CoreException {
		if (!getProject().exists()) {
			return new IProject[] {};
		} else {
			try {
				if (kind == FULL_BUILD) {
					fullBuild(monitor);
				} else {
					IResourceDelta delta = getDelta(getProject());
					if (delta == null) {
						fullBuild(monitor);
					} else {
						incrementalBuild(delta, monitor);
					}
				}
			} catch (OperationCanceledException e) {
			}
			return null;
		}
	}

	/**
	 * It does a full build.
	 * 
	 * @param monitor
	 *            is the progress monitor
	 * @throws CoreException
	 */
	protected void fullBuild(IProgressMonitor monitor) throws CoreException {
		AcceleoGenNature nature = AcceleoGenNature.getDefault(getProject());
		if (nature != null) {
			AcceleoGenCompileOperation compileOperation = new AcceleoGenCompileOperation(new IFile[] {}, nature.getGeneratorContainers(), AcceleoGenCompileOperation.FULL_BUILD);
			if (compileOperation.shouldCompile()) {
				compileOperation.run(monitor);
			}
		}
	}

	/**
	 * It does an incremental build.
	 * 
	 * @param delta
	 *            is the resource delta
	 * @param monitor
	 *            is the progress monitor
	 * @throws CoreException
	 */
	protected void incrementalBuild(IResourceDelta delta, IProgressMonitor monitor) throws CoreException {
		AcceleoGenNature nature = AcceleoGenNature.getDefault(getProject());
		if (nature != null) {
			IFile[] members = Resources.deltaMembers(delta, new String[] { SpecificScript.GENERATORS_EXTENSION, "java" }); //$NON-NLS-1$
			if (members.length > 0) {
				AcceleoGenCompileOperation compileOperation = new AcceleoGenCompileOperation(members, nature.getGeneratorContainers(), AcceleoGenCompileOperation.INCREMENTAL_BUILD);
				if (compileOperation.shouldCompile()) {
					compileOperation.run(monitor);
				}
			}
		}
	}

	/* (non-Javadoc) */
	protected void clean(IProgressMonitor monitor) throws CoreException {
		super.clean(monitor);
		AcceleoGenNature nature = AcceleoGenNature.getDefault(getProject());
		if (nature != null) {
			AcceleoGenCompileOperation compileOperation = new AcceleoGenCompileOperation(new IFile[] {}, nature.getGeneratorContainers(), AcceleoGenCompileOperation.CLEAN);
			if (compileOperation.shouldCompile()) {
				compileOperation.run(monitor);
			}
		}
	}

}
