/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.FastPartitioner;
import org.eclipse.ui.editors.text.FileDocumentProvider;

import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplatePartitionScanner;

/**
 * Shared document provider specialized for template file resources (IFile).
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateDocumentProvider extends FileDocumentProvider {

	/**
	 * The color manager for the template editor.
	 */
	protected ColorManager colorManager;

	/**
	 * Constructor.
	 * 
	 * @param colorManager
	 *            is the color manager
	 */
	public AcceleoTemplateDocumentProvider(ColorManager colorManager) {
		super();
		this.colorManager = colorManager;
	}

	/* (non-Javadoc) */
	protected IDocument createDocument(Object element) throws CoreException {
		IDocument document = super.createDocument(element);
		if (document != null) {
			IDocumentPartitioner partitioner = new FastPartitioner(
			// FastPartitioner
					// for
					// eclipse
					// 3.1,
					// DefaultPartitioner
					// for
					// eclipse
					// 3.0
					new AcceleoTemplatePartitionScanner(colorManager), AcceleoTemplatePartitionScanner.LEGAL_CONTENT_TYPES);
			partitioner.connect(document);
			document.setDocumentPartitioner(partitioner);
		}
		return document;
	}

}
