/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.natures.AcceleoGenAddNatureOperation;

/**
 * The wizard which creates a new generator project.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoNewGenProjectWizard extends Wizard implements INewWizard {

	/**
	 * The new project wizard page.
	 */
	protected AcceleoNewProjectWizardPage page;

	/**
	 * Constructor.
	 */
	public AcceleoNewGenProjectWizard() {
		super();
		setNeedsProgressMonitor(true);
		setDefaultPageImageDescriptor(AcceleoEcoreGenUiPlugin.getImageDescriptor("images/newGeneratorProject.png")); //$NON-NLS-1$  
	}

	/* (non-Javadoc) */
	public void addPages() {
		page = new AcceleoNewProjectWizardPage(AcceleoGenUIMessages.getString("AcceleoNewGenProjectWizard.Title")); //$NON-NLS-1$
		addPage(page);
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String projectName = page.getProjectName();
		try {
			IProject genProject = fr.obeo.acceleo.tools.ui.resources.Resources.createPluginProject(projectName, new String[] { "fr.obeo.acceleo.gen" }, new NullProgressMonitor()); //$NON-NLS-1$
			AcceleoGenAddNatureOperation addNature = new AcceleoGenAddNatureOperation(genProject);
			getContainer().run(false, false, addNature);
		} catch (Exception e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
		return true;
	}

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		setWindowTitle(AcceleoGenUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

}
