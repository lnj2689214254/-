/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.scanner;

import org.eclipse.swt.graphics.RGB;

/**
 * Color constants for templates.
 * 
 * @author www.obeo.fr
 * 
 */
public interface IAcceleoTemplateColorConstants {

	public static final RGB COMMENT = new RGB(63, 127, 95);

	public static final RGB LITERAL_1 = new RGB(200, 0, 0);

	public static final RGB LITERAL_2 = new RGB(0, 0, 255);

	public static final RGB LITERAL_3 = new RGB(63, 127, 127);

	public static final RGB SCRIPT = new RGB(200, 0, 0);

	public static final RGB USER = new RGB(130, 160, 190);

	public static final RGB IF = new RGB(80, 80, 255);

	public static final RGB FOR = new RGB(80, 80, 255);

	public static final RGB FEATURE = new RGB(80, 80, 255);

	public static final RGB KEYWORD = new RGB(127, 0, 85);

	public static final RGB DEFAULT = new RGB(0, 0, 0);

}
