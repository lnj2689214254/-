/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.rule;

import org.eclipse.jface.text.rules.ICharacterScanner;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.Token;

/**
 * Rule to detect keywords.
 * 
 * @author www.obeo.fr
 * 
 */
public class KeywordRule implements IPredicateRule {

	/** Keyword to detect for this rule */
	private final String keyword;

	/** Token to return for this rule */
	private final IToken token;

	/**
	 * Creates a new keyword rule.
	 * 
	 * @param token
	 *            is the token to use for this rule
	 */
	public KeywordRule(String keyword, IToken token) {
		this.keyword = keyword;
		this.token = token;
	}

	/* (non-Javadoc) */
	public IToken getSuccessToken() {
		return token;
	}

	/* (non-Javadoc) */
	public IToken evaluate(ICharacterScanner scanner) {
		if (keyword.length() > 0) {
			for (int i = 0; i < keyword.length(); i++) {
				int c = scanner.read();
				if (c == ICharacterScanner.EOF || c != keyword.charAt(i)) {
					while (i >= 0) {
						scanner.unread();
						i--;
					}
					return Token.UNDEFINED;
				}
			}
			return token;
		} else {
			return Token.UNDEFINED;
		}
	}

	/* (non-Javadoc) */
	public IToken evaluate(ICharacterScanner scanner, boolean resume) {
		return evaluate(scanner);
	}

}