/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards;

import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.runtime.IPath;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.ui.resources.FileSelectionDialog;

/**
 * The role of this wizard page is to select an ecore metamodel, in the
 * workspace or in the registry (EPackage).
 * 
 * @author www.obeo.fr
 */

public class AcceleoSelectMetamodelWizardPage extends WizardPage {

	/**
	 * The metamodel URI.
	 */
	private Text metamodelURI;

	/**
	 * The extensions.
	 */
	private String[] extensions;

	/**
	 * The metamodel type.
	 */
	private Combo metamodelType = null;

	/**
	 * The metamodel types.
	 */
	private String[] types = null;

	/**
	 * Indicates if we have to select the main type of the metamodel.
	 */
	private boolean chooseMetamodelType = false;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param extensions
	 *            is a table of extensions
	 */
	public AcceleoSelectMetamodelWizardPage(String pageName, String[] extensions) {
		this(pageName, extensions, false);
	}

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param extensions
	 *            is a table of extensions
	 * @param chooseMetamodelType
	 *            indicates if we have to select the main type of the metamodel
	 */
	public AcceleoSelectMetamodelWizardPage(String pageName, String[] extensions, boolean chooseMetamodelType) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.Description")); //$NON-NLS-1$
		this.extensions = extensions;
		this.chooseMetamodelType = chooseMetamodelType;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite rootContainer = new Composite(parent, SWT.NULL);
		GridLayout rootContainerLayout = new GridLayout();
		rootContainerLayout.numColumns = 1;
		rootContainerLayout.marginTop = 14;
		rootContainerLayout.verticalSpacing = 9;
		rootContainerLayout.marginLeft = 7;
		rootContainerLayout.marginRight = 7;
		rootContainer.setLayout(rootContainerLayout);

		Composite registryContainer = new Composite(rootContainer, SWT.NULL);
		GridLayout registryContainerLayout = new GridLayout();
		registryContainerLayout.numColumns = 3;
		registryContainerLayout.verticalSpacing = 9;
		registryContainer.setLayout(registryContainerLayout);

		Label registryLabel = new Label(registryContainer, SWT.NULL);
		registryLabel.setText(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.RegistryLabel") + ':'); //$NON-NLS-1$

		Set registryValues = new TreeSet(EPackage.Registry.INSTANCE.keySet());
		final String[] valueLabels = (String[]) registryValues.toArray(new String[registryValues.size()]);
		Combo comboBox = new Combo(registryContainer, SWT.READ_ONLY);
		comboBox.setItems(valueLabels);
		int visibleItemCount = 15;
		if (valueLabels.length < visibleItemCount) {
			comboBox.setVisibleItemCount(valueLabels.length);
		} else {
			comboBox.setVisibleItemCount(visibleItemCount);
		}
		comboBox.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				metamodelURI.setText(valueLabels[((Combo) e.widget).getSelectionIndex()]);
			}
		});

		Button button = new Button(registryContainer, SWT.PUSH);
		button.setText(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.BrowseButtonLabel")); //$NON-NLS-1$
		button.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				handleBrowse();
			}
		});

		Composite uriContainer = new Composite(rootContainer, SWT.NULL);
		GridData gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.horizontalSpan = 4;
		uriContainer.setLayoutData(gridData);
		GridLayout uriContainerLayout = new GridLayout();
		uriContainerLayout.numColumns = 1;
		uriContainer.setLayout(uriContainerLayout);

		Label uriLabel = new Label(uriContainer, SWT.NULL);
		uriLabel.setText(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.URILabel") + ':'); //$NON-NLS-1$

		metamodelURI = new Text(uriContainer, SWT.BORDER | SWT.SINGLE);
		gridData = new GridData(GridData.FILL_HORIZONTAL);
		gridData.horizontalSpan = 4;
		metamodelURI.setLayoutData(gridData);
		metamodelURI.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				updateTypes();
				dialogChanged();
			}
		});

		if (chooseMetamodelType) {
			Composite typeContainer = new Composite(rootContainer, SWT.NULL);
			GridData typeContainerGridData = new GridData(GridData.FILL_HORIZONTAL);
			typeContainerGridData.horizontalSpan = 4;
			typeContainer.setLayoutData(typeContainerGridData);
			GridLayout typeContainerLayout = new GridLayout();
			typeContainerLayout.numColumns = 1;
			typeContainer.setLayout(typeContainerLayout);

			Label typeLabel = new Label(typeContainer, SWT.NULL);
			typeLabel.setText(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.TypeLabel") + ':'); //$NON-NLS-1$

			metamodelType = new Combo(typeContainer, SWT.READ_ONLY);
			gridData = new GridData(GridData.FILL_HORIZONTAL);
			gridData.horizontalSpan = 4;
			metamodelType.setLayoutData(gridData);
			metamodelType.addSelectionListener(new SelectionListener() {
				public void widgetDefaultSelected(SelectionEvent e) {
				}

				public void widgetSelected(SelectionEvent e) {
					dialogChanged();
				}
			});
		}

		updateTypes();
		dialogChanged();
		setControl(rootContainer);
	}

	private void handleBrowse() {
		FileSelectionDialog dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), AcceleoGenUIMessages
				.getString("AcceleoSelectMetamodelWizardPage.MetamodelSelectionTitle"), 1, extensions, true); //$NON-NLS-1$
		dialog.open();
		if (dialog.getResult() != null && dialog.getResult().length > 0 && dialog.getResult()[0] instanceof IPath) {
			metamodelURI.setText(((IPath) dialog.getResult()[0]).toString());
		}
	}

	/**
	 * Updates the metamodel types.
	 */
	private void updateTypes() {
		if (metamodelType != null) {
			TreeSet typeValues = new TreeSet();
			String metamodelURI = getMetamodelURI();
			EPackage ePackage = ETools.uri2EPackage(metamodelURI);
			EClassifier[] classifiers = ETools.computeAllClassifiers(ePackage);
			for (int i = 0; i < classifiers.length; i++) {
				EClassifier classifier = classifiers[i];
				typeValues.add(ETools.getEClassifierShortPath(classifier));
			}
			types = (String[]) typeValues.toArray(new String[typeValues.size()]);
			metamodelType.setItems(types);
			int visibleItemCount = 15;
			if (types.length < visibleItemCount) {
				metamodelType.setVisibleItemCount(types.length);
			} else {
				metamodelType.setVisibleItemCount(visibleItemCount);
			}
			int index = bestType(-1, "class", 0); //$NON-NLS-1$
			index = bestType(index, "class", 1); //$NON-NLS-1$
			index = bestType(index, "class", 2); //$NON-NLS-1$
			index = bestType(index, "model", 0); //$NON-NLS-1$
			index = bestType(index, "model", 1); //$NON-NLS-1$
			index = bestType(index, "model", 2); //$NON-NLS-1$
			index = bestType(index, "root", 0); //$NON-NLS-1$
			index = bestType(index, "root", 1); //$NON-NLS-1$
			index = bestType(index, "root", 2); //$NON-NLS-1$
			index = bestType(index, "package", 0); //$NON-NLS-1$
			index = bestType(index, "package", 1); //$NON-NLS-1$
			index = bestType(index, "package", 2); //$NON-NLS-1$
			if (index > -1) {
				metamodelType.select(index);
			}
		}
	}

	private int bestType(int index, String name, int level) {
		if (index == -1) {
			String nameLower = name.toLowerCase();
			for (int i = 0; i < types.length; i++) {
				String type = types[i];
				int iDot = type.lastIndexOf("."); //$NON-NLS-1$
				if (iDot > -1) {
					type = type.substring(iDot + 1);
				}
				type = type.toLowerCase();
				if (level == 0 && type.equals(nameLower)) {
					return i;
				} else if (level == 1 && type.startsWith(nameLower)) {
					return i;
				} else if (level == 2 && type.endsWith(nameLower)) {
					return i;
				}
			}
		}
		return index;
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		String metamodelURI = getMetamodelURI();
		if (metamodelURI.length() == 0) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.Error.EmptyURI")); //$NON-NLS-1$
			return;
		}
		if (ETools.uri2EPackage(metamodelURI) == null) {
			updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.Error.InvalidURI")); //$NON-NLS-1$
			return;
		}
		if (chooseMetamodelType) {
			if (getMetamodelType().length() == 0) {
				updateStatus(AcceleoGenUIMessages.getString("AcceleoSelectMetamodelWizardPage.Error.EmptyType")); //$NON-NLS-1$
				return;
			}
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

	/**
	 * Returns the metamodel URI.
	 * 
	 * @return the metamodel URI
	 */
	public String getMetamodelURI() {
		return metamodelURI.getText();
	}

	/**
	 * Returns the metamodel type.
	 * 
	 * @return the metamodel type
	 */
	public String getMetamodelType() {
		if (metamodelType != null && types != null && metamodelType.getSelectionIndex() > -1 && metamodelType.getSelectionIndex() < types.length) {
			return types[metamodelType.getSelectionIndex()];
		} else {
			return ""; //$NON-NLS-1$
		}
	}

}
