/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.natures;

import org.eclipse.core.resources.IProject;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Adds the generator nature to projects.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoGenAddNatureAction implements IObjectActionDelegate {

	/**
	 * Selected project.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoGenAddNatureAction() {
		super();
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		try {
			if (selection instanceof StructuredSelection) {
				Object selectedObject = ((StructuredSelection) selection).getFirstElement();
				IProject project = null;
				if (selectedObject instanceof IProject) {
					project = (IProject) selectedObject;
				} else if (selectedObject instanceof IJavaProject) {
					project = ((IJavaProject) selectedObject).getProject();
				}
				if (project != null) {
					AcceleoGenAddNatureOperation addNature = new AcceleoGenAddNatureOperation(project);
					PlatformUI.getWorkbench().getProgressService().run(false, false, addNature);
				}
			}
		} catch (Exception e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
