/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.scanner;

import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WhitespaceRule;
import org.eclipse.swt.SWT;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.editors.template.ColorManager;
import fr.obeo.acceleo.gen.ui.editors.template.rule.BlockRule;
import fr.obeo.acceleo.gen.ui.editors.template.rule.KeywordRule;

/**
 * A scanner for detecting feature sequences.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateFeatureScanner extends AcceleoTemplateBasedScanner {

	/**
	 * Constructor.
	 * 
	 * @param manager
	 *            is the color manager
	 */
	public AcceleoTemplateFeatureScanner(ColorManager manager) {
		this(manager, false);
	}

	/**
	 * Constructor.
	 * 
	 * @param manager
	 *            is the color manager
	 * @param italic
	 *            indicates if the italic style must be used
	 */
	public AcceleoTemplateFeatureScanner(ColorManager manager, boolean italic) {
		IRule[] rules = getRules(manager, italic);
		setRules(rules);
		setDefaultReturnToken(getDefaultReturnToken(manager, italic));
	}

	/**
	 * Gets the rules of the scanner.
	 * 
	 * @param manager
	 *            is the color manager
	 * @param italic
	 *            indicates if the italic style must be used
	 * @return
	 */
	protected IRule[] getRules(ColorManager manager, boolean italic) {
		IRule[] rules = new IRule[21];
		rules[0] = new BlockRule(TemplateConstants.LITERAL[0], TemplateConstants.LITERAL[1], TemplateConstants.LITERAL_SPEC, new Token(new TextAttribute(manager
				.getColor(IAcceleoTemplateColorConstants.LITERAL_3), null, (italic) ? SWT.ITALIC : SWT.NONE)));
		rules[1] = new BlockRule(TemplateConstants.BRACKETS[0], TemplateConstants.BRACKETS[1], new BlockRule[] { (BlockRule) rules[0] }, new Token(new TextAttribute(manager
				.getColor(IAcceleoTemplateColorConstants.LITERAL_2), null, SWT.ITALIC)));
		rules[2] = new KeywordRule(TemplateConstants.IMPORT_WORD + ' ', new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD
				: SWT.BOLD)));
		rules[3] = new KeywordRule(TemplateConstants.MODELTYPE_WORD + ' ', new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD
				: SWT.BOLD)));
		rules[4] = new KeywordRule(TemplateConstants.IF_BEGIN + TemplateConstants.PARENTH[0], new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null,
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[5] = new KeywordRule(TemplateConstants.IF_BEGIN,
				new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[6] = new KeywordRule(TemplateConstants.PARENTH[1] + TemplateConstants.IF_THEN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null,
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[7] = new KeywordRule(TemplateConstants.PARENTH[1] + " " + TemplateConstants.IF_THEN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, //$NON-NLS-1$
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[8] = new KeywordRule(TemplateConstants.IF_THEN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[9] = new KeywordRule(TemplateConstants.IF_END, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[10] = new KeywordRule(TemplateConstants.IF_ELSE_IF + TemplateConstants.PARENTH[0], new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null,
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[11] = new KeywordRule(TemplateConstants.IF_ELSE_IF + " " + TemplateConstants.PARENTH[0], new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, //$NON-NLS-1$
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[12] = new KeywordRule(TemplateConstants.IF_ELSE_IF, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD
				: SWT.BOLD)));
		rules[13] = new KeywordRule(TemplateConstants.IF_ELSE,
				new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[14] = new KeywordRule(TemplateConstants.FOR_BEGIN + TemplateConstants.PARENTH[0], new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null,
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[15] = new KeywordRule(TemplateConstants.FOR_BEGIN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD
				: SWT.BOLD)));
		rules[16] = new KeywordRule(TemplateConstants.PARENTH[1] + TemplateConstants.FOR_THEN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null,
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[17] = new KeywordRule(TemplateConstants.PARENTH[1] + " " + TemplateConstants.FOR_THEN, new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, //$NON-NLS-1$
				(italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[18] = new KeywordRule(TemplateConstants.FOR_THEN, new Token(
				new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[19] = new KeywordRule(TemplateConstants.FOR_END,
				new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.KEYWORD), null, (italic) ? SWT.ITALIC | SWT.BOLD : SWT.BOLD)));
		rules[20] = new WhitespaceRule(new AcceleoTemplateWhitespaceDetector());
		return rules;
	}

	/**
	 * Gets the default token of the scanner.
	 * 
	 * @param manager
	 *            is the color manager
	 * @param italic
	 *            indicates if the italic style must be used
	 * @return
	 */
	protected Token getDefaultReturnToken(ColorManager manager, boolean italic) {
		return new Token(new TextAttribute(manager.getColor(IAcceleoTemplateColorConstants.FEATURE), null, (italic) ? SWT.ITALIC : SWT.NONE));
	}

	/* (non-Javadoc) */
	public String getConfiguredContentType() {
		return AcceleoTemplatePartitionScanner.TEMPLATE_FEATURE;
	}

}
