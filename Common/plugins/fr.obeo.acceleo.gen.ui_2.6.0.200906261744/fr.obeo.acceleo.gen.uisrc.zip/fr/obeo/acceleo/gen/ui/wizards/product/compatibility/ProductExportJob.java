/*******************************************************************************
 * Copyright (c) 2005, 2007 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package fr.obeo.acceleo.gen.ui.wizards.product.compatibility;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.wizard.IWizardContainer;
import org.eclipse.pde.internal.core.exports.FeatureExportInfo;
import org.eclipse.pde.internal.core.exports.FeatureExportOperation;
import org.eclipse.pde.internal.core.exports.ProductExportOperation;
import org.eclipse.pde.internal.core.iproduct.IProduct;
import org.eclipse.pde.internal.core.iproduct.IProductModel;
import org.eclipse.pde.internal.ui.PDEPluginImages;
import org.eclipse.pde.internal.ui.PDEUIMessages;
import org.eclipse.ui.progress.IProgressConstants;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

public class ProductExportJob extends FeatureExportJob {
	
	private IProduct fProduct;
	private String fRoot;
	
	public ProductExportJob(FeatureExportInfo info, IProductModel model, String productRoot, IWizardContainer container) {
		super(info, AcceleoGenUIMessages.getString("FeatureExportJob.ProductExportJob_name"), container);
		fProduct = model.getProduct();
		fRoot = productRoot;
	}
	
	protected FeatureExportOperation createOperation() {
		try {
			Object instance;
			try {
				instance = ProductExportOperation.class.getConstructor(new Class[] { FeatureExportInfo.class, IProduct.class, String.class }).newInstance(new Object[] { fInfo, fProduct, fRoot });
			} catch (NoSuchMethodException e) {
				instance = ProductExportOperation.class.getConstructor(new Class[] { FeatureExportInfo.class, String.class, IProduct.class, String.class }).newInstance(new Object[] { fInfo, "Export Acceleo Product", fProduct, fRoot});//$NON-NLS-1$
			}
			return (ProductExportOperation)instance;
		} catch (IllegalArgumentException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (SecurityException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (InstantiationException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (IllegalAccessException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (InvocationTargetException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (NoSuchMethodException e) {
			MessageDialog.openError(container.getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		}
		return null;
	}

}
