/*******************************************************************************
 * Copyright (c) 2008 Obeo.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Obeo - initial API and implementation
 *******************************************************************************/
package fr.obeo.acceleo.gen.ui.editors.template;

import fr.obeo.acceleo.gen.template.TemplateConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.jface.text.reconciler.IReconcilingStrategyExtension;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.projection.ProjectionAnnotation;
import org.eclipse.swt.widgets.Display;

/**
 * This reconciler will allow us to enable folding in the Acceleo template
 * editor.
 * <p>
 * Rules are as follows :
 * <ol>
 * <li>All items stated below as &quot;foldable&quot; will effectively be if
 * they span more than 2 lines.</li>
 * <li>Comments located before the very first script are considered foldable.</li>
 * <li>If a comment is located above the import block, it will be initially
 * folded.</li>
 * <li>The import block iself is foldable.</li>
 * <li>Scripts are considered foldable.</li>
 * <li>If scripts are preceded by a comment (empty lines in-between comment and
 * script are ignored in this check), this comment will be foldable.</li>
 * </ol>
 * </p>
 * 
 * @author <a href="mailto:laurent.goubet@obeo.fr">Laurent Goubet</a>
 */
public final class AcceleoTemplateReconcilingStrategy implements IReconcilingStrategy, IReconcilingStrategyExtension {
    /**
     * Number of characters the "script" statement starting delimiter extends
     * to.
     */
    private final static int SCRIPT_STATEMENT_LENGTH = TemplateConstants.SCRIPT_BEGIN.length() - 1;

    /**
     * This will hold the list of all annotations that have been added since the
     * last reconciling.
     */
    private final Map addedAnnotations = new HashMap();

    /** Current known positions of foldable block. */
    private final Map currentAnnotations = new HashMap();

    /**
     * This will hold the list of all annotations that have been removed since
     * the last reconciling.
     */
    private final List deletedAnnotations = new ArrayList();

    /** The document we'll seek foldable blocks in. */
    private IDocument document;

    /** Editor this provides folding support to. */
    private final AcceleoTemplateEditor editor;

    /**
     * This will hold the list of all annotations that have been modified since
     * the last reconciling.
     */
    private final Map modifiedAnnotations = new HashMap();

    /** Current offset. */
    private int offset;

    /** The statement end delimiter (either '&gt;' or ']' at current). */
    private char statementEnd;

    /** The statement start delimiter (either '&lt;' or '[' at current). */
    private char statementStart;

    /**
     * Instantiates the reconciling strategy for a given editor.
     * 
     * @param editor
     *            Editor which we seek to provide folding support for.
     */
    public AcceleoTemplateReconcilingStrategy(AcceleoTemplateEditor editor) {
        this.editor = editor;
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.eclipse.jface.text.reconciler.IReconcilingStrategyExtension#initialReconcile()
     */
    public void initialReconcile() {
        offset = 0;
        computePositions(true);
        updateFoldingStructure();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#reconcile(org.eclipse.jface.text.reconciler.DirtyRegion,
     *      org.eclipse.jface.text.IRegion)
     */
    public void reconcile(DirtyRegion dirtyRegion, IRegion subRegion) {
        reconcile(subRegion);
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#reconcile(org.eclipse.jface.text.IRegion)
     */
    public void reconcile(IRegion partition) {
        offset = partition.getOffset();
        computePositions(false);
        updateFoldingStructure();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#setDocument(org.eclipse.jface.text.IDocument)
     */
    public void setDocument(IDocument document) {
        this.document = document;
        computeDelimiter();
    }

    /**
     * {@inheritDoc}
     * 
     * @see org.eclipse.jface.text.reconciler.IReconcilingStrategyExtension#setProgressMonitor(org.eclipse.core.runtime.IProgressMonitor)
     */
    public void setProgressMonitor(IProgressMonitor monitor) {
        // none
    }

    /**
     * This will determine the delimiter used within the template ("&lt;%" or
     * "[%").
     */
    private void computeDelimiter() {
        try {
            char firstCharOffset = 0;
            char firstNonEmptyChar = document.getChar(firstCharOffset);
            while (firstNonEmptyChar == ' ' || firstNonEmptyChar == '\n' || firstNonEmptyChar == '\r') {
                firstNonEmptyChar = document.getChar(firstCharOffset++);
            }
            if ('[' == firstNonEmptyChar) {
                statementStart = '[';
                statementEnd = ']';
            } else if ('<' == firstNonEmptyChar) {
                statementStart = '<';
                statementEnd = '>';
            }
        } catch (final BadLocationException e) {
            // nothing to do, delimiter will stay as initialized (\u0000)
        }
    }

    /**
     * This will compute the current block positions if the delimiter could be
     * determined. The offset at which computations start is determined by
     * {@link #offset}.
     * 
     * @param initial
     *            Indicates that this is the initial reconciling. Some
     *            annotations have to be initially folded, but we cannot fold
     *            them during edition (see bug 311317).
     */
    private void computePositions(boolean initial) {
        if (statementStart != '\u0000') {
            deletedAnnotations.clear();
            modifiedAnnotations.clear();
            addedAnnotations.clear();
            deletedAnnotations.addAll(currentAnnotations.keySet());
            final Iterator entryIterator = currentAnnotations.entrySet().iterator();
            while (entryIterator.hasNext()) {
                final Map.Entry entry = (Map.Entry) entryIterator.next();
                final Position position = (Position) entry.getValue();
                if (position.getOffset() + position.getLength() < offset) {
                    deletedAnnotations.remove(entry.getKey());
                }
            }
            try {
                boolean eof = seekStatementStart();
                int startOffset = offset;
                while (!eof) {
                    // set offset after the block start delimiter.
                    offset += 2;

                    /*
                     * If this is a comment, it will be foldable when on more
                     * than two lines (first and last line are kept visible when
                     * fold). If if is a script, we'll eat chars aways till the
                     * next script (if this next script is directly preceded by
                     * a comment, it will also be foldable). Else, we are on the
                     * import block which is foldable.
                     */
                    if ("--".equals(document.get(offset, 2))) { //$NON-NLS-1$
                        eof = seekStatementEnd();
                        final int endOffset = offset++;
                        if (document.getNumberOfLines(startOffset, endOffset - startOffset) > 2) {
                            // The very first comment should be initially
                            // collapsed (usually copyright information)
                            /*
                             * bug #311317 : only fold it if this is the initial
                             * reconciling
                             */
                            createOrUpdateAnnotation(startOffset, endOffset - startOffset, initial && startOffset == 0);
                        }
                    } else if (TemplateConstants.LINK_PREFIX_SCRIPT.equals(document.get(offset, TemplateConstants.LINK_PREFIX_SCRIPT.length()))) {
                        eof = seekScriptEnd();
                        int endOffset = getPreviousNonEmty(offset);
                        if (!eof) {
                            // next script is preceded by a comment?
                            if (TemplateConstants.COMMENT_END.equals(document.get(endOffset - TemplateConstants.COMMENT_END.length() + 1, TemplateConstants.COMMENT_END.length()))) {
                                final int commentStart = getPrecedingStatementStart(endOffset - TemplateConstants.COMMENT_END.length() + 1);
                                // If the comment extends on more than two
                                // lines, make it foldable
                                if (document.getNumberOfLines(commentStart, endOffset - commentStart) > 2) {
                                    createOrUpdateAnnotation(commentStart, endOffset - commentStart, false);
                                }

                                endOffset = getPreviousNonEmty(commentStart);
                            }
                        }
                        if (document.getNumberOfLines(startOffset, endOffset - startOffset) > 2) {
                            createOrUpdateAnnotation(startOffset, endOffset - startOffset, false);
                        }
                    } else {
                        // This is the metamodel block
                        eof = seekStatementEnd();
                        final int endOffset = offset++;
                        if (document.getNumberOfLines(startOffset, endOffset - startOffset) > 2) {
                            createOrUpdateAnnotation(startOffset, endOffset - startOffset, false);
                        }
                    }

                    eof = seekStatementStart();
                    startOffset = offset;
                }
            } catch (final BadLocationException e) {
                // Nothing to do
            }
            for (int i = 0; i < deletedAnnotations.size(); i++) {
                currentAnnotations.remove(deletedAnnotations.get(i));
            }
        }
    }

    /**
     * This will update lists {@link #deletedAnnotations},
     * {@link #addedAnnotations} and {@link #modifiedAnnotations} according to
     * the given values.
     * 
     * @param newOffset
     *            Offset of the text we want the annotation updated of.
     * @param newLength
     *            Length of the text we want the annotation updated of.
     * @param initiallyCollapsed
     *            Indicates that the created annotation should be folded from
     *            start.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private void createOrUpdateAnnotation(int newOffset, int newLength, boolean initiallyCollapsed) throws BadLocationException {
        boolean createAnnotation = true;
        final Map copy = new HashMap(currentAnnotations);
        final String text = document.get(newOffset, newLength);
        final Iterator entryIterator = copy.entrySet().iterator();
        while (entryIterator.hasNext()) {
            final Map.Entry entry = (Map.Entry) entryIterator.next();
            if (((Annotation) entry.getKey()).getText().equals(text)) {
                createAnnotation = false;
                final Position oldPosition = (Position) entry.getValue();
                if (oldPosition.getOffset() != newOffset || oldPosition.getLength() != newLength) {
                    final Position newPosition = new Position(newOffset, newLength);
                    modifiedAnnotations.put(entry.getKey(), newPosition);
                    currentAnnotations.put(entry.getKey(), newPosition);
                }
                deletedAnnotations.remove(entry.getKey());
                break;
            }
        }
        if (createAnnotation) {
            final Annotation annotation = new ProjectionAnnotation(initiallyCollapsed);
            annotation.setText(text);
            final Position position = new Position(newOffset, newLength);
            currentAnnotations.put(annotation, position);
            addedAnnotations.put(annotation, position);
        }
    }

    /**
     * This will return the preceding statement start found starting from
     * <code>startOffset</code>.
     * 
     * @param startOffset
     *            Offset from which we need the preceding statement start.
     * @return The preceding statement start offset.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private int getPrecedingStatementStart(int startOffset) throws BadLocationException {
        char next = document.getChar(startOffset);
        while (next != statementStart && '%' != document.getChar(startOffset + 1)) {
            startOffset--;
            next = document.getChar(startOffset);
        }
        return startOffset;
    }

    /**
     * Returns the offset of the first non-white-space character encountered
     * before the given offset.
     * 
     * @param startOffset
     *            Offset at which the reverse search must start.
     * @return Offset of the first previous non-white-space character.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private int getPreviousNonEmty(int startOffset) throws BadLocationException {
        int nonEmptyOffset = startOffset - 1;
        char next = document.getChar(nonEmptyOffset);
        while (next == '\n' || next == '\r' || next == ' ') {
            nonEmptyOffset--;
            next = document.getChar(nonEmptyOffset);
        }
        return nonEmptyOffset;
    }

    /**
     * Eats characters away until we find the end of a script. This actually
     * looks for the start of the next script and rewinds till the end of the
     * latter's preceding comment if any.
     * 
     * @return <code>true</code> if the end of file has been reached.
     *         <code>false</code> otherwise.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private boolean seekScriptEnd() throws BadLocationException {
        seekStatementStart();
        boolean eof = offset + SCRIPT_STATEMENT_LENGTH >= document.getLength();
        while (!eof && !TemplateConstants.LINK_PREFIX_SCRIPT.equals(document.get(offset + 2, TemplateConstants.LINK_PREFIX_SCRIPT.length()))) {
            offset += 2;
            seekStatementStart();
            eof = offset + SCRIPT_STATEMENT_LENGTH >= document.getLength();
        }
        return eof;
    }

    /**
     * Eats all chars away till we find a {@link #statementEnd} char preceded by
     * the '%' character.
     * 
     * @return <code>true</code> if the end of file has been reached.
     *         <code>false</code> otherwise.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private boolean seekStatementEnd() throws BadLocationException {
        char next = document.getChar(offset);
        final boolean eof = offset + 1 >= document.getLength();
        while (!eof && next != statementEnd) {
            offset++;
            next = document.getChar(offset);
        }
        // char is the sought delimiter
        if (!eof && '%' != document.getChar(offset - 1)) {
            offset++;
            seekStatementEnd();
        }
        return eof;
    }

    /**
     * Eats chars away till we find a {@link #statementStart} char followed by
     * the '%' character.
     * 
     * @return <code>true</code> if the end of file has been reached.
     *         <code>false</code> otherwise.
     * @throws BadLocationException
     *             Thrown if we try and get an out of range character. Should
     *             not happen.
     */
    private boolean seekStatementStart() throws BadLocationException {
        char next = document.getChar(offset);
        boolean eof = offset + 1 >= document.getLength();
        while (!eof && next != statementStart) {
            offset++;
            next = document.getChar(offset);
            eof = offset + 1 == document.getLength();
        }
        // char is the sought delimiter
        if (!eof && '%' != document.getChar(offset + 1)) {
            offset++;
            seekStatementStart();
        }
        return eof;
    }

    /**
     * Updates the editor's folding structure.
     */
    private void updateFoldingStructure() {
        Display.getDefault().asyncExec(new Runnable() {
            public void run() {
                editor.updateFoldingStructure(addedAnnotations, deletedAnnotations, modifiedAnnotations);
            }
        });
    }
}
