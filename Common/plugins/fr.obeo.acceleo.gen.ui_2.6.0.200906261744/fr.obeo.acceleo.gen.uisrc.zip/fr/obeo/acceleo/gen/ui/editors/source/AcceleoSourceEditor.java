/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.source.IAnnotationAccess;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.ui.editors.text.TextFileDocumentProvider;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.texteditor.AbstractDecoratedTextEditor;
import org.eclipse.ui.texteditor.IAbstractTextEditorHelpContextIds;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.IWorkbenchActionDefinitionIds;
import org.eclipse.ui.texteditor.ResourceAction;
import org.eclipse.ui.texteditor.TextOperationAction;

import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.phantom.ChainPhantomProvider;
import fr.obeo.acceleo.gen.phantom.SyncPhantom;
import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENode;
import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.gen.template.eval.TextModelMapping;
import fr.obeo.acceleo.gen.template.eval.log.EvalFailure;
import fr.obeo.acceleo.gen.template.eval.merge.MergeTools;
import fr.obeo.acceleo.gen.template.scripts.EmptyScript;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveSettings;
import fr.obeo.acceleo.gen.ui.editors.reflective.IPreviewPart;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceDeleteGeneratorAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceGenerateHierarchyAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceOpenDefaultAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceOpenLinkAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceReGenerateHierarchyAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceRefreshAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceReloadGeneratorAction;
import fr.obeo.acceleo.gen.ui.editors.reflective.actions.AcceleoSourceSelectGeneratorAction;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;
import fr.obeo.acceleo.tools.classloaders.AcceleoClassLoader;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.ui.views.AcceleoConsole;

/**
 * This is the source editor used in the second page of the reflective editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceEditor extends AbstractDecoratedTextEditor implements IPreviewPart {

	private fr.obeo.acceleo.tools.ui.graphics.ColorManager colorManager = new fr.obeo.acceleo.tools.ui.graphics.ColorManager();

	// Foreground color for the text which is not in the model.
	protected final Color STATIC_TEXT_FOREGROUND = colorManager.getColor(new RGB(150, 50, 170));

	// Foreground color for the text which is comment
	protected final Color COMMENT_FOREGROUND = colorManager.getColor(new RGB(100, 180, 100));

	// Background color for the selected text
	protected final Color SELECTED_TEXT_BACKGROUND = colorManager.getColor(new RGB(230, 200, 250));

	// Foreground color for the selected text
	protected final Color SELECTED_TEXT_FOREGROUND = colorManager.getColor(new RGB(0, 0, 0));

	/**
	 * Document provider.
	 */
	private class AcceleoSourceDocumentProvider extends TextFileDocumentProvider {
		public IDocument getDocument(Object element) {
			IDocument document = super.getDocument(element);
			document.set(""); //$NON-NLS-1$
			return document;
		}
	}

	/**
	 * Model file.
	 */
	protected IFile xmi;

	/**
	 * Optional chain file.
	 */
	protected IFile chain;

	/**
	 * Object currently selected.
	 */
	protected EObject object;

	/**
	 * Object which is currently generated.
	 */
	protected EObject evalEObject = null;

	/**
	 * Current node of generation.
	 */
	protected ENode eval = null;

	/**
	 * Reflective editor settings that know available generators.
	 */
	protected AcceleoReflectiveSettings settings;

	/**
	 * Reflective editor.
	 */
	protected AcceleoReflectiveEditor reflective;

	/**
	 * Listener which is notified when a viewer's selection changes.
	 */
	protected ISelectionChangedListener selectionChangedListener;

	/**
	 * Annotation model.
	 */
	protected AcceleoSourceAnnotationModel problemHandler = null;

	/**
	 * Constructor.
	 * 
	 * @param reflective
	 *            is the reflective editor.
	 * @param xmi
	 *            is the model file.
	 */
	public AcceleoSourceEditor(AcceleoReflectiveEditor reflective, IFile xmi) {
		super();
		this.settings = new AcceleoReflectiveSettings();
		this.settings.init(new EmptyScript());
		this.reflective = reflective;
		this.xmi = xmi;
		this.object = reflective.getRoot();
		setSourceViewerConfiguration(new AcceleoSourceConfiguration(this));
		setDocumentProvider(new AcceleoSourceDocumentProvider());
	}

	/**
	 * @return the model file
	 */
	public IFile getXmi() {
		return xmi;
	}

	/**
	 * @return the reflective editor
	 */
	public AcceleoReflectiveEditor getReflective() {
		return reflective;
	}

	/* (non-Javadoc) */
	public EObject getSelectedEObject() {
		return object;
	}

	/* (non-Javadoc) */
	public AcceleoReflectiveSettings getSettings() {
		return settings;
	}

	/* (non-Javadoc) */
	public void selectGenerator(File file, IFile chain) throws TemplateSyntaxExceptions, CoreException {
		AcceleoClassLoader.setPreferredLoader(reflective.getRoot());
		try {
			this.chain = chain;
			File chainFile = (chain != null) ? chain.getLocation().toFile() : null;
			SpecificScript specificGenSettings = new SpecificScript(file, chainFile, null);
			specificGenSettings.reset();
			settings.setScript(specificGenSettings);
			refresh();
		} finally {
			AcceleoClassLoader.setPreferredLoader(null);
		}
	}

	/* (non-Javadoc) */
	public void reloadGenerator() throws TemplateSyntaxExceptions, CoreException {
		AcceleoClassLoader.setPreferredLoader(reflective.getRoot());
		try {
			settings.resetScript();
			refresh();
		} finally {
			AcceleoClassLoader.setPreferredLoader(null);
		}
	}

	/* (non-Javadoc) */
	public void deleteGenerator() throws CoreException {
		AcceleoClassLoader.setPreferredLoader(reflective.getRoot());
		try {
			settings.reloadDefaultScript();
			refresh();
		} finally {
			AcceleoClassLoader.setPreferredLoader(null);
		}
	}

	/* (non-Javadoc) */
	public void refresh() {
		if (AcceleoConsole.canShow())
			AcceleoConsole.getDefault().asDefaultForSystemOut();
		problemHandler.setAcceptSourceLog(settings.getScript().isDefault());
		EObject object_ = object;
		reset();
		reflective.refresh();
		if (object_ != null)
			reflective.getContentOutlinePage().setSelection(new StructuredSelection(object_));
	}

	/* (non-Javadoc) */
	public void dispose() {
		super.dispose();
		reflective.getContentOutlinePage().removeSelectionChangedListener(selectionChangedListener);
		colorManager.dispose();
	}

	/**
	 * Erase the memory for click on the objects of the model.
	 */
	public void reset() {
		object2Eval.clear();
		object = null;
		evalEObject = null;
	}

	/* (non-Javadoc) */
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		super.init(site, input);
		selectionChangedListener = createSelectionChangeListener();
		reflective.getContentOutlinePage().addSelectionChangedListener(selectionChangedListener);
	}

	private ISelectionChangedListener createSelectionChangeListener() {
		return new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				ISelection selection = event.getSelection();
				Object element = ((IStructuredSelection) selection).getFirstElement();
				EObject object = element instanceof EObject ? (EObject) element : null;
				if (object != null) {
					selectEObject(object);
				}
			}
		};
	}

	/* (non-Javadoc) */
	protected ISourceViewer createSourceViewer(Composite parent, IVerticalRuler ruler, int styles) {
		ISourceViewer viewer = super.createSourceViewer(parent, ruler, styles);
		return viewer;
	}

	/* (non-Javadoc) */
	protected void doSetInput(IEditorInput input) throws CoreException {
		IResource resource = input instanceof IFileEditorInput ? ((IFileEditorInput) input).getFile() : null;
		if (resource != null) {
			if (problemHandler == null)
				problemHandler = new AcceleoSourceAnnotationModel(this, resource);
		}
		input = new FileEditorInput(reflective.getFile().getProject().getFile(".project")); //$NON-NLS-1$ // workaround
		// :
		// ASSERT
		// file.exists()
		super.doSetInput(input);
	}

	/* (non-Javadoc) */
	public boolean isEditable() {
		return false;
	}

	/* (non-Javadoc) */
	public void doSave(IProgressMonitor progressMonitor) {
		try {
			IFile file = tryToGetCurrentFile();
			if (file != null) {
				InputStream contents = new ByteArrayInputStream(getSourceViewer().getDocument().get().getBytes());
				if (file.exists()) {
					file.setContents(contents, true, true, new SubProgressMonitor(progressMonitor, 1));
				} else {
					file.create(contents, true, new SubProgressMonitor(progressMonitor, 1));
				}
			}
		} catch (CoreException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
		}
	}

	/* (non-Javadoc) */
	public void doSaveAs() {
	}

	/* (non-Javadoc) */
	protected IAnnotationAccess createAnnotationAccess() {
		return new AcceleoSourceAnnotationAccess();
	}

	/* (non-Javadoc) */
	public void selectAndReveal(int start, int length) {
		getSourceViewer().getTextWidget().setSelectionForeground(SELECTED_TEXT_FOREGROUND);
		getSourceViewer().getTextWidget().setSelectionBackground(SELECTED_TEXT_BACKGROUND);
		super.selectAndReveal(start, length);
	}

	/**
	 * An object is selected in the model. Search parent object which can be
	 * generated. The editor contains the text generated for parent object. If
	 * it isn't found, editor becomes empty. Update error markers and highlight
	 * selected range.
	 * 
	 * @param object
	 *            selected
	 */
	protected void selectEObject(EObject object) {
		boolean sameObject = true;
		if (object != this.object) {
			sameObject = false;
			this.object = object;
			// Search parent object which can be generated
			EObject newEvalEObject = getEvalEObject(object);
			if (newEvalEObject == null) {
				// Parent object not found -> empty text
				object = null;
				evalEObject = null;
				eval = null;
				getSourceViewer().setDocument(new Document(""), problemHandler); //$NON-NLS-1$
				applyTextPresentation();
				problemHandler.acceptProblems(eval);
			} else if (evalEObject != newEvalEObject) {
				// Parent object found and different -> generate text
				evalEObject = newEvalEObject;
				IRunnableWithProgress runnable = new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) {
						try {
							LaunchManager mode = LaunchManager.create("run", true); //$NON-NLS-1$
							mode.setMonitor(monitor);
							eval = evaluate(evalEObject, mode);
						} catch (ENodeException e) {
							AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
							eval = null;
						} catch (FactoryException e) {
							AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
							eval = null;
						}
					}
				};
				try {
					PlatformUI.getWorkbench().getProgressService().run(true, true, runnable);
				} catch (InvocationTargetException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					evalEObject = null;
					eval = null;
				} catch (InterruptedException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoSourceEditor.EvaluationInterrupted"), true); //$NON-NLS-1$
					evalEObject = null;
					eval = null;
				}
				if (eval != null) {
					String text = eval.asString();
					getSourceViewer().setDocument(new Document(text), problemHandler);
					applyTextPresentation();
					// Generated text equals file content?
					IFile file = tryToGetCurrentFile();
					if (file != null) {
						String content = Resources.getFileContent(file).toString();
						if (!Resources.equalsFileContent(content, text)) {
							eval.log().addError(new EvalFailure(AcceleoGenUIMessages.getString("AcceleoSourceEditor.InvalidEvaluation"))); //$NON-NLS-1$
						}
					}
					// Update error markers
					problemHandler.acceptProblems(eval);
				}
			}
		}
		Int2[] positions = getPositions(object);
		if (positions.length > 0) {
			Int2 pos = null;
			if (updateSelection > -1) {
				for (int i = 0; i < positions.length && pos == null; i++) {
					if (positions[i].b() <= updateSelection && positions[i].e() > updateSelection) {
						pos = positions[i];
					}
				}
			} else {
				if (sameObject) {
					IRegion region = getHighlightRange();
					if (region != null) {
						for (int i = 0; i < positions.length && pos == null; i++) {
							if (positions[i].b() >= region.getOffset() + region.getLength()) {
								pos = positions[i];
							}
						}
					}
				}
			}
			if (pos == null) {
				pos = positions[0];
			}
			ISourceViewer viewer = getSourceViewer();
			StyledText widget = viewer.getTextWidget();
			widget.setRedraw(false);
			try {
				setHighlightRange(pos.b(), pos.e() - pos.b(), true);
			} catch (Exception e) {
			}
			selectAndReveal(pos.b(), pos.e() - pos.b());
			widget.setRedraw(true);
		} else {
			IRegion region = getHighlightRange();
			if (region != null) {
				selectAndReveal(region.getOffset(), 0);
			} else {
				selectAndReveal(0, 0);
			}
		}
	}

	/**
	 * Returns the positions of the given object
	 * 
	 * @param object
	 *            is the model object
	 * @return the positions
	 */
	protected Int2[] getPositions(EObject object) {
		if (eval != null && eval.getTextModelMapping() != null) {
			Int2[] result = eval.getTextModelMapping().eObject2Positions(object);
			while (object != null && result.length == 0) {
				object = object.eContainer();
				result = eval.getTextModelMapping().eObject2Positions(object);
			}
			return result;
		} else {
			return new Int2[] {};
		}
	}

	/**
	 * Selection memory.
	 */
	protected Map object2Eval = new HashMap();

	/**
	 * Search parent object which can be generated for given object.
	 * 
	 * @param object
	 *            selected
	 * @return parent object which can be generated
	 */
	protected EObject getEvalEObject(EObject object) {
		while (object != null && !settings.getScript().isGenerated(object)) {
			object = object.eContainer();
		}
		return object;
	}

	/**
	 * Generate text for given object.
	 * 
	 * @param evalEObject
	 *            is an object which can be generated
	 * @param mode
	 *            is the mode
	 * @return a node of generation
	 * @throws FactoryException
	 * @throws ENodeException
	 */
	protected ENode evaluate(EObject evalEObject, LaunchManager mode) throws FactoryException, ENodeException {
		ENode eval = (ENode) object2Eval.get(evalEObject);
		if (eval == null) {
			Template template = settings.getScript().getRootTemplate(evalEObject, true);
			if (template != null) {
				boolean withComment = settings.getScript().isDefault() || !settings.getScript().hasFileTemplate();
				if (withComment) {
					eval = template.evaluateWithComment(evalEObject, mode);
				} else {
					eval = template.evaluate(evalEObject, mode);
				}
				object2Eval.put(evalEObject, eval);
			} else {
				eval = new ENode(ENode.EMPTY, evalEObject, Template.EMPTY, true);
			}
		}
		return eval;
	}

	/* (non-Javadoc) */
	public IFile tryToGetCurrentFile() {
		return null;
	}

	/**
	 * Select the object at the given position.
	 * 
	 * @param pos
	 *            is the position in the text
	 */
	public void updateSelection(int pos) {
		updateSelection = pos;
		try {
			if (eval != null && pos > -1) {
				// EObject
				if (eval.getTextModelMapping() != null) {
					EObject object = eval.getTextModelMapping().index2EObject(pos);
					if (object != null) {
						reflective.getContentOutlinePage().setSelection(new StructuredSelection(object));
					}
				}
				// TemplateElement
				if (eval.getTextTemplateElementMapping() != null) {
					if (getSettings() != null && getSettings().getScript() != null && getSettings().getScript().getFile() != null) {
						TemplateElement element = eval.getTextTemplateElementMapping().index2TemplateElement(pos);
						if (element != null) {
							Int2 posInTemplate = element.getPos();
							if (posInTemplate.b() > -1) {
								IEditorReference[] editors = getSite().getPage().getEditorReferences();
								for (int i = 0; i < editors.length; i++) {
									IEditorPart editor = editors[i].getEditor(true);
									if (editor instanceof AcceleoTemplateEditor) {
										if (getSettings().getScript().getFile().equals(((AcceleoTemplateEditor) editor).getFile())) {
											((AcceleoTemplateEditor) editor).setHighlightRange(posInTemplate.b(), posInTemplate.e(), true);
										}
									}
								}
							}
						}
					}
				}
			}
		} finally {
			updateSelection = -1;
		}
	}

	private int updateSelection = -1;

	/**
	 * Apply presentation settings.
	 */
	protected void applyTextPresentation() {
		if (eval != null && eval.getTextModelMapping() != null) {
			Int2[] pos = eval.getTextModelMapping().getHighlightedPos(TextModelMapping.HIGHLIGHTED_STATIC_TEXT);
			for (int i = 0; i < pos.length; i++) {
				getSourceViewer().setTextColor(STATIC_TEXT_FOREGROUND, pos[i].b(), pos[i].e() - pos[i].b(), false);
			}
			pos = eval.getTextModelMapping().getHighlightedPos(TextModelMapping.HIGHLIGHTED_COMMENT);
			for (int i = 0; i < pos.length; i++) {
				getSourceViewer().setTextColor(COMMENT_FOREGROUND, pos[i].b(), pos[i].e() - pos[i].b(), false);
			}
			getSourceViewer().getTextWidget().redraw();
		}
	}

	/* (non-Javadoc) */
	protected void createActions() {
		// Acceleo actions
		IAction action = new AcceleoSourceSelectGeneratorAction(reflective, new String[] { SpecificScript.GENERATORS_EXTENSION });
		setAction("Editors.SelectGeneratorAction", action); //$NON-NLS-1$
		action = new AcceleoSourceReloadGeneratorAction(reflective);
		setAction("Editors.ReloadGeneratorAction", action); //$NON-NLS-1$
		action = new AcceleoSourceDeleteGeneratorAction(reflective);
		setAction("Editors.DeleteGeneratorAction", action); //$NON-NLS-1$
		action = new AcceleoSourceRefreshAction(reflective);
		setAction("Editors.RefreshAction", action); //$NON-NLS-1$
		action = new AcceleoSourceGenerateHierarchyAction(reflective);
		setAction("Editors.GenerateHierarchyAction", action); //$NON-NLS-1$
		action = new AcceleoSourceReGenerateHierarchyAction(reflective);
		setAction("Editors.ReGenerateHierarchyAction", action); //$NON-NLS-1$
		action = new AcceleoSourceOpenDefaultAction(reflective);
		setAction("Editors.OpenDefaultAction", action); //$NON-NLS-1$
		action = new AcceleoSourceOpenLinkAction(reflective);
		setAction("Editors.OpenLinkAction", action); //$NON-NLS-1$
		// Copy action
		action = new TextOperationAction(AcceleoGenUIMessages.getResourceBundle(), "Editors.Copy.", this, ITextOperationTarget.COPY, true); //$NON-NLS-1$
		((ResourceAction) action).setHelpContextId(IAbstractTextEditorHelpContextIds.COPY_ACTION);
		action.setActionDefinitionId(IWorkbenchActionDefinitionIds.COPY);
		setAction(ITextEditorActionConstants.COPY, action);
		// Select all action
		action = new TextOperationAction(AcceleoGenUIMessages.getResourceBundle(), "Editors.SelectAll.", this, ITextOperationTarget.SELECT_ALL, true); //$NON-NLS-1$
		((ResourceAction) action).setHelpContextId(IAbstractTextEditorHelpContextIds.SELECT_ALL_ACTION);
		action.setActionDefinitionId(IWorkbenchActionDefinitionIds.SELECT_ALL);
		setAction(ITextEditorActionConstants.SELECT_ALL, action);

		// F5
		ICommandService vCommandService = (ICommandService) getSite().getService(ICommandService.class);
		Command vCommand = vCommandService.getCommand("org.eclipse.ui.file.refresh"); //$NON-NLS-1$
		if (vCommand.isDefined()) {
			IHandlerService handlerService = (IHandlerService) getSite().getService(IHandlerService.class);
			IHandler handler = new AbstractHandler() {
				public Object execute(ExecutionEvent event) throws ExecutionException {
					getAction("Editors.ReloadGeneratorAction").run(); //$NON-NLS-1$
					return null;
				}
			};
			handlerService.activateHandler("org.eclipse.ui.file.refresh", handler); //$NON-NLS-1$
		}
		// Select All
		final IAction selectAllAction = getAction(ITextEditorActionConstants.SELECT_ALL);
		Command selectAllCommand = vCommandService.getCommand(selectAllAction.getActionDefinitionId());
		if (selectAllCommand.isDefined()) {
			IHandlerService handlerService = (IHandlerService) getSite().getService(IHandlerService.class);
			IHandler handler = new AbstractHandler() {
				public Object execute(ExecutionEvent event) throws ExecutionException {
					selectAllAction.run();
					return null;
				}
			};
			handlerService.activateHandler(selectAllAction.getActionDefinitionId(), handler);
		}
		// Copy
		final IAction copyAction = getAction(ITextEditorActionConstants.COPY);
		Command copyCommand = vCommandService.getCommand(copyAction.getActionDefinitionId());
		if (copyCommand.isDefined()) {
			IHandlerService handlerService = (IHandlerService) getSite().getService(IHandlerService.class);
			IHandler handler = new AbstractHandler() {
				public Object execute(ExecutionEvent event) throws ExecutionException {
					copyAction.run();
					return null;
				}
			};
			handlerService.activateHandler(copyAction.getActionDefinitionId(), handler);
		}
	}

	/* (non-Javadoc) */
	protected void editorContextMenuAboutToShow(IMenuManager menu) {
		MenuManager submenu = new MenuManager("Acceleo"); //$NON-NLS-1$
		addAction(submenu, "Editors.SelectGeneratorAction"); //$NON-NLS-1$
		addAction(submenu, "Editors.ReloadGeneratorAction"); //$NON-NLS-1$
		addAction(submenu, "Editors.DeleteGeneratorAction"); //$NON-NLS-1$
		addAction(submenu, "Editors.GenerateHierarchyAction"); //$NON-NLS-1$
		addAction(submenu, "Editors.ReGenerateHierarchyAction"); //$NON-NLS-1$
		submenu.add(new Separator("source")); //$NON-NLS-1$
		addAction(submenu, "Editors.RefreshAction"); //$NON-NLS-1$
		submenu.add(new Separator("browse")); //$NON-NLS-1$
		addAction(submenu, "Editors.OpenDefaultAction"); //$NON-NLS-1$
		addAction(submenu, "Editors.OpenLinkAction"); //$NON-NLS-1$
		menu.add(submenu);
		menu.add(new Separator("generator")); //$NON-NLS-1$
		menu.add(new Separator(ITextEditorActionConstants.GROUP_EDIT));
		menu.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
		addAction(menu, ITextEditorActionConstants.GROUP_EDIT, ITextEditorActionConstants.SELECT_ALL);
		addAction(menu, ITextEditorActionConstants.GROUP_EDIT, ITextEditorActionConstants.COPY);
	}

	/* (non-Javadoc) */
	public void openLink() {
		if (eval != null && eval.getTextModelMapping() != null) {
			int pos = getSourceViewer().getTextWidget().getCaretOffset();
			if (pos > -1) {
				EObject linkEObject = eval.getTextModelMapping().index2LinkEObject(pos);
				if (linkEObject != null) {
					reflective.getContentOutlinePage().setSelection(new StructuredSelection(linkEObject));
				}
			}
		}
	}

	/* (non-Javadoc) */
	public void generate(IContainer targetContainer, IProgressMonitor progressMonitor) throws FactoryException, ENodeException, CoreException {
		lastGenerateHierarchyContainer = targetContainer;
		List files = generate(targetContainer, true, progressMonitor);
		if (chain != null) {
			ChainPhantomProvider.getDefault().add(chain, (IFile[]) files.toArray(new IFile[files.size()]), progressMonitor);
		}
	}

	protected List generate(IContainer targetContainer, boolean recursive, IProgressMonitor progressMonitor) throws FactoryException, ENodeException, CoreException {
		return generate(targetContainer, object, recursive, progressMonitor);
	}

	protected List generate(IContainer targetContainer, EObject object, boolean recursive, IProgressMonitor progressMonitor) throws FactoryException, ENodeException, CoreException {
		List result = new ArrayList();
		if (settings.getScript().isGenerated(object)) {
			IPath path = settings.getScript().getFilePath(object, true);
			// path != null => Generate file
			if (path != null) {
				StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
				long startTime = System.currentTimeMillis();
				eval = evaluate(object, LaunchManager.create("run", true)); //$NON-NLS-1$
				if (eval.log().hasError()) {
					report.append("->"); //$NON-NLS-1$
					report.append(AcceleoGenUIMessages.getString("AcceleoSourceEditor.GenerationError", new Object[] { path })); //$NON-NLS-1$
					report.append('\n');
					report.append(eval.log().toString());
					report.append('\n');
				}
				StringBuffer buffer = new StringBuffer(eval.asString());
				StringBuffer oldBuffer = Resources.getFileContent(targetContainer.getFile(path), false);
				if (oldBuffer.length() > 0) {
					String lostCode = MergeTools.merge(targetContainer.getFile(path), buffer, oldBuffer, MergeTools.DEFAULT_USER_BEGIN, MergeTools.DEFAULT_USER_END);
					if (lostCode.length() > 0) {
						lostCode = '[' + AcceleoGenUIMessages.getString("AcceleoSourceEditor.LostCode") + "] " + new Date().toString() + '\n' + lostCode + '\n'; //$NON-NLS-1$ //$NON-NLS-2$
						Resources.appendFile(targetContainer, path.addFileExtension(MergeTools.LOST_FILE_EXTENSION), lostCode, progressMonitor).setDerived(true);
					}
				}
				IFile generated = Resources.createFile(targetContainer, path, buffer.toString(), progressMonitor);
				long endTime = System.currentTimeMillis();
				SyncPhantom.createPhantomExtensionPoint(generated, getReflective().getFile(), settings.getScript().getFile(), targetContainer, chain, eval, endTime - startTime, progressMonitor);
				result.add(generated);
				if (report.length() > 0) {
					AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoSourceEditor.GenerationReport", new Object[] { path.toString() }) + '\n' + report.toString(), true); //$NON-NLS-1$
				}
			}
		}
		if (recursive)
			result.addAll(generateSub(targetContainer, object, progressMonitor));
		return result;
	}

	protected List generateSub(IContainer targetContainer, EObject object, IProgressMonitor progressMonitor) throws FactoryException, ENodeException, CoreException {
		List result = new ArrayList();
		Iterator contents = object.eContents().iterator();
		while (contents.hasNext()) {
			EObject content = (EObject) contents.next();
			result.addAll(generate(targetContainer, content, true, progressMonitor));
		}
		return result;
	}

	/**
	 * Last target container used to generate files for the selected object.
	 */
	protected IContainer lastGenerateHierarchyContainer = null;

	/* (non-Javadoc) */
	public IContainer getLastGenerateHierarchyContainer() {
		return lastGenerateHierarchyContainer;
	}

	/* (non-Javadoc) */
	public void setLastGenerateHierarchyContainer(IContainer lastGenerateHierarchyContainer) {
		this.lastGenerateHierarchyContainer = lastGenerateHierarchyContainer;
	}

	/* (non-Javadoc) */
	public String getName() {
		return AcceleoGenUIMessages.getString("AcceleoSourceEditor.TabLabel"); //$NON-NLS-1$
	}

}
