/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.gen.ui.wizards;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IExportWizard;
import org.eclipse.ui.IWorkbench;

import fr.obeo.acceleo.gen.template.AcceleoCompiler;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Wizard to export a generator project to a Template model.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoExportToModelWizard extends Wizard implements IExportWizard {

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * The page to select the templates.
	 */
	protected AcceleoSelectFilesWizardPage pageSelectFiles;

	/**
	 * The page to create a new model.
	 */
	protected AcceleoNewFileWizardPage pageNewFile;

	/**
	 * Create the wizard.
	 */
	public AcceleoExportToModelWizard() {
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String containerName = pageNewFile.getContainerName();
		final String fileName = pageNewFile.getFileName();
		final IPath[] scripts = pageSelectFiles.getSelection();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(containerName, fileName, scripts, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e.getTargetException(), true);
			return false;
		}
		return true;
	}

	private void doFinish(String containerName, String fileName, IPath[] scripts, IProgressMonitor monitor) throws CoreException {
		if (scripts != null && scripts.length == 1 && scripts[0] != null) {
			IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
			IResource resource = root.findMember(new Path(containerName));
			if (resource == null || !resource.exists() || !(resource instanceof IContainer)) {
				AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoGenUIMessages.getString("AcceleoNewEmptyTemplateWizard.Error.InvalidContainer", new Object[] { containerName }), true); //$NON-NLS-1$
			} else {
				IContainer container = (IContainer) resource;
				File script = AcceleoModuleProvider.getDefault().getFile(scripts[0]);
				if (script != null && script.exists()) {
					try {
						SpecificScript aScript = new SpecificScript(script, null, null);
						aScript.reset();
						AcceleoCompiler compiler = new AcceleoCompiler();
						EObject result = compiler.export(aScript);
						if (result != null) {
							save(result, container.getFullPath().append(fileName).toString());
						}
					} catch (TemplateSyntaxExceptions e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (ENodeException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					} catch (IOException e) {
						AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
					}
				}
			}
		}
	}

	private void save(EObject result, String modelURI) throws IOException {
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		Resource newModelResource = resourceSet.createResource(Resources.createPlatformResourceURI(modelURI));
		newModelResource.getContents().add(result);
		Map options = new HashMap();
		newModelResource.save(options);
		newModelResource.unload();
	}

	/* non-javadoc */
	public void addPages() {
		addPage(pageSelectFiles = new AcceleoSelectFilesWizardPage(AcceleoGenUIMessages.getString("AcceleoExportToModelWizard.SelectGen"), 1, 1, new String[] { "mt" }, true)); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageNewFile = new AcceleoNewFileWizardPage(AcceleoGenUIMessages.getString("AcceleoExportToModelWizard.NewFile"), selection, "emt")); //$NON-NLS-1$ //$NON-NLS-2$
	}

	/* non-javadoc */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		setWindowTitle(AcceleoGenUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

}
