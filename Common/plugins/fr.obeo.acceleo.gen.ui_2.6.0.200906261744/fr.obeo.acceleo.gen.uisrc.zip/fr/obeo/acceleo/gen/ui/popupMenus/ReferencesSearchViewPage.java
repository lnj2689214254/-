/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.part.IShowInTargetList;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;

/**
 * This class is the page referenced by the extention point
 * org.eclipse.search.searchResultViewPages. It is used to show
 * ReferencesSearchResult
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferencesSearchViewPage extends AbstractTextSearchViewPage implements IAdaptable {
	/**
	 * The TreeContentProvider to use
	 */
	private ReferencesTreeContentProvider treeContentProvider;

	/**
	 * Constructor
	 */
	public ReferencesSearchViewPage() {
		super(AbstractTextSearchViewPage.FLAG_LAYOUT_TREE);
	}

	private static final String[] SHOW_IN_TARGETS = new String[] { IPageLayout.ID_RES_NAV };

	private static final IShowInTargetList SHOW_IN_TARGET_LIST = new IShowInTargetList() {
		public String[] getShowInTargetIds() {
			return SHOW_IN_TARGETS;
		}
	};

	/* (non-Javadoc) */
	protected void clear() {
		if (treeContentProvider != null)
			treeContentProvider.clear();
	}

	/* (non-Javadoc) */
	protected void configureTableViewer(TableViewer viewer) {
	}

	/* (non-Javadoc) */
	protected void configureTreeViewer(TreeViewer viewer) {
		viewer.setUseHashlookup(true);
		viewer.setSorter(new ReferenceSorter());
		viewer.setLabelProvider(new ReferenceLabelProvider());
		treeContentProvider = new ReferencesTreeContentProvider(viewer);
		viewer.setContentProvider(treeContentProvider);
	}

	/* (non-Javadoc) */
	protected void elementsChanged(Object[] objects) {
		if (treeContentProvider != null)
			treeContentProvider.elementsChanged(objects);
	}

	/* (non-Javadoc) */
	public Object getAdapter(Class adapter) {
		if (IShowInTargetList.class.equals(adapter)) {
			return SHOW_IN_TARGET_LIST;
		}
		return null;
	}

	/* (non-Javadoc) */
	protected void showMatch(Match match, int currentOffset, int currentLength, boolean activate) throws PartInitException {
		if (match.getElement() instanceof ReferenceEntry) {
			IFile file = ((ReferenceEntry) match.getElement()).getTemplateFile();
			if (file != null) {
				IWorkbenchWindow workbenchWindow = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
				IWorkbenchPage page = workbenchWindow.getActivePage();
				try {
					AcceleoTemplateEditor editor = (AcceleoTemplateEditor) page.openEditor(new FileEditorInput(file), "fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor"); //$NON-NLS-1$
					editor.selectAndReveal(match.getOffset(), match.getLength());
				} catch (PartInitException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}
		}
	}
}
