/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template.scanner;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.Token;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.editors.template.ColorManager;
import fr.obeo.acceleo.gen.ui.editors.template.rule.BlockRule;
import fr.obeo.acceleo.gen.ui.editors.template.rule.KeywordRule;

/**
 * Global partition scanner.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplatePartitionScanner extends RuleBasedPartitionScanner {

	// Comment identifier
	public final static String TEMPLATE_COMMENT = "__template_comment"; //$NON-NLS-1$

	// Script identifier
	public final static String TEMPLATE_SCRIPT = "__template_script"; //$NON-NLS-1$

	// User identifier
	public final static String TEMPLATE_USER = "__template_user"; //$NON-NLS-1$

	// If identifier
	public final static String TEMPLATE_IF = "__template_if"; //$NON-NLS-1$

	// For identifier
	public final static String TEMPLATE_FOR = "__template_for"; //$NON-NLS-1$

	// Feature identifier
	public final static String TEMPLATE_FEATURE = "__template_feature"; //$NON-NLS-1$

	// All legal content types
	public final static String[] LEGAL_CONTENT_TYPES = new String[] { TEMPLATE_COMMENT, TEMPLATE_SCRIPT, TEMPLATE_USER, TEMPLATE_IF, TEMPLATE_FOR, TEMPLATE_FEATURE };

	/**
	 * Constructor.
	 */
	public AcceleoTemplatePartitionScanner(ColorManager manager) {
		List rules = new ArrayList();
		BlockRule literal = new BlockRule(TemplateConstants.LITERAL[0], TemplateConstants.LITERAL[1], TemplateConstants.LITERAL_SPEC, new Token(IDocument.DEFAULT_CONTENT_TYPE));
		/** * Comment ** */
		rules.add(new BlockRule(TemplateConstants.COMMENT_BEGIN, TemplateConstants.COMMENT_END, new BlockRule[] {}, new Token(TEMPLATE_COMMENT)));
		/** * Script ** */
		rules.add(new BlockRule(TemplateConstants.SCRIPT_BEGIN, TemplateConstants.SCRIPT_END, new BlockRule[] { literal }, new Token(TEMPLATE_SCRIPT)));
		/** * User ** */
		rules.add(new BlockRule(TemplateConstants.USER_BEGIN, "\n", new BlockRule[] {}, new Token(TEMPLATE_USER))); //$NON-NLS-1$
		rules.add(new BlockRule(TemplateConstants.USER_END, "\n", new BlockRule[] {}, new Token(TEMPLATE_USER))); //$NON-NLS-1$
		/** * If ** */
		rules.add(new BlockRule(TemplateConstants.IF_BEGIN, TemplateConstants.IF_THEN, new BlockRule[] { literal }, new Token(TEMPLATE_IF)));
		rules.add(new BlockRule(TemplateConstants.IF_ELSE_IF, TemplateConstants.IF_THEN, new BlockRule[] { literal }, new Token(TEMPLATE_IF)));
		rules.add(new KeywordRule(TemplateConstants.IF_ELSE, new Token(TEMPLATE_IF)));
		rules.add(new KeywordRule(TemplateConstants.IF_END, new Token(TEMPLATE_IF)));
		/** * For ** */
		rules.add(new BlockRule(TemplateConstants.FOR_BEGIN, TemplateConstants.FOR_THEN, new BlockRule[] { literal }, new Token(TEMPLATE_FOR)));
		rules.add(new KeywordRule(TemplateConstants.FOR_END, new Token(TEMPLATE_FOR)));
		/** * Feature ** */
		rules.add(new BlockRule(TemplateConstants.FEATURE_BEGIN, TemplateConstants.FEATURE_END, new BlockRule[] {}, new Token(TEMPLATE_FEATURE)));
		setPredicateRules((IPredicateRule[]) rules.toArray(new IPredicateRule[rules.size()]));
	}

}
