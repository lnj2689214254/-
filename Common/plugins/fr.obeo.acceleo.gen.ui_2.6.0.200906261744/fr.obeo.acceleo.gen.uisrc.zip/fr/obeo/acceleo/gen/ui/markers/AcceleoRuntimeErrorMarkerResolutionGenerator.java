/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.markers;

import java.util.Iterator;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.presentation.EcoreEditor;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.edit.domain.EditingDomain;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IMarkerResolution;
import org.eclipse.ui.IMarkerResolution2;
import org.eclipse.ui.IMarkerResolutionGenerator2;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;

/**
 * The quick fix resolutions of the runtime error marker.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoRuntimeErrorMarkerResolutionGenerator implements IMarkerResolutionGenerator2 {

	/* (non-Javadoc) */
	public IMarkerResolution[] getResolutions(IMarker marker) {
		IMarkerResolution[] result = new IMarkerResolution2[2];
		result[0] = new IMarkerResolution2() {
			public String getLabel() {
				return AcceleoGenUIMessages.getString("AcceleoRuntimeErrorMarkerResolutionGenerator.Resolution1.Label"); //$NON-NLS-1$
			}

			public void run(IMarker marker) {
				try {
					String modelPath = (String) marker.getAttribute(ENodeException.RUNTIME_ERROR_MARKER_MODEL);
					String uriFragment = (String) marker.getAttribute(ENodeException.RUNTIME_ERROR_MARKER_FRAGMENT);
					openModelEditor(modelPath, uriFragment);
				} catch (PartInitException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				} catch (CoreException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}

			public String getDescription() {
				return AcceleoGenUIMessages.getString("AcceleoRuntimeErrorMarkerResolutionGenerator.Resolution1.Description"); //$NON-NLS-1$
			}

			public Image getImage() {
				return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/openModel.gif"); //$NON-NLS-1$
			}
		};
		result[1] = new IMarkerResolution2() {
			public String getLabel() {
				return AcceleoGenUIMessages.getString("AcceleoRuntimeErrorMarkerResolutionGenerator.Resolution2.Label"); //$NON-NLS-1$
			}

			public void run(IMarker marker) {
				try {
					marker.delete();
				} catch (CoreException e) {
					AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
				}
			}

			public String getDescription() {
				return AcceleoGenUIMessages.getString("AcceleoRuntimeErrorMarkerResolutionGenerator.Resolution2.Description"); //$NON-NLS-1$
			}

			public Image getImage() {
				return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/deleteMarker.gif"); //$NON-NLS-1$
			}
		};
		return result;
	}

	/**
	 * This method is used to open a reflective editor on the active page.
	 * 
	 * @param modelFullPath
	 *            is the path of the model to open
	 * @param uriFragment
	 *            is the uri of the object to select
	 * @throws PartInitException
	 */
	public static void openModelEditor(String modelFullPath, String uriFragment) throws PartInitException {
		if (modelFullPath != null) {
			IPath modelPath = new Path(modelFullPath);
			if (modelPath.segmentCount() > 1 && modelPath.segment(0).equals("resource")) { //$NON-NLS-1$
				modelPath = modelPath.removeFirstSegments(1);
			}
			if (modelPath.segmentCount() > 1 && ResourcesPlugin.getWorkspace().getRoot().getFile(modelPath).exists()) {
				IWorkbench workbench = PlatformUI.getWorkbench();
				IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
				if (workbenchWindow != null) {
					IWorkbenchPage page = workbenchWindow.getActivePage();
					if (page != null) {
						IEditorDescriptor descriptor = workbench.getEditorRegistry().findEditor("fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor"); //$NON-NLS-1$
						if (descriptor != null) {
							AcceleoReflectiveEditor modelEditor = (AcceleoReflectiveEditor) page.openEditor(new FileEditorInput(ResourcesPlugin.getWorkspace().getRoot().getFile(modelPath)),
									descriptor.getId(), false);
							if (modelEditor != null) {
								selectModelElement(modelEditor, uriFragment);
							}
						}
					}
				}
			}
		}
	}

	private static boolean selectModelElement(EcoreEditor editor, String uriFragment) {
		if (uriFragment != null && uriFragment.length() > 0) {
			EditingDomain domain = editor.getEditingDomain();
			Iterator resources = domain.getResourceSet().getResources().iterator();
			while (resources.hasNext()) {
				Object resource = resources.next();
				if (resource instanceof XMLResource) {
					XMLResource xmlResource = (XMLResource) resource;
					EObject object;
					try {
						object = xmlResource.getEObject(uriFragment);
					} catch (Exception e) {
						object = null;
					}
					if (object != null) {
						editor.setSelection(new StructuredSelection(object));
						if (editor.getContentOutlinePage() != null) {
							editor.getContentOutlinePage().setSelection(new StructuredSelection(object));
						}
						return true;
					}
				}
			}
		}
		return false;
	}

	/* (non-Javadoc) */
	public boolean hasResolutions(IMarker marker) {
		try {
			return marker.getType().equals(ENodeException.RUNTIME_ERROR_MARKER_ID);
		} catch (CoreException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			return false;
		}
	}

}
