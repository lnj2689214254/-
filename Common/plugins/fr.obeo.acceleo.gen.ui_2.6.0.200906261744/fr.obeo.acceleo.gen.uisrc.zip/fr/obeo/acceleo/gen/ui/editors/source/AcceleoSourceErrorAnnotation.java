/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.ImageUtilities;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Source error annotation.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceErrorAnnotation extends Annotation {

	/**
	 * Annotation type error ID.
	 */
	public final static String ANNOTATION_TYPE_ERROR = "org.eclipse.ui.workbench.texteditor.error"; //$NON-NLS-1$

	/**
	 * Undefined annotation type.
	 */
	public final static String UNDEFINED = "undefined"; //$NON-NLS-1$

	/**
	 * Problem informations.
	 */
	private AcceleoSourceProblem problem;

	/**
	 * Constructor.
	 * 
	 * @param problem
	 *            is the problem
	 */
	public AcceleoSourceErrorAnnotation(AcceleoSourceProblem problem) {
		this.problem = problem;
	}

	/**
	 * Paint the annotation.
	 * 
	 * @param gc
	 * @param canvas
	 * @param bounds
	 */
	public void paint(GC gc, Canvas canvas, Rectangle bounds) {
		ImageUtilities.drawImage(AcceleoEcoreGenUiPlugin.getDefault().getImage("/icons/reflective/error.gif"), gc, canvas, bounds, SWT.CENTER); //$NON-NLS-1$
	}

	/**
	 * Start index of the annotation in the text.
	 * 
	 * @return start index
	 */
	public int getStart() {
		return problem.getStart();
	}

	/**
	 * End index of the annotation in the text.
	 * 
	 * @return end index
	 */
	public int getEnd() {
		return problem.getEnd();
	}

	/* (non-Javadoc) */
	public String getType() {
		switch (problem.getType()) {
		case AcceleoSourceProblem.TYPE_ERROR:
			return ANNOTATION_TYPE_ERROR;
		default:
			return UNDEFINED;
		}
	}

	/**
	 * Annotation message.
	 * 
	 * @return message
	 */
	public String getMessage() {
		return problem.toString();
	}

};
