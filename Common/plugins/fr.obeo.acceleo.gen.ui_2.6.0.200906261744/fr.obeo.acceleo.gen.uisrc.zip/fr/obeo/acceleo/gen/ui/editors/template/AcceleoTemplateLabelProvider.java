/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateNodeElement;
import fr.obeo.acceleo.gen.template.scripts.ScriptDescriptor;
import fr.obeo.acceleo.gen.template.statements.TemplateFeatureStatement;
import fr.obeo.acceleo.gen.template.statements.TemplateIfStatement;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.tools.ui.graphics.CompositeImage;

import java.util.Map;

import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;

/**
 * The label provider for the objects shown in the outline view.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateLabelProvider extends org.eclipse.jface.viewers.LabelProvider implements IColorProvider {

	/**
	 * Template editor.
	 */
	protected AcceleoTemplateEditor editor;

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the template editor
	 */
	public AcceleoTemplateLabelProvider(AcceleoTemplateEditor editor) {
		super();
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public Image getImage(Object element) {
		if (element instanceof Map.Entry) {
			Map.Entry entry = (Map.Entry) element;
			if (editor.getGenerator().getFileTemplate((Template) entry.getValue()) != null) {
				return CompositeImage.compose(AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/template.gif"), AcceleoEcoreGenUiPlugin.getDefault().getImage( //$NON-NLS-1$
						"icons/reflective/generate.gif")); //$NON-NLS-1$
			} else {
				return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/template.gif"); //$NON-NLS-1$
			}
		} else if (element instanceof Template && ((Template) element).getParent() instanceof TemplateIfStatement) {
			return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/condition.gif"); //$NON-NLS-1$
		} else if (element instanceof TemplateFeatureStatement) {
			return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/feature.gif"); //$NON-NLS-1$
		} else if (element instanceof TemplateNodeElement) {
			return AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/proposals/statement.gif"); //$NON-NLS-1$
		} else {
			return null;
		}
	}

	/* (non-Javadoc) */
	public String getText(Object element) {
		if (element instanceof Map.Entry) {
			Map.Entry entry = (Map.Entry) element;
			AcceleoTemplateOutlineStatus status = editor.getContentOutlinePage().getOutlineStatus();
			if (status.getSortType() == AcceleoTemplateOutlineStatus.SORT_BY_TYPE) {
				StringBuffer buffer = new StringBuffer(""); //$NON-NLS-1$
				String type = ((ScriptDescriptor) entry.getKey()).getType();
				int dot = type.lastIndexOf("."); //$NON-NLS-1$
				dot = dot > -1 ? type.substring(0, dot).lastIndexOf(".") : -1; //$NON-NLS-1$
				if (dot > -1) {
					type = type.substring(dot + 1);
				}
				buffer.append(type);
				buffer.append(" : "); //$NON-NLS-1$
				buffer.append(((ScriptDescriptor) entry.getKey()).getName());
				return buffer.toString();
			} else if (status.getSortType() == AcceleoTemplateOutlineStatus.SORT_BY_NAME) {
				StringBuffer buffer = new StringBuffer(""); //$NON-NLS-1$
				String type = ((ScriptDescriptor) entry.getKey()).getType();
				int dot = type.lastIndexOf("."); //$NON-NLS-1$
				dot = dot > -1 ? type.substring(0, dot).lastIndexOf(".") : -1; //$NON-NLS-1$
				if (dot > -1) {
					type = type.substring(dot + 1);
				}
				buffer.append(((ScriptDescriptor) entry.getKey()).getName());
				buffer.append(" : "); //$NON-NLS-1$
				buffer.append(type);
				return buffer.toString();
			} else {
				return ((ScriptDescriptor) entry.getKey()).getOutlineText();
			}
		} else if (element instanceof Template && ((Template) element).getParent() instanceof TemplateIfStatement) {
			return ((TemplateIfStatement) ((Template) element).getParent()).getConditionText((Template) element);
		} else if (element instanceof TemplateNodeElement) {
			return ((TemplateNodeElement) element).getOutlineText();
		} else {
			return element.toString();
		}
	}

	/* (non-Javadoc) */
	public Color getForeground(Object element) {
		return null;
	}

	/* (non-Javadoc) */
	public Color getBackground(Object element) {
		return null;
	}

}
