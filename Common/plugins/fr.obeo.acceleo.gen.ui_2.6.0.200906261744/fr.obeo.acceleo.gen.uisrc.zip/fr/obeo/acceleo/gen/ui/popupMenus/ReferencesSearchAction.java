/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITypedRegion;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.search.ui.NewSearchUI;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;
import fr.obeo.acceleo.gen.ui.editors.template.scanner.AcceleoTemplatePartitionScanner;
import fr.obeo.acceleo.tools.AcceleoToolsPlugin;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * This action trigger the references search
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferencesSearchAction extends Action implements IWorkbenchWindowActionDelegate, IObjectActionDelegate {

	/**
	 * The action id
	 */
	public final static String ACTION_ID = "fr.obeo.gen.ui.actions.SearchReferences"; //$NON-NLS-1$

	/**
	 * The associated command ID
	 */
	public final static String COMMAND_ID = "fr.obeo.gen.ui.edit.searchReferences"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public void dispose() {
		// nothing to do
	}

	/* (non-Javadoc) */
	public void init(IWorkbenchWindow window) {
		// nothing to do
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		super.run();
		if (PlatformUI.getWorkbench().getActiveWorkbenchWindow() != null && PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage() != null
				&& PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor() instanceof AcceleoTemplateEditor) {
			AcceleoTemplateEditor editor = (AcceleoTemplateEditor) PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
			IDocument document = editor.getDocumentProvider().getDocument(editor.getEditorInput());
			if (editor.getSelectionProvider() != null) {
				ITextSelection selection = (ITextSelection) editor.getSelectionProvider().getSelection();
				if (selection != null) {

					String text = document.get();
					TemplateConstants.initConstants(text);

					// find identifier
					ITypedRegion region = null;
					try {
						region = document.getPartition(selection.getOffset());
					} catch (BadLocationException e) {
						AcceleoToolsPlugin.getDefault().log(e, true);
					}
					int begin = selection.getOffset();
					int end = selection.getOffset();
					while (end < text.length() && Character.isJavaIdentifierPart(text.charAt(end))) {
						end++;
					}
					while (begin > 0 && Character.isJavaIdentifierPart(text.charAt(begin - 1))) {
						begin--;
					}

					if (isValidRegion(editor.getFile(), text, region, begin)) {
						IFile declarationFile = OpenDefinitionAction.getDeclarationFile(editor);
						String templateName = ReferencesSearchQuery.fileToImportString(declarationFile);
						ReferencesSearchQuery query = null;

						if (templateName == null) {
							templateName = ReferencesSearchQuery.fileToImportString(editor.getFile());
							query = createSearchQuery(editor.getFile().getProject(), text.substring(begin, end), templateName);
						} else {
							query = createSearchQuery(declarationFile.getProject(), text.substring(begin, end), templateName);
						}

						NewSearchUI.runQueryInBackground(query);
					}
				}
			}
		}
	}

	/**
	 * Creates the query looking for References in Acceleo templates.
	 * 
	 * @param project
	 *            the project where the query is running
	 * @param identifier
	 *            the identifier to look for
	 * @param templateImportString
	 *            the base name of the template containing the identifier
	 * @return the engine used to search the references
	 */
	protected ReferencesSearchQuery createSearchQuery(IProject project, String identifier, String templateImportString) {
		return new ReferencesSearchQuery(project, identifier, templateImportString);
	}

	/**
	 * Tell if an identifier can be found at the given offset
	 * 
	 * @param file
	 *            the template
	 * @param text
	 *            the text of the template
	 * @param region
	 *            the type of the region
	 * @param idOffset
	 *            the offset to use
	 * @return true if offset can be used to declare identifier
	 */
	protected boolean isValidRegion(IFile file, String text, ITypedRegion region, int idOffset) {
		if ("__dftl_partition_content_type".equals(region.getType())) { //$NON-NLS-1$
			return false; // identifier is not in a valid region
		}
		// identifier must not be a literal
		boolean literal = (TextSearch.getDefaultSearch().countIn(text, TemplateConstants.LITERAL[0], region.getOffset(), idOffset, TemplateConstants.LITERAL_SPEC, null) % 2) != 0;

		if (literal && !AcceleoTemplatePartitionScanner.TEMPLATE_SCRIPT.equals(region.getType())) {
			return false; // literals are not identifiers outside of script
			// region
		}
		return true;
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		// nothing to do

	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		// nothing to do
	}
}
