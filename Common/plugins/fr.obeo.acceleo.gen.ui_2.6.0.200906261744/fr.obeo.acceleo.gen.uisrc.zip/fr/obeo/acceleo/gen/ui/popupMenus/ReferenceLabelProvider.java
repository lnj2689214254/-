/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.jdt.internal.ui.JavaPluginImages;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.model.WorkbenchLabelProvider;

/**
 * This class provide labels for the references search.
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferenceLabelProvider extends LabelProvider {
	/**
	 * The label provider of the workbench.
	 */
	private WorkbenchLabelProvider labelProvider;

	/**
	 * The image to give by default.
	 */
	private static Image defaultImage = JavaPluginImages.DESC_MISC_PUBLIC.createImage();

	/**
	 * Constructor.
	 */
	public ReferenceLabelProvider() {
		labelProvider = new WorkbenchLabelProvider();
	}

	/* (non-Javadoc) */
	public Image getImage(Object element) {
		if (element instanceof IResource) {
			return labelProvider.getImage(element);
		} else {
			return defaultImage;
		}
	}

	/* (non-Javadoc) */
	public String getText(Object element) {
		if (element instanceof IFile) {
			return ((IFile) element).getName();
		} else if (element instanceof IProject) {
			return ((IProject) element).getName();
		} else if (element instanceof IResource) {
			return ((IResource) element).getProjectRelativePath().toString();
		} else if (element instanceof ReferenceEntry) {
			return ((ReferenceEntry) element).getMessage();
		}
		return super.getText(element);
	}
}
