/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

/**
 * Source log informations.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceProblem {

	/**
	 * The message.
	 */
	protected String message;

	/**
	 * Token at log index in the text
	 */
	protected String token;

	/**
	 * The start index for the log.
	 */
	protected int start;

	/**
	 * The end index for the log.
	 */
	protected int end;

	/**
	 * Log type.
	 */
	protected int type;

	/**
	 * Log error type.
	 */
	public final static int TYPE_ERROR = 1;

	/**
	 * Constructor.
	 * 
	 * @param message
	 *            is the message
	 * @param token
	 *            is the token in the text
	 * @param start
	 *            is start index for the log
	 * @param end
	 *            is end index for the log
	 */
	public AcceleoSourceProblem(String message, String token, int start, int end) {
		this.message = message;
		this.token = token;
		this.start = start;
		this.end = end;
		this.type = TYPE_ERROR;
	}

	/**
	 * @return message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @return token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @return the start index for the log.
	 */
	public int getStart() {
		return start;
	}

	/**
	 * @return the end index for the log.
	 */
	public int getEnd() {
		return end;
	}

	/**
	 * @return the type of the log
	 */
	public int getType() {
		return type;
	}

	/* (non-Javadoc) */
	public String toString() {
		return getMessage();
	}

}
