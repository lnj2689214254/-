/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.template;

import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.scripts.ScriptDescriptor;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;

import java.util.Map;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerComparator;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.IPageSite;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

/**
 * A class for template content outline pages. This content outline page will be
 * presented to the user via the standard Content Outline View (the user decides
 * whether their workbench window contains this view) whenever that template
 * editor is active.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoTemplateOutlinePage extends ContentOutlinePage {

	/**
	 * Template editor.
	 */
	protected AcceleoTemplateEditor editor;

	/**
	 * Outline tree viewer.
	 */
	private TreeViewer viewer = null;

	/**
	 * Status of the outline.
	 */
	private AcceleoTemplateOutlineStatus outlineStatus;

	/**
	 * Image descriptors for sort buttons.
	 */
	private static ImageDescriptor imgDescriptors[];

	/**
	 * Comparator used to sort outline elements.
	 */
	private ViewerComparator comparator = new ViewerComparator() {
		/* (non-Javadoc) */
		public int compare(Viewer viewer, Object e1, Object e2) {
			int ret = 0;
			if (e1 instanceof Map.Entry && e2 instanceof Map.Entry) {
				ScriptDescriptor scriptDescriptor1 = (ScriptDescriptor) ((Map.Entry) e1).getKey();
				ScriptDescriptor scriptDescriptor2 = (ScriptDescriptor) ((Map.Entry) e2).getKey();
				switch (outlineStatus.getSortType()) {
				case AcceleoTemplateOutlineStatus.UNSORTED:
					ret = scriptDescriptor1.getPos().b() - scriptDescriptor2.getPos().b();
					break;
				case AcceleoTemplateOutlineStatus.SORT_BY_TYPE:
					ret = scriptDescriptor1.getType().compareTo(scriptDescriptor2.getType());
					if (ret == 0) { // then by name
						ret = scriptDescriptor1.getName().compareTo(scriptDescriptor2.getName());
					}
					break;
				case AcceleoTemplateOutlineStatus.SORT_BY_NAME:
					ret = scriptDescriptor1.getName().compareTo(scriptDescriptor2.getName());
					if (ret == 0) { // then by type
						ret = scriptDescriptor1.getType().compareTo(scriptDescriptor2.getType());
					}
					break;
				}
			} else if (e1 instanceof TemplateElement && e2 instanceof TemplateElement) {
				return ((TemplateElement) e1).getPos().b() - ((TemplateElement) e2).getPos().b();
			} else {
				ret = super.compare(viewer, e1, e2);
			}
			return ret;
		}
	};

	/**
	 * Action class of the toggle sort button.
	 * 
	 */
	private class ToggleNameSortOrder extends Action {
		private final int sortOrder;

		/** Constructor. */
		public ToggleNameSortOrder(String text, int sortOrder, ImageDescriptor imgDesc) {
			super(text, IAction.AS_RADIO_BUTTON);

			if (imgDescriptors == null) {
				imgDescriptors = new ImageDescriptor[3];
				imgDescriptors[0] = ImageDescriptor.createFromImage(AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/actions/unsorted.gif")); //$NON-NLS-1$
				imgDescriptors[1] = ImageDescriptor.createFromImage(AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/actions/sortedEClass.gif")); //$NON-NLS-1$
				imgDescriptors[2] = ImageDescriptor.createFromImage(AcceleoEcoreGenUiPlugin.getDefault().getImage("icons/actions/sortedTemplate.gif")); //$NON-NLS-1$
			}
			setImageDescriptor(imgDescriptors[sortOrder]);
			this.sortOrder = sortOrder;
			setChecked(sortOrder == outlineStatus.getSortType());
		}

		/* (non-Javadoc) */
		public void run() {
			viewer.setComparator(comparator);
			outlineStatus.setSortType(sortOrder);
			getTreeViewer().refresh();
		}
	}

	/**
	 * Constructor.
	 * 
	 * @param editor
	 *            is the template editor
	 */
	public AcceleoTemplateOutlinePage(AcceleoTemplateEditor editor) {
		super();
		this.editor = editor;
		this.outlineStatus = new AcceleoTemplateOutlineStatus();
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		super.createControl(parent);
		viewer = getTreeViewer();
		viewer.setContentProvider(createContentProvider());
		viewer.setLabelProvider(createLabelProvider());
		viewer.setComparator(comparator);
		if (editor.getGenerator() != null) {
			setInput(editor.getGenerator());
		}
		IPageSite site = getSite();
		IToolBarManager toolBarManager = site.getActionBars().getToolBarManager();
		toolBarManager.add(new ToggleNameSortOrder(AcceleoGenUIMessages.getString("AcceleoTemplateOutlinePage.Unsorted"), AcceleoTemplateOutlineStatus.UNSORTED, null)); //$NON-NLS-1$
		toolBarManager.add(new ToggleNameSortOrder(AcceleoGenUIMessages.getString("AcceleoTemplateOutlinePage.SortedByName"), AcceleoTemplateOutlineStatus.SORT_BY_NAME, null)); //$NON-NLS-1$
		toolBarManager.add(new ToggleNameSortOrder(AcceleoGenUIMessages.getString("AcceleoTemplateOutlinePage.SortedByType"), AcceleoTemplateOutlineStatus.SORT_BY_TYPE, null)); //$NON-NLS-1$
	}

	/**
	 * Creates the content provider.
	 * 
	 * @return the content provider
	 */
	protected IContentProvider createContentProvider() {
		return new AcceleoTemplateContentProvider(editor);
	}

	/**
	 * Creates the label provider.
	 * 
	 * @return the label provider
	 */
	protected IBaseLabelProvider createLabelProvider() {
		return new AcceleoTemplateLabelProvider(editor);
	}

	/**
	 * Updates the input model.
	 * 
	 * @param model
	 *            is the new input model
	 */
	public void setInput(Object model) {
		if (getTreeViewer() != null) {
			getTreeViewer().setInput(model);
		}
	}

	/**
	 * Getter for the ouline sort status.
	 */
	public AcceleoTemplateOutlineStatus getOutlineStatus() {
		return outlineStatus;
	}

}
