/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards.product;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.Platform;
import org.eclipse.ui.dialogs.WizardNewProjectReferencePage;
import org.osgi.framework.Bundle;

/**
 * The class used to configure all the JET generations of the
 * 'AcceleoExportToProductWizard' wizard. The purpose of the wizard is to create
 * a new product (i.e an eclipse plug-in) for one or several Acceleo modules.
 * 
 * @author <a href="mailto:jonathan.musset@obeo.fr">Jonathan Musset</a>
 */
public class AcceleoCreateModuleProductData {

	/**
	 * Eclipse version.
	 */
	private String eclipseVersion;

	/**
	 * New product ID.
	 */
	private String productID;

	/**
	 * New application ID.
	 */
	private String applicationID;

	/**
	 * IDs of the required plug-ins.
	 */
	private List pluginDependencies;

	/**
	 * Acceleo templates.
	 */
	private List moduleTemplates;

	/**
	 * Constructor.
	 * 
	 * @param wizard
	 *            is the wizard
	 */
	public AcceleoCreateModuleProductData(AcceleoExportToProductWizard wizard) {
		Bundle rt = Platform.getBundle(Platform.PI_RUNTIME);
		if (rt != null && rt.getHeaders() != null) {
			eclipseVersion = (String) rt.getHeaders().get(org.osgi.framework.Constants.BUNDLE_VERSION);
		} else {
			eclipseVersion = "3.2.0"; //$NON-NLS-1$
		}
		productID = wizard.getNewProductPage().getProjectName();
		applicationID = productID + ".launch"; //$NON-NLS-1$
		pluginDependencies = new ArrayList();
		moduleTemplates = new ArrayList();
		computeTemplatesConfiguration(wizard.getProjectReferencesPage());
	}

	/**
	 * Initializes the plug-ins dependencies and the API which runs the code
	 * generation by visiting each project reference.
	 * 
	 * @param page
	 *            is the standard project reference page
	 */
	private void computeTemplatesConfiguration(WizardNewProjectReferencePage page) {
		if (page.getReferencedProjects() != null) {
			IProject[] projects = page.getReferencedProjects();
			for (int i = 0; i < projects.length; i++) {
				IProject project = projects[i];
				pluginDependencies.add(project.getName());
			}
		}
	}

	/**
	 * Gets the eclipse version.
	 * 
	 * @return the eclipse version
	 */
	public String getEclipseVersion() {
		return eclipseVersion;
	}

	/**
	 * Gets the application ID.
	 * 
	 * @return the application ID
	 */
	public String getApplicationID() {
		return applicationID;
	}

	/**
	 * Gets the product ID.
	 * 
	 * @return the product ID
	 */
	public String getProductID() {
		return productID;
	}

	/**
	 * Gets the module templates.
	 * 
	 * @return the module templates
	 */
	public List getModuleTemplates() {
		return moduleTemplates;
	}

	/**
	 * Gets the plugin dependencies.
	 * 
	 * @return the plugin dependencies
	 */
	public List getPluginDependencies() {
		return pluginDependencies;
	}

}
