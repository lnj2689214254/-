/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.provider.EcoreEditPlugin;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.edit.provider.ComposedImage;
import org.eclipse.emf.edit.provider.ReflectiveItemProvider;

import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.ecore.tools.ELoaderUtils;
import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.EMFEditorUtil;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Specific item provider for the reflective editor.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoReflectiveItemProvider extends ReflectiveItemProvider {

	/**
	 * Constructor.
	 * 
	 * @param adapterFactory
	 *            is the adapter factory
	 */
	public AcceleoReflectiveItemProvider(AcceleoReflectiveItemProviderAdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * Get the reflective editor.
	 * 
	 * @return reflective editor
	 */
	protected AcceleoReflectiveEditor getReflectiveEditor() {
		return ((AcceleoReflectiveItemProviderAdapterFactory) adapterFactory).getReflectiveEditor();
	}

	/**
	 * Get the input file for the corresponding reflective editor.
	 * 
	 * @return the input file
	 */
	protected IFile getFile() {
		return getReflectiveEditor().getFile();
	}

	/**
	 * Try to get an eClass icon in /icons folder. The hierarchy of icons must
	 * correspond to the hierarchy in the metamodel. If the icon of an object
	 * doesn't exist, the icon DEFAULT.gif of the current directory is used.
	 * 
	 * @param eClass
	 * @return icon URI
	 */
	protected URI tryToFindImageURI(EClass eClass) {
		// Sample : "java.resources.Folder"
		String name = ETools.getEClassifierPath(eClass);
		// Search in folder /icons
		IFile file = getFile();
		if (file != null) {
			IPath path = new Path("/icons/" + name.replaceAll("\\.", "/") + ".gif"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
			IFile metamodel = ELoaderUtils.xmi2ecore(file);
			if (metamodel != null) {
				IFile icon = metamodel.getParent().getFile(path);
				if (icon.exists()) {
					URI uri = Resources.createPlatformResourceURI(icon.getFullPath().toString());
					return uri;
				} else {
					// Possibly DEFAULT.gif
					path = path.removeLastSegments(1).append(new Path("DEFAULT.gif")); //$NON-NLS-1$
					icon = metamodel.getParent().getFile(path);
					if (icon.exists()) {
						URI uri = Resources.createPlatformResourceURI(icon.getFullPath().toString());
						return uri;
					}
				}
			}
			path = new Path("model").append(path); //$NON-NLS-1$
			URI uri = getIconsInBundles(file.getProject(), path);
			if (uri == null) {
				// Possibly DEFAULT.gif
				path = path.removeLastSegments(1).append(new Path("DEFAULT.gif")); //$NON-NLS-1$
				uri = getIconsInBundles(file.getProject(), path);
			}
			return uri;
		} else {
			return null;
		}
	}

	private URI getIconsInBundles(IProject project, IPath path) {
		if (iconsBundleId != null) {
			File file = AcceleoModuleProvider.getDefault().getFile(iconsBundleId, path);
			if (file != null) {
				return URI.createFileURI(file.getAbsolutePath());
			}
		} else {
			if (project.exists()) {
				String[] requiredPluginIDs = fr.obeo.acceleo.tools.resources.Resources.getRequiredPluginIDs(project);
				for (int i = 0; i < requiredPluginIDs.length; i++) {
					File file = AcceleoModuleProvider.getDefault().getFile(requiredPluginIDs[i], path);
					if (file != null) {
						iconsBundleId = requiredPluginIDs[i];
						return URI.createFileURI(file.getAbsolutePath());
					}
				}
			}
		}
		return null;
	}

	private String iconsBundleId = null;

	/* (non-Javadoc) */
	public Object getImage(Object object) {
		EObject eObject = (EObject) object;
		Object image = getEClassImage(eObject);
		// Decorate icon when object hasError or when object is generated
		if (getReflectiveEditor().getActivePreviewEditor() != null) {
			boolean hasError = getReflectiveEditor().getActivePreviewEditor().getSettings().getScript().hasError(eObject);
			boolean isGenerated = getReflectiveEditor().getActivePreviewEditor().getSettings().getScript().isGenerated(eObject);
			return decorateImage(image, hasError, isGenerated);
		} else {
			return decorateImage(image, false, false);
		}
	}

	private Object getEClassImage(EObject eObject) {
		EClass eClass = eObject.eClass();
		Object image = EMFEditorUtil.findImageFromClassifier(eClass, false);
		if (image == null) {
			// Try to get eClass icon
			String eClassName = ETools.getEClassifierShortPath(eClass);
			image = eClassName2Image.get(eClassName);
			if (image == null && !eClassName2Image.containsKey(eClassName)) {
				image = tryToFindImageURI(eClass);
				if (image == null) {
					image = getSpecificImage(eObject);
					if (image == null) {
						image = URI.createURI(getResourceLocator().getImage("full/obj16/Item").toString() + '#' + eClass.getName()); //$NON-NLS-1$
					}
				}
				eClassName2Image.put(eClassName, image);
			}
		}
		return image;
	}

	private Map eClassName2Image = new HashMap();

	/**
	 * Gets the specific image for the given EObject
	 * 
	 * @param object
	 *            is an object of the model
	 * @return the image
	 */
	protected Object getSpecificImage(EObject object) {
		if (object == null) {
			return null;
			// Images for uml2
		} else if (object.getClass().getName().startsWith("org.eclipse.uml2")) { //$NON-NLS-1$
			String className = object.getClass().getName();
			if (className.endsWith("Impl")) { //$NON-NLS-1$
				className = className.substring(0, className.length() - 4);
			}
			int iDot = className.lastIndexOf("."); //$NON-NLS-1$
			if (iDot > -1) {
				className = className.substring(iDot + 1);
			}
			if (className.equals("Package")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EPackage.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Association")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EReference.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("AssociationClass")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EReference.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Extension")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EReference.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Property")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EAttribute.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("ExtensionEnd")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EAttribute.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Package")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EPackage.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Model")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EPackage.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Operation")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EOperation.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Parameter")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EParameter.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Class")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Interface")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("DataType")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("Enumeration")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
			} else if (className.equals("PrimitiveType")) { //$NON-NLS-1$
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
			} else {
				return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EObject.gif"), null).toString()); //$NON-NLS-1$
			}
			// Images for uml14
		} else if (Platform.getBundle("fr.obeo.acceleo.uml14") != null && object.getClass().getName().startsWith("fr.obeo.acceleo.uml14.")) { //$NON-NLS-1$ //$NON-NLS-2$
			try {
				if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.model_management.Package").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EPackage.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Classifier").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Attribute").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EAttribute.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.AssociationEnd").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EReference.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Association").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EObject.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Operation").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EOperation.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Method").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EOperation.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml14").loadClass("fr.obeo.acceleo.uml14.foundation.core.Parameter").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EParameter.gif"), null).toString()); //$NON-NLS-1$
				} else {
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EObject.gif"), null).toString()); //$NON-NLS-1$
				}
			} catch (ClassNotFoundException e) {
				return null;
			}
			// Images for uml13
		} else if (Platform.getBundle("fr.obeo.acceleo.uml13") != null && object.getClass().getName().startsWith("fr.obeo.acceleo.uml13.")) { //$NON-NLS-1$ //$NON-NLS-2$
			try {
				if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.model_management.Package").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EPackage.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Classifier").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EClass.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Attribute").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EAttribute.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.AssociationEnd").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EReference.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Association").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EObject.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Operation").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EOperation.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Method").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EOperation.gif"), null).toString()); //$NON-NLS-1$
				} else if (Platform.getBundle("fr.obeo.acceleo.uml13").loadClass("fr.obeo.acceleo.uml13.foundation.core.Parameter").isInstance(object)) { //$NON-NLS-1$ //$NON-NLS-2$
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EParameter.gif"), null).toString()); //$NON-NLS-1$
				} else {
					return URI.createURI(FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/EObject.gif"), null).toString()); //$NON-NLS-1$
				}
			} catch (ClassNotFoundException e) {
				return null;
			}
		} else {
			URL url = FileLocator.find(EcoreEditPlugin.getPlugin().getBundle(), new Path("/icons/full/obj16/" + object.eClass().getName() + ".gif"), null); //$NON-NLS-1$ //$NON-NLS-2$
			if (url != null) {
				return URI.createURI(url.toString());
			} else {
				return null;
			}
		}
	}

	/**
	 * Decorate image when object hasError or when object is generated
	 * 
	 * @param image
	 * @param hasError
	 *            indicate if 'error' decorator is necessary
	 * @param isGenerated
	 *            indicate if 'generate' decorator is necessary
	 * @return the decorated image
	 */
	protected Object decorateImage(Object image, final boolean hasError, final boolean isGenerated) {
		if (hasError || isGenerated) {
			Collection images = new ArrayList();
			if (image == null) {
				image = AcceleoEcoreGenUiPlugin.getDefault().getImage("/icons/proposals/predefined.gif"); //$NON-NLS-1$
			}
			images.add(image);
			// hasError
			if (hasError) {
				images.add(AcceleoEcoreGenUiPlugin.getDefault().getImage("/icons/reflective/error.gif")); //$NON-NLS-1$
			}
			// isGenerated
			if (isGenerated) {
				images.add(AcceleoEcoreGenUiPlugin.getDefault().getImage("/icons/reflective/generate.gif")); //$NON-NLS-1$
			}
			if (images.size() > 1) {
				return new ComposedImage(images) {
					public List getDrawPoints(Size size) {
						List result = super.getDrawPoints(size);
						if (hasError && isGenerated) {
							((Point) result.get(0)).y = 0;
							((Point) result.get(1)).y = 7;
							((Point) result.get(2)).x = 3;
							((Point) result.get(2)).y = 4;
						} else if (hasError) {
							((Point) result.get(0)).y = 0;
							((Point) result.get(1)).y = 7;
						} else if (isGenerated) {
							((Point) result.get(0)).y = 0;
							((Point) result.get(1)).x = 3;
							((Point) result.get(1)).y = 4;
						}
						return result;
					}
				};
			}
		}
		return image;
	}

	/* (non-Javadoc) */
	public String getText(Object object) {
		return getText(object, getReflectiveEditor().showType);
	}

	private String getText(Object object, boolean showType) {
		EObject eObject = (EObject) object;
		String displayType;
		if (showType) {
			displayType = " [" + ((eObject.eContainingFeature() != null) ? eObject.eContainingFeature().getName() + ':' : "") + eObject.eClass().getName() + ']' //$NON-NLS-1$ //$NON-NLS-2$
					+ ((eObject.eContainer() != null) ? " <<" + getText(eObject.eContainer(), false) + ">>" : ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		} else {
			displayType = ""; //$NON-NLS-1$
		}
		try {
			if (EFactory.eInstanceOf(eObject, "resources.FileLog")) { //$NON-NLS-1$
				// FileLog => show the number of elements
				List logs = EFactory.eGetAsList(eObject, "logs"); //$NON-NLS-1$
				if (logs != null && logs.size() > 0)
					return AcceleoGenUIMessages.getString("AcceleoReflectiveItemProvider.ErrorCount", new Object[] { Integer.toString(logs.size()), }) + displayType; //$NON-NLS-1$
			} else if (EFactory.eInstanceOf(eObject, "resources.Log")) { //$NON-NLS-1$
				// Log => show the message
				String message = EFactory.eGetAsString(eObject, "message"); //$NON-NLS-1$
				if (message != null)
					return message + displayType;
			} else {
				// others => show naming attribute
				String naming = EFactory.eGetAsString(eObject, "naming"); //$NON-NLS-1$
				if (naming != null && naming.length() > 0)
					return naming + displayType;
			}
		} catch (FactoryException e) {
		}
		if (EFactory.eValid(eObject, "naming")) { //$NON-NLS-1$
			return TemplateConstants.FEATURE_BEGIN + "naming" + TemplateConstants.FEATURE_END + displayType; //$NON-NLS-1$
		} else {
			return super.getText(object) + displayType;
		}
	}

	/* (non-Javadoc) */
	protected EStructuralFeature getLabelFeature(EClass eClass) {
		EAttribute result = null;
		for (Iterator i = eClass.getEAllAttributes().iterator(); i.hasNext();) {
			EAttribute eAttribute = (EAttribute) i.next();
			if (!eAttribute.isMany() && eAttribute.getEType().getInstanceClass() != FeatureMap.Entry.class) {
				if ("name".equalsIgnoreCase(eAttribute.getName())) { //$NON-NLS-1$
					result = eAttribute;
					break;
				} else if (result == null) {
					result = eAttribute;
				} else if (eAttribute.getEAttributeType().getInstanceClass() == String.class && result.getEAttributeType().getInstanceClass() != String.class) {
					result = eAttribute;
				}
			}
		}
		return result;
	}

	/* (non-Javadoc) */
	public Object getCreateChildImage(Object owner, Object feature, Object child, Collection selection) {
		if (feature instanceof EReference && child instanceof EObject) {
			EReference reference = (EReference) feature;
			EClass parentClass = reference.getEContainingClass();
			EClass childClass = ((EObject) child).eClass();
			// Try to get childClass icon
			String childClassName = ETools.getEClassifierShortPath(childClass);
			Object image = eClassName2Image.get(childClassName);
			if (image == null && !eClassName2Image.containsKey(childClassName)) {
				image = tryToFindImageURI(childClass);
				if (image == null) {
					image = getSpecificImage((EObject) child);
				}
				eClassName2Image.put(childClassName, image);
			}
			if (image != null)
				return image;
			else
				return URI.createURI(getResourceLocator().getImage("full/ctool16/CreateChild").toString() + '#' + parentClass.getName() + '/' + childClass.getName()); //$NON-NLS-1$
		}
		return getResourceLocator().getImage("full/ctool16/CreateChild"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	protected String getTypeText(Object object) {
		return object instanceof EObject ? ((EObject) object).eClass().getName() : getString("_UI_Unknown_type"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	protected String getFeatureText(Object feature) {
		return feature instanceof EStructuralFeature ? ((EStructuralFeature) feature).getName() : getResourceLocator().getString("_UI_Unknown_feature"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public void fireNotifyChanged(Notification notification) {
		super.fireNotifyChanged(notification);
		int type = notification.getEventType();
		if (type != Notification.REMOVING_ADAPTER && type != Notification.RESOLVE) {
			if (getReflectiveEditor().getActivePreviewEditor() != null) {
				getReflectiveEditor().getActivePreviewEditor().refresh();
			}
		}
	}

}
