/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.gen.ui.editors.template;

public class AcceleoTemplateOutlineStatus {

	/** Sort by type constant. */
	public static final int UNSORTED = 0;

	/** Sort by type constant. */
	public static final int SORT_BY_TYPE = 1;

	/** Sort by name constant. */
	public static final int SORT_BY_NAME = 2;

	/** Current sort order. */
	private int sortType = SORT_BY_TYPE;

	/**
	 * Getter for the current sort order.
	 * 
	 * @return the current sort order
	 */
	public int getSortType() {
		return sortType;
	}

	/**
	 * Setter for the current sort order.
	 * 
	 * @param sortType
	 *            the new sort order
	 */
	public void setSortType(int sortType) {
		this.sortType = sortType;
	}
}
