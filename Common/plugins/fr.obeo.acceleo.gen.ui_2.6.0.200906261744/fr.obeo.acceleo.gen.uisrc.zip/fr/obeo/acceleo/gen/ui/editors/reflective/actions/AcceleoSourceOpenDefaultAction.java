/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.reflective.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.texteditor.AbstractTextEditor;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor;

/**
 * Open the default eclipse editor for the selected object in the model.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceOpenDefaultAction extends Action {

	/**
	 * The reflective editor
	 */
	protected AcceleoReflectiveEditor reflectiveEditor;

	/**
	 * Constructor.
	 * 
	 * @param reflectiveEditor
	 *            is the reflective editor
	 */
	public AcceleoSourceOpenDefaultAction(AcceleoReflectiveEditor reflectiveEditor) {
		super(AcceleoGenUIMessages.getString("Editors.OpenDefaultAction.label")); //$NON-NLS-1$
		setDescription(AcceleoGenUIMessages.getString("Editors.OpenDefaultAction.label")); //$NON-NLS-1$
		setToolTipText(AcceleoGenUIMessages.getString("Editors.OpenDefaultAction.label"));//$NON-NLS-1$
		this.reflectiveEditor = reflectiveEditor;
	}

	/* (non-Javadoc) */
	public void run() {
		IWorkbenchWindow workbenchWindow = reflectiveEditor.getEditorSite().getWorkbenchWindow();
		IWorkbenchPage page = workbenchWindow.getActivePage();
		if (page != null && reflectiveEditor.getActivePreviewEditor() != null) {
			try {
				IFile file = reflectiveEditor.getActivePreviewEditor().tryToGetCurrentFile();
				if (file != null) {
					IWorkbench workbench = workbenchWindow.getWorkbench();
					if (workbench != null) {
						IEditorDescriptor descriptor = workbench.getEditorRegistry().getDefaultEditor(file.getFullPath().toString());
						String id = (descriptor != null) ? descriptor.getId() : "org.eclipse.ui.DefaultTextEditor"; //$NON-NLS-1$
						IEditorPart part = page.openEditor(new FileEditorInput(file), id, true);
						if (part instanceof AbstractTextEditor) {
							IRegion region = reflectiveEditor.getSourceEditor().getHighlightRange();
							if (region != null) {
								((AbstractTextEditor) part).selectAndReveal(region.getOffset(), region.getLength());
							}
						}
					}
				}
			} catch (Exception e) {
			}
		}
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return AcceleoEcoreGenUiPlugin.getImageDescriptor("/icons/actions/open_default_editor.gif"); //$NON-NLS-1$
	}

}
