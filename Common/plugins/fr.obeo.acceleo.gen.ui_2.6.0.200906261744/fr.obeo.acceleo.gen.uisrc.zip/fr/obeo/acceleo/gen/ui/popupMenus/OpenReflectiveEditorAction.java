/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionDelegate;
import org.eclipse.ui.part.FileEditorInput;

import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;

/**
 * Open the reflective editor on the selected file.
 * 
 * @author www.obeo.fr
 * 
 */
public class OpenReflectiveEditorAction extends ActionDelegate implements IActionDelegate {

	/**
	 * Selected file.
	 */
	protected IFile file = null;

	/* (non-Javadoc) */
	public void run(IAction action) {
		if (file != null) {
			IWorkbenchWindow workbenchWindow = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
			IWorkbenchPage page = workbenchWindow.getActivePage();
			try {
				page.openEditor(new FileEditorInput(file), "fr.obeo.acceleo.gen.ui.editors.reflective.AcceleoReflectiveEditor"); //$NON-NLS-1$
			} catch (PartInitException e) {
				AcceleoEcoreGenUiPlugin.getDefault().log(e, true);
			}
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			Object object = ((IStructuredSelection) selection).getFirstElement();
			if (object instanceof IFile) {
				file = (IFile) object;
			}
		}
	}

}