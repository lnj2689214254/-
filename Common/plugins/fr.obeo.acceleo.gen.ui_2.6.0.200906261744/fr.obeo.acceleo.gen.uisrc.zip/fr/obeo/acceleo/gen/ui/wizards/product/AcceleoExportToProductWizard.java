/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.wizards.product;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.osgi.service.resolver.BundleDescription;
import org.eclipse.osgi.service.resolver.State;
import org.eclipse.pde.core.plugin.IPluginModelBase;
import org.eclipse.pde.internal.core.PDECore;
import org.eclipse.pde.internal.core.exports.FeatureExportInfo;
import org.eclipse.pde.internal.core.iproduct.ILauncherInfo;
import org.eclipse.pde.internal.core.iproduct.IProduct;
import org.eclipse.pde.internal.core.iproduct.IProductModel;
import org.eclipse.pde.internal.core.iproduct.IProductModelFactory;
import org.eclipse.pde.internal.core.iproduct.IProductPlugin;
import org.eclipse.pde.internal.core.product.WorkspaceProductModel;
import org.eclipse.pde.internal.ui.PDEPluginImages;
import org.eclipse.pde.internal.ui.wizards.product.ProductFromExtensionOperation;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IExportWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.WizardNewProjectCreationPage;
import org.eclipse.ui.dialogs.WizardNewProjectReferencePage;
import org.eclipse.ui.progress.IProgressConstants;

import fr.obeo.acceleo.gen.template.TemplateConstants;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.wizards.product.compatibility.ProductExportJob;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * A wizard to create a new product (i.e an eclipse plug-in) for one or several
 * Acceleo modules.
 * 
 * @author <a href="mailto:jonathan.musset@obeo.fr">Jonathan Musset</a>
 */
public class AcceleoExportToProductWizard extends Wizard implements IExportWizard {

	/**
	 * The current selection.
	 */
	protected IStructuredSelection selection;

	/**
	 * This is a new product wizard page.
	 */
	private WizardNewProjectCreationPage newProductPage;

	/**
	 * This is a wizard page to select the Acceleo modules to be considered.
	 */
	private WizardNewProjectReferencePage projectReferencesPage;

	/**
	 * This is a wizard page to export the new product.
	 */
	private ProductExportWizardPage productExportWizardPage;

	/**
	 * Constructor.
	 */
	public AcceleoExportToProductWizard() {
		super();
		setDefaultPageImageDescriptor(PDEPluginImages.DESC_PRODUCT_EXPORT_WIZ);
		setWindowTitle(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.Title")); //$NON-NLS-1$
	}

	/**
	 * Gets the new product wizard page.
	 * 
	 * @return the new product wizard page
	 */
	public WizardNewProjectCreationPage getNewProductPage() {
		return newProductPage;
	}

	/**
	 * Gets the wizard page where the Acceleo modules have been selected.
	 * 
	 * @return the Acceleo modules wizard page
	 */
	public WizardNewProjectReferencePage getProjectReferencesPage() {
		return projectReferencesPage;
	}

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#addPages()
	 */
	public void addPages() {
		IProject selectedProject = getSelectedProject();
		ImageDescriptor wizardImage = AcceleoEcoreGenUiPlugin.getImageDescriptor("icons/wizard/product.gif"); //$NON-NLS-1$
		newProductPage = new WizardNewProjectCreationPage(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.NewAcceleoProduct")); //$NON-NLS-1$
		if (selectedProject != null) {
			newProductPage.setInitialProjectName(selectedProject.getName() + ".product"); //$NON-NLS-1$
		} else {
			newProductPage.setInitialProjectName("org.acceleo.module.???.product"); //$NON-NLS-1$
		}
		newProductPage.setTitle(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.CreateNewProduct")); //$NON-NLS-1$
		newProductPage.setDescription(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.TypeProductName")); //$NON-NLS-1$
		newProductPage.setImageDescriptor(wizardImage);
		addPage(newProductPage);
		projectReferencesPage = new WizardNewProjectReferencePage(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ModuleSelection")); //$NON-NLS-1$
		projectReferencesPage.setDescription(AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.SelectReferencedModules")); //$NON-NLS-1$
		projectReferencesPage.setImageDescriptor(wizardImage);
		addPage(projectReferencesPage);
		productExportWizardPage = new ProductExportWizardPage(selection);
		addPage(productExportWizardPage);
		super.addPages();
	}

	/**
	 * Gets the current selection in the workbench, and returns the
	 * corresponding project.
	 * 
	 * @return the selected project
	 */
	private IProject getSelectedProject() {
		IProject selectedProject = null;
		if (selection != null && !selection.isEmpty()) {
			if (selection.size() > 0) {
				Object element = selection.getFirstElement();
				if (element instanceof IAdaptable) {
					element = ((IAdaptable) element).getAdapter(IResource.class);
				}
				if (element instanceof IProject) {
					selectedProject = (IProject) element;
				} else if (element instanceof IResource) {
					selectedProject = ((IResource) element).getProject();
				}
			}
		}
		return selectedProject;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#createPageControls(org.eclipse.swt.widgets.Composite)
	 */
	public void createPageControls(Composite pageContainer) {
		super.createPageControls(pageContainer);
		IProject selectedProject = getSelectedProject();
		if (selectedProject != null && ((Composite) projectReferencesPage.getControl()).getChildren().length > 1 && ((Composite) projectReferencesPage.getControl()).getChildren()[1] instanceof Table) {
			Table table = (Table) ((Composite) projectReferencesPage.getControl()).getChildren()[1];
			TableItem[] children = table.getItems();
			for (int i = 0; i < children.length; i++) {
				TableItem item = children[i];
				Object data = item.getData();
				if (data instanceof IProject && selectedProject.getName().equals(((IProject) data).getName())) {
					item.setChecked(true);
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#performFinish()
	 */
	public boolean performFinish() {
		IRunnableWithProgress create = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) {
				try {
					IPath destinationPath = new Path(productExportWizardPage.getDestination());
					AcceleoCreateModuleProductData arg = new AcceleoCreateModuleProductData(AcceleoExportToProductWizard.this);
					IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(newProductPage.getProjectName());
					IPath location = newProductPage.getLocationPath();
					if (!project.exists()) {
						IProjectDescription desc = project.getWorkspace().newProjectDescription(newProductPage.getProjectName());
						if (location != null && ResourcesPlugin.getWorkspace().getRoot().getLocation().equals(location)) {
							location = null;
						}
						desc.setLocation(location);
						project.create(desc, monitor);
						project.open(monitor);
						convertProject(project, arg, monitor);
					}
					if (!project.isOpen()) {
						project.open(monitor);
					}
					IFile productFile = project.getFile(new Path("acceleoModule.product")); //$NON-NLS-1$
					createProduct(productFile, arg, monitor);
					if (productFile.exists()) {
						StringBuffer buffer = Resources.getFileContent(productFile);
						int i = buffer.indexOf("</plugins>"); //$NON-NLS-1$
						if (i > -1) {
							boolean hasChanged1 = addPluginTextAt(buffer, i, arg.getProductID());
							boolean hasChanged2;
							if (!arg.getEclipseVersion().startsWith("3.2.")) { //$NON-NLS-1$
								hasChanged2 = addPluginTextAt(buffer, i, "org.eclipse.equinox.launcher"); //$NON-NLS-1$
							} else {
								hasChanged2 = false;
							}
							if (hasChanged1 || hasChanged2) {
								Resources.createFile(project, new Path("acceleoModule.product"), buffer.toString(), monitor); //$NON-NLS-1$
							}
						}
						scheduleExportJob(productFile);
					}
					File targetFolder = destinationPath.toFile();
					if (targetFolder.exists()) {
						File modelFolder = destinationPath.append("model").toFile(); //$NON-NLS-1$
						if (!modelFolder.exists()) {
							modelFolder.mkdir();
						}
						File srcGenFolder = destinationPath.append("src-gen").toFile(); //$NON-NLS-1$
						if (!srcGenFolder.exists()) {
							srcGenFolder.mkdir();
						}
						CreateModuleProductLaunchBatWriter launcherBatWriter = new CreateModuleProductLaunchBatWriter();
						String launchBatText = launcherBatWriter.generate(arg);
						createFile(targetFolder, "run.bat", launchBatText); //$NON-NLS-1$
						CreateModuleProductLaunchShWriter launcherShWriter = new CreateModuleProductLaunchShWriter();
						String launcherShText = launcherShWriter.generate(arg);
						createFile(targetFolder, "run.sh", launcherShText); //$NON-NLS-1$
						List templateIDs = new ArrayList();
						List templateNames = new ArrayList();
						IFile[] templates = Resources.members(getSelectedProject(), new String[] { SpecificScript.GENERATORS_EXTENSION });
						for (int i = 0; i < templates.length; i++) {
							StringBuffer templateContent = Resources.getFileContent(templates[i]);
							if (TextSearch.getRegexSearch().indexOf(templateContent.toString(),
									TemplateConstants.SCRIPT_FILE + "[ \t\r\n]*" + TemplateConstants.SCRIPT_PROPERTY_ASSIGN + "[ \t\r\n]*" + TemplateConstants.LITERAL[0]).b() > -1) { //$NON-NLS-1$  //$NON-NLS-2$
								templateIDs.add(templates[i].getFullPath().toString());
								templateNames.add(new Path(templates[i].getName()).removeFileExtension().lastSegment());
							}
						}
						CreateModuleProductAcceleoIniWriter acceleoIniWriter = new CreateModuleProductAcceleoIniWriter();
						String acceleoIniText = acceleoIniWriter.generate(new Object[] { arg, templateIDs.toArray(new String[templateIDs.size()]),
								templateNames.toArray(new String[templateNames.size()]) });
						createFile(targetFolder, "acceleo.ini", acceleoIniText); //$NON-NLS-1$
					}
				} catch (CoreException e) {
					IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
					AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
				}
			}

			private boolean addPluginTextAt(StringBuffer buffer, int offset, String pluginID) {
				String pluginText = "<plugin id=\"" + pluginID + "\"/>"; //$NON-NLS-1$ //$NON-NLS-2$
				if (buffer.indexOf(pluginText) == -1) {
					buffer.insert(offset, "   " + pluginText + "\n   "); //$NON-NLS-1$ //$NON-NLS-2$
					return true;
				} else {
					return false;
				}
			}

			private void createFile(File targetFolder, String fileName, String text) {
				try {
					final File launchBatFile = new File(targetFolder.getAbsolutePath() + '/' + fileName);
					final Writer writer = new BufferedWriter(new FileWriter(launchBatFile));
					writer.write(text);
					writer.close();
				} catch (final IOException e) {
					IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
					AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
				}
			}
		};
		try {
			PlatformUI.getWorkbench().getProgressService().run(false, false, create);
			return true;
		} catch (InvocationTargetException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
			return false;
		} catch (InterruptedException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
			return false;
		}
	}

	/**
	 * Converts the given project to an Acceleo product project.
	 * 
	 * @param project
	 *            is the project to convert
	 * @param arg
	 *            is the class used to configure all the JET generations
	 * @param monitor
	 *            is the monitor
	 */
	private void convertProject(IProject project, AcceleoCreateModuleProductData arg, IProgressMonitor monitor) {
		String baseFolder = "/src/" + arg.getProductID().replaceAll("\\.", "/"); //$NON-NLS-1$  //$NON-NLS-2$  //$NON-NLS-3$
		createDefaultImage(project, monitor);
		CreateModuleProductActivatorWriter activatorWriter = new CreateModuleProductActivatorWriter();
		String text = activatorWriter.generate(arg);
		IPath file = new Path(baseFolder + "/Activator.java"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductBuildWriter buildWriter = new CreateModuleProductBuildWriter();
		text = buildWriter.generate(arg);
		file = new Path("build.properties"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductClasspathWriter classpathWriter = new CreateModuleProductClasspathWriter();
		text = classpathWriter.generate(arg);
		file = new Path(".classpath"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductMANIFESTWriter manifestWriter = new CreateModuleProductMANIFESTWriter();
		text = manifestWriter.generate(arg);
		file = new Path("META-INF/MANIFEST.MF"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductProjectWriter projectWriter = new CreateModuleProductProjectWriter();
		text = projectWriter.generate(arg);
		file = new Path(".project"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductGenerateWriter generateWriter = new CreateModuleProductGenerateWriter();
		text = generateWriter.generate(arg);
		file = new Path(baseFolder + "/runner/AcceleoGenerate.java"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductPluginXMLWriter pluginXMLWriter = new CreateModuleProductPluginXMLWriter();
		text = pluginXMLWriter.generate(arg);
		file = new Path("plugin.xml"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductApplicationWriter appWriter = new CreateModuleProductApplicationWriter();
		text = appWriter.generate(arg);
		file = new Path(baseFolder + "/runner/GenRunner.java"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductAboutHtmlWriter aboutHtmlWriter = new CreateModuleProductAboutHtmlWriter();
		text = aboutHtmlWriter.generate(arg);
		file = new Path("about.html"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductAboutIniWriter aboutIniWriter = new CreateModuleProductAboutIniWriter();
		text = aboutIniWriter.generate(arg);
		file = new Path("about.ini"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
		CreateModuleProductAboutPropertiesWriter aboutPropertiesWriter = new CreateModuleProductAboutPropertiesWriter();
		text = aboutPropertiesWriter.generate(arg);
		file = new Path("about.properties"); //$NON-NLS-1$
		createFile(project, file, text, monitor);
	}

	/**
	 * Creates a 'default.gif' image in the 'icons' folder of the project.
	 * 
	 * @param project
	 *            is a project
	 * @param monitor
	 *            is the monitor
	 */
	private void createDefaultImage(IProject project, IProgressMonitor monitor) {
		try {
			URL imageURL = Platform.getBundle(AcceleoEcoreGenUiPlugin.getDefault().getID()).getEntry("icons/wizard/product.gif"); //$NON-NLS-1$
			imageURL = FileLocator.toFileURL(imageURL);
			File imageFile = new File(imageURL.getFile());
			IFolder icons = project.getFolder(new Path("icons")); //$NON-NLS-1$
			if (!icons.exists()) {
				icons.create(true, true, monitor);
			}
			if (!icons.exists(new Path("default.gif"))) { //$NON-NLS-1$
				copyFile(imageFile, icons.getFile("default.gif").getLocation().toFile()); //$NON-NLS-1$
				icons.refreshLocal(1, monitor);
			}
		} catch (IOException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		} catch (CoreException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		}
	}

	/**
	 * Creates a file and its content.
	 * 
	 * @param project
	 *            is the project
	 * @param projectRelativePath
	 *            is the path of the file to create, relative to the project
	 * @param content
	 *            is the content of the new file
	 * @param monitor
	 *            is the monitor
	 */
	private void createFile(IProject project, IPath projectRelativePath, String content, IProgressMonitor monitor) {
		try {
			ByteArrayInputStream javaStream = new ByteArrayInputStream(content.getBytes("UTF8")); //$NON-NLS-1$
			IContainer container = project;
			String[] folders = projectRelativePath.removeLastSegments(1).segments();
			for (int i = 0; i < folders.length; i++) {
				container = container.getFolder(new Path(folders[i]));
				if (!container.exists()) {
					((IFolder) container).create(true, true, monitor);
				}
			}
			IFile file = container.getFile(new Path(projectRelativePath.lastSegment()));
			if (!file.exists()) {
				file.create(javaStream, true, monitor);
			} else {
				file.setContents(javaStream, true, false, monitor);
			}
		} catch (CoreException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		} catch (UnsupportedEncodingException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		}
	}

	/**
	 * Copy the given file.
	 * 
	 * @param sourceFile
	 *            is the file to copy
	 * @param targetFile
	 *            is the file to create
	 * @throws FileNotFoundException
	 *             the input file isn't found
	 * @throws IOException
	 *             if an I/O error occurs.
	 */
	private void copyFile(File sourceFile, File targetFile) throws FileNotFoundException, IOException {
		if (targetFile.exists()) {
			return;
		}
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream(sourceFile);
			out = new FileOutputStream(targetFile);

			final int length = 8 * 1024;
			byte[] buffer = new byte[length];
			int count = 0;
			do {
				out.write(buffer, 0, count);
				count = in.read(buffer, 0, buffer.length);
			} while (count != -1);
		} finally {
			if (out != null) {
				out.close();
			}
			if (in != null) {
				in.close();
			}
		}
	}

	/**
	 * Creates a product file.
	 * 
	 * @param productFile
	 *            is the product file
	 * @param arg
	 *            is the class used to configure all the JET generations
	 * @param monitor
	 *            is the monitor
	 */
	private void createProduct(final IFile productFile, final AcceleoCreateModuleProductData arg, IProgressMonitor monitor) {
		try {
			ProductFromExtensionOperation op = new ProductFromExtensionOperation(productFile, arg.getProductID()) {
				protected void initializeProduct(IProduct product) {
					super.initializeProduct(product);
					product.setId(arg.getProductID());
					product.setApplication(arg.getApplicationID());
					product.setName("Acceleo Module Product"); //$NON-NLS-1$
					IProductModelFactory factory = product.getModel().getFactory();
					ILauncherInfo launcherInfo = factory.createLauncherInfo();
					launcherInfo.setLauncherName("acceleo"); //$NON-NLS-1$
					product.setLauncherInfo(launcherInfo);
				}

				protected void addPlugins(IProductModelFactory factory, IProduct product, IPluginModelBase[] plugins) {
					IProductPlugin[] pplugins = new IProductPlugin[plugins.length + 1 + arg.getPluginDependencies().size()];
					pplugins[0] = factory.createPlugin();
					pplugins[0].setId(productFile.getProject().getName());
					for (int i = 0; i < plugins.length; i++) {
						IProductPlugin pplugin = factory.createPlugin();
						pplugin.setId(plugins[i].getPluginBase().getId());
						pplugins[i + 1] = pplugin;
					}
					for (int i = 0; i < arg.getPluginDependencies().size(); i++) {
						IProductPlugin pplugin = factory.createPlugin();
						pplugin.setId((String) arg.getPluginDependencies().get(i));
						pplugins[plugins.length + 1 + i] = pplugin;
					}
					product.addPlugins(pplugins);
				}
			};
			getContainer().run(false, true, op);
		} catch (InvocationTargetException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		} catch (InterruptedException e) {
			IStatus status = new Status(IStatus.ERROR, AcceleoEcoreGenUiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e);
			AcceleoEcoreGenUiPlugin.getDefault().getLog().log(status);
		}
	}

	/**
	 * Schedules an 'export' job to be run. The job is added to a queue of
	 * waiting jobs, and will be run when it arrives at the beginning of the
	 * queue.
	 * 
	 * @param productFile
	 *            is the product file
	 */
	protected void scheduleExportJob(IFile productFile) {
		WorkspaceProductModel productModel = new WorkspaceProductModel(productFile, false);
		try {
			productModel.load();
			if (!productModel.isLoaded()) {
				MessageDialog.openError(getContainer().getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
						AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
			} else {
				FeatureExportInfo info = new FeatureExportInfo();
				info.toDirectory = true;
				info.exportSource = false;
				info.destinationDirectory = productExportWizardPage.getDestination();
				info.items = getPluginModels(productModel);
				String rootDirectory = "acceleo"; //$NON-NLS-1$
				if ("".equals(rootDirectory.trim())) //$NON-NLS-1$
					rootDirectory = "."; //$NON-NLS-1$
				ProductExportJob job = new ProductExportJob(info, productModel, rootDirectory, getContainer());
				job.setUser(true);
				job.schedule();
				job.setProperty(IProgressConstants.ICON_PROPERTY, PDEPluginImages.DESC_FEATURE_OBJ);
			}
		} catch (CoreException e) {
			MessageDialog.openError(getContainer().getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (IllegalArgumentException e) {
			MessageDialog.openError(getContainer().getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		} catch (SecurityException e) {
			MessageDialog.openError(getContainer().getShell(), AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardError"), //$NON-NLS-1$
					AcceleoGenUIMessages.getString("AcceleoExportToProductWizard.ProductExportWizardCorrupt")); //$NON-NLS-1$
		}
	}

	/**
	 * Get plugin dependencies.
	 * 
	 * @param productModel
	 *            is the product model (abstract representation of the product
	 *            file)
	 * @return the dependencies
	 */
	private BundleDescription[] getPluginModels(WorkspaceProductModel productModel) {
		ArrayList list = new ArrayList();
		State state = PDECore.getDefault().getModelManager().getState().getState();
		IProductPlugin[] plugins = productModel.getProduct().getPlugins();
		for (int i = 0; i < plugins.length; i++) {
			BundleDescription bundle = state.getBundle(plugins[i].getId(), null);
			if (bundle != null) {
				list.add(bundle);
				BundleDescription[] fragments = bundle.getFragments();
				for (int j = 0; j < fragments.length; j++) {
					if (!list.contains(fragments[j])) {
						list.add(fragments[j]);
					}
				}
			}
		}
		return (BundleDescription[]) list.toArray(new BundleDescription[list.size()]);
	}

}
