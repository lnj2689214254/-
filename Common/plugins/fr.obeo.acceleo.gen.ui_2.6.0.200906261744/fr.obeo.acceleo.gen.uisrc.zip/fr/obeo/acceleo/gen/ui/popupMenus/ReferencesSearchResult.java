/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.popupMenus;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.text.AbstractTextSearchResult;
import org.eclipse.search.ui.text.IEditorMatchAdapter;
import org.eclipse.search.ui.text.IFileMatchAdapter;
import org.eclipse.search.ui.text.Match;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;

import fr.obeo.acceleo.gen.ui.AcceleoGenUIMessages;
import fr.obeo.acceleo.gen.ui.editors.template.AcceleoTemplateEditor;

/**
 * This class store results of the query. It is also an adapter.
 * 
 * @author Yvan LUSSAUD <a
 *         href="mailto:yvan.lussaud@obeo.fr">yvan.lussaud@obeo.fr</a>
 * 
 */
public class ReferencesSearchResult extends AbstractTextSearchResult implements IEditorMatchAdapter, IFileMatchAdapter {
	/**
	 * The query
	 */
	private ReferencesSearchQuery query = null;

	/**
	 * Constructor
	 * 
	 * @param query
	 *            the query to use
	 */
	public ReferencesSearchResult(ReferencesSearchQuery query) {
		this.query = query;
	}

	/* (non-Javadoc) */
	public IEditorMatchAdapter getEditorMatchAdapter() {
		return this;
	}

	/* (non-Javadoc) */
	public IFileMatchAdapter getFileMatchAdapter() {
		return this;
	}

	/* (non-Javadoc) */
	public ImageDescriptor getImageDescriptor() {
		return ImageDescriptor.getMissingImageDescriptor();
	}

	/* (non-Javadoc) */
	public String getLabel() {
		return AcceleoGenUIMessages.getString("AcceleoGenReferencesSearch.Result.Label"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public ISearchQuery getQuery() {
		return query;
	}

	/* (non-Javadoc) */
	public String getTooltip() {
		return AcceleoGenUIMessages.getString("AcceleoGenReferencesSearch.Result.Tooltip"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public Match[] computeContainedMatches(AbstractTextSearchResult result, IEditorPart editor) {
		IFile file = (editor.getEditorInput() instanceof IFileEditorInput) ? ((IFileEditorInput) editor.getEditorInput()).getFile() : null;
		return result.getMatches(file);
	}

	/* (non-Javadoc) */
	public boolean isShownInEditor(Match match, IEditorPart editor) {
		if ((editor instanceof AcceleoTemplateEditor) && match.getElement() instanceof IFile) {
			AcceleoTemplateEditor acceleoEditor = (AcceleoTemplateEditor) editor;
			IFile matchedFile = (IFile) match.getElement();
			return acceleoEditor.getFile().equals(matchedFile);
		} else {
			return false;
		}
	}

	/* (non-Javadoc) */
	public Match[] computeContainedMatches(AbstractTextSearchResult result, IFile file) {
		return result.getMatches(file);
	}

	/* (non-Javadoc) */
	public IFile getFile(Object element) {
		if (element instanceof IFile) {
			return (IFile) element;
		} else {
			return null;
		}
	}
}
