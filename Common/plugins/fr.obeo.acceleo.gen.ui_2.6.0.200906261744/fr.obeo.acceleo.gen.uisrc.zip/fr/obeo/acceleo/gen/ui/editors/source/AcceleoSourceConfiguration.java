/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.gen.ui.editors.source;

import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;

/**
 * This class bundles the configuration space of a source viewer.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoSourceConfiguration extends SourceViewerConfiguration {

	/**
	 * The source editor.
	 */
	protected AcceleoSourceEditor editor;

	/**
	 * The double click strategy.
	 */
	protected AcceleoSourceDoubleClickStrategy doubleClickStrategy;

	/**
	 * Create a new source viewer configuration.
	 * 
	 * @param editor
	 */
	public AcceleoSourceConfiguration(AcceleoSourceEditor editor) {
		super();
		this.editor = editor;
	}

	/* (non-Javadoc) */
	public ITextDoubleClickStrategy getDoubleClickStrategy(ISourceViewer sourceViewer, String contentType) {
		if (doubleClickStrategy == null)
			doubleClickStrategy = new AcceleoSourceDoubleClickStrategy(editor);
		return doubleClickStrategy;
	}

	/* (non-Javadoc) */
	public IAnnotationHover getAnnotationHover(ISourceViewer sourceViewer) {
		return new AcceleoSourceHover(editor);
	}

	/* (non-Javadoc) */
	public ITextHover getTextHover(ISourceViewer sourceViewer, String contentType) {
		return new AcceleoSourceHover(editor);
	}

}
