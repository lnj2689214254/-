/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.jaxen.JaxenException;
import org.jdom.Element;

/**
 * To load and convert a specific XMI file.
 * 
 * @author www.obeo.fr
 * 
 */
public interface IXmiLoader {

	/**
	 * Indicates if the given file can be converted.
	 * 
	 * @param file
	 *            is the file to validate
	 * @return true if the given file can be converted
	 */
	boolean validate(IFile file);

	/**
	 * Converts to EMF
	 * 
	 * @param file
	 *            is the valid file
	 * @param resultPath
	 *            is the path of the EMF output
	 * @param progressMonitor
	 *            is the monitor
	 * @throws CoreException
	 */
	void convert(IFile file, String resultPath, IProgressMonitor progressMonitor) throws CoreException;

	/**
	 * Indicates if we have to change the input text.
	 * 
	 * @return true to change the input text
	 */
	boolean hasInputTextChanged();

	/**
	 * To change the input text.
	 * 
	 * @param input
	 *            is the input text
	 * @return the new text
	 */
	String changeInputText(String input);

	/**
	 * Indicates if we have to change the XML input.
	 * 
	 * @return true to change the XML input
	 */
	boolean hasInputXmlChanged();

	/**
	 * To change the root element of the XML input
	 * 
	 * @param input
	 *            is the root element of the XML input
	 * @throws JaxenException
	 */
	void changeInputXml(Element input) throws JaxenException;

	/**
	 * Bad chars killer.
	 * 
	 * @return the bad strings
	 */
	String[] badStrings();

}
