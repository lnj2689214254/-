/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLStreamException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import fr.obeo.acceleo.bridge.AcceleoBridgePlugin;
import fr.obeo.acceleo.bridge.IXmiLoader;
import fr.obeo.acceleo.bridge.ModelReaderException;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * UML 2.0 EA to UML 2.0 EMF transformation for UML 2.0 metamodel.
 * 
 * @author www.obeo.fr
 * 
 */
public class Uml20EAConverter {

	/**
	 * xmi file location.
	 */
	protected String xmiLocation = ""; //$NON-NLS-1$

	/**
	 * To load and convert a specific XMI file.
	 */
	protected IXmiLoader xmiLoader = null;

	private final Map badStrings = new LinkedHashMap();

	/**
	 * This method fixes inconsistencies (in XMI produced by EA) that could
	 * handle more easily with java replaceAll method.
	 * 
	 * This method replaces also bad chars killer in the current file with
	 * temporary strings. These temporary strings will be replaced at the end
	 * the converter process.
	 * 
	 * @param xmiPath
	 * @return
	 * @throws CoreException
	 */
	private InputStream fixXMIFileInconsistenciesWithStringReplace(String xmiPath) throws CoreException {
		final File xmiFile = new File(xmiPath);
		FileInputStream fis = null;
		final StringBuffer sb = new StringBuffer();
		try {
			// Find all xmi:id with a space
			final List xmiIdToChange = new ArrayList();
			final File xmiFileFirst = new File(xmiPath);
			final InputStream fisFirst = new FileInputStream(xmiFileFirst);
			final BufferedReader readerFirst = new BufferedReader(new InputStreamReader(fisFirst));
			String line = null;
			while ((line = readerFirst.readLine()) != null) {
				if (line.matches(".*?xmi:id=\"[^\"]*?\\s[^\"]*?\".*?")) {
					xmiIdToChange.add(line.substring(line.indexOf("xmi:id")).substring(8, line.substring(line.indexOf("xmi:id")).indexOf("\"", 8)));
				}
			}
			fisFirst.close();

			// Fix XMI
			fis = new FileInputStream(xmiFile);
			final BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
			line = null;

			int nbBadStrings = 0;
			while ((line = reader.readLine()) != null) {

				// Fix xmi:id and its reference with a space
				for (final Iterator it = xmiIdToChange.iterator(); it.hasNext();) {
					final String currentXmiId = (String) it.next();
					if (line.indexOf(currentXmiId) != -1) {
						// All space in an xmi:id are replaced by a _
						line = line.replaceAll(currentXmiId, currentXmiId.replaceAll(" ", "_"));
					}
				}

				line = line.replaceAll("xmlns:uml=\"http://schema.omg.org/spec/UML/2.1\"", "xmlns:uml=\"http://www.eclipse.org/uml2/2.0.0/UML\" xmlns:ecore=\"http://www.eclipse.org/emf/2002/Ecore\"");
				line = line
						.replaceAll("xmlns:uml=\"http://schema.omg.org/spec/UML/2.1/\"", "xmlns:uml=\"http://www.eclipse.org/uml2/2.0.0/UML\" xmlns:ecore=\"http://www.eclipse.org/emf/2002/Ecore\"");
				line = line.replaceAll("xmlns:uml=\"http://schema.omg.org/spec/UML/2.1/uml.xml\"",
						"xmlns:uml=\"http://www.eclipse.org/uml2/2.0.0/UML\" xmlns:ecore=\"http://www.eclipse.org/emf/2002/Ecore\"");
				line = line.replaceAll("<importedPackage href=\"http://schema.omg.org/spec/UML/2.1/uml.xml\"/>",
						"<importedPackage xmi:type=\"uml:Model\" href=\"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#_0\"/>");
				line = line.replaceAll("<importedPackage href=\"http://schema.omg.org/spec/UML/2.1/\"/>",
						"<importedPackage xmi:type=\"uml:Model\" href=\"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#_0\"/>");
				line = line.replaceAll("<uml:Profile", "<packagedElement xmi:type=\"uml:Profile\"");
				line = line.replaceAll("</uml:Profile>", "</packagedElement>");
				line = line.replaceAll("<uml:Model", "<uml:Model xmlns:xmi=\"http://schema.omg.org/spec/XMI/2.1\"");
				line = line.replaceAll("<ownedEnd xmi:id=\"", "<ownedEnd xmi:type=\"uml:ExtensionEnd\" xmi:id=\"");
				line = line.replaceAll("value=\"n\"", "value=\"-1\"");

				// if an enumeration value is the default value then this value
				// should not appear in the XMI
				line = line.replaceAll("messageKind=\"complete\"", "");
				line = line.replaceAll("messageSort=\"synchCall\"", "");
				line = line.replaceAll("visibilityKind=\"public\"", "");
				line = line.replaceAll("transitionKind=\"internal\"", "");
				line = line.replaceAll("pseudostateKind=\"initial\"", "");
				line = line.replaceAll("connectorKind=\"assembly\"", "");
				line = line.replaceAll("callConcurrencyKind=\"sequential\"", "");
				line = line.replaceAll("aggregationKind=\"none\"", "");
				line = line.replaceAll("parameterDirectionKind=\"in\"", "");
				line = line.replaceAll("parameterEffectKind=\"create\"", "");
				line = line.replaceAll("objectNodeOrderingKind=\"unordered\"", "");
				line = line.replaceAll("interactionOperatorKind=\"seq\"", "");
				line = line.replaceAll("expansionKind=\"parallel\"", "");
				line = line.replaceAll("base_ASSOCIATION_TARGET", "base_AssociationRole");// EA
				line = line.replaceAll("&lt;", "__lt__");
				line = line.replaceAll("&gt;", "__gt__");
				// does
				// not
				// export
				// stereotypes
				// applied
				// to
				// roles
				// correctly
				// ...

				// TODO Save Encoding
				// <?xml version="1.0" encoding="windows-1252"?>

				if (xmiLoader.badStrings() != null && xmiLoader.badStrings().length > 0) {
					for (int i = 0; i < xmiLoader.badStrings().length; i++) {
						if (TextSearch.getRegexSearch().indexOf(line, xmiLoader.badStrings()[i]).b() > -1) {
							final StringBuffer result = new StringBuffer(line);
							final Int2[] positions = TextSearch.getRegexSearch().allIndexOf(line, xmiLoader.badStrings()[i]);
							if (positions.length > 0) {
								for (int j = positions.length - 1; j >= 0; j--) {
									final String replacementString = "__BAD_STRINGS_" + nbBadStrings + "__"; //$NON-NLS-1$ //$NON-NLS-2$
									badStrings.put(replacementString, result.substring(positions[j].b(), positions[j].e()));
									result.replace(positions[j].b(), positions[j].e(), replacementString);
									nbBadStrings++;
								}
							}
							line = result.toString();
						}
					}
				}

				sb.append(line + "\n");
			}
		} catch (final FileNotFoundException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} finally {
			try {
				fis.close();
			} catch (final IOException e) {
				AcceleoBridgePlugin.getDefault().log(e, false);
			}
		}

		return new ByteArrayInputStream(sb.toString().getBytes());
	}

	/**
	 * This method undoes some replacement made in previous step.
	 * 
	 * @param xmiPath
	 *            is the path of uml model
	 * @throws IOException
	 *             if I/O error occurs
	 */
	private void undoReplace(String xmiPath) throws IOException {
		final File xmiFile = new File(xmiPath);
		FileInputStream fis = null;
		final StringBuffer sb = new StringBuffer();
		try {
			// Fix XMI
			fis = new FileInputStream(xmiFile);
			final BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
			String line = null;
			while ((line = reader.readLine()) != null) {
				line = line.replaceAll("__lt__", "&lt;");
				line = line.replaceAll("__gt__", "&gt;");
				sb.append(line + "\n");
			}
		} catch (final FileNotFoundException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} finally {
			try {
				fis.close();
			} catch (final IOException e) {
				AcceleoBridgePlugin.getDefault().log(e, false);
			}
		}

		File f = new File(xmiPath);
		InputStream inputStream = new ByteArrayInputStream(sb.toString().getBytes());
		OutputStream out = new FileOutputStream(f);
		byte buf[] = new byte[1024];
		int len;
		while ((len = inputStream.read(buf)) > 0) {
			out.write(buf, 0, len);
		}
		out.close();
		inputStream.close();
	}

	/**
	 * The schema location attribute is removed during EMF load and save step.
	 * This method re-adds it.
	 * 
	 * This method undoes also bad chars killer replacement done at the
	 * beginning of the converter process.
	 * 
	 * @param xmiPath
	 * @param schemaLocationAttribute
	 * @throws CoreException
	 * @throws IOException
	 */
	private void addSchemaAttributeAndUndoBadCharKillerReplacement(String xmiPath, String schemaLocationAttribute) throws CoreException, IOException {
		final File xmiFile = new File(xmiPath);
		FileInputStream fis = null;
		final StringBuffer sb = new StringBuffer();
		try {
			String line = null;
			fis = new FileInputStream(xmiFile);
			final BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
			line = null;
			while ((line = reader.readLine()) != null) {
				line = line.replaceAll("<xmi:XMI", "<xmi:XMI " + schemaLocationAttribute);
				// TODO Check if it is possible to move it in badstring section
				line = line.replaceAll("__raquo__", "�");
				line = line.replaceAll("__laquo__", "�");
				List badStringsToRemove = new ArrayList();
				boolean startJob = false;
				boolean skipLoop = false;
				if (TextSearch.getRegexSearch().indexOf(line, "__BAD_STRINGS_").b() > -1) { //$NON-NLS-1$
					if (badStrings.size() > 0) {
						final Iterator it = badStrings.entrySet().iterator();
						while (it.hasNext() && !skipLoop) {
							final Map.Entry entry = (Map.Entry) it.next();
							final String replacementString = (String) entry.getKey();
							final String initialString = (String) entry.getValue();
							if (TextSearch.getRegexSearch().indexOf(line, replacementString).b() > -1) {
								line = TextSearch.getDefaultSearch().replaceAllIn(line, replacementString, initialString, 0, line.length(), null);
								badStringsToRemove.add(replacementString);
								startJob = true;
							} else if (startJob) {
								skipLoop = true;
							} else {
								badStringsToRemove.add(replacementString);
							}
						}
					}
				}
				for (Iterator it = badStringsToRemove.iterator(); it.hasNext();) {
					badStrings.remove(it.next());
				}

				sb.append(line + "\n");
			}
		} catch (final FileNotFoundException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} finally {
			try {
				fis.close();
			} catch (final IOException e) {
				AcceleoBridgePlugin.getDefault().log(e, false);
			}
		}

		final InputStream io = new ByteArrayInputStream(sb.toString().getBytes());
		final FileOutputStream fos = new FileOutputStream(xmiPath);
		final byte[] buf = new byte[256];
		int read = 0;
		while ((read = io.read(buf)) > 0) {
			fos.write(buf, 0, read);
		}
		fos.close();
		io.close();
	}

	/**
	 * Loads a xmi file.
	 * 
	 * @param xmiLocation
	 *            is the MDR xmi file location
	 * @param xmiLoader
	 *            is the loader
	 */
	public void loadEAUml(String xmiLocation, IXmiLoader xmiLoader) {
		if (xmiLocation.startsWith("/")) { //$NON-NLS-1$
			xmiLocation = '/' + xmiLocation;
		}
		this.xmiLocation = xmiLocation;
		this.xmiLoader = xmiLoader;
	}

	/**
	 * Creates an UML model for EMF.
	 * 
	 * @param xmiPath
	 *            is the file to create
	 * @throws FactoryException
	 * @throws ModelReaderException
	 * @throws CoreException
	 */
	public void saveAsEmfUml(String xmiPath) throws FactoryException, ModelReaderException, CoreException {
		final ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		String tmpXmiLocation;
		tmpXmiLocation = (new Path(xmiLocation)).removeFileExtension().addFileExtension("old").addFileExtension("xmi").toString(); //$NON-NLS-1$ //$NON-NLS-2$
		InputStream tmpInputStream = fixXMIFileInconsistenciesWithStringReplace(xmiLocation);
		String schemaLocationAttribute = "";
		try {
			final FixUml20EAXMI f = new FixUml20EAXMI(new Path(tmpXmiLocation).removeLastSegments(1).toString() + "/");
			// parses all the file to fix bugs
			f.fix(tmpXmiLocation, tmpInputStream);
			schemaLocationAttribute = f.getSchemaLocationAttribute();
		} catch (final XMLStreamException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} catch (final FactoryConfigurationError e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		}
		if (xmiLoader.hasInputXmlChanged()) {
			try {
				final Element xmlRoot = (new SAXBuilder(false)).build(new File(tmpXmiLocation + ".tmp.xmi")).getRootElement();
				xmiLoader.changeInputXml(xmlRoot);
				final XMLOutputter xmlout = new XMLOutputter();
				xmlout.setIndent("   "); //$NON-NLS-1$
				xmlout.setNewlines(true);
				tmpInputStream = new ByteArrayInputStream(xmlout.outputString(xmlRoot).getBytes());
				final FileOutputStream fos = new FileOutputStream(tmpXmiLocation + ".tmp.xmi");
				final byte[] buf = new byte[256];
				int read = 0;
				while ((read = tmpInputStream.read(buf)) > 0) {
					fos.write(buf, 0, read);
				}
			} catch (final Exception e) {
				AcceleoBridgePlugin.getDefault().log(e, false);
			}
		}
		try {
			emfLoadAndSave((new Path(xmiPath)).removeFileExtension().addFileExtension("old").addFileExtension("xmi").addFileExtension("tmp").addFileExtension("xmi").toString(), xmiPath, resourceSet);
			addSchemaAttributeAndUndoBadCharKillerReplacement((new Path(xmiLocation)).removeFileExtension().addFileExtension("uml").toString(), schemaLocationAttribute);

			ResourcesPlugin.getWorkspace().getRoot().refreshLocal(IResource.DEPTH_INFINITE, null);
			final IFile oldXmiFile = ResourcesPlugin.getWorkspace().getRoot().getFile(
					(new Path(xmiPath)).removeFileExtension().addFileExtension("old").addFileExtension("xmi").addFileExtension("tmp").addFileExtension("xmi"));
			try {
				if (oldXmiFile.exists()) {
					oldXmiFile.delete(true, null);
				}
				final IFile tmpXmiFile = ResourcesPlugin.getWorkspace().getRoot().getFile((new Path(xmiPath)).removeFileExtension().addFileExtension("old").addFileExtension("xmi"));
				if (tmpXmiFile.exists()) {
					tmpXmiFile.delete(true, null);
				}
				undoReplace((new Path(xmiLocation)).removeFileExtension().addFileExtension("uml").toString());
			} catch (final RuntimeException e) {
				// Just to prevent an exception due to Eclipse unable to delete
				// a temp file
				// if such an exception were thrown, the default mechanism would
				// be triggered,
				// which would be useless
				AcceleoBridgePlugin.getDefault().log(e, false);
			}

		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		}
	}

	/**
	 * This method loads UML model with EMF. This process allows to check that
	 * the model is EMF compatible. Some unknown elements are removed during
	 * this EMF load and save process.
	 * 
	 * @param path
	 *            path of the fixed model with XML process
	 * @param newPath
	 *            new path with UML extension
	 * @param resourceSet
	 * @throws IOException
	 */
	private void emfLoadAndSave(String path, String newPath, ResourceSet resourceSet) throws IOException {
		final Uml20EAResourceFactoryImpl umlEA = new Uml20EAResourceFactoryImpl();
		final XMIResource modelResource = (XMIResource) umlEA.createResource(URI.createPlatformResourceURI(path, true));
		final Map defaultLoadOptions = modelResource.getDefaultLoadOptions();
		modelResource.load(defaultLoadOptions);

		final Map options = new HashMap();
		options.put(XMLResource.OPTION_RECORD_UNKNOWN_FEATURE, Boolean.TRUE);
		// TODO Save encoding during first XML step
		options.put(XMLResource.OPTION_ENCODING, "windows-1252");
		// Do not remove the following line, which prevents an EMF bug when a
		// resource is loaded
		// with extendedMetaData but saved without (NullPointerException)
		options.put(XMLResource.OPTION_EXTENDED_META_DATA, new Uml20EAExtendedMetaData());
		modelResource.setURI(URI.createPlatformResourceURI(newPath, true));
		modelResource.save(options);
		modelResource.unload();
	}

}
