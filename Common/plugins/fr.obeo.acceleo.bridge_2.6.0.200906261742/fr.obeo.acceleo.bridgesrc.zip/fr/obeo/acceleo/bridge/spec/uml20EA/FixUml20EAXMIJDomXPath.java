/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.jaxen.JaxenException;
import org.jaxen.jdom.JDOMXPath;
import org.jdom.Element;

/**
 * This is a simple class to fix up the UML 2.0 XMI that is produced by
 * Enterprise Architect 7.1
 * 
 * Because of performance problem with this API, most of fixes are done by
 * FixUML20EAXMI java class These class fix only what could not be done with the
 * XML stAX API.
 * 
 * @author www.obeo.fr
 * 
 */
public class FixUml20EAXMIJDomXPath {

	/**
	 * Modifiers the XMI files a copy of the file named by xmiIn and writes this
	 * copy to the file named by xmiOut.
	 * 
	 * @param root
	 *            the root element of the XMI file
	 * @throws JaxenException
	 */
	public void fix(Element root) throws JaxenException {
		removeProvided(root);
		removeRequired(root);
	}

	/**
	 * Remove provided XML element
	 * 
	 * @param root
	 * @throws JaxenException
	 */
	private void removeProvided(Element root) throws JaxenException {
		List toDetach = new ArrayList();
		String exp = "//*[local-name()='provided']"; //$NON-NLS-1$
		Collection ops = (new JDOMXPath(exp)).selectNodes(root);
		for (Iterator i = ops.iterator(); i.hasNext();) {
			Element opEl = (Element) i.next();
			toDetach.add(opEl);
		}
		for (Iterator i = toDetach.iterator(); i.hasNext();) {
			Element e = (Element) i.next();
			e.detach();
		}
	}

	/**
	 * Remove required XML element
	 * 
	 * @param root
	 * @throws JaxenException
	 */
	private void removeRequired(Element root) throws JaxenException {
		List toDetach = new ArrayList();
		String exp = "//*[local-name()='required']"; //$NON-NLS-1$
		Collection ops = (new JDOMXPath(exp)).selectNodes(root);
		for (Iterator i = ops.iterator(); i.hasNext();) {
			Element opEl = (Element) i.next();
			toDetach.add(opEl);
		}
		for (Iterator i = toDetach.iterator(); i.hasNext();) {
			Element e = (Element) i.next();
			e.detach();
		}
	}

}