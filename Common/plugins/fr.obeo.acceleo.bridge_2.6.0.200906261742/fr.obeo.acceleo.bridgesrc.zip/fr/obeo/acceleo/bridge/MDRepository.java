/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;

import javax.jmi.model.ModelPackage;
import javax.jmi.model.MofPackage;
import javax.jmi.reflect.RefBaseObject;
import javax.jmi.reflect.RefPackage;
import javax.jmi.xmi.MalformedXMIException;

import org.jaxen.JaxenException;
import org.jdom.JDOMException;
import org.netbeans.api.mdr.CreationFailedException;
import org.netbeans.api.mdr.MDRManager;
import org.netbeans.api.xmi.XMIReader;
import org.netbeans.api.xmi.XMIReaderFactory;
import org.openide.util.Lookup;

/**
 * Encapsulates a MDR repository facade.
 * 
 * @author www.obeo.fr
 * 
 */
public class MDRepository {

	/**
	 * The MDR repository facade.
	 */
	protected org.netbeans.api.mdr.MDRepository repository;

	private MDRManager manager;

	private ModelPackage metaModelExtent;

	private XMIReader reader;

	/**
	 * Constructor.
	 */
	public MDRepository(String metaModelUri) throws MalformedXMIException, CreationFailedException, IOException {
		URL metaModelUrl = new URL(metaModelUri);
		System.setProperty("org.netbeans.mdr.storagemodel.StorageFactoryClassName", "org.netbeans.mdr.persistence.memoryimpl.StorageFactoryImpl"); //$NON-NLS-1$ //$NON-NLS-2$
		manager = MDRManager.getDefault();
		repository = manager.getDefaultRepository();
		String[] extentNames = repository.getExtentNames();
		for (int i = 0; i <= extentNames.length - 1; i++) {
			if (!extentNames[i].equals("MOF")) //$NON-NLS-1$
				repository.getExtent(extentNames[i]).refDelete();
		}
		// loading metamodel
		metaModelExtent = (ModelPackage) repository.getExtent(metaModelUrl.toExternalForm());
		if (metaModelExtent == null) {
			metaModelExtent = (ModelPackage) repository.createExtent(metaModelUrl.toExternalForm());
		}
		XMIReaderFactory readerFactory = (XMIReaderFactory) Lookup.getDefault().lookup(XMIReaderFactory.class);
		reader = readerFactory.createXMIReader();
		reader.read(metaModelUrl.toExternalForm(), metaModelExtent);
	}

	/**
	 * Reads a MDR model and returns the root element.
	 * 
	 * @param xmiLocation
	 *            is the MDR xmi file location
	 * @param xmiLoader
	 *            to load and convert a specific XMI file.
	 * @return the root element
	 */
	public RefPackage readModel(String xmiLocation, IXmiLoader xmiLoader) throws JDOMException, JaxenException, IOException, CreationFailedException, MalformedXMIException {
		URL xmiUmlUrl = new URL("file:/" + xmiLocation); //$NON-NLS-1$
		RefPackage extentExist = repository.getExtent(xmiUmlUrl.toExternalForm());
		if (extentExist != null)
			extentExist.refDelete();
		RefPackage uml = repository.createExtent(xmiUmlUrl.toExternalForm(), getUmlPackage(metaModelExtent));
		Collection xmiOutermostObjects = reader.read(xmiUmlUrl.toExternalForm(), uml);
		RefPackage refPackage = ((RefBaseObject) xmiOutermostObjects.iterator().next()).refOutermostPackage();
		return refPackage;
	}

	private MofPackage getUmlPackage(ModelPackage metaModelExtent) {
		for (Iterator it = metaModelExtent.getMofPackage().refAllOfClass().iterator(); it.hasNext();) {
			MofPackage pkg = (MofPackage) it.next();
			if (pkg.getContainer() == null && "UML".equals(pkg.getName())) { //$NON-NLS-1$
				return pkg;
			}
		}
		return null;
	}

}
