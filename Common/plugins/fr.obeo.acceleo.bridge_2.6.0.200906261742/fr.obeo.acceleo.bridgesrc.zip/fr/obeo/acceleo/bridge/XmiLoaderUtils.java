/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

/**
 * To get the best XMI loader.
 * 
 * @author www.obeo.fr
 * 
 */
public class XmiLoaderUtils {

	private static final String XMI_LOADER_EXTENSION_ID = "fr.obeo.acceleo.bridge.xmiloader"; //$NON-NLS-1$

	/**
	 * To get the best XMI loader.
	 * 
	 * @param file
	 *            is the XMI file
	 * @return the best XMI loader
	 */
	public static IXmiLoader getXmiLoader(IFile file) {
		if (xmiLoaders == null) {
			IExtensionRegistry registry = Platform.getExtensionRegistry();
			IExtensionPoint extensionPoint = registry.getExtensionPoint(XMI_LOADER_EXTENSION_ID);
			if (extensionPoint == null) {
				xmiLoaders = new TreeSet();
				AcceleoBridgePlugin.getDefault().log(AcceleoBridgeMessages.getString("UnresolvedExtensionPoint", new Object[] { XMI_LOADER_EXTENSION_ID, }), true); //$NON-NLS-1$
			} else {
				xmiLoaders = new TreeSet(new Comparator() {
					public int compare(Object arg0, Object arg1) {
						Integer priority0;
						String s0 = ((IConfigurationElement) arg0).getAttribute("priority"); //$NON-NLS-1$
						if (s0 != null) {
							priority0 = new Integer(Integer.parseInt(s0));
						} else {
							priority0 = new Integer(0);
						}
						Integer priority1;
						String s1 = ((IConfigurationElement) arg1).getAttribute("priority"); //$NON-NLS-1$
						if (s1 != null) {
							priority1 = new Integer(Integer.parseInt(s1));
						} else {
							priority1 = new Integer(0);
						}
						int result = priority1.compareTo(priority0);
						if (result == 0) {
							result = 1;
						}
						return result;
					}
				});
				IExtension[] extensions = extensionPoint.getExtensions();
				for (int i = 0; i < extensions.length; i++) {
					IExtension extension = extensions[i];
					IConfigurationElement[] members = extension.getConfigurationElements();
					for (int j = 0; j < members.length; j++) {
						IConfigurationElement member = members[j];
						xmiLoaders.add(member);
					}
				}
			}
		}
		Iterator it = xmiLoaders.iterator();
		while (it.hasNext()) {
			IConfigurationElement member = (IConfigurationElement) it.next();
			String xmiLoader = member.getAttribute("xmiloader"); //$NON-NLS-1$
			if (xmiLoader != null) {
				Bundle theBundle = Platform.getBundle(member.getNamespace());
				if (theBundle == null) {
					theBundle = AcceleoBridgePlugin.getDefault().getBundle();
				}
				try {
					Class c = theBundle.loadClass(xmiLoader);
					Object instance = c.newInstance();
					if (instance instanceof IXmiLoader && ((IXmiLoader) instance).validate(file)) {
						return (IXmiLoader) instance;
					}
				} catch (ClassNotFoundException e) {
					AcceleoBridgePlugin.getDefault().log(e, true);
				} catch (InstantiationException e) {
					AcceleoBridgePlugin.getDefault().log(e, true);
				} catch (IllegalAccessException e) {
					AcceleoBridgePlugin.getDefault().log(e, true);
				}
			}
		}
		return null;
	}

	private static Collection xmiLoaders = null;

}
