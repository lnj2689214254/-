/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.jaxen.JaxenException;
import org.jdom.Element;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.bridge.AcceleoBridgePlugin;
import fr.obeo.acceleo.bridge.IXmiLoader;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Default loader for UML 2.1/XMI model
 * 
 * @author www.obeo.fr
 * 
 */
public class DefaultUml20EAXmiLoader implements IXmiLoader {

	private static final String umlExtension = "uml"; //$NON-NLS-1$

	private static final String[] validStringUml20 = { "XMLNS:UML=\"HTTP://SCHEMA.OMG.ORG/SPEC/UML/2.1\"" //$NON-NLS-1$
			, "<XMI:DOCUMENTATION EXPORTER=\"ENTERPRISE ARCHITECT\" EXPORTERVERSION=\"6.5\"/>" //$NON-NLS-1$
	};

	// � \u00E9
	// � \u00E8
	// � \u00E0
	// � \u00EA
	// � \u00F4
	// � \u00EE
	// � \u00E2
	// � \u00E7
	// � \u00C2
	// � \u00C3
	// ~ \u007E
	// � \u00A7
	// � \u00A8
	// � \u00A9
	// � \u00AA
	// � \u00AB
	// � \u00BB
	// � \u00A0
	// � \u00A2
	// � \u00B0
	// � \u00BA
	public String[] badStrings() {
		return new String[] {
				"[����]", "&#x[0-9a-fA-F]+;", "[\u00E9\u00E8\u00E0\u00EA\u00F4\u00EE\u00E2\u00E7\u00C2\u00C3\u007E\u00A7\u00A8\u00A9\u00AA\u00AB\u00BB\u00A2\u00A0\u00B0\u00BA]", "\u00B0" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
	}

	public String changeInputText(String input) {
		return null;
	}

	public void changeInputXml(Element input) throws JaxenException {
		FixUml20EAXMIJDomXPath fix = new FixUml20EAXMIJDomXPath();
		fix.fix(input);
	}

	public void convert(IFile file, String resultPath, IProgressMonitor progressMonitor) throws CoreException {
		file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
		try {
			final String xmiLocation = file.getLocation().toString();
			if (resultPath == null) {
				resultPath = file.getFullPath().removeFileExtension().addFileExtension(umlExtension).toString();
			}
			Resources.getContainerOrCreateFolder(ResourcesPlugin.getWorkspace().getRoot(), new Path(resultPath).removeLastSegments(1), progressMonitor);
			Class type;
			try {
				Bundle bundle = Platform.getBundle("fr.obeo.acceleo.bridge"); //$NON-NLS-1$
				if (bundle != null) {
					if (bundle.getState() != Bundle.ACTIVE) {
						bundle.start();
					}
					Thread.currentThread().setContextClassLoader(AcceleoBridgePlugin.getDefault().getMDClassLoader());
					type = bundle.loadClass("fr.obeo.acceleo.bridge.spec.uml20EA.Uml20EAConverter"); //$NON-NLS-1$
				} else {
					type = null;
				}
			} catch (ClassNotFoundException e) {
				type = null;
			}
			if (type != null) {
				Object instance = type.newInstance();
				Method method = type.getMethod("loadEAUml", new Class[] { String.class, IXmiLoader.class }); //$NON-NLS-1$
				method.invoke(instance, new Object[] { xmiLocation, this });
				method = type.getMethod("saveAsEmfUml", new Class[] { String.class }); //$NON-NLS-1$
				method.invoke(instance, new Object[] { resultPath });
			}
		} catch (Throwable e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			boolean blocking = true;
			if (e.getClass().getName().equals("fr.obeo.acceleo.bridge.ModelReaderException")) { //$NON-NLS-1$
				try {
					Class type = Thread.currentThread().getContextClassLoader().loadClass("fr.obeo.acceleo.bridge.ModelReaderException"); //$NON-NLS-1$
					Method method = type.getMethod("isBlocking", new Class[] {}); //$NON-NLS-1$
					blocking = !"false".equals(method.invoke(e, new Object[] {}).toString()); //$NON-NLS-1$
				} catch (Exception exception) {
					blocking = true;
				}
			}
			throw new CoreException(new Status((blocking) ? IStatus.ERROR : IStatus.WARNING, AcceleoBridgePlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e));
		} finally {
			Thread.currentThread().setContextClassLoader(oldClassLoader);
			file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		}
	}

	public boolean hasInputTextChanged() {
		return false;
	}

	public boolean hasInputXmlChanged() {
		return true;
	}

	public boolean validate(IFile file) {
		String result = Resources.getFileContent(file).toString().toUpperCase();
		for (int i = 0; i <= validStringUml20.length - 1; i++) {
			if (result.indexOf(validStringUml20[i]) > -1) {
				return true;
			}
		}
		return false;
	}

}
