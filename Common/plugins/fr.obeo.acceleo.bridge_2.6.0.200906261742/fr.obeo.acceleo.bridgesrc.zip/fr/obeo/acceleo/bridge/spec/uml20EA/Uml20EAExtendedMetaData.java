/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.EcoreUtil;

/**
 * 
 * @author www.obeo.fr
 * 
 */
public class Uml20EAExtendedMetaData extends BasicExtendedMetaData {

	/**
	 * Mappings to consider when trying to map elements. The keys used for this
	 * map are the fragment URI of the objects.
	 */
	private final Map elementMappings = new HashMap();

	public Uml20EAExtendedMetaData() {
		super();
		// elementMappings.put("//Realization", "//ComponentRealization");
		// //$NON-NLS-1$ //$NON-NLS-2$
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @see org.eclipse.emf.ecore.util.BasicExtendedMetaData#getType(EPackage,
	 *      String)
	 */
	public EClassifier getType(EPackage ePackage, String name) {
		final String mapping = (String) elementMappings.get(EcoreUtil.getURI(ePackage).fragment() + '/' + name);
		if (mapping != null) {
			final String[] fragments = mapping.split("/"); //$NON-NLS-1$
			return super.getType(ePackage, fragments[fragments.length - 1]);
		}
		return super.getType(ePackage, name);
	}

}
