/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.jaxen.JaxenException;
import org.jdom.Element;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.bridge.util.FixEAXMI;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Default loader for XMI 1.X/UML13.
 * 
 * @author www.obeo.fr
 * 
 */
public class DefaultUml13XmiLoader implements IXmiLoader {

	private static final String umlExtension = "uml13"; //$NON-NLS-1$

	private static final String[] validStringUml13 = { "XMI.NAME=\"UML\" XMI.VERSION=\"1.3\"", "XMI.NAME = \"UML\" XMI.VERSION = \"1.3\"", "XMI.NAME='UML' XMI.VERSION='1.3'", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			"XMI.NAME = 'UML' XMI.VERSION = '1.3'", "//ORG.OMG/UML/1.3" }; //$NON-NLS-1$ //$NON-NLS-2$

	/* (non-Javadoc) */
	public boolean validate(IFile file) {
		String result = Resources.getFileContent(file).toString().toUpperCase();
		for (int i = 0; i <= validStringUml13.length - 1; i++) {
			if (result.indexOf(validStringUml13[i]) > -1) {
				return true;
			}
		}
		return false;
	}

	/* (non-Javadoc) */
	public void convert(IFile file, String resultPath, IProgressMonitor progressMonitor) throws CoreException {
		file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
		try {
			final String xmiLocation = file.getLocation().toString();
			if (resultPath == null) {
				resultPath = file.getFullPath().removeFileExtension().addFileExtension(umlExtension).toString();
			}
			Resources.getContainerOrCreateFolder(ResourcesPlugin.getWorkspace().getRoot(), new Path(resultPath).removeLastSegments(1), progressMonitor);
			// Remark : "loadClass + newInstance + getMethod + invoke" to
			// resolve class loader problems for MDR
			Class type;
			try {
				Bundle bundle = Platform.getBundle("fr.obeo.acceleo.bridge"); //$NON-NLS-1$
				if (bundle != null) {
					if (bundle.getState() != Bundle.ACTIVE) {
						bundle.start();
					}
					Thread.currentThread().setContextClassLoader(AcceleoBridgePlugin.getDefault().getMDClassLoader());
					type = bundle.loadClass("fr.obeo.acceleo.bridge.Uml13Converter"); //$NON-NLS-1$
				} else {
					type = null;
				}
			} catch (ClassNotFoundException e) {
				type = null;
			}
			if (type != null) {
				Object instance = type.newInstance();
				Method method = type.getMethod("loadMdrUml", new Class[] { String.class, IXmiLoader.class }); //$NON-NLS-1$
				method.invoke(instance, new Object[] { xmiLocation, this });
				method = type.getMethod("saveAsEmfUml", new Class[] { String.class }); //$NON-NLS-1$
				method.invoke(instance, new Object[] { resultPath });
			}
		} catch (Throwable e) {
			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			boolean blocking = true;
			if (e.getClass().getName().equals("fr.obeo.acceleo.bridge.ModelReaderException")) { //$NON-NLS-1$
				// Remark : "loadClass + newInstance + getMethod + invoke" to
				// resolve class loader problems for MDR
				try {
					Class type = Thread.currentThread().getContextClassLoader().loadClass("fr.obeo.acceleo.bridge.ModelReaderException"); //$NON-NLS-1$
					Method method = type.getMethod("isBlocking", new Class[] {}); //$NON-NLS-1$
					blocking = !"false".equals(method.invoke(e, new Object[] {}).toString()); //$NON-NLS-1$
				} catch (Exception exception) {
					blocking = true;
				}
			}
			throw new CoreException(new Status((blocking) ? IStatus.ERROR : IStatus.WARNING, AcceleoBridgePlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e));
		} finally {
			Thread.currentThread().setContextClassLoader(oldClassLoader);
			file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		}
	}

	/* (non-Javadoc) */
	public boolean hasInputChanged() {
		return true;
	}

	/* (non-Javadoc) */
	public StringBuffer changeInput(StringBuffer input) {
		return input;
	}

	/* (non-Javadoc) */
	public boolean hasInputTextChanged() {
		return false;
	}

	/* (non-Javadoc) */
	public String changeInputText(String input) {
		return input;
	}

	/* (non-Javadoc) */
	public boolean hasInputXmlChanged() {
		return true;
	}

	/* (non-Javadoc) */
	public void changeInputXml(Element input) throws JaxenException {
		// Transform nodes <UML:ModelElement.taggedValue> into
		// <UML:TaggedValue>
		// and <UML:ModelElement.stereotype> into <UML:Stereotype> at the
		// end of the file.
		FixEAXMI fix = new FixEAXMI();
		fix.fix((Element) input);
	}

	/* (non-Javadoc) */
	public String[] badStrings() {
		return new String[] { "[����]", "&#x[0-9a-fA-F]+;", "[�������]" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ 
	}

}
