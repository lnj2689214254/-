/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.Path;
import org.eclipse.help.internal.appserver.PluginClassLoaderWrapper;
import org.osgi.framework.BundleContext;

import fr.obeo.acceleo.tools.resources.AcceleoPlugin;

/**
 * The main plugin class to be used in the desktop.
 * 
 * @author www.obeo.fr
 */
public class AcceleoBridgePlugin extends AcceleoPlugin {

	/* (non-Javadoc) */
	public String getID() {
		return "fr.obeo.acceleo.bridge"; //$NON-NLS-1$
	}

	// The shared instance.
	private static AcceleoBridgePlugin plugin;

	/**
	 * Resource bundle.
	 */
	private ResourceBundle resourceBundle;

	/**
	 * The constructor.
	 */
	public AcceleoBridgePlugin() {
		plugin = this;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
		resourceBundle = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static AcceleoBridgePlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 * 
	 * @param key
	 *            identifies the string
	 * @return the string from the plugin's resource bundle, or 'key' if not
	 *         found
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = AcceleoBridgePlugin.getDefault().getResourceBundle();
		try {
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle.
	 * 
	 * @return the plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		try {
			if (resourceBundle == null)
				resourceBundle = ResourceBundle.getBundle("fr.obeo.acceleo.bridge.AcceleoBridgePluginResources"); //$NON-NLS-1$
		} catch (MissingResourceException x) {
			resourceBundle = null;
		}
		return resourceBundle;
	}

	/**
	 * Plugins to put in the MDR class loader.
	 */
	private static final String[] classLoaderWrappers = { "org.eclipse.ant.core", "org.eclipse.emf.ecore", "org.eclipse.emf.ecore.xmi", "fr.obeo.acceleo.tools", "fr.obeo.acceleo.uml14", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
			"fr.obeo.acceleo.uml13", "fr.obeo.acceleo.bridge", "fr.obeo.acceleo.ecore" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

	/**
	 * Gets the MDR class loader.
	 * 
	 * @return the MDR class loader
	 * @throws MalformedURLException
	 */
	public ClassLoader getMDClassLoader() throws MalformedURLException {
		if (classLoader == null) {
			List URLs = new ArrayList();
			for (int i = 0; i < classLoaderWrappers.length; i++) {
				String id = classLoaderWrappers[i];
				URLs.addAll(Arrays.asList(new PluginClassLoaderWrapper(id).getURLs()));
			}
			String location = new Path(System.getProperty("java.home")).toString() + "/lib/rt.jar"; //$NON-NLS-1$ //$NON-NLS-2$
			if (location.startsWith("/")) { //$NON-NLS-1$
				location = '/' + location;
			}
			URLs.add(new URL("file:/" + location)); //$NON-NLS-1$
			classLoader = new URLClassLoader((URL[]) URLs.toArray(new URL[URLs.size()]), AcceleoBridgePlugin.class.getClassLoader());
		}
		return classLoader;
	}

	private ClassLoader classLoader;

}
