/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.bridge;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jmi.reflect.RefPackage;
import javax.jmi.xmi.MalformedXMIException;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.jaxen.JaxenException;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.netbeans.api.mdr.CreationFailedException;

import fr.obeo.acceleo.ecore.factories.Factories;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.Int2;
import fr.obeo.acceleo.tools.strings.TextSearch;

/**
 * MDR to EMF transformation.
 * 
 * @author www.obeo.fr
 * 
 */
public abstract class AbstractConverter {

	/**
	 * Metamodel EMF nsURI. It is initialized on each class which extends
	 * AbstractConverter.
	 */
	protected String emfURI;

	/**
	 * Metamodel MDR nsURI It is initialized on each class which extends
	 * AbstractConverter
	 */
	protected String mdrURI;

	/**
	 * Metamodel version It is initialized on each class which extends
	 * AbstractConverter
	 */
	protected String umlVersion;

	/**
	 * MDR xmi file location.
	 */
	protected String xmiLocation = ""; //$NON-NLS-1$

	/**
	 * To load and convert a specific XMI file.
	 */
	protected IXmiLoader xmiLoader = null;

	/**
	 * Constructor.
	 * 
	 * @param emfURI
	 *            is the EMF metamodel
	 * @param mdrURI
	 *            is the MDR metamodel
	 * @param umlVersion
	 *            is the UML version
	 */
	public AbstractConverter(String emfURI, String mdrURI, String umlVersion) {
		this.emfURI = emfURI;
		this.mdrURI = getLocation(mdrURI);
		this.umlVersion = umlVersion;
	}

	/**
	 * Loads a MDR xmi file.
	 * 
	 * @param xmiLocation
	 *            is the MDR xmi file location
	 * @param xmiLoader
	 *            is the loader
	 */
	public void loadMdrUml(String xmiLocation, IXmiLoader xmiLoader) {
		if (xmiLocation.startsWith("/")) { //$NON-NLS-1$
			xmiLocation = '/' + xmiLocation;
		}
		this.xmiLocation = xmiLocation;
		this.xmiLoader = xmiLoader;
	}

	/**
	 * Creates an UML model for EMF.
	 * 
	 * @param xmiPath
	 *            is the file to create
	 * @throws FactoryException
	 * @throws ModelReaderException
	 * @throws CoreException
	 */
	public void saveAsEmfUml(String xmiPath) throws FactoryException, ModelReaderException, CoreException {
		ModelReaderException exception = null;
		Factories emfFactories = new Factories(emfURI, AbstractConverter.class.getClassLoader());
		StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
		URI xmiURI = URI.createURI(xmiPath);
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		Resource xmiResource = resourceSet.createResource(xmiURI);
		try {
			EObject root;
			String tmpXmiLocation;
			boolean writeTmpXmi = false;
			Map badStrings = new HashMap();
			if (xmiLoader.hasInputTextChanged() || xmiLoader.hasInputXmlChanged()) {
				tmpXmiLocation = (new Path(xmiLocation)).removeFileExtension().addFileExtension("old").addFileExtension("xmi").toString(); //$NON-NLS-1$ //$NON-NLS-2$
				if (xmiLoader.badStrings() != null && xmiLoader.badStrings().length > 0) {
					try {
						String text = readFile(new File((writeTmpXmi) ? tmpXmiLocation : xmiLocation), true);
						for (int i = 0; i < xmiLoader.badStrings().length; i++) {
							if (TextSearch.getRegexSearch().indexOf(text, xmiLoader.badStrings()[i]).b() > -1) {
								StringBuffer result = new StringBuffer(text);
								Int2[] positions = TextSearch.getRegexSearch().allIndexOf(text, xmiLoader.badStrings()[i]);
								if (positions.length > 0) {
									for (int j = positions.length - 1; j >= 0; j--) {
										String replacementString = "__BAD_STRINGS_" + i + ':' + j + "__"; //$NON-NLS-1$ //$NON-NLS-2$
										badStrings.put(replacementString, result.substring(positions[j].b(), positions[j].e()));
										result.replace(positions[j].b(), positions[j].e(), replacementString);
									}
								}
								text = result.toString();
							}
						}
						Writer writer = new FileWriter(new File(tmpXmiLocation));
						writer.write(text);
						writer.flush();
						writer.close();
						writeTmpXmi = true;
					} catch (Exception e) {
						AcceleoBridgePlugin.getDefault().log(e, false);
					}
				}
				if (xmiLoader.hasInputXmlChanged()) {
					try {
						Element xmlRoot = (new SAXBuilder(false)).build(new File((writeTmpXmi) ? tmpXmiLocation : xmiLocation)).getRootElement();
						xmiLoader.changeInputXml(xmlRoot);
						Writer writer = new FileWriter(new File(tmpXmiLocation));
						XMLOutputter xmlout = new XMLOutputter();
						xmlout.setIndent("   "); //$NON-NLS-1$
						xmlout.setNewlines(true);
						writer.write(xmlout.outputString(xmlRoot));
						writer.flush();
						writer.close();
						writeTmpXmi = true;
					} catch (Exception e) {
						AcceleoBridgePlugin.getDefault().log(e, false);
					}
				}
				if (xmiLoader.hasInputTextChanged()) {
					try {
						String text = readFile(new File((writeTmpXmi) ? tmpXmiLocation : xmiLocation), true);
						text = xmiLoader.changeInputText(text);
						Writer writer = new FileWriter(new File(tmpXmiLocation));
						writer.write(text);
						writer.flush();
						writer.close();
						writeTmpXmi = true;
					} catch (Exception e) {
						AcceleoBridgePlugin.getDefault().log(e, false);
					}
				}
				if (!writeTmpXmi) {
					tmpXmiLocation = xmiLocation;
				}
			} else {
				tmpXmiLocation = xmiLocation;
			}
			try {
				MDRepository repository = new MDRepository(mdrURI);
				RefPackage umlPackage = repository.readModel(tmpXmiLocation, xmiLoader);
				root = mdr2emf(umlPackage, emfFactories, report);
			} finally {
				if (writeTmpXmi) {
					File tmpXmiFile = new File(tmpXmiLocation);
					if (tmpXmiFile.exists()) {
						tmpXmiFile.delete();
					}
				}
			}
			if (root != null) {
				try {
					xmiResource.getContents().add(root);
					Map options = new HashMap();
					options.put(XMLResource.OPTION_ENCODING, System.getProperty("file.encoding")); //$NON-NLS-1$
					xmiResource.save(options);
					xmiResource.unload();
					if (badStrings.size() > 0) {
						try {
							IContainer container = ResourcesPlugin.getWorkspace().getRoot();
							String text = Resources.getFileContent(container.getFile(new Path(xmiPath))).toString();
							Iterator it = badStrings.entrySet().iterator();
							while (it.hasNext()) {
								Map.Entry entry = (Map.Entry) it.next();
								String replacementString = (String) entry.getKey();
								String initialString = (String) entry.getValue();
								text = TextSearch.getDefaultSearch().replaceAllIn(text, replacementString, initialString, 0, text.length(), null);
							}
							Resources.createFile(container, new Path(xmiPath), text, new NullProgressMonitor());
						} catch (Exception e) {
							AcceleoBridgePlugin.getDefault().log(e, false);
						}
					}
				} catch (IOException e) {
					exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), e.getMessage(), }), true); //$NON-NLS-1$
				}
			} else {
				exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveRootFailure", new Object[] { xmiURI.toFileString(), }), true); //$NON-NLS-1$
			}
			// MDRepository.getDefault(UML_MDR_URI).shutdownManager();
		} catch (CreationFailedException cfe) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), cfe.getMessage(), }), true); //$NON-NLS-1$
		} catch (MalformedXMIException mxe) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), mxe.getMessage(), }), true); //$NON-NLS-1$
		} catch (IOException ioe) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), ioe.getMessage(), }), true); //$NON-NLS-1$
		} catch (JaxenException jaxe) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), jaxe.getMessage(), }), true); //$NON-NLS-1$
		} catch (JDOMException jdome) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.SaveFailure", new Object[] { xmiURI.toFileString(), jdome.getMessage(), }), true); //$NON-NLS-1$
		}
		if (exception == null && report.length() > 0) {
			exception = new ModelReaderException(AcceleoBridgeMessages.getString("AbstractConverter.ReaderWarning", new Object[] { xmiPath, }) + ": \n" + report, false); //$NON-NLS-1$ //$NON-NLS-2$
		}
		if (exception != null) {
			throw exception;
		}
	}

	private String readFile(File file, boolean useSystemSeparator) {
		StringBuffer buffer = new StringBuffer();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			try {
				int size = 0;
				char[] buff = new char[512];
				while ((size = in.read(buff)) >= 0) {
					buffer.append(buff, 0, size);
				}
			} finally {
				if (in != null) {
					in.close();
				}
			}
		} catch (IOException exception) {
			throw new RuntimeException(exception);
		}
		return buffer.toString();
	}

	/**
	 * Launchs MDR to EMF transformation.
	 * 
	 * @param umlPackage
	 *            is the mdr package
	 * @param emfFactories
	 *            are the factories use to create the EMF model.
	 * @param report
	 *            is the report
	 * @return the EMF model
	 * @throws FactoryException
	 * @throws CreationFailedException
	 * @throws IOException
	 * @throws MalformedXMIException
	 * @throws JaxenException
	 * @throws JDOMException
	 */
	protected abstract EObject mdr2emf(RefPackage umlPackage, Factories emfFactories, StringBuffer report) throws FactoryException, CreationFailedException, IOException, MalformedXMIException,
			JaxenException, JDOMException;

	/**
	 * Returns the location of the given file in the file system.
	 * 
	 * @return the location of the given file in the file system
	 */
	private String getLocation(String path) {
		try {
			URL installURL = AcceleoBridgePlugin.getDefault().getBundle().getEntry(path);
			return Platform.resolve(installURL).toString();
		} catch (Exception e) {
			return path;
		}
	}

}
