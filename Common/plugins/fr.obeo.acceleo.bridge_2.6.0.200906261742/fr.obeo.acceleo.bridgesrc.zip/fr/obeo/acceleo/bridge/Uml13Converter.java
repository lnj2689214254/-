package fr.obeo.acceleo.bridge;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jmi.reflect.RefEnum;
import javax.jmi.reflect.RefFeatured;
import javax.jmi.reflect.RefPackage;
import javax.jmi.xmi.MalformedXMIException;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.jaxen.JaxenException;
import org.jdom.JDOMException;
import org.netbeans.api.mdr.CreationFailedException;
import org.omg.uml.modelmanagement.Model;
import org.omg.uml.modelmanagement.ModelManagementPackage;

import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.Factories;
import fr.obeo.acceleo.ecore.factories.FactoryException;

/**
 * MDR to EMF transformation for UML13 metamodel.
 */
public class Uml13Converter extends AbstractConverter {

	/**
	 * Constructor.
	 */
	public Uml13Converter() {
		super("http://www.obeo.fr/acceleo/uml13", "/model/01-12-02_Diff.xml", "1.3"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	}

	/* (non-Javadoc) */
	protected EObject mdr2emf(RefPackage umlPackage, Factories emfFactories, StringBuffer report) throws FactoryException, CreationFailedException, IOException, MalformedXMIException, JaxenException,
			JDOMException {
		ModelManagementPackage modelManagementPackage = ((org.netbeans.jmi.uml.UmlPackage) umlPackage).getModelManagement();
		Model model = null;
		Iterator it = modelManagementPackage.getModel().refAllOfType().iterator();
		while (model == null && it.hasNext()) {
			Object object = it.next();
			if (object instanceof Model && ((Model) object).refImmediateComposite() == null) {
				model = (Model) object;
			}
		}
		if (model != null) {
			EObject emfRoot = mdr2emfCreateObjects(model, emfFactories, report, 0);
			mdr2emfFeatures(model, emfRoot, report);
			mdr2emf.clear();
			return emfRoot;
		} else {
			return null;
		}
	}

	private EObject mdr2emfCreateObjects(RefFeatured mdrParent, Factories emfFactories, StringBuffer report, int level) throws FactoryException {
		EObject emfParent = (EObject) mdr2emf.get(mdrParent);
		if (emfParent == null) {
			String metaObjectName = (String) mdrParent.refMetaObject().refGetValue("name"); //$NON-NLS-1$
			emfParent = emfFactories.create(metaObjectName);
			Iterator it = emfParent.eClass().getEAllReferences().iterator();
			while (it.hasNext()) {
				EReference eReference = (EReference) it.next();
				if (eReference.isContainment() && !eReference.getName().equals("taggedValue") && !eReference.getName().equals("stereotype")) { //$NON-NLS-1$ //$NON-NLS-2$
					Object mdrObject = mdrParent.refGetValue(eReference.getName());
					if (mdrObject != null) {
						if (mdrObject instanceof Collection) {
							for (Iterator i = ((Collection) mdrObject).iterator(); i.hasNext();) {
								RefFeatured mdrChild = (RefFeatured) i.next();
								EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report, level++);
								EFactory.eAdd(emfParent, eReference.getName(), emfChild);
							}
						} else if (mdrObject instanceof Object[]) {
							Object[] tab = (Object[]) mdrObject;
							for (int i = 0; i < tab.length; i++) {
								RefFeatured mdrChild = (RefFeatured) tab[i];
								EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report, level++);
								EFactory.eAdd(emfParent, eReference.getName(), emfChild);
							}
						} else if (mdrObject instanceof RefFeatured) {
							RefFeatured mdrChild = (RefFeatured) mdrObject;
							EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report, level++);
							EFactory.eSet(emfParent, eReference.getName(), emfChild);
						} else {
							report.append(AcceleoBridgeMessages.getString("TransformationUnknownType", new Object[] { mdrObject.getClass().getName(), })); //$NON-NLS-1$
							report.append('\n');
						}
					}
				}
			}
			mdr2emf.put(mdrParent, emfParent);
		}
		return emfParent;
	}

	private Map mdr2emf = new HashMap();

	private void mdr2emfFeatures(RefFeatured mdrParent, EObject emfParent, StringBuffer report) throws FactoryException {
		// Attributes
		Iterator it = emfParent.eClass().getEAllAttributes().iterator();
		while (it.hasNext()) {
			EAttribute eAttribute = (EAttribute) it.next();
			mdr2emfFeature(mdrParent, emfParent, eAttribute, report);
		}
		// References
		it = emfParent.eClass().getEAllReferences().iterator();
		while (it.hasNext()) {
			EReference eReference = (EReference) it.next();
			if (!eReference.getName().equals("taggedValue") && !eReference.getName().equals("stereotype")) { //$NON-NLS-1$ //$NON-NLS-2$
				if (!eReference.isContainment()) {
					mdr2emfFeature(mdrParent, emfParent, eReference, report);
				} else {
					Object mdrObject = mdrParent.refGetValue(eReference.getName());
					if (mdrObject != null) {
						if (mdrObject instanceof Collection) {
							for (Iterator i = ((Collection) mdrObject).iterator(); i.hasNext();) {
								RefFeatured mdrChild = (RefFeatured) i.next();
								EObject emfChild = (EObject) mdr2emf.get(mdrChild);
								mdr2emfFeatures(mdrChild, emfChild, report);
							}
						} else if (mdrObject instanceof Object[]) {
							Object[] tab = (Object[]) mdrObject;
							for (int i = 0; i < tab.length; i++) {
								RefFeatured mdrChild = (RefFeatured) tab[i];
								EObject emfChild = (EObject) mdr2emf.get(mdrChild);
								mdr2emfFeatures(mdrChild, emfChild, report);
							}
						} else if (mdrObject instanceof RefFeatured) {
							RefFeatured mdrChild = (RefFeatured) mdrObject;
							EObject emfChild = (EObject) mdr2emf.get(mdrChild);
							mdr2emfFeatures(mdrChild, emfChild, report);
						} else {
							report.append(AcceleoBridgeMessages.getString("TransformationUnknownType", new Object[] { mdrObject.getClass().getName(), })); //$NON-NLS-1$
							report.append('\n');
						}
					}
				}
			}
		}
	}

	private void mdr2emfFeature(RefFeatured mdrParent, EObject emfParent, EStructuralFeature feature, StringBuffer report) throws FactoryException {
		Object mdrChild;
		try {
			mdrChild = mdrParent.refGetValue(feature.getName());
		} catch (Exception e) {
			mdrChild = null;
		}
		mdr2emfFeature(mdrChild, mdrParent, emfParent, feature, report);
	}

	private void mdr2emfFeature(Object mdrChild, RefFeatured mdrParent, EObject emfParent, EStructuralFeature feature, StringBuffer report) throws FactoryException {
		if (mdrChild != null) {
			if (mdrChild instanceof Collection) {
				for (Iterator it = ((Collection) mdrChild).iterator(); it.hasNext();) {
					mdr2emfFeature(it.next(), mdrParent, emfParent, feature, report);
				}
			} else if (mdrChild instanceof Object[]) {
				Object[] tab = (Object[]) mdrChild;
				for (int i = 0; i < tab.length; i++) {
					mdr2emfFeature(tab[i], mdrParent, emfParent, feature, report);
				}
			} else if (mdrChild instanceof RefFeatured) {
				EObject emfChild = (EObject) mdr2emf.get(mdrChild);
				EFactory.eAdd(emfParent, feature.getName(), emfChild);
			} else if (mdrChild instanceof Integer) {
				EFactory.eAdd(emfParent, feature.getName(), new Long(((Integer) mdrChild).longValue()));
			} else if (mdrChild instanceof String || mdrChild instanceof Long || mdrChild instanceof Double || mdrChild instanceof Boolean) {
				EFactory.eAdd(emfParent, feature.getName(), mdrChild);
			} else if (mdrChild instanceof RefEnum) {
				RefEnum refEnum = (RefEnum) mdrChild;
				EFactory.eSet(emfParent, feature.getName(), refEnum.toString(), AcceleoBridgePlugin.class.getClassLoader());
			} else {
				report.append(AcceleoBridgeMessages.getString("TransformationUnknownType", new Object[] { mdrChild.getClass().getName(), })); //$NON-NLS-1$
				report.append('\n');
			}
		}
	}

}
