/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMIResource;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import com.bea.xml.stream.AttributeBase;
import com.bea.xml.stream.NamespaceBase;
import com.bea.xml.stream.events.CharactersEvent;
import com.bea.xml.stream.events.EndElementEvent;
import com.bea.xml.stream.events.StartElementEvent;

import fr.obeo.acceleo.bridge.AcceleoBridgePlugin;

/**
 * This is a to fix up the UML 2.0 XMI that is produced by Enterprise Architect
 * 7.1
 * 
 * @author www.obeo.fr
 * 
 */
public class FixUml20EAXMI {

	// path of container
	private String containerPath = "";

	// Comments are contained in Extension part. New comment tags will be
	// associated to elements
	private final Map comments = new HashMap();

	// schemaLocationAttribute is removed by EMF loading/saving,
	// this attribute containing schemaLocationAttribute value will be added in
	// a post EMF process
	private String schemaLocationAttribute = "";

	private final QName QN_NAME = new QName("name");

	private final QName QN_KEY = new QName("key");

	private final QName QN_VALUE = new QName("value");

	private final QName QN_HREF = new QName("href");

	private final QName QN_TYPE = new QName("type");

	private final QName QN_DOCUMENTATION = new QName("documentation");

	private final QName QN_OWNED_COMMENT = new QName("ownedComment");

	private final QName QN_UPPER_VALUE = new QName("upperValue");

	private final QName QN_EANNOTATIONS = new QName("eAnnotations");

	private final QName QN_CONTENTS = new QName("contents");

	private final QName QN_SOURCE = new QName("source");

	private final QName QN_XMIID = new QName("xmi:id");

	private final QName QN_XMITYPE = new QName("xmi:type");

	private final QName QN_QUAL_ID = new QName("http://schema.omg.org/spec/XMI/2.1", "id");

	private final QName QN_QUAL_IDREF = new QName("http://schema.omg.org/spec/XMI/2.1", "idref");

	private final QName QN_QUAL_TYPE = new QName("http://schema.omg.org/spec/XMI/2.1", "type");
	
	private final QName QN_SUPPLIER = new QName("supplier");

	// These maps will be used to "re-structure" links between Port and
	// Interface in a component diagram
	private final Map portToInterface = new HashMap();

	private final Map interfaceToClass = new HashMap();

	private final Map classToRealization = new HashMap();

	/**
	 * Map of (String, String) that will contain xmi:id as keys and xmi:idref as
	 * values for the type of ownedEnds that EA exports as children of the
	 * ownedEnd instead of attributes.
	 */
	private final Map mapOfOwnedEndTypes = new HashMap();

	/**
	 * Map that will contain a <strong>List</strong> of the notes associated to
	 * a given tagged value, by id of the stereotyped element.
	 */
	private final Map notesMap = new HashMap();

	/**
	 * List of String, each String being the xmi:id of an Operation that is
	 * marked as returning an array.
	 */
	private final List methodsThatReturnArray = new ArrayList();

	/**
	 * List of valid types found in the model. Since EA exports associations
	 * with types pointing to non-type elements, this list is useful to filter
	 * illegal associations. Valid types are : Class, Interface, DataType,
	 * Enumeration, PrimitiveType.
	 */
	private final List validTypes = new ArrayList(1024);

	/**
	 * Constant that represents the list of valid UML21 Types.
	 */
	private static final List VALID_UML21_TYPES = Collections.unmodifiableList(Arrays.asList(new String[] { "uml:Class", "uml:Interface", "uml:DataType", "uml:Enumeration", "uml:PrimitiveType" }));

	/**
	 * Represents the key/value pair that will be stored for a tagged value
	 * note. The key matches the tag's name, tha value matches the note.
	 * 
	 * @author ldelaigue
	 * 
	 */
	private static class TagNote {
		public String xmiId;

		public String key;

		public String value;

		public TagNote(String aXmiId, String aKey, String aValue) {
			xmiId = aXmiId;
			key = aKey;
			value = aValue;
		}
	}

	/**
	 * Regex pattern used to find certain internal ids that EA uses for some
	 * obscure reason.
	 */
	private static final Pattern CLT_PATTERN = Pattern.compile("\\$CLT=(\\{[a-zA-Z0-9\\-\\_]*\\})\\$CLT");

	/**
	 * Regex pattern that matches tagged values that represent in fact
	 * references to other objects. EA should export the profile correctly and
	 * use the stereotype application xmiId, but it does not.
	 */
	private static final Pattern TAGGED_VALUE_PATTERN = Pattern.compile("\\{[a-zA-Z0-9\\-\\_]*\\}[\\s?,\\s?\\{[a-zA-Z0-9\\-\\_]*\\}]*");

	private static final Pattern TAGGED_VALUE_ID_PATTERN = Pattern.compile("(\\{[a-zA-Z0-9\\-\\_]*\\})");

	/**
	 * Map that will contain the xmi ids that correspond to internal EA ids,
	 * that we call here "cltId".
	 */
	private final Map xmiIdBycltId = new HashMap();

	public FixUml20EAXMI(String containerPath) {
		this.containerPath = containerPath;
	}

	/**
	 * Inner class to record profile structure in order to add missing data in
	 * the generated UML file
	 */
	private class ProfileData {

		public String profileName;

		public String nsUri;

		public String nsPrefix;

		public List stereotypeDatas = new ArrayList();

		public ProfileData(String profileName, String nsUri, String nsPrefix) {
			this.profileName = profileName;
			this.nsUri = nsUri;
			this.nsPrefix = nsPrefix;
		}

		public void addStereotype(StereotypeData s) {
			stereotypeDatas.add(s);
		}
	}

	/**
	 * Inner class to record stereotype structure in order to add missing data
	 * in the generated UML file
	 */
	private class StereotypeData {

		public String stereotypeName;

		public String stereotypeId;

		public List taggedValueDatas = new ArrayList();

		public StereotypeData(String stereotypeName, String stereotypeId) {
			this.stereotypeName = stereotypeName;
			this.stereotypeId = stereotypeId;
		}

		public void addTaggedValue(TaggedValueData t) {
			taggedValueDatas.add(t);
		}
	}

	/**
	 * Inner class to record tagged value structure in order to add missing data
	 * in the generated UML file
	 */
	private class TaggedValueData {
		public String taggedValueName;

		public String taggedValueType;

		public String taggedValueHref;

		public String taggedValueIdref;

		public TaggedValueData(String taggedValueName, String taggedValueType, String taggedValueHref, String taggedValueIdref) {
			this.taggedValueName = taggedValueName;
			this.taggedValueType = taggedValueType;
			this.taggedValueHref = taggedValueHref;
			this.taggedValueIdref = taggedValueIdref;
		}
	}

	/**
	 * After a first parsing where profile structures were extracted. This
	 * method should be launched on each extracted profile to add missing data.
	 * 
	 * @param p
	 *            profile structure containing extracted information from first
	 *            parsing
	 * @param writer
	 * @throws XMLStreamException
	 */
	public void createEAnnotationsProfile(ProfileData p, XMLEventWriter writer) throws XMLStreamException {
		writer.add(new CharactersEvent("\n"));
		final StartElementEvent startEventEAnnotations = new StartElementEvent(QN_EANNOTATIONS);
		startEventEAnnotations.addAttribute(new AttributeBase(QN_XMIID, "__GENERATED_ID_Anno_" + p.profileName + "__"));
		startEventEAnnotations.addAttribute(new AttributeBase(QN_SOURCE, "http://www.eclipse.org/uml2/2.0.0/UML"));
		writer.add(startEventEAnnotations);
		writer.add(new CharactersEvent("\n"));
		final StartElementEvent startEventContents = new StartElementEvent(QN_CONTENTS);
		startEventContents.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EPackage"));
		startEventContents.addAttribute(new AttributeBase(QN_XMIID, "__GENERATED_ID_Profile_" + p.profileName + "__"));
		startEventContents.addAttribute(new AttributeBase(QN_NAME, p.profileName));
		startEventContents.addAttribute(new AttributeBase(new QName("nsURI"), p.nsUri));
		startEventContents.addAttribute(new AttributeBase(new QName("nsPrefix"), p.nsPrefix));
		writer.add(startEventContents);
		writer.add(new CharactersEvent("\n"));
		for (final Iterator it = p.stereotypeDatas.iterator(); it.hasNext();) {
			final StereotypeData sd = (StereotypeData) it.next();
			final StartElementEvent startEventEClassifiers = new StartElementEvent(new QName("eClassifiers"));
			startEventEClassifiers.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EClass"));
			startEventEClassifiers.addAttribute(new AttributeBase(QN_XMIID, "__GENERATEDID_" + p.profileName + "_" + sd.stereotypeName + "__"));
			startEventEClassifiers.addAttribute(new AttributeBase(QN_NAME, sd.stereotypeName));
			writer.add(startEventEClassifiers);
			writer.add(new CharactersEvent("\n"));
			final StartElementEvent startEventEAnnotationsStereotype = new StartElementEvent(QN_EANNOTATIONS);
			startEventEAnnotationsStereotype.addAttribute(new AttributeBase(QN_XMIID, "__GENERATEDID_" + p.profileName + "_" + sd.stereotypeName + "Annotation__"));
			startEventEAnnotationsStereotype.addAttribute(new AttributeBase(QN_SOURCE, "http://www.eclipse.org/uml2/2.0.0/UML"));
			startEventEAnnotationsStereotype.addAttribute(new AttributeBase(new QName("references"), sd.stereotypeId));
			writer.add(startEventEAnnotationsStereotype);
			writer.add(new EndElementEvent(QN_EANNOTATIONS));
			writer.add(new CharactersEvent("\n"));
			for (final Iterator it2 = sd.taggedValueDatas.iterator(); it2.hasNext();) {
				final TaggedValueData tvd = (TaggedValueData) it2.next();
				final StartElementEvent startEventEStructuralFeatures = new StartElementEvent(new QName("eStructuralFeatures"));
				if (!tvd.taggedValueType.equals("") && (tvd.taggedValueType.equals("uml:PrimitiveType"))) {
					startEventEStructuralFeatures.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EAttribute"));
				} else {
					startEventEStructuralFeatures.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EReference"));
				}
				startEventEStructuralFeatures.addAttribute(new AttributeBase(QN_XMIID, "__GENERATEDID_" + p.profileName + "_" + sd.stereotypeName + "_" + tvd.taggedValueName + "__"));
				startEventEStructuralFeatures.addAttribute(new AttributeBase(QN_NAME, tvd.taggedValueName));
				startEventEStructuralFeatures.addAttribute(new AttributeBase(new QName("ordered"), "false"));
				startEventEStructuralFeatures.addAttribute(new AttributeBase(new QName("lowerBound"), "1"));
				writer.add(startEventEStructuralFeatures);
				writer.add(new CharactersEvent("\n"));
				final StartElementEvent startEventType = new StartElementEvent(new QName("eType"));

				if (!tvd.taggedValueType.equals("")) {
					if (tvd.taggedValueType.equals("uml:PrimitiveType")) {
						startEventType.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EDataType"));
					} else {
						startEventType.addAttribute(new AttributeBase(QN_XMITYPE, "ecore:EClass"));
					}
				}
				if (!tvd.taggedValueHref.equals("")) {
					if (tvd.taggedValueHref.startsWith("pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#")) {
						startEventType.addAttribute(new AttributeBase(QN_HREF, tvd.taggedValueHref.replaceAll("pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#",
								"http://www.eclipse.org/emf/2002/Ecore#//E")));
					} else {
						startEventType.addAttribute(new AttributeBase(QN_HREF, tvd.taggedValueHref
								.replaceAll("pathmap://UML_METAMODELS/UML.metamodel.uml#", "http://www.eclipse.org/uml2/2.1.0/UML#//")));
					}
				} else if (!tvd.taggedValueIdref.equals("")) {
					startEventType.addAttribute(new AttributeBase(QN_HREF, tvd.taggedValueIdref));
				}
				if ((!tvd.taggedValueType.equals("")) || (!tvd.taggedValueHref.equals("")) || (!tvd.taggedValueIdref.equals(""))) {
					writer.add(startEventType);
					writer.add(new EndElementEvent(new QName("eType")));
				}
				writer.add(new CharactersEvent("\n"));
				writer.add(new EndElementEvent(new QName("eStructuralFeatures")));
				writer.add(new CharactersEvent("\n"));
			}
			writer.add(new EndElementEvent(new QName("eClassifiers")));
			writer.add(new CharactersEvent("\n"));
		}
		writer.add(new EndElementEvent(QN_CONTENTS));
		writer.add(new CharactersEvent("\n"));
		writer.add(new EndElementEvent(QN_EANNOTATIONS));
		writer.add(new CharactersEvent("\n"));
		final StartElementEvent startEventElementImport = new StartElementEvent(new QName("elementImport"));
		startEventElementImport.addAttribute(new AttributeBase(QN_XMIID, "__METACLASS_ID_" + p.profileName + "__"));
		writer.add(startEventElementImport);
		writer.add(new CharactersEvent("\n"));
		final StartElementEvent startEventImportedElement = new StartElementEvent(new QName("importedElement"));
		startEventImportedElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:Class"));
		startEventImportedElement.addAttribute(new AttributeBase(QN_HREF, "pathmap://UML_METAMODELS/UML.metamodel.uml#Element"));
		writer.add(startEventImportedElement);
		writer.add(new EndElementEvent(QN_EANNOTATIONS));
		writer.add(new CharactersEvent("\n"));
		writer.add(new EndElementEvent(new QName("elementImport")));
		writer.add(new CharactersEvent("\n"));
	}

	/**
	 * Replace an attribute by an other in a given list
	 * 
	 * @param baseList
	 *            the given List
	 * @param oldAttr
	 *            the old attribute
	 * @param newAttr
	 *            the attribute which will replace oldAttr
	 * @return the List with the replaced attribute
	 */
	private List replaceAttribute(Iterator baseList, Attribute oldAttr, AttributeBase newAttr) {
		final ArrayList res = new ArrayList();
		res.add(newAttr);
		while (baseList.hasNext()) {
			final Attribute attr = (Attribute) baseList.next();
			if (!attr.equals(oldAttr)) {
				res.add(attr);
			}
		}
		return res;
	}

	/**
	 * Return the list of attributes for an XML start element
	 * 
	 * @param baseList
	 * @return the list of attributes from an XML start element
	 */
	private List getAttributes(Iterator baseList) {
		final ArrayList res = new ArrayList();
		while (baseList.hasNext()) {
			final Attribute attr = (Attribute) baseList.next();
			res.add(attr);
		}
		return res;
	}

	/**
	 * This method fixes type value to the Eclipse UML2 good value
	 * 
	 * @param baseEvent
	 * @return the XML element with fixed type value
	 * @throws XMLStreamException
	 */
	private StartElementEvent fixType(StartElement baseEvent) throws XMLStreamException {
		final StartElementEvent currentStartElement = new StartElementEvent(baseEvent.asStartElement());
		final Attribute href = currentStartElement.getAttributeByName(QN_HREF);
		if (href != null) {
			if (href.getValue().equals("http://schema.omg.org/spec/UML/2.1/uml.xml#String") || href.getValue().equals("http://schema.omg.org/spec/UML/2.1/#String")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), href,
						new AttributeBase(QN_HREF, "pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#String")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (href.getValue().equals("http://schema.omg.org/spec/UML/2.1/uml.xml#Integer") || href.getValue().equals("http://schema.omg.org/spec/UML/2.1/#Integer")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), href, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#Integer")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (href.getValue().equals("http://schema.omg.org/spec/UML/2.1/uml.xml#Boolean") || href.getValue().equals("http://schema.omg.org/spec/UML/2.1/#Boolean")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), href, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#Boolean")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (href.getValue().equals("http://schema.omg.org/spec/UML/2.1/uml.xml#UnlimitedNatural") || href.getValue().equals("http://schema.omg.org/spec/UML/2.1/#UnlimitedNatural")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), href, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#UnlimitedNatural")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else {
				final String tmpHrefValue = href.getValue().replaceAll("uml.xml", "");
				final String currentClassType = tmpHrefValue.replaceAll("http://schema.omg.org/spec/UML/2.1/#", "");
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), href, new AttributeBase(QN_HREF, "pathmap://UML_METAMODELS/UML.metamodel.uml#"
						+ currentClassType)));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:Class"));
			}
		}
		final Attribute idref = currentStartElement.getAttributeByName(QN_QUAL_IDREF);
		if (idref != null) {
			if (idref.getValue().toUpperCase().equals("EAJAVA_STRING") || idref.getValue().toUpperCase().equals("EA_STRING")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), idref, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#String")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (idref.getValue().toUpperCase().equals("EAJAVA_INTEGER") || idref.getValue().toUpperCase().equals("EA_INTEGER") || idref.getValue().toUpperCase().equals("EAJAVA_INT")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), idref, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#Integer")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (idref.getValue().toUpperCase().equals("EAJAVA_BOOLEAN") || idref.getValue().toUpperCase().equals("EA_BOOLEAN")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), idref, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#Boolean")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (idref.getValue().toUpperCase().equals("EAJAVA_UNLIMITEDNATURAL") || idref.getValue().toUpperCase().equals("EA_UNLIMITEDNATURAL")
					|| idref.getValue().toUpperCase().equals("EAJAVA_FLOAT")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), idref, new AttributeBase(QN_HREF,
						"pathmap://UML_LIBRARIES/UMLPrimitiveTypes.library.uml#UnlimitedNatural")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			} else if (idref.getValue().toUpperCase().equals("EAJAVA_DATE")) {
				currentStartElement.setAttributes(replaceAttribute(currentStartElement.getAttributes(), idref, new AttributeBase(QN_HREF, "pathmap://UML_METAMODELS/Ecore.metamodel.uml#EDate")));
				currentStartElement.addAttribute(new AttributeBase(QN_XMITYPE, "uml:PrimitiveType"));
			}
		}
		return currentStartElement;
	}

	/**
	 * Remove an attribute by an other in a given list
	 * 
	 * @param baseList
	 *            the given List
	 * @param oldAttr
	 *            the attribute to remove
	 * @return the List without the removed attribute
	 */
	private List removeAttribute(Iterator baseList, Attribute oldAttr) {
		final ArrayList res = new ArrayList();
		while (baseList.hasNext()) {
			final Attribute attr = (Attribute) baseList.next();
			if (!attr.equals(oldAttr)) {
				res.add(attr);
			}
		}
		return res;
	}

	/**
	 * This method removes attributes
	 * 
	 * @param baseEvent
	 *            the last read event.
	 * @param reader
	 *            the XML input reader.
	 * @param writer
	 *            the XML output writer.
	 * @throws XMLStreamException
	 */
	private void removeAttributes(StartElementEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, String[] attributesToRemove) throws XMLStreamException {
		final Attribute[] attributesArray = new Attribute[attributesToRemove.length];
		for (int i = 0; i < attributesArray.length; i++) {
			attributesArray[i] = baseEvent.getAttributeByName(new QName(attributesToRemove[i]));
		}
		final StartElementEvent newSe = new StartElementEvent(baseEvent);

		for (int i = 0; i < attributesArray.length; i++) {
			if (attributesArray[i] != null) {
				newSe.setAttributes(removeAttribute(newSe.getAttributes(), attributesArray[i]));
			}
		}

		baseEvent = newSe;
		writer.add(baseEvent);
	}

	/**
	 * Remove subelement
	 * 
	 * @param reader
	 *            the XML input reader.
	 * @param writer
	 *            the XML output writer.
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	private void removeSubElement(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, String callingElement, String elementToRemove) throws XMLStreamException {
		writer.add(baseEvent);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String name = se.getName().getLocalPart();
				if (name.equals(elementToRemove)) {
					// Management of type removed as a child but added as an
					// attribute on baseEvent
					if ("type".equals(elementToRemove)) {
						final Attribute currentXmiIdAttr = baseEvent.asStartElement().getAttributeByName(QN_QUAL_ID);
						final Attribute typeIdRef = se.getAttributeByName(QN_QUAL_IDREF);
						if (currentXmiIdAttr != null && typeIdRef != null) {
							mapOfOwnedEndTypes.put(currentXmiIdAttr.getValue(), typeIdRef.getValue());
						}
					}
					removeElement(event, reader);
				} else {
					removeSubElement(event, reader, writer, callingElement, elementToRemove);
				}
				event = null;
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			// writes the output event (modified or not)
			if (event != null) {
				writer.add(event);
			}
		}
	}

	/**
	 * Remove subelements
	 * 
	 * @param reader
	 *            the XML input reader.
	 * @param writer
	 *            the XML output writer.
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	private void removeSubElements(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, String callingElement, List elementsToRemove) throws XMLStreamException {
		writer.add(baseEvent);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String name = se.getName().getLocalPart();
				if (elementsToRemove.contains(name)) {
					// Management of type removed as a child but added as an
					// attribute on baseEvent
					if (elementsToRemove.contains("type")) {
						final Attribute currentXmiIdAttr = baseEvent.asStartElement().getAttributeByName(QN_QUAL_ID);
						final Attribute typeIdRef = se.getAttributeByName(QN_QUAL_IDREF);
						if (currentXmiIdAttr != null && typeIdRef != null) {
							mapOfOwnedEndTypes.put(currentXmiIdAttr.getValue(), typeIdRef.getValue());
						}
					}
					removeElement(event, reader);
				} else {
					removeSubElements(event, reader, writer, callingElement, elementsToRemove);
				}
				event = null;
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			// writes the output event (modified or not)
			if (event != null) {
				writer.add(event);
			}
		}
	}

	/**
	 * Remove element
	 * 
	 * @param baseEvent
	 * @param reader
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	private void removeElement(XMLEvent baseEvent, XMLEventReader reader) throws XMLStreamException {
		boolean fixing = true;
		while (fixing) {
			final XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				removeElement(event, reader);
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}
		}
	}

	/**
	 * Read and record current element and sub-elements without specific
	 * processing
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param writer
	 * @throws XMLStreamException
	 */
	private void readAndRecordElement(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer) throws XMLStreamException {
		writer.add(baseEvent);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String currentElementName = se.getName().getLocalPart();
				if (currentElementName.equals("type")) {
					event = fixType(se);
				}

				readAndRecordElement(event, reader, writer);
				event = null;
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			if (event != null) {
				writer.add(event);
			}
		}
	}

	/**
	 * Fix problem where EnterpriseArchitect does not give a type for
	 * LiteralString default value. This method adds LiteralString type when a
	 * default value has no type.
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param writer
	 * @throws XMLStreamException
	 */
	private void fixDefaultValue(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer) throws XMLStreamException {
		final StartElementEvent se = new StartElementEvent(baseEvent.asStartElement());
		final Attribute type = se.getAttributeByName(QN_QUAL_TYPE);
		if (type == null) {
			se.addAttribute(new AttributeBase(QN_XMITYPE, "uml:LiteralString"));
		}
		baseEvent = se;
		writer.add(baseEvent);
	}

	/**
	 * Record tagged value structure These method is used in the UML Profile
	 * "refactoring" step
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param writer
	 * @param sd
	 * @throws XMLStreamException
	 */
	private void recordTaggedValueStructure(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, StereotypeData sd) throws XMLStreamException {
		final StartElement se2 = baseEvent.asStartElement();
		final Attribute ca2 = se2.getAttributeByName(QN_NAME);
		if (ca2 != null) {
			writer.add(baseEvent);
			final String taggedValueName = ca2.getValue();
			final TaggedValueData tvd = new TaggedValueData(taggedValueName, "", "", "");
			boolean fixing = true;
			while (fixing) {
				XMLEvent event = (XMLEvent) reader.next();

				switch (event.getEventType()) {

				case XMLEvent.START_ELEMENT:
					StartElement se = event.asStartElement();
					final String currentElementName = se.getName().getLocalPart();
					if (currentElementName.equals("type")) {
						se = fixType(event.asStartElement());
						Attribute ca3 = se.getAttributeByName(QN_HREF);
						if (ca3 != null) {
							tvd.taggedValueHref = ca3.getValue();
						} else {
							ca3 = se.getAttributeByName(QN_QUAL_IDREF);
							if (ca3 != null) {
								tvd.taggedValueIdref = ca3.getValue();
							}
						}
						final Attribute caType = se.getAttributeByName(QN_XMITYPE);
						if (caType != null) {
							tvd.taggedValueType = caType.getValue();
						}
						event = se;
					}
					break;
				case XMLEvent.END_ELEMENT:
					final EndElement ee = event.asEndElement();
					final String currentElementNamee = ee.getName().getLocalPart();
					if (currentElementNamee.equals("ownedAttribute")) {
						fixing = false;
					}
					break;
				default:
					break;
				}

				if (event != null) {
					writer.add(event);
				}
			}
			sd.addTaggedValue(tvd);
		} else {
			readAndRecordElement(baseEvent, reader, writer);
		}
	}

	/**
	 * Record stereotype structure These method is used in the UML Profile
	 * "refactoring" step
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param writer
	 * @param currentProfile
	 * @throws XMLStreamException
	 */
	private void recordStereotypeStructure(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, ProfileData currentProfile) throws XMLStreamException {
		writer.add(baseEvent);

		final StartElement se = baseEvent.asStartElement();
		final Attribute aname = se.getAttributeByName(QN_NAME);
		final String stereotypeName = aname.getValue();
		final Attribute aid = se.getAttributeByName(QN_QUAL_ID);
		final String stereotypeId = aid.getValue();
		final StereotypeData sd = new StereotypeData(stereotypeName, stereotypeId);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se2 = event.asStartElement();
				final Attribute ca2 = se2.getAttributeByName(QN_QUAL_TYPE);
				if (ca2.getValue().equals("uml:Property")) {
					recordTaggedValueStructure(event, reader, writer, sd);
					event = null;
				} else {
					readAndRecordElement(event, reader, writer);
					event = null;
				}
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			if (event != null) {
				writer.add(event);
			}
		}
		currentProfile.addStereotype(sd);
	}

	/**
	 * Record profile structure and extract profile from UML model into a new
	 * UML file containing only the current profile These method is used in the
	 * UML Profile "refactoring" step
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param filePath
	 * @param profiles
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	private void recordProfileStructure(XMLEvent baseEvent, XMLEventReader reader, String filePath, List profiles) throws XMLStreamException, IOException {

		final StartElement se = baseEvent.asStartElement();
		final Attribute ca = se.getAttributeByName(QN_NAME);
		final String profileName = ca.getValue();

		final FileWriter fw = new FileWriter(containerPath + profileName + ".profile.uml");
		final XMLEventWriter writer = XMLOutputFactory.newInstance().createXMLEventWriter(fw);

		final ProfileData currentProfile = new ProfileData(profileName, profileName, profileName);
		final StartElementEvent newSe = new StartElementEvent(baseEvent.asStartElement());
		newSe.setName(new QName("uml:Profile"));
		newSe.addAttribute(new AttributeBase(new QName("metaclassReference"), "__METACLASS_ID_" + profileName + "__"));

		boolean xmiNsExist = false;
		boolean umlNsExist = false;
		boolean ecoreNsExist = false;

		for (final Iterator it = newSe.getNamespaces(); it.hasNext();) {
			final Namespace n = (Namespace) it.next();
			if ("http://schema.omg.org/spec/XMI/2.1".equals(n.getNamespaceURI())) {
				xmiNsExist = true;
			}
			if ("http://www.eclipse.org/uml2/2.1.0/UML".equals(n.getNamespaceURI())) {
				umlNsExist = true;
			}
			if ("http://www.eclipse.org/uml2/2.0.0/UML".equals(n.getNamespaceURI())) {
				umlNsExist = true;
			}
			if ("http://www.eclipse.org/emf/2002/Ecore".equals(n.getNamespaceURI())) {
				ecoreNsExist = true;
			}
		}

		if (!xmiNsExist) {
			newSe.addAttribute(new AttributeBase(new QName("xmlns:xmi"), "http://schema.omg.org/spec/XMI/2.1"));
		}
		if (!umlNsExist) {
			newSe.addAttribute(new AttributeBase(new QName("xmlns:uml"), "http://www.eclipse.org/uml2/2.1.0/UML"));
		}
		if (!ecoreNsExist) {
			newSe.addAttribute(new AttributeBase(new QName("xmlns:ecore"), "http://www.eclipse.org/emf/2002/Ecore"));
		}

		baseEvent = newSe;
		writer.add(baseEvent);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se2 = event.asStartElement();
				final Attribute ca2 = se2.getAttributeByName(QN_QUAL_TYPE);
				if (ca2 != null && ca2.getValue().equals("uml:Stereotype")) {
					recordStereotypeStructure(event, reader, writer, currentProfile);
					event = null;
				} else {
					readAndRecordElement(event, reader, writer);
					event = null;
				}
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				createEAnnotationsProfile(currentProfile, writer);
				writer.add(new EndElementEvent(new QName("uml:Profile")));
				event = null;
				break;
			default:
				break;
			}

			if (event != null) {
				writer.add(event);
			}
		}
		writer.close();
		fw.close();

		profiles.add(currentProfile);
	}

	/**
	 * Comments are contained in the Extension part of the document. Comments
	 * should be extracted. In a second step, each comment should be associated
	 * to its model element.
	 * 
	 * This method populate a map (xmi:id commented model element, comment
	 * text).
	 * 
	 * @param baseEvent
	 * @param reader
	 * @param writer
	 * @param idref
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	private void manageExtensionSection(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer, String idref) throws XMLStreamException, IOException {
		writer.add(baseEvent);
		boolean fixing = true;
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String currentElementName = se.getName().getLocalPart();
				// return type multiplicity for operations
				if ("type".equals(currentElementName)) {
					// EA exports these as an attribute "returnarray" in the
					// extension part...
					final Attribute returnArrayAttr = se.getAttributeByName(new QName("returnarray"));
					if (returnArrayAttr != null && "1".equals(returnArrayAttr.getValue())) {
						methodsThatReturnArray.add(idref);
					}
				} else if ("xrefs".equals(currentElementName)) {
					// Management of some stereotype application's attributes
					final Attribute valueAttr = se.getAttributeByName(QN_VALUE);
					if (valueAttr != null) {
						final String value = valueAttr.getValue();
						if (value != null && value.length() > 0) {
							// This variable "m" must be local since the current
							// method is called recursively
							final Matcher m = CLT_PATTERN.matcher(valueAttr.getValue());
							if (m.find()) {
								final String idToAdd = m.group(1);// Storing
								// the
								// bracketed part
								xmiIdBycltId.put(idToAdd, idref);
							}
						}
					}
				} else if ("tag".equals(currentElementName)) {
					// Management of notes
					final Attribute notesAttrib = se.getAttributeByName(new QName("notes"));
					if (notesAttrib != null) {
						final String note = notesAttrib.getValue();
						// We don't take into account automatic EA notes for
						// enumerated types
						if (note != null && !note.startsWith("Values: ")) {
							final Attribute nameAttrib = se.getAttributeByName(QN_NAME);
							final Attribute xmiIdAttrib = se.getAttributeByName(QN_QUAL_ID);
							if (nameAttrib != null && xmiIdAttrib != null) {
								List notesList = null;
								if (notesMap.containsKey(idref)) {
									notesList = (List) notesMap.get(idref);
								} else {
									notesList = new ArrayList();
									notesMap.put(idref, notesList);
								}
								notesList.add(new TagNote(xmiIdAttrib.getValue(), nameAttrib.getValue(), notesAttrib.getValue()));
							}
						}
					}
				}
				Attribute idrefAttribute = se.getAttributeByName(QN_HREF);
				if (idrefAttribute == null) {
					idrefAttribute = se.getAttributeByName(QN_QUAL_IDREF);
				}
				// Now, either "xmi:idref" or "idref" attribute has been found
				// if it exists.
				if (idrefAttribute != null) {
					manageExtensionSection(event, reader, writer, idrefAttribute.getValue());
				} else {
					if (currentElementName.equals("documentation")) {
						final Attribute commentValue = se.getAttributeByName(QN_VALUE);
						if (commentValue != null) {
							comments.put(idref, commentValue.getValue());
						}
					} else if (currentElementName.equals("properties")) {
						// EA stores some comments in the documentation
						// attribute of a properties tag for classes...
						final Attribute commentValue = se.getAttributeByName(QN_DOCUMENTATION);
						if (commentValue != null) {
							comments.put(idref, commentValue.getValue());
						}
					}
					manageExtensionSection(event, reader, writer, idref);
				}
				event = null;
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			if (event != null) {
				writer.add(event);
			}
		}
	}

	private void recordRealizationAttributeForComponentDiagramFix(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer) throws XMLStreamException, IOException {
		final Attribute supplierInterface = baseEvent.asStartElement().getAttributeByName(new QName("supplier"));
		final Attribute clientClass = baseEvent.asStartElement().getAttributeByName(new QName("client"));
		final Attribute idRealization = baseEvent.asStartElement().getAttributeByName(QN_QUAL_ID);

		if (supplierInterface != null && clientClass != null && idRealization != null) {
			if (interfaceToClass.containsKey(supplierInterface.getValue())) {
				final List classes = (List) interfaceToClass.get(supplierInterface.getValue());
				classes.add(clientClass.getValue());
				interfaceToClass.put(supplierInterface.getValue(), classes);
			} else {
				final List classes = new ArrayList();
				classes.add(clientClass.getValue());
				interfaceToClass.put(supplierInterface.getValue(), classes);
			}
			// We store the id of the uml:Serialization AND the id of the supplier
			if (classToRealization.containsKey(clientClass.getValue())) {
				final List realizations = (List) classToRealization.get(clientClass.getValue());
				realizations.add(new String[]{idRealization.getValue(), supplierInterface.getValue()});
				classToRealization.put(clientClass.getValue(), realizations);
			} else {
				final List realizations = new ArrayList();
				realizations.add(new String[]{idRealization.getValue(), supplierInterface.getValue()});
				classToRealization.put(clientClass.getValue(), realizations);
			}
		}
		writer.add(baseEvent);
	}

	private void recordPortStructureForComponentDiagramFix(XMLEvent baseEvent, XMLEventReader reader, XMLEventWriter writer) throws XMLStreamException, IOException {
		final Attribute idPort = baseEvent.asStartElement().getAttributeByName(QN_QUAL_ID);
		writer.add(baseEvent);
		boolean fixing = true;
		if (idPort == null) {
			fixing = false;
		}
		while (fixing) {
			XMLEvent event = (XMLEvent) reader.next();

			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final String currentElementName = event.asStartElement().getName().getLocalPart();
				if (currentElementName.equals("provided")) {
					final Attribute idrefInterface = event.asStartElement().getAttributeByName(QN_QUAL_IDREF);
					if (idrefInterface != null) {
						if (portToInterface.containsKey(idPort.getValue())) {
							final List interfaces = (List) portToInterface.get(idPort.getValue());
							interfaces.add(idrefInterface.getValue());
							portToInterface.put(idPort.getValue(), interfaces);
						} else {
							final List interfaces = new ArrayList();
							interfaces.add(idrefInterface.getValue());
							portToInterface.put(idPort.getValue(), interfaces);
						}
					}
				}
				readAndRecordElement(event, reader, writer);
				event = null;
				break;
			case XMLEvent.END_ELEMENT:
				fixing = false;
				break;
			default:
				break;
			}

			if (event != null) {
				writer.add(event);
			}
		}
	}

	/**
	 * Reads the input xml file with the XMLEventReader, fix elements when
	 * necessary and writes the output on an XMLEventWriter.
	 * 
	 * @param reader
	 *            the XML input reader.
	 * @param writer
	 *            the XML output writer.
	 * @throws XMLStreamException
	 * @throws IOException
	 */
	public void fix(String filePath, InputStream is) throws XMLStreamException, IOException {

		// init reader
		final XMLEventReader reader = XMLInputFactory.newInstance().createXMLEventReader(is);
		// init writer
		final FileWriter fw = new FileWriter(filePath);
		final XMLEventWriter writer = XMLOutputFactory.newInstance().createXMLEventWriter(fw);

		final List profiles = new ArrayList();

		while (true) {
			XMLEvent event = (XMLEvent) reader.next();
			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String currentElementName = se.getName().getLocalPart();
				final Attribute ca = se.getAttributeByName(QN_QUAL_TYPE);
				final String caValue = ca == null ? "" : ca.getValue();
				if (currentElementName.equals("Documentation")) {
					removeElement(event, reader);
					event = null;
				} else if (caValue.equals("uml:Port")) {
					recordPortStructureForComponentDiagramFix(event, reader, writer);
					event = null;
				} else if (caValue.equals("uml:Realization")) {
					recordRealizationAttributeForComponentDiagramFix(event, reader, writer);
					event = null;
				} else if (caValue.equals("uml:Usage")) {
					recordRealizationAttributeForComponentDiagramFix(event, reader, writer);
					event = null;
				} else if (caValue.equals("uml:Dependency")) {
					removeElement(event, reader);
					event = null;
				} else if (caValue.equals("uml:Association")) {
					List elementsToRemove = new ArrayList();
					elementsToRemove.add("memberEnd");
					elementsToRemove.add("ownedEnd");
					removeSubElements(event, reader, writer, currentElementName, elementsToRemove);
					event = null;
				} else if (caValue.equals("uml:StateMachine") ||
						caValue.equals("uml:Activity") ||
						caValue.equals("uml:ControlFlow") ||
						caValue.equals("uml:Trigger")) {
					// UML State and Activity diagrams are not supported yet
					// we delete the corresponding information
					removeElement(event, reader);
					event = null;
				} else if (currentElementName.equals("ownedEnd")) {
					// EA exports the type of a property as a subnode instead of
					// an attribute "type" on the current node
					removeSubElement(event, reader, writer, currentElementName, "type");
					event = null;
				} else if (currentElementName.equals("message")) {
					removeAttributes(new StartElementEvent(event.asStartElement()), reader, writer, new String[] { "receiveEvent", "sendEvent" });
					event = null;
				} else if (currentElementName.equals("ownedConnector")) {
					removeElement(event, reader);
					event = null;
				} else if (currentElementName.equals("defaultValue")) {
					fixDefaultValue(event, reader, writer);
					event = null;
				} else if (currentElementName.equals("type")) {
					event = fixType(event.asStartElement());
				} else if (currentElementName.equals("Extension")) {
					manageExtensionSection(event, reader, writer, "");
					event = null;
				} else if (currentElementName.equals("packagedElement")) {
					// Recording valid types for illegal associations management
					if (VALID_UML21_TYPES.contains(caValue)) {
						final Attribute xmiId = se.getAttributeByName(QN_QUAL_ID);
						if (xmiId != null) {
							validTypes.add(xmiId.getValue());
						}
					}
					if (caValue.equals("uml:Profile")) {
						recordProfileStructure(event, reader, filePath, profiles);
						event = null;
					} else {
						final Attribute name = se.getAttributeByName(QN_NAME);
						if (name != null && name.getValue().equals("EA_CommonTypes_Package")) {
							removeElement(event, reader);
							event = null;
						}
						if (name != null && name.getValue().equals("EA_Java_Types_Package")) {
							removeSubElement(event, reader, writer, "packagedElement", "generalization");
							event = null;
						}
					}
				} else if (currentElementName.equals("EAStub")) {
					// Let's remove EAStubs for the moment
					// (seront cependant utiles lors d'un export en plusieurs
					// fichiers)
					final StringBuffer attributes = new StringBuffer();
					attributes.append("Check your model, EA exported the following stub: <EAStub ");
					for (final Iterator it = se.getAttributes(); it.hasNext();) {
						final Attribute att = (Attribute) it.next();
						attributes.append(att.getName()).append("=\"").append(att.getValue()).append("\" ");
					}
					attributes.append(">");
					AcceleoBridgePlugin.getDefault().log(attributes.toString(), false);
					event = null;
				}
				break;
			case XMLEvent.END_ELEMENT:
				// EndElement ee = event.asEndElement();
				// String currentEndElementName = ee.getName().getLocalPart();
				// if (currentEndElementName.equals("Profile")) {
				//
				// }
				break;
			case XMLEvent.COMMENT:
				break;
			default:
				break;
			}

			// writes the output event (modified or not)
			if (event != null) {
				writer.add(event);
			}
			event = reader.peek();

			// stops the process at the end of the document
			if (event.getEventType() == XMLEvent.END_DOCUMENT) {
				break;
			}
		}
		// closing readers and writers
		reader.close();
		writer.close();
		fw.close();

		// //////////////////////////////////////////////////////////////////////
		// /////////////////////
		// SECOND STEP: TO MODIFY UML MODEL WITH INFORMATION RECORDED IN THE
		// PREVIOUS READING
		// //////////////////////////////////////////////////////////////////////
		// /////////////////////

		// init reader
		final FileReader fr2 = new FileReader(filePath);
		final XMLEventReader reader2 = XMLInputFactory.newInstance().createXMLEventReader(fr2);
		// init writer
		final FileWriter fw2 = new FileWriter(filePath + ".tmp.xmi");
		final XMLEventWriter writer2 = XMLOutputFactory.newInstance().createXMLEventWriter(fw2);

		final List appliedStereotypes = new ArrayList();
		final List stereotypeNames = new ArrayList();
		boolean addingReturnArray = false;
		while (true) {
			boolean addingAppliedStereotypes = false;
			boolean foundReturnParameter = false;
			// 
			String idElementToComment = null;
			String idElementToAddNote = null;
			String currentXmiId = null;
			XMLEvent event = (XMLEvent) reader2.next();
			switch (event.getEventType()) {

			case XMLEvent.START_ELEMENT:
				final StartElement se = event.asStartElement();
				final String currentElementName = se.getName().getLocalPart();
				final Attribute currentAttributeId = se.getAttributeByName(QN_QUAL_ID);
				final Attribute currentAttributeType = se.getAttributeByName(QN_QUAL_TYPE);
				if (currentElementName.equals("XMI")) {
					writer2.add(new CharactersEvent("\n"));
					final StartElementEvent newSe = new StartElementEvent(new QName("xmi:XMI"));
					newSe.setAttributes(getAttributes(event.asStartElement().getAttributes()));
					newSe.addNamespace(new NamespaceBase("uml", "http://www.eclipse.org/uml2/2.1.0/UML"));
					newSe.addNamespace(new NamespaceBase("xmi", "http://schema.omg.org/spec/XMI/2.1"));
					newSe.addNamespace(new NamespaceBase("xsi", "http://www.w3.org/2001/XMLSchema-instance"));
					newSe.addNamespace(new NamespaceBase("ecore", "http://www.eclipse.org/emf/2002/Ecore"));
					String schemaLocationData = "";
					for (final Iterator it = profiles.iterator(); it.hasNext();) {
						final ProfileData pro = (ProfileData) it.next();
						newSe.addNamespace(new NamespaceBase(pro.nsPrefix, pro.nsUri));
						schemaLocationData += pro.nsUri + " " + pro.profileName + ".profile.uml#" + "__GENERATED_ID_Profile_" + pro.profileName + "__ ";
						if (!pro.profileName.equals("thecustomprofile")) {
							for (final Iterator it2 = pro.stereotypeDatas.iterator(); it2.hasNext();) {
								final StereotypeData sd = (StereotypeData) it2.next();
								stereotypeNames.add(sd.stereotypeName);
							}
						}
					}
					newSe.addAttribute(new AttributeBase(new QName("xsi:schemaLocation"), schemaLocationData));
					schemaLocationAttribute = "xsi:schemaLocation=\"" + schemaLocationData + "\"";
					event = newSe;
				} else if (stereotypeNames.contains(currentElementName)) {
					appliedStereotypes.add(event);
					event = null;
				} else if (currentAttributeId != null) {
					currentXmiId = currentAttributeId.getValue();
					if (comments.containsKey(currentXmiId)) {
						idElementToComment = currentXmiId;
					}
					if ("ownedOperation".equals(currentElementName) && methodsThatReturnArray.contains(currentXmiId)) {
						addingReturnArray = true;
					} else if ("ownedParameter".equals(currentElementName) && addingReturnArray) {
						final Attribute direction = se.getAttributeByName(new QName("direction"));
						if (direction != null && "return".equals(direction.getValue())) {
							addingReturnArray = false;
							foundReturnParameter = true;
						}
					}
					if (mapOfOwnedEndTypes.containsKey(currentXmiId)) {
						final String typeXmiId = (String) mapOfOwnedEndTypes.get(currentXmiId);
						if (validTypes.contains(typeXmiId)) {
							final Attribute typeAttr = new AttributeBase(QN_TYPE, typeXmiId);
							final StartElementEvent newSe = new StartElementEvent(se);
							newSe.addAttribute(typeAttr);
							event = newSe;
						} else {
							// Log a warning
							AcceleoBridgePlugin.getDefault().log("Discarded association end (id = " + currentXmiId + ") with invalid type of id = " + typeXmiId, false);
						}
					}
					if (notesMap.containsKey(currentXmiId)) {
						idElementToAddNote = currentXmiId;
					}

					else if (currentAttributeType != null) {
						if (currentAttributeType.getValue().equals("uml:Port")) {
							if (portToInterface.containsKey(currentXmiId)) {
								final StartElementEvent newSe = new StartElementEvent(event.asStartElement());
								final List interfaces = (List) portToInterface.get(currentXmiId);
								for (final Iterator it = interfaces.iterator(); it.hasNext();) {
									final String currentInterfaceId = (String) it.next();
									if (interfaceToClass.containsKey(currentInterfaceId)) {
										final List classes = (List) interfaceToClass.get(currentInterfaceId);
										for (final Iterator it2 = classes.iterator(); it2.hasNext();) {
											final String currentClassId = (String) it2.next();
											newSe.addAttribute(new AttributeBase(QN_TYPE, currentClassId));
										}
									}
								}
								event = newSe;
							}
						} else if (currentAttributeType.getValue().equals("uml:Class")) {
							if (classToRealization.containsKey(currentXmiId)) {
								final List realizations = (List) classToRealization.get(currentXmiId);
								String idRealization = "";
								for (final Iterator it = realizations.iterator(); it.hasNext();) {
									String[] values = (String[])it.next();
									String idSupplier = values[1];
									// If the supplier isn't a valid type, we don't reference it
									if (validTypes.contains(idSupplier)) {
										idRealization += " " + values[0];
									}
								}
								if (!"".equals(idRealization)) {
									final StartElementEvent newSe = new StartElementEvent(event.asStartElement());
									newSe.addAttribute(new AttributeBase(new QName("clientDependency"), idRealization));
									event = newSe;
								}
							}
						} else if (currentAttributeType.getValue().equals("uml:Realization")) {
							// If the supplier isn't a valid type, we remove the uml:Realization
							Attribute supplier = se.getAttributeByName(QN_SUPPLIER);
							if (!validTypes.contains(supplier.getValue())) {
								removeElement(event, reader2);
								event = null;
							}
						}
					}
				}

				// Delete of provided and required tags could not be done here.
				// Maybe there is a bug in stAX API.
				// else if (currentElementName.equals("provided")) {
				// event = null;
				// }
				// else if (currentElementName.equals("required")) {
				// event = null;
				// }
				break;
			case XMLEvent.END_ELEMENT:
				final EndElement ee = event.asEndElement();
				final String currentElementNameE = ee.getName().getLocalPart();
				if (stereotypeNames.contains(currentElementNameE)) {
					appliedStereotypes.add(event);
					event = null;
				}
				if (currentElementNameE.equals("Model")) {
					addingAppliedStereotypes = true;
				}
				// Delete of provided and required tags could not be done here.
				// Maybe there is a bug in stAX API.
				// else if (currentElementNameE.equals("provided")) {
				// event = null;
				// }
				// else if (currentElementNameE.equals("provided")) {
				// event = null;
				// }
				break;
			case XMLEvent.COMMENT:
				break;
			default:
				break;
			}

			// writes the output event (modified or not)
			if (event != null) {
				writer2.add(event);
				if (idElementToAddNote != null) {
					final StartElementEvent newSE = new StartElementEvent(QN_EANNOTATIONS);
					newSE.addAttribute(new AttributeBase(QN_XMIID, idElementToComment + "_EANNOT"));
					newSE.addAttribute(new AttributeBase(QN_SOURCE, "notes"));
					writer2.add(newSE);
					final List notes = (List) notesMap.get(idElementToAddNote);
					for (final Iterator ite = notes.iterator(); ite.hasNext();) {
						final TagNote tagNote = (TagNote) ite.next();
						final StartElementEvent detailsSE = new StartElementEvent(new QName("details"));
						detailsSE.addAttribute(new AttributeBase(QN_XMIID, tagNote.xmiId));
						detailsSE.addAttribute(new AttributeBase(QN_KEY, tagNote.key));
						detailsSE.addAttribute(new AttributeBase(QN_VALUE, tagNote.value));
						writer2.add(detailsSE);
						writer2.add(new EndElementEvent(new QName("details")));
					}
					writer2.add(new EndElementEvent(QN_EANNOTATIONS));
					idElementToAddNote = null;
				}
				if (addingAppliedStereotypes) {
					for (final Iterator it = appliedStereotypes.iterator(); it.hasNext();) {
						final XMLEvent xe = (XMLEvent) it.next();
						// Let's check whether this stereotype application has
						// an attribute that contains cltIds
						// in the form attrName="{cltId1},{cltId2}"
						if (xe.isStartElement()) {
							final StartElementEvent newSe = new StartElementEvent(xe.asStartElement().getName());
							final Iterator attribs = xe.asStartElement().getAttributes();
							while (attribs.hasNext()) {
								final Attribute attr = (Attribute) attribs.next();
								final String value = attr.getValue();
								if (TAGGED_VALUE_PATTERN.matcher(value).matches()) {
									final List newValues = new ArrayList();
									final Matcher m = TAGGED_VALUE_ID_PATTERN.matcher(value);
									while (m.find()) {
										final String cltId = m.group();
										if (xmiIdBycltId.containsKey(cltId)) {
											newValues.add(xmiIdBycltId.get(cltId));
										}
									}
									final Iterator it2 = newValues.iterator();
									// Let's rewrite the list of correct ids,
									// separated by spaces
									final StringBuffer newValue = new StringBuffer();
									newValue.append(it2.next());
									while (it2.hasNext()) {
										newValue.append(" ").append(it2.next());
									}
									if (newValue.length() > 0) {
										final Attribute newValueAttr = new AttributeBase(attr.getName(), newValue.toString());
										newSe.addAttribute(newValueAttr);
									}
								} else {
									newSe.addAttribute(attr);
								}
							}
							writer2.add(newSe);
						} else {
							writer2.add(xe);
						}
					}
				}
				if (idElementToComment != null) {
					final StartElementEvent newSe = new StartElementEvent(QN_OWNED_COMMENT);
					newSe.addAttribute(new AttributeBase(QN_XMIID, idElementToComment + "_Comment"));
					newSe.addAttribute(new AttributeBase(new QName("annotatedElement"), idElementToComment));
					writer2.add(newSe);
					writer2.add(new StartElementEvent(new QName("body")));
					writer2.add(new CharactersEvent((String) comments.get(idElementToComment)));
					writer2.add(new EndElementEvent(new QName("body")));
					writer2.add(new EndElementEvent(QN_OWNED_COMMENT));
					idElementToComment = null;
				}
				if (foundReturnParameter) {
					// Let's add an upper cardinality to the return parameter
					// <upperValue xmi:type="uml:LiteralUnlimitedNatural"
					// xmi:id="_Q4epMEExEd2497d6jUP_XA" value="*"/>
					foundReturnParameter = false;
					final StartElementEvent newSe = new StartElementEvent(QN_UPPER_VALUE);
					newSe.addAttribute(new AttributeBase(QN_XMIID, currentXmiId + "_UV"));
					newSe.addAttribute(new AttributeBase(QN_XMITYPE, "uml:LiteralUnlimitedNatural"));
					newSe.addAttribute(new AttributeBase(QN_VALUE, "*"));
					writer2.add(newSe);
					// Let's close the upperValue
					final EndElementEvent newEe = new EndElementEvent(QN_UPPER_VALUE);
					writer2.add(newEe);
				}
				if (event.getEventType() == XMLEvent.END_DOCUMENT) {
					break;
				}
			}
		}

		// closing readers and writers
		reader2.close();
		writer2.close();
		fw2.close();
		final ResourceSet resourceSet = new ResourceSetImpl();
		((ResourceSetImpl) resourceSet).getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());

		for (final Iterator it = profiles.iterator(); it.hasNext();) {
			final ProfileData pro = (ProfileData) it.next();
			emfLoadAndSave(convertFileSystemPathToResourcePath(containerPath) + "/" + pro.profileName + ".profile.uml", resourceSet);
		}
	}

	/**
	 * This method is used to load and save UML Profile extracted from the UML
	 * model
	 * 
	 * @param path
	 * @param resourceSet
	 * @throws IOException
	 */
	private static void emfLoadAndSave(String path, ResourceSet resourceSet) throws IOException {
		final Uml20EAResourceFactoryImpl umlEA = new Uml20EAResourceFactoryImpl();
		final XMIResource modelResource = (XMIResource) umlEA.createResource(URI.createPlatformResourceURI(path, true));
		final Map defaultLoadOptions = modelResource.getDefaultLoadOptions();
		modelResource.load(defaultLoadOptions);

		final Map options = new HashMap();
		options.put(XMLResource.OPTION_RECORD_UNKNOWN_FEATURE, Boolean.TRUE);
		modelResource.setURI(URI.createPlatformResourceURI(path, true));
		modelResource.save(options);
		modelResource.unload();
	}

	/**
	 * Convert a file system path to a Eclipse workspace relative path
	 * 
	 * @param path
	 * @return
	 */
	public static String convertFileSystemPathToResourcePath(String path) {
		IResource resource;
		if (Platform.getLocation().equals(path)) {
			resource = ResourcesPlugin.getWorkspace().getRoot();
			return resource.getFullPath().toString();
		} else {
			resource = ResourcesPlugin.getWorkspace().getRoot().getContainerForLocation(new Path(path));
			return ResourcesPlugin.getWorkspace().getRoot().getContainerForLocation(new Path(path)).getFullPath().toString();
		}

	}

	/**
	 * Fix Stax problems.
	 * 
	 * @param xmiIn
	 * @param xmiOut
	 */
	public static InputStream fixStax(InputStream in) {
		final StringBuffer sb = new StringBuffer();
		final BufferedReader input = new BufferedReader(new InputStreamReader(in));
		try {
			String line;
			while ((line = input.readLine()) != null) {
				// specials characters not accepted at the end of a data
				// field :
				line = line.replaceAll("&gt;</", "&gt; </");
				line = line.replaceAll("&lt;</", "&lt; </");
				line = line.replaceAll("&quot;</", "&quot; </");
				line = line.replaceAll("&amp;</", "&amp; </");
				line = line.replaceAll("&#39;</", "&#39; </");
				sb.append(line + "\n");
			}
			input.close();
		} catch (final IOException e) {
			AcceleoBridgePlugin.getDefault().log(e, false);
		}
		return new ByteArrayInputStream(sb.toString().getBytes());
	}

	public String getSchemaLocationAttribute() {
		return schemaLocationAttribute;
	}

}