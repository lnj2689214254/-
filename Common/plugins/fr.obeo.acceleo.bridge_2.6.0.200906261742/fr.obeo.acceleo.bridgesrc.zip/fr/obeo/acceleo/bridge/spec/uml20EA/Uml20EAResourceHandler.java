/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.bridge.spec.uml20EA;

import java.io.InputStream;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.BasicResourceHandler;
import org.eclipse.emf.ecore.xml.type.AnyType;

/**
 * 
 * @author www.obeo.fr
 * 
 */
public class Uml20EAResourceHandler extends BasicResourceHandler {

	public void postLoad(XMLResource resource, InputStream inputStream, Map options) {
		final Map extMap = resource.getEObjectToExtensionMap();
		for (Iterator itr = extMap.keySet().iterator(); itr.hasNext();) {
			EObject key = (EObject) itr.next();
			AnyType value = (AnyType) extMap.get(key);
			handleUnknownData(key, value);
		}
	}

	private void handleUnknownData(EObject eObj, AnyType unknownData) {
		handleUnknownFeatures(eObj, unknownData.getMixed());
		handleUnknownFeatures(eObj, unknownData.getAnyAttribute());
	}

	private void handleUnknownFeatures(EObject owner, FeatureMap featureMap) {
		for (Iterator iter = featureMap.iterator(); iter.hasNext();) {
			FeatureMap.Entry entry = (FeatureMap.Entry) iter.next();
			EStructuralFeature f = entry.getEStructuralFeature();
			if (handleUnknownFeature(owner, f, entry.getValue())) {
				iter.remove();
			}
		}
	}

	private boolean handleUnknownFeature(EObject owner, EStructuralFeature f, Object value) {
		return false;
	}

}
