/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.debug;

import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.chain.ui.AcceleoChainUiPlugin;
import fr.obeo.acceleo.chain.ui.popupMenus.AcceleoChainLaunchOperation;
import fr.obeo.acceleo.gen.debug.ui.model.AcceleoDebugTarget;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.model.LaunchConfigurationDelegate;

/**
 * Configuration delegate to launch a chain.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoLaunchDelegate extends LaunchConfigurationDelegate {

	public static final String CHAIN_ATTRIBUTE_ID = "CHAIN_ATTRIBUTE_ID"; //$NON-NLS-1$

	public static final String CHAIN_DO_PROFILING = "CHAIN_DO_PROFILING"; //$NON-NLS-1$

	public static final String PROFILE_SAVE_TO = "PROFILE_SAVE_TO"; //$NON-NLS-1$

	public static final String FILE_SEPARATOR = ":"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public void launch(ILaunchConfiguration configuration, String mode, ILaunch launch, IProgressMonitor monitor) throws CoreException {
		final String chain = configuration.getAttribute(CHAIN_ATTRIBUTE_ID, (String) null);
		if (chain == null) {
			AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoLaunchDelegate.MissingChain"), true); //$NON-NLS-1$
		} else {
			final List files = new ArrayList();
			final StringTokenizer st = new StringTokenizer(chain, FILE_SEPARATOR);
			while (st.hasMoreTokens()) {
				final IPath path = new Path(st.nextToken().trim());
				final IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(path);
				if (resource != null && resource instanceof IFile) {
					files.add(resource);
				} else {
					AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("MissingChain", new Object[] { path.toFile(), }), true); //$NON-NLS-1$
				}
			}
			final LaunchManager launchManager = LaunchManager.create(mode, true);
			try {
				if ("debug".equals(mode)) { //$NON-NLS-1$
					launch.addDebugTarget(new AcceleoDebugTarget(launch, TemplateElement.getDebugger()));
				}
				if (configuration.getAttribute(CHAIN_DO_PROFILING, false) && "run".equals(mode)) { //$NON-NLS-1$
					launchManager.profile();
				}
				final AcceleoChainLaunchOperation operation = new AcceleoChainLaunchOperation((IFile[]) files.toArray(new IFile[files.size()]), launchManager);
				operation.run(monitor);
				if (launchManager.isProfiling()) {
					TemplateElement.getProfiler().save(configuration.getAttribute(PROFILE_SAVE_TO, (String) null));
				}
			} catch (final InterruptedException e) {
				AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("InterruptedOperation"), true); //$NON-NLS-1$
			} catch (final Exception e) {
				AcceleoChainUiPlugin.getDefault().log(e, true);
			} finally {
				if (launchManager.isProfiling()) {
					TemplateElement.getProfiler().reset();
				}
			}
		}

	}
}
