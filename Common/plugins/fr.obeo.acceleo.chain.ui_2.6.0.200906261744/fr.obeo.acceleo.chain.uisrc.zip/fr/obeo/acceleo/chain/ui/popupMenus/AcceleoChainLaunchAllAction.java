/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.popupMenus;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.chain.ui.AcceleoChainUiPlugin;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

/**
 * The action which launchs all chains of the workspace : *.chain
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoChainLaunchAllAction implements IObjectActionDelegate {

	/**
	 * Default chain file extension.
	 */
	protected static final String CHAIN_EXTENSION = "chain"; //$NON-NLS-1$

	/**
	 * Selected chain file.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoChainLaunchAllAction() {
		super();
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		try {
			List chainFiles = new ArrayList();
			IFile file = (IFile) ((StructuredSelection) selection).getFirstElement();
			IProject[] projects = file.getWorkspace().getRoot().getProjects();
			for (int i = 0; i < projects.length; i++) {
				IProject project = projects[i];
				IResource[] resources = project.members();
				for (int j = 0; j < resources.length; j++) {
					if (resources[j] instanceof IFile && resources[j].getFullPath().getFileExtension().equals(CHAIN_EXTENSION)) {
						chainFiles.add(resources[j]);
					}
				}
			}
			AcceleoChainLaunchOperation operation = new AcceleoChainLaunchOperation((IFile[]) chainFiles.toArray(new IFile[chainFiles.size()]), LaunchManager.create("run", true)); //$NON-NLS-1$
			PlatformUI.getWorkbench().getProgressService().run(true, true, operation);
		} catch (InvocationTargetException e) {
			AcceleoChainUiPlugin.getDefault().log(e, true);
		} catch (InterruptedException e) {
			AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("InterruptedOperation"), true); //$NON-NLS-1$
		} catch (CoreException e) {
			AcceleoChainUiPlugin.getDefault().log(e, true);
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
