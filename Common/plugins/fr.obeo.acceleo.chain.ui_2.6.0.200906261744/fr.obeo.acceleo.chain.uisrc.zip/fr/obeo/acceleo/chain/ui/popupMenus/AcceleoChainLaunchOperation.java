/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.popupMenus;

import java.io.File;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.tools.CLoaderUtils;
import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.chain.ui.AcceleoChainUiPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.AcceleoToolsPlugin;

/**
 * The operation which launchs the selected chains.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoChainLaunchOperation extends WorkspaceModifyOperation {

	/**
	 * Selected chain files.
	 */
	protected IFile[] chainFiles;

	/**
	 * The mode in which to launch, one of the mode constants defined - RUN_MODE
	 * or DEBUG_MODE.
	 */
	protected LaunchManager mode;

	/**
	 * The generation filter.
	 */
	protected IGenFilter genFilter;

	/**
	 * Constructor.
	 * 
	 * @param chainFiles
	 *            is the selected chains
	 * @param mode
	 *            is the mode in which to launch, one of the mode constants
	 *            defined - RUN_MODE or DEBUG_MODE
	 */
	public AcceleoChainLaunchOperation(IFile[] chainFiles, LaunchManager mode) {
		super();
		this.chainFiles = chainFiles;
		this.genFilter = new IGenFilter() {
			public boolean filter(File script, IFile targetFile, EObject object) throws CoreException {
				return true;
			}
		};
		this.mode = mode;
	}

	/**
	 * Constructor.
	 * 
	 * @param chainFiles
	 *            is the selected chains
	 * @param genFilter
	 *            is a generation filter
	 * @param mode
	 *            is the mode in which to launch, one of the mode constants
	 *            defined - RUN_MODE or DEBUG_MODE
	 */
	public AcceleoChainLaunchOperation(IFile[] chainFiles, IGenFilter genFilter, LaunchManager mode) {
		super();
		this.chainFiles = chainFiles;
		this.genFilter = genFilter;
		this.mode = mode;
	}

	/* (non-Javadoc) */
	protected void execute(IProgressMonitor progressMonitor) {
		final int logCount = AcceleoToolsPlugin.getDefault().getAcceleoLogCount(IStatus.ERROR);
		IWorkspaceRunnable runnable = new IWorkspaceRunnable() {
			public void run(IProgressMonitor progressMonitor) throws CoreException {
				// Load chains
				CChain[] chains = new CChain[chainFiles.length];
				for (int i = 0; i < chainFiles.length; i++) {
					IFile chainFile = chainFiles[i];
					chains[i] = CLoaderUtils.getCChainForChainFile(chainFile);
					if (chains[i] == null) {
						AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoChainLaunchOperation.InvalidChain", new Object[] { chainFile.getFullPath().toString(), }), true); //$NON-NLS-1$
					}
				}
				// Launch chains
				if (chains.length == 1) {
					progressMonitor.beginTask(AcceleoChainUIMessages.getString("AcceleoChainLaunchOperation.Task.LaunchSingleChain"), totalWork(chains)); //$NON-NLS-1$
				} else if (chains.length > 1) {
					progressMonitor.beginTask(AcceleoChainUIMessages.getString("AcceleoChainLaunchOperation.Task.LaunchMultipleChain"), totalWork(chains)); //$NON-NLS-1$
				}
				for (int i = 0; i < chains.length; i++) {
					CChain chain = chains[i];
					if (chain != null) {
						long startTime = System.currentTimeMillis();
						chain.launch(genFilter, progressMonitor, mode);
						long endTime = System.currentTimeMillis();
						if (mode.getMode() == LaunchManager.DEBUG_MODE) {
							System.out.println(AcceleoChainUIMessages.getString(
									"AcceleoChainLaunchOperation.CompletedChain", new Object[] { chainFiles[i].getFullPath().toString(), Long.toString(endTime - startTime), })); //$NON-NLS-1$
						}
					}
				}
			}
		};
		if (mode.getMode() == LaunchManager.DEBUG_MODE) {
			TemplateElement.getDebugger().start();
		}
		try {
			ResourcesPlugin.getWorkspace().run(runnable, progressMonitor);
		} catch (CoreException e) {
			AcceleoChainUiPlugin.getDefault().log(e, true);
		} finally {
			if (mode.getMode() == LaunchManager.DEBUG_MODE) {
				TemplateElement.getDebugger().end();
			}
		}
		if (AcceleoToolsPlugin.getDefault().getAcceleoLogCount(IStatus.ERROR) > logCount) {
			if (PlatformUI.isWorkbenchRunning() && PlatformUI.getWorkbench() != null && PlatformUI.getWorkbench().getDisplay() != null && !PlatformUI.getWorkbench().getDisplay().isDisposed()) {
				PlatformUI.getWorkbench().getDisplay().syncExec(new Runnable() {
					public void run() {
						Shell shell = new Shell();
						int diff = AcceleoToolsPlugin.getDefault().getAcceleoLogCount(IStatus.ERROR) - logCount;
						MessageDialog
								.openError(
										shell,
										AcceleoChainUIMessages.getString("AcceleoChainLaunchOperation.Error.DialogTitle"), AcceleoChainUIMessages.getString("AcceleoChainLaunchOperation.Error.DialogMessage", new Object[] { Integer.toString(diff), })); //$NON-NLS-1$ //$NON-NLS-2$
						shell.dispose();
					}
				});
			}
		}
	}

	private int totalWork(CChain[] chains) {
		int totalWork = 0;
		for (int i = 0; i < chains.length; i++) {
			CChain chain = chains[i];
			if (chain != null) {
				totalWork += chain.totalWork();
			}
		}
		return totalWork;
	}

}
