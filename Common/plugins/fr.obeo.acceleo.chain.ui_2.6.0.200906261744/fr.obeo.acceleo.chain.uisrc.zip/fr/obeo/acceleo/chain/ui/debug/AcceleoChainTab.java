/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.debug;

import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.tools.ui.resources.FileSelectionDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;

/**
 * Tab to specify the chain to run/debug.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoChainTab extends AbstractLaunchConfigurationTab {

	private Text chainPathText;

	private Button chainPathButton;

	private Button profileButton;

	private Text profilePathText;

	private Button profilePathButton;

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		final Font font = parent.getFont();

		final Composite comp = new Composite(parent, SWT.NONE);
		setControl(comp);
		final GridLayout topLayout = new GridLayout();
		topLayout.verticalSpacing = 0;
		topLayout.numColumns = 3;
		comp.setLayout(topLayout);
		comp.setFont(font);

		createVerticalSpacer(comp, 3);

		final Label chainLabel = new Label(comp, SWT.NONE);
		chainLabel.setText(AcceleoChainUIMessages.getString("AcceleoChainTab.ChainLabel") + ':'); //$NON-NLS-1$
		GridData gd = new GridData(GridData.BEGINNING);
		chainLabel.setLayoutData(gd);
		chainLabel.setFont(font);

		chainPathText = new Text(comp, SWT.SINGLE | SWT.BORDER);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		chainPathText.setLayoutData(gd);
		chainPathText.setFont(font);
		chainPathText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				if (profileButton.getSelection() && "".equals(profilePathText.getText())) { //$NON-NLS-1$
					profilePathText.setText(chainPathText.getText().trim() + ".profiler"); //$NON-NLS-1$
				}
				updateLaunchConfigurationDialog();
			}
		});

		chainPathButton = createPushButton(comp, AcceleoChainUIMessages.getString("AcceleoChainTab.BrowseButtonLabel"), null); //$NON-NLS-1$
		chainPathButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				browseChainFiles();
			}
		});

		profileButton = createCheckButton(comp, AcceleoChainUIMessages.getString("AcceleoChainTab.ProfileButtonLabel") + ':'); //$NON-NLS-1$
		profileButton.addSelectionListener(new SelectionListener() {

			public void widgetDefaultSelected(SelectionEvent e) {
				if (profileButton.getSelection() && "".equals(profilePathText.getText())) { //$NON-NLS-1$
					profilePathText.setText(chainPathText.getText().trim() + ".profiler"); //$NON-NLS-1$
				}
				updateLaunchConfigurationDialog();
				profilePathText.setEnabled(profileButton.getSelection());
				profilePathButton.setEnabled(profileButton.getSelection());
			}

			public void widgetSelected(SelectionEvent e) {
				if (profileButton.getSelection() && "".equals(profilePathText.getText())) { //$NON-NLS-1$
					profilePathText.setText(chainPathText.getText().trim() + ".profiler"); //$NON-NLS-1$
				}
				updateLaunchConfigurationDialog();
				profilePathText.setEnabled(profileButton.getSelection());
				profilePathButton.setEnabled(profileButton.getSelection());
			}

		});
		profilePathText = new Text(comp, SWT.SINGLE | SWT.BORDER);
		gd = new GridData(GridData.FILL_HORIZONTAL);
		profilePathText.setLayoutData(gd);
		profilePathText.setFont(font);
		profilePathText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				updateLaunchConfigurationDialog();
			}
		});
		profilePathButton = createPushButton(comp, AcceleoChainUIMessages.getString("AcceleoChainTab.BrowseButtonLabel"), null); //$NON-NLS-1$
		profilePathButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				browseProfileFile();
			}
		});

	}

	/**
	 * Gets the extensions of the file to browse.
	 * 
	 * @return the extensions of the files to browse
	 */
	protected String[] getChainFileExtensions() {
		return new String[] { "chain" }; //$NON-NLS-1$
	}

	/**
	 * Gets the extensions of the file to browse.
	 * 
	 * @return the extensions of the files to browse
	 */
	protected String[] getProfileFileExtensions() {
		return new String[] { "profiler" }; //$NON-NLS-1$
	}

	/**
	 * Open a resource chooser to select chain files.
	 */
	protected void browseChainFiles() {
		final FileSelectionDialog dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
				AcceleoChainUIMessages.getString("AcceleoChainTab.FileSelection"), -1, getChainFileExtensions(), false); //$NON-NLS-1$
		if (chainPathText.getText() != null) {
			final List initialResources = new ArrayList();
			final StringTokenizer st = new StringTokenizer(chainPathText.getText(), AcceleoLaunchDelegate.FILE_SEPARATOR);
			while (st.hasMoreTokens()) {
				final IPath path = new Path(st.nextToken().trim());
				initialResources.add(path);
			}
			dialog.setInitialSelections(initialResources.toArray());
		}
		dialog.open();
		if (dialog.getResult() != null) {
			final StringBuffer text = new StringBuffer(""); //$NON-NLS-1$
			for (int i = 0; i < dialog.getResult().length; i++) {
				final IPath path = (IPath) dialog.getResult()[i];
				if (i > 0) {
					text.append(' ');
					text.append(AcceleoLaunchDelegate.FILE_SEPARATOR);
					text.append(' ');
				}
				text.append(path.toString());
			}
			chainPathText.setText(text.toString());
		}
	}

	protected void browseProfileFile() {
		final FileSelectionDialog dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(),
				AcceleoChainUIMessages.getString("AcceleoChainTab.FileSelection"), -1, getProfileFileExtensions(), false); //$NON-NLS-1$
		if (profilePathText.getText() != null) {
			final List initialResources = new ArrayList();
			final StringTokenizer st = new StringTokenizer(profilePathText.getText(), AcceleoLaunchDelegate.FILE_SEPARATOR);
			while (st.hasMoreTokens()) {
				final IPath path = new Path(st.nextToken().trim());
				initialResources.add(path);
			}
			dialog.setInitialSelections(initialResources.toArray());
		}
		dialog.open();
		if (dialog.getResult() != null) {
			final StringBuffer text = new StringBuffer(""); //$NON-NLS-1$
			for (int i = 0; i < dialog.getResult().length; i++) {
				final IPath path = (IPath) dialog.getResult()[i];
				if (i > 0) {
					text.append(' ');
					text.append(AcceleoLaunchDelegate.FILE_SEPARATOR);
					text.append(' ');
				}
				text.append(path.toString());
			}
			profilePathText.setText(text.toString());
		}
	}

	/* (non-Javadoc) */
	public void setDefaults(ILaunchConfigurationWorkingCopy configuration) {
		// nothing to do here
	}

	/* (non-Javadoc) */
	public void initializeFrom(ILaunchConfiguration configuration) {
		try {
			final String chain = configuration.getAttribute(AcceleoLaunchDelegate.CHAIN_ATTRIBUTE_ID, (String) null);
			if (chain != null) {
				chainPathText.setText(chain);
			}
			profileButton.setSelection(configuration.getAttribute(AcceleoLaunchDelegate.CHAIN_DO_PROFILING, false));
			final String profilePath = configuration.getAttribute(AcceleoLaunchDelegate.PROFILE_SAVE_TO, (String) null);
			if (profilePath != null) {
				profilePathText.setText(profilePath);
			}
		} catch (final CoreException e) {
			setErrorMessage(e.getMessage());
		}
	}

	/* (non-Javadoc) */
	public void performApply(ILaunchConfigurationWorkingCopy configuration) {
		final boolean profile = profileButton.getSelection();
		String chain = chainPathText.getText().trim();
		if (chain.length() == 0) {
			chain = null;
		}
		String profilePath = profilePathText.getText().trim();
		if (profilePath.length() == 0) {
			profilePath = null;
		}
		configuration.setAttribute(AcceleoLaunchDelegate.CHAIN_ATTRIBUTE_ID, chain);
		configuration.setAttribute(AcceleoLaunchDelegate.CHAIN_DO_PROFILING, profile);
		configuration.setAttribute(AcceleoLaunchDelegate.PROFILE_SAVE_TO, profilePath);
	}

	/* (non-Javadoc) */
	public String getName() {
		return AcceleoChainUIMessages.getString("AcceleoChainTab.TabName"); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public boolean isValid(ILaunchConfiguration launchConfig) {
		final String text = chainPathText.getText();
		if (text.length() > 0) {
			final StringTokenizer st = new StringTokenizer(text, AcceleoLaunchDelegate.FILE_SEPARATOR);
			while (st.hasMoreTokens()) {
				final IPath path = new Path(st.nextToken().trim());
				if (ResourcesPlugin.getWorkspace().getRoot().findMember(path) == null) {
					setErrorMessage(AcceleoChainUIMessages.getString("MissingChain", new Object[] { path.toString(), })); //$NON-NLS-1$
					return false;
				}
			}
		} else {
			setMessage(AcceleoChainUIMessages.getString("AcceleoChainTab.ChainSelectionHint")); //$NON-NLS-1$
		}
		return super.isValid(launchConfig);
	}

}
