/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.SelectionDialog;

import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoNewFileWizardPage;
import fr.obeo.acceleo.tools.ui.resources.FileSelectionDialog;
import fr.obeo.acceleo.tools.ui.resources.FolderSelectionDialog;

/**
 * The role of this wizard page is to configure the parameters of the chain
 * call.
 * 
 * @author www.obeo.fr
 */

public class AcceleoSetModuleParametersWizardPage extends WizardPage {

	/**
	 * The root composite.
	 */
	private Composite rootContainer;

	/**
	 * The parameter text widgets.
	 */
	private Text[] parameterText;

	/**
	 * The values of the parameters.
	 */
	private String[] parameterValues = new String[] {};

	/**
	 * The page to select a module.
	 */
	private AcceleoSelectModuleWizardPage pageSelectModule;

	/**
	 * The file to create the new file.
	 */
	private AcceleoNewFileWizardPage pageNewFile;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param pageSelectModule
	 *            is the page to select a module
	 * @param pageNewFile
	 *            is the file to create the new file
	 */
	public AcceleoSetModuleParametersWizardPage(String pageName, AcceleoSelectModuleWizardPage pageSelectModule, AcceleoNewFileWizardPage pageNewFile) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoChainUIMessages.getString("AcceleoSetModuleParametersWizardPage.Description")); //$NON-NLS-1$
		this.pageSelectModule = pageSelectModule;
		this.pageNewFile = pageNewFile;
	}

	/**
	 * Returns the values of the parameters.
	 * 
	 * @return the values of the parameters
	 */
	public String[] getParameterValues() {
		return parameterValues;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		rootContainer = new Composite(parent, SWT.NULL);
		GridLayout rootContainerLayout = new GridLayout();
		rootContainerLayout.numColumns = 1;
		rootContainerLayout.marginTop = 1;
		rootContainerLayout.verticalSpacing = 1;
		rootContainerLayout.marginLeft = 1;
		rootContainerLayout.marginRight = 1;
		rootContainer.setLayout(rootContainerLayout);
		parameterText = new Text[0];
		dialogChanged();
		setControl(rootContainer);
	}

	/**
	 * Refreshes the top level control for this dialog page under the given
	 * parent composite.
	 */
	public void refreshControl() {
		if (parameterText != null) {
			for (int i = 0; i < parameterText.length; i++) {
				parameterText[i].getParent().dispose();
			}
		}
		getShell().pack();
		IConfigurationElement[] parameters = getParameters();
		parameterText = new Text[parameters.length];
		for (int i = 0; i < parameters.length; i++) {
			Composite parameterContainer = new Composite(rootContainer, SWT.NULL);
			GridLayout parameterContainerLayout = new GridLayout();
			parameterContainerLayout.numColumns = 2;
			parameterContainerLayout.verticalSpacing = 1;
			parameterContainer.setLayout(parameterContainerLayout);
			Label parameterLabel = new Label(parameterContainer, SWT.NULL);
			String parameterType = parameters[i].getAttribute("description"); //$NON-NLS-1$
			if (parameterType == null)
				parameterType = ""; //$NON-NLS-1$
			parameterLabel.setText(parameterType);
			new Label(parameterContainer, SWT.NULL);
			parameterText[i] = new Text(parameterContainer, SWT.BORDER | SWT.SINGLE);
			parameterText[i].addModifyListener(new ModifyListener() {
				public void modifyText(ModifyEvent e) {
					dialogChanged();
				}
			});
			GridData data = new GridData(GridData.GRAB_HORIZONTAL | GridData.GRAB_VERTICAL);
			data.heightHint = parameterText[i].getLineHeight();
			data.widthHint = parameterText[i].getLineHeight() * 39;
			parameterText[i].setLayoutData(data);
			if (!"PROJECT_AUTO".equals(parameters[i].getAttribute("dialog"))) { //$NON-NLS-1$ //$NON-NLS-2$
				Button button = new Button(parameterContainer, SWT.PUSH);
				button.setText(AcceleoChainUIMessages.getString("AcceleoSetModuleParametersWizardPage.BrowseButtonLabel")); //$NON-NLS-1$
				final int parameterIndex = i;
				final String dialog = (parameters[i].getAttribute("dialog") != null) ? parameters[i].getAttribute("dialog") : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
				final String extensions = (parameters[i].getAttribute("extensions") != null) ? parameters[i].getAttribute("extensions") : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
				button.addSelectionListener(new SelectionAdapter() {
					public void widgetSelected(SelectionEvent e) {
						handleBrowse(parameterIndex, dialog, extensions);
					}
				});
			} else {
				IPath parameterPath = new Path(pageNewFile.getContainerName());
				if (parameterPath.segmentCount() > 0) {
					parameterText[i].setText(parameterPath.segment(0));
					parameterText[i].setEditable(false);
				} else {
					parameterText[i].setText(""); //$NON-NLS-1$
				}
			}
		}
		getShell().pack();
		dialogChanged();
	}

	private IConfigurationElement[] getParameters() {
		List result = new ArrayList();
		if (pageSelectModule.getModule() != null) {
			IConfigurationElement[] children = pageSelectModule.getModule().getChildren();
			for (int i = 0; i < children.length; i++) {
				IConfigurationElement parameter = children[i];
				result.add(parameter);
			}
		}
		return (IConfigurationElement[]) result.toArray(new IConfigurationElement[result.size()]);
	}

	private void handleBrowse(int parameterIndex, String dialogType, String extensions) {
		SelectionDialog dialog;
		if ("FOLDER_SELECTION".equals(dialogType)) { //$NON-NLS-1$
			dialog = new FolderSelectionDialog(AcceleoChainUIMessages.getString("AcceleoSetModuleParametersWizardPage.FolderSelectionTitle")); //$NON-NLS-1$
		} else if ("FILE_SELECTION".equals(dialogType)) { //$NON-NLS-1$
			List dialogFilters = new ArrayList();
			if (extensions == null || extensions.trim().length() == 0) {
				dialogFilters.add("*"); //$NON-NLS-1$
			} else {
				StringTokenizer st = new StringTokenizer(extensions.trim(), ","); //$NON-NLS-1$
				while (st.hasMoreTokens()) {
					dialogFilters.add(st.nextToken().trim());
				}
			}
			dialog = new FileSelectionDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), AcceleoChainUIMessages
					.getString("AcceleoSetModuleParametersWizardPage.FileSelectionMessage"), 1, (String[]) dialogFilters //$NON-NLS-1$
					.toArray(new String[dialogFilters.size()]), true);
		} else {
			return;
		}
		dialog.open();
		if (dialog.getResult() != null && dialog.getResult().length > 0) {
			if (dialog.getResult()[0] instanceof IPath) {
				parameterText[parameterIndex].setText(((IPath) dialog.getResult()[0]).toString());
			} else if (dialog.getResult()[0] instanceof IResource) {
				parameterText[parameterIndex].setText(((IResource) dialog.getResult()[0]).getFullPath().toString());
			}
		}
		dialogChanged();
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		if (parameterText == null || parameterText.length == 0) {
			updateStatus(AcceleoChainUIMessages.getString("AcceleoSetModuleParametersWizardPage.EmptyField")); //$NON-NLS-1$
			parameterValues = new String[] {};
			return;
		}
		parameterValues = new String[parameterText.length];
		for (int i = 0; i < parameterText.length; i++) {
			if (parameterText[i] == null || parameterText[i].getText() == null || parameterText[i].getText().trim().length() == 0) {
				updateStatus(AcceleoChainUIMessages.getString("AcceleoSetModuleParametersWizardPage.EmptyField")); //$NON-NLS-1$
				parameterValues = new String[] {};
				return;
			} else {
				parameterValues[i] = parameterText[i].getText();
			}
		}
		updateStatus(null);
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

}
