/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;

import fr.obeo.acceleo.tools.ui.AcceleoToolsUiPlugin;

/**
 * The label provider to select the module with the wizard page.
 * 
 * @author www.obeo.fr
 * 
 */
public class SelectModuleLabelProvider implements ILabelProvider {

	/**
	 * The image for the launchers.
	 */
	private static final Image launcherImage = AcceleoToolsUiPlugin.getImageDescriptor("icons/plugins/bundle.gif").createImage(); //$NON-NLS-1$

	/**
	 * The image for the categories.
	 */
	private static final Image categoryImage = AcceleoToolsUiPlugin.getImageDescriptor("icons/plugins/registry.gif").createImage(); //$NON-NLS-1$

	/**
	 * Constructor.
	 */
	public SelectModuleLabelProvider() {
	}

	/* (non-Javadoc) */
	public Image getImage(Object element) {
		if (element instanceof IConfigurationElement) {
			return launcherImage;
		} else if (element instanceof String) {
			return categoryImage;
		} else {
			return null;
		}
	}

	/* (non-Javadoc) */
	public String getText(Object element) {
		if (element instanceof IConfigurationElement) {
			String text = ((IConfigurationElement) element).getAttribute("title"); //$NON-NLS-1$
			if (text == null)
				text = ""; //$NON-NLS-1$
			return text;
		} else if (element instanceof String) {
			return (String) element;
		} else {
			return "UNKNOWN"; //$NON-NLS-1$
		}
	}

	/* (non-Javadoc) */
	public void addListener(ILabelProviderListener arg0) {
	}

	/* (non-Javadoc) */
	public void dispose() {
	}

	/* (non-Javadoc) */
	public boolean isLabelProperty(Object arg0, String arg1) {
		return false;
	}

	/* (non-Javadoc) */
	public void removeListener(ILabelProviderListener arg0) {
	}

}
