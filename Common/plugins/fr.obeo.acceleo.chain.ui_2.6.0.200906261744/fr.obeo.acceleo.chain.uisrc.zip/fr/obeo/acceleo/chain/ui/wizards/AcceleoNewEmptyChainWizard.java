/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainFactory;
import fr.obeo.acceleo.chain.Repository;
import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.chain.ui.AcceleoChainUiPlugin;
import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoNewFileWizardPage;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * The role of this wizard is to create an empty chain.
 * 
 * @author www.obeo.fr
 */
public class AcceleoNewEmptyChainWizard extends Wizard implements INewWizard {

	/**
	 * The page to create a new file.
	 */
	protected AcceleoNewFileWizardPage pageNewFile;

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoNewEmptyChainWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/* (non-Javadoc) */
	public void addPages() {
		addPage(pageNewFile = new AcceleoNewFileWizardPage(AcceleoChainUIMessages.getString("AcceleoNewEmptyChainWizard.Title"), selection, "chain")); //$NON-NLS-1$ //$NON-NLS-2$
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String containerName = pageNewFile.getContainerName();
		final String fileName = pageNewFile.getFileName();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(containerName, fileName, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e.getTargetException(), true);
			return false;
		}
		return true;
	}

	private void doFinish(String containerName, String fileName, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask(AcceleoChainUIMessages.getString("Task.CreateFile", new Object[] { fileName, }), 2); //$NON-NLS-1$
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IResource resource = root.findMember(new Path(containerName));
		if (resource == null || !resource.exists() || !(resource instanceof IContainer)) {
			AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("MissingContainer", new Object[] { containerName, }), true); //$NON-NLS-1$
		} else {
			IContainer container = (IContainer) resource;
			IPath path = container.getFullPath().append(new Path(fileName));
			createChainFile(path, monitor);
			monitor.worked(1);
			final IFile file = root.getFile(path);
			if (file.exists()) {
				monitor.setTaskName(AcceleoChainUIMessages.getString("AcceleoNewEmptyChainWizard.Task.OpenChain")); //$NON-NLS-1$
				getShell().getDisplay().asyncExec(new Runnable() {
					public void run() {
						IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
						try {
							IDE.openEditor(page, file, true);
						} catch (PartInitException e) {
						}
					}
				});
			}
			monitor.worked(1);
		}
	}

	private void createChainFile(IPath path, IProgressMonitor monitor) {
		try {
			URI chainURI = Resources.createPlatformResourceURI(path.toString());
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
			Resource chainResource = resourceSet.createResource(chainURI);
			chainResource.getContents().add((EObject) createChainContent(path));
			chainResource.save(Collections.EMPTY_MAP);
			chainResource.unload();
		} catch (Exception e) {
			AcceleoChainUiPlugin.getDefault().log(e, true);
		} finally {
			monitor.done();
		}
	}

	/**
	 * Creates and returns the root element of the chain to create.
	 * 
	 * @param path
	 *            is the full path of the chain
	 * @return the root element of the chain to create
	 * @throws FactoryException
	 * @throws CoreException
	 */
	protected Object createChainContent(IPath path) throws FactoryException, CoreException {
		Chain chain = ChainFactory.eINSTANCE.createChain();
		// Repository
		Repository repository = ChainFactory.eINSTANCE.createRepository();
		EFactory.eSet(chain, "repository", repository); //$NON-NLS-1$
		// Action Set
		ActionSet actionSet = ChainFactory.eINSTANCE.createActionSet();
		EFactory.eAdd(chain, "actions", actionSet); //$NON-NLS-1$
		return chain;
	}

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		setWindowTitle(AcceleoChainUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}

}
