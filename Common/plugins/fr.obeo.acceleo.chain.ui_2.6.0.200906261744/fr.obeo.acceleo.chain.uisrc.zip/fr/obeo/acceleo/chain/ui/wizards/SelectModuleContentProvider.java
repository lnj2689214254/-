/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

/**
 * The content provider to select the module with the wizard page.
 * 
 * @author www.obeo.fr
 * 
 */
public class SelectModuleContentProvider implements ITreeContentProvider {

	/**
	 * The module extension point.
	 */
	private final static String MODULE_EXTENSION_ID = "fr.obeo.acceleo.gen.module"; //$NON-NLS-1$

	/**
	 * The extension of the file to launch.
	 */
	private String launcherExtension;

	/**
	 * Constructor.
	 * 
	 * @param launcherExtension
	 *            is the extension of the file to launch
	 */
	public SelectModuleContentProvider(String launcherExtension) {
		super();
		this.launcherExtension = launcherExtension;
	}

	private IExtensionRegistry registry;

	/**
	 * 
	 * @return a collection of IConfigurationElement representing all the
	 *         modules
	 */
	private Collection getModules() {
		Collection result = new LinkedList();
		IExtensionPoint extensionPoint = registry.getExtensionPoint(MODULE_EXTENSION_ID);
		if (extensionPoint != null) {
			IExtension[] extensions = extensionPoint.getExtensions();
			for (int i = 0; i < extensions.length; i++) {
				IExtension extension = extensions[i];
				IConfigurationElement[] members = extension.getConfigurationElements();
				for (int j = 0; j < members.length; j++) {
					IConfigurationElement member = members[j];
					if (!result.contains(member)) {
						String chainPath = member.getAttribute("chainPath"); //$NON-NLS-1$
						if (chainPath != null && chainPath.endsWith("." //$NON-NLS-1$
								+ launcherExtension)) {
							result.add(member);
						}
					}
				}
			}
		}
		return result;

	}

	/* (non-Javadoc) */
	public Object[] getElements(Object element) {
		if (element instanceof IExtensionRegistry) {
			registry = (IExtensionRegistry) element;
			List result = new ArrayList();
			Iterator it = getModules().iterator();
			while (it.hasNext()) {
				Object obj = getCategory((IConfigurationElement) it.next());
				if (!result.contains(obj))
					result.add(obj);
			}
			Collections.sort(result, new Comparator() {
				public int compare(Object arg0, Object arg1) {
					String s0;
					String s1;
					if (arg0 instanceof IConfigurationElement) {
						s0 = ((IConfigurationElement) arg0).getAttribute("title"); //$NON-NLS-1$
					} else if (arg0 instanceof String) {
						s0 = (String) arg0;
					} else {
						return 1;
					}
					if (arg1 instanceof IConfigurationElement) {
						s1 = ((IConfigurationElement) arg1).getAttribute("title"); //$NON-NLS-1$
					} else if (arg1 instanceof String) {
						s1 = (String) arg1;
					} else {
						return 1;
					}
					return s0.compareTo(s1);
				}
			});
			return result.toArray();
		} else {
			return new Object[] {};
		}
	}

	/**
	 * Keep a singleton String for each category
	 */
	Map categoryMap = new HashMap();

	/**
	 * Return the corresponding category
	 * 
	 * @param member
	 * @return the corresponding category or the element if there is no category
	 */
	private Object getCategory(IConfigurationElement member) {
		String cat = member.getAttribute("category"); //$NON-NLS-1$
		// if there is no category just
		if (cat == null)
			return member;
		if (!categoryMap.containsKey(cat))
			categoryMap.put(cat, cat);
		return categoryMap.get(cat);
	}

	/* (non-Javadoc) */
	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof String) {
			Collection result = new ArrayList();
			Iterator it = getModules().iterator();
			while (it.hasNext()) {
				IConfigurationElement element = (IConfigurationElement) it.next();
				if (element.getAttribute("category") != null && element.getAttribute("category").equals(parentElement)) //$NON-NLS-1$ //$NON-NLS-2$
					result.add(element);
			}
			return result.toArray();
		}
		return null;
	}

	/* (non-Javadoc) */
	public Object getParent(Object element) {
		return null;
	}

	/* (non-Javadoc) */
	public boolean hasChildren(Object element) {
		return (element instanceof String);
	}

	/* (non-Javadoc) */
	public void dispose() {
	}

	/* (non-Javadoc) */
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
	}

}
