/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;

import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainFactory;
import fr.obeo.acceleo.chain.EmfMetamodel;
import fr.obeo.acceleo.chain.Folder;
import fr.obeo.acceleo.chain.Generate;
import fr.obeo.acceleo.chain.Generator;
import fr.obeo.acceleo.chain.Log;
import fr.obeo.acceleo.chain.Model;
import fr.obeo.acceleo.chain.Repository;
import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoNewFileWizardPage;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoSelectFilesWizardPage;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoSelectMetamodelWizardPage;

/**
 * The role of this wizard is to create a chain.
 * 
 * @author www.obeo.fr
 */
public class AcceleoNewChainWizard extends AcceleoNewEmptyChainWizard {

	/**
	 * The page to select the metamodel.
	 */
	protected AcceleoSelectMetamodelWizardPage pageSelectMetamodel;

	private String metamodelURI;

	/**
	 * The page to select the model.
	 */
	protected AcceleoSelectFilesWizardPage pageSelectModel;

	private String modelPath;

	/**
	 * The page to select the scripts.
	 */
	protected AcceleoSelectFilesWizardPage pageSelectScripts;

	private IPath[] scripts;

	/**
	 * Constructor.
	 */
	public AcceleoNewChainWizard() {
		super();
	}

	/* (non-Javadoc) */
	public void addPages() {
		addPage(pageSelectMetamodel = new AcceleoSelectMetamodelWizardPage(AcceleoChainUIMessages.getString("AcceleoNewChainWizard.Page1.Title"), new String[] { "ecore" })); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageSelectModel = new AcceleoSelectFilesWizardPage(AcceleoChainUIMessages.getString("AcceleoNewChainWizard.Page2.Title"), 1, 1, new String[] { "*" }, false)); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageSelectScripts = new AcceleoSelectFilesWizardPage(
				AcceleoChainUIMessages.getString("AcceleoNewChainWizard.Page3.Title"), 1, -1, new String[] { SpecificScript.GENERATORS_EXTENSION }, true)); //$NON-NLS-1$
		addPage(pageNewFile = new AcceleoNewFileWizardPage(AcceleoChainUIMessages.getString("AcceleoNewChainWizard.Page4.Title"), selection, "chain")); //$NON-NLS-1$ //$NON-NLS-2$
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		metamodelURI = pageSelectMetamodel.getMetamodelURI();
		modelPath = pageSelectModel.getSelection()[0].toString();
		scripts = pageSelectScripts.getSelection();
		return super.performFinish();
	}

	/* (non-Javadoc) */
	protected Object createChainContent(IPath path) throws FactoryException, CoreException {
		// Create root element
		Chain chain = ChainFactory.eINSTANCE.createChain();
		// Repository
		Repository repository = ChainFactory.eINSTANCE.createRepository();
		EFactory.eSet(chain, "repository", repository); //$NON-NLS-1$
		// Action Set
		ActionSet actionSet = ChainFactory.eINSTANCE.createActionSet();
		EFactory.eAdd(chain, "actions", actionSet); //$NON-NLS-1$
		// Model file
		Model model = ChainFactory.eINSTANCE.createModel();
		EFactory.eAdd(repository, "files", model); //$NON-NLS-1$
		EFactory.eSet(model, "path", modelPath); //$NON-NLS-1$
		// Target folder
		Folder folder = ChainFactory.eINSTANCE.createFolder();
		EFactory.eAdd(repository, "files", folder); //$NON-NLS-1$
		EFactory.eSet(folder, "path", path.removeLastSegments(1).toString()); //$NON-NLS-1$
		// Log
		Log log = ChainFactory.eINSTANCE.createLog();
		EFactory.eAdd(repository, "files", log); //$NON-NLS-1$
		EFactory.eSet(log, "path", path.removeLastSegments(1).append(path.removeFileExtension().lastSegment() + ".log.txt").toString()); //$NON-NLS-1$ //$NON-NLS-2$
		// Metamodel file
		EmfMetamodel pim = ChainFactory.eINSTANCE.createEmfMetamodel();
		EFactory.eAdd(repository, "files", pim); //$NON-NLS-1$
		EFactory.eSet(pim, "path", metamodelURI); //$NON-NLS-1$
		// Script files and generate actions
		for (int i = 0; i < scripts.length; i++) {
			Generator script = ChainFactory.eINSTANCE.createGenerator();
			EFactory.eAdd(repository, "files", script); //$NON-NLS-1$
			EFactory.eSet(script, "path", scripts[i].toString()); //$NON-NLS-1$
			Generate action = ChainFactory.eINSTANCE.createGenerate();
			EFactory.eAdd(actionSet, "actions", action); //$NON-NLS-1$
			EFactory.eSet(action, "documentation", scripts[i].removeFileExtension().lastSegment()); //$NON-NLS-1$
			EFactory.eSet(action, "folder", folder); //$NON-NLS-1$
			EFactory.eSet(action, "log", log); //$NON-NLS-1$
			EFactory.eSet(action, "metamodel", pim); //$NON-NLS-1$
			EFactory.eSet(action, "model", model); //$NON-NLS-1$
			EFactory.eSet(action, "generator", script); //$NON-NLS-1$
		}
		return chain;
	}

}
