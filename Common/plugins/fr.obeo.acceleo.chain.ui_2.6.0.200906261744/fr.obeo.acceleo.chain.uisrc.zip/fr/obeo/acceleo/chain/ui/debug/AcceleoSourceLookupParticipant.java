/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.debug;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupParticipant;

import fr.obeo.acceleo.gen.debug.ui.model.AcceleoStackFrame;

/**
 * The source lookup participant.
 * 
 * @author www.obeo.fr
 */
public class AcceleoSourceLookupParticipant extends AbstractSourceLookupParticipant {

	/* (non-Javadoc) */
	public String getSourceName(Object object) throws CoreException {
		if (object instanceof AcceleoStackFrame) {
			AcceleoStackFrame stackFrame = (AcceleoStackFrame) object;
			return stackFrame.getSourceName();
		}
		return null;
	}

	/* (non-Javadoc) */
	public Object[] findSourceElements(Object object) throws CoreException {
		Object[] result = null;
		if (object instanceof AcceleoStackFrame) {
			AcceleoStackFrame stackFrame = (AcceleoStackFrame) object;
			result = new Object[] { stackFrame.getStackInfo().getFile() };
		} else {
			result = super.findSourceElements(object);
		}
		return result;
	}

}
