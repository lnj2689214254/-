/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import org.eclipse.compare.Splitter;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;

import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;

/**
 * The role of this page is to select a module.
 * 
 * @author www.obeo.fr
 */

public class AcceleoSelectModuleWizardPage extends WizardPage {

	/**
	 * The description text.
	 */
	protected Text descriptionText;

	/**
	 * The selected module.
	 */
	private IConfigurationElement module = null;

	/**
	 * The extension of the file to create.
	 */
	private String launcherExtension;

	/**
	 * Constructor.
	 * 
	 * @param pageName
	 *            is the name of the page
	 * @param launcherExtension
	 *            is the extension of the file to create
	 */
	public AcceleoSelectModuleWizardPage(String pageName, String launcherExtension) {
		super(pageName);
		setTitle(pageName);
		setDescription(AcceleoChainUIMessages.getString("AcceleoSelectModuleWizardPage.Description")); //$NON-NLS-1$
		this.launcherExtension = launcherExtension;
	}

	/**
	 * Returns the selected module.
	 * 
	 * @return the selected module
	 */
	public IConfigurationElement getModule() {
		return module;
	}

	/* (non-Javadoc) */
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		container.setLayout(layout);
		layout.numColumns = 1;
		layout.verticalSpacing = 9;
		Composite splitter = new Splitter(container, SWT.VERTICAL);
		layout = new GridLayout();
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.verticalSpacing = 0;
		layout.horizontalSpacing = 0;
		layout.numColumns = 1;
		splitter.setLayout(layout);
		GridData gridData = new GridData(GridData.FILL_BOTH);
		gridData.verticalIndent = 1;
		splitter.setLayoutData(gridData);
		Composite modulesContainer = new Composite(splitter, SWT.NULL);
		layout = new GridLayout();
		modulesContainer.setLayout(layout);
		layout.numColumns = 1;
		layout.verticalSpacing = 9;
		Label label = new Label(modulesContainer, SWT.NULL);
		label.setText(AcceleoChainUIMessages.getString("AcceleoSelectModuleWizardPage.ModuleLabel") + ':'); //$NON-NLS-1$
		createModulesViewer(modulesContainer);
		Composite descriptionContainer = new Composite(splitter, SWT.NULL);
		layout = new GridLayout();
		descriptionContainer.setLayout(layout);
		layout.numColumns = 1;
		layout.verticalSpacing = 9;
		label = new Label(descriptionContainer, SWT.NULL);
		label.setText(AcceleoChainUIMessages.getString("AcceleoSelectModuleWizardPage.DescriptionLabel") + ':'); //$NON-NLS-1$
		descriptionText = new Text(descriptionContainer, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		GridData data = new GridData(GridData.GRAB_HORIZONTAL | GridData.GRAB_VERTICAL);
		data.heightHint = descriptionText.getLineHeight() * 11;
		data.widthHint = descriptionText.getLineHeight() * 39;
		descriptionText.setLayoutData(data);
		descriptionText.setEditable(false);
		dialogChanged();
		setControl(container);
	}

	private TreeViewer createModulesViewer(Composite parent) {
		Tree tree = new Tree(parent, SWT.MULTI | SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		GridData data = new GridData(GridData.FILL_HORIZONTAL | GridData.FILL_VERTICAL);
		tree.setLayoutData(data);
		TreeViewer treeViewer = new TreeViewer(tree);
		treeViewer.setLabelProvider(new SelectModuleLabelProvider());
		treeViewer.setContentProvider(new SelectModuleContentProvider(launcherExtension));
		treeViewer.setInput(Platform.getExtensionRegistry());
		treeViewer.addSelectionChangedListener(new ISelectionChangedListener() {
			public void selectionChanged(SelectionChangedEvent event) {
				if (!event.getSelection().isEmpty() && event.getSelection() instanceof StructuredSelection) {
					StructuredSelection selection = (StructuredSelection) event.getSelection();
					if (selection.getFirstElement() instanceof IConfigurationElement) {
						module = (IConfigurationElement) selection.getFirstElement();
						String description = module.getAttribute("description"); //$NON-NLS-1$
						if (description == null)
							description = ""; //$NON-NLS-1$
						descriptionText.setText(description);
					} else {
						module = null;
					}
					dialogChanged();
				}
			}
		});
		return treeViewer;
	}

	/**
	 * Validates the changes on the page.
	 */
	private void dialogChanged() {
		if (module == null) {
			updateStatus(AcceleoChainUIMessages.getString("AcceleoSelectModuleWizardPage.EmptyModule")); //$NON-NLS-1$
		} else {
			updateStatus(null);
		}
	}

	/**
	 * Updates the status of the page.
	 * 
	 * @param message
	 *            is the error message.
	 */
	private void updateStatus(String message) {
		setMessage(message);
		setPageComplete(message == null);
	}

}
