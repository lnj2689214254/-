/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.ui.wizards;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainCall;
import fr.obeo.acceleo.chain.ChainFactory;
import fr.obeo.acceleo.chain.Repository;
import fr.obeo.acceleo.chain.tools.CLoaderUtils;
import fr.obeo.acceleo.chain.ui.AcceleoChainUIMessages;
import fr.obeo.acceleo.chain.ui.AcceleoChainUiPlugin;
import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.gen.ui.AcceleoEcoreGenUiPlugin;
import fr.obeo.acceleo.gen.ui.wizards.AcceleoNewFileWizardPage;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * The role of this wizard is to create a chain that contains a chain call.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoNewModuleLauncherWizard extends Wizard implements INewWizard {

	/**
	 * The page to select a module.
	 */
	protected AcceleoSelectModuleWizardPage pageSelectModule;

	/**
	 * The page to create a new file.
	 */
	protected AcceleoNewFileWizardPage pageNewFile;

	/**
	 * The page to configure the parameters of the chain call.
	 */
	protected AcceleoSetModuleParametersWizardPage pageSetModuleParameters;

	/**
	 * The current selection.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoNewModuleLauncherWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/* (non-Javadoc) */
	public void addPages() {
		addPage(pageSelectModule = new AcceleoSelectModuleWizardPage(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.Page1.Title"), "chain")); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageNewFile = new AcceleoNewFileWizardPage(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.Page2.Title"), selection, "chain")); //$NON-NLS-1$ //$NON-NLS-2$
		addPage(pageSetModuleParameters = new AcceleoSetModuleParametersWizardPage(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.Page3.Title"), pageSelectModule, pageNewFile)); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	public IWizardPage getNextPage(IWizardPage page) {
		IWizardPage nextPage = super.getNextPage(page);
		if (nextPage == pageSetModuleParameters) {
			pageSetModuleParameters.refreshControl();
		}
		return nextPage;
	}

	/* (non-Javadoc) */
	public boolean performFinish() {
		final String containerName = pageNewFile.getContainerName();
		final String fileName = pageNewFile.getFileName();
		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					doFinish(containerName, fileName, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};
		try {
			getContainer().run(true, false, op);
		} catch (InterruptedException e) {
			return false;
		} catch (InvocationTargetException e) {
			AcceleoEcoreGenUiPlugin.getDefault().log(e.getTargetException(), true);
			return false;
		}
		return true;
	}

	private void doFinish(String containerName, String fileName, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask(AcceleoChainUIMessages.getString("Task.CreateFile", new Object[] { fileName, }), 1); //$NON-NLS-1$
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IResource resource = root.findMember(new Path(containerName));
		if (resource == null || !resource.exists() || !(resource instanceof IContainer)) {
			AcceleoEcoreGenUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("MissingContainer", new Object[] { containerName, }), true); //$NON-NLS-1$
		} else {
			IContainer container = (IContainer) resource;
			IPath path = container.getFullPath().append(new Path(fileName));
			createChainFile(path, monitor);
			initModels(monitor);
			monitor.worked(1);
		}
	}

	private void createChainFile(IPath path, IProgressMonitor monitor) {
		try {
			URI chainURI = Resources.createPlatformResourceURI(path.toString());
			ResourceSet resourceSet = new ResourceSetImpl();
			resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
			Resource chainResource = resourceSet.createResource(chainURI);
			chainResource.getContents().add((EObject) createChainContent());
			chainResource.save(Collections.EMPTY_MAP);
			chainResource.unload();
		} catch (Exception e) {
			AcceleoChainUiPlugin.getDefault().log(e, true);
		} finally {
			monitor.done();
		}
	}

	/**
	 * Init the models if needed, copying the defaultFile attribute
	 * 
	 * @param monitor
	 *            current progress monitor
	 */
	protected void initModels(IProgressMonitor monitor) {
		String[] callParameterValues = pageSetModuleParameters.getParameterValues();
		// here we keep the parameter descriptions
		List moduleParameters = new ArrayList();
		Bundle bundle = Platform.getBundle(pageSelectModule.getModule().getNamespaceIdentifier());
		if (pageSelectModule.getModule() != null) {
			IConfigurationElement[] children = pageSelectModule.getModule().getChildren();
			for (int i = 0; i < children.length; i++) {
				IConfigurationElement parameter = children[i];
				moduleParameters.add(parameter);
			}
		}
		// let's check the parameter values and init the file if a dummy one is
		// provided
		for (int i = 0; i < callParameterValues.length; i++) {
			// if file is not existing
			IPath newFilePath = new Path(callParameterValues[i]);
			if (newFilePath.segmentCount() > 1) {
				IResource file = ResourcesPlugin.getWorkspace().getRoot().getFile(newFilePath);
				if (file instanceof IFile && !((IFile) file).exists()) {
					// if the module define a default file
					String defaultFilePath = ((IConfigurationElement) moduleParameters.get(i)).getAttribute("defaultFile");//$NON-NLS-1$
					if (defaultFilePath != null) {
						File defaultFile = AcceleoModuleProvider.getDefault().getFile(bundle.getSymbolicName(), new Path(defaultFilePath));
						if (defaultFile != null) {
							FileInputStream source;
							try {
								source = new FileInputStream(defaultFile);
								((IFile) file).create(source, true, monitor);
							} catch (FileNotFoundException e) {
								AcceleoChainUiPlugin.getDefault().log(e, false);
							} catch (CoreException e) {
								AcceleoChainUiPlugin.getDefault().log(e, false);
							}
						} else {
							AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.MissingInitializer", new Object[] { defaultFilePath, }), false); //$NON-NLS-1$
						}
					}
				}
			}
		}

	}

	/**
	 * Creates and returns the root element of the chain to create.
	 * 
	 * @return the root element of the chain to create
	 * @throws FactoryException
	 * @throws CoreException
	 */
	protected Object createChainContent() throws FactoryException, CoreException {
		String[] callParameterValues = pageSetModuleParameters.getParameterValues();
		String callPath = pageSelectModule.getModule().getAttribute("chainPath"); //$NON-NLS-1$
		if (callPath != null && Platform.getBundle(pageSelectModule.getModule().getNamespace()) != null) {
			Bundle bundle = Platform.getBundle(pageSelectModule.getModule().getNamespace());
			callPath = new Path(bundle.getSymbolicName()).append(callPath).toString();
		} else {
			AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.MissingChain", new Object[] { callPath, }), true); //$NON-NLS-1$
			callPath = ""; //$NON-NLS-1$
		}
		Chain chain = ChainFactory.eINSTANCE.createChain();
		// Repository
		Repository repository = ChainFactory.eINSTANCE.createRepository();
		EFactory.eSet(chain, "repository", repository); //$NON-NLS-1$
		// Action Set
		ActionSet actionSet = ChainFactory.eINSTANCE.createActionSet();
		EFactory.eAdd(chain, "actions", actionSet); //$NON-NLS-1$
		// Chain Call
		ChainCall chainCall = ChainFactory.eINSTANCE.createChainCall();
		actionSet.getActions().add(chainCall);
		chainCall.setChainPath(callPath);
		chainCall.setDocumentation(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.ChainCallDocumentation", new Object[] { callPath, })); //$NON-NLS-1$
		Chain calledChain = getCalledChain(new Path(callPath));
		if (calledChain != null) {
			if (callParameterValues.length != (calledChain.getParametersFiles().size() + calledChain.getParametersPatterns().size())) {
				AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.InvalidParameters", new Object[] { callPath, }), true); //$NON-NLS-1$
			}
			int i = 0;
			Iterator parameterFiles = calledChain.getParametersFiles().iterator();
			while (parameterFiles.hasNext()) {
				EObject newParameterFile = EcoreUtil.copy((EObject) parameterFiles.next());
				EFactory.eSet(newParameterFile, "path", callParameterValues[i]); //$NON-NLS-1$
				repository.getFiles().add(newParameterFile);
				chainCall.getArgumentsFiles().add(newParameterFile);
				i++;
			}
			for (int j = i; j < callParameterValues.length; j++) {
				chainCall.getArgumentsPatterns().add(callParameterValues[j]);
			}
		} else {
			AcceleoChainUiPlugin.getDefault().log(AcceleoChainUIMessages.getString("AcceleoNewModuleLauncherWizard.MissingChain", new Object[] { callPath, }), true); //$NON-NLS-1$
		}
		return chain;
	}

	private Chain getCalledChain(IPath callPath) {
		IFile workspaceFile = ResourcesPlugin.getWorkspace().getRoot().getFile(callPath);
		if (workspaceFile.exists()) {
			return CLoaderUtils.getCChainForChainFile(workspaceFile);
		} else {
			File file = AcceleoModuleProvider.getDefault().getFile(callPath);
			if (file != null && file.exists()) {
				URI chainURI = URI.createFileURI(file.getAbsolutePath());
				return CLoaderUtils.getCChainForChainURI(chainURI);
			}
		}
		return null;
	}

	/* (non-Javadoc) */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
		setWindowTitle(AcceleoChainUIMessages.getString("WizardMainTitleLabel")); //$NON-NLS-1$
	}
}
