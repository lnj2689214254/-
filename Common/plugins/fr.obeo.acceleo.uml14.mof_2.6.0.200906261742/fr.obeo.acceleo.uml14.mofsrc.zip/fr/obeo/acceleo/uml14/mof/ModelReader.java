package fr.obeo.acceleo.uml14.mof;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jmi.reflect.RefEnum;
import javax.jmi.reflect.RefFeatured;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.omg.uml.UmlPackage;
import org.omg.uml.modelmanagement.Model;
import org.omg.uml.modelmanagement.ModelManagementPackage;

import fr.obeo.acceleo.ecore.factories.EFactory;
import fr.obeo.acceleo.ecore.factories.Factories;
import fr.obeo.acceleo.ecore.factories.FactoryException;

/**
 * Read an UML 1.4 model from a MDR xmi file.
 */
public class ModelReader {

	/**
	 * Uml14 nsURI.
	 */
	protected static final String UML14_URI = "http://www.obeo.fr/acceleo/uml14"; //$NON-NLS-1$

	/**
	 * MDR xmi file location.
	 */
	protected String xmiLocation = ""; //$NON-NLS-1$

	/**
	 * Loads a MDR xmi file.
	 * 
	 * @param xmiLocation
	 *            is the MDR xmi file location
	 */
	public void loadMdrUml14(String xmiLocation) {
		this.xmiLocation = xmiLocation;
	}

	/**
	 * Creates an UML 1.4 model for EMF.
	 * 
	 * @param xmiPath
	 *            is the file to create
	 * @throws FactoryException
	 * @throws ModelReaderException
	 */
	public void saveAsEmfUml14(String xmiPath) throws FactoryException, ModelReaderException {
		ModelReaderException exception = null;
		Factories emfFactories = new Factories(UML14_URI, ModelReader.class.getClassLoader());
		StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
		EObject root = mdr2emf(emfFactories, report);
		URI xmiURI = URI.createFileURI(xmiPath);
		ResourceSet resourceSet = new ResourceSetImpl();
		resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(Resource.Factory.Registry.DEFAULT_EXTENSION, new XMIResourceFactoryImpl());
		Resource xmiResource = resourceSet.createResource(xmiURI);
		if (root != null) {
			try {
				xmiResource.getContents().add(root);
				Map options = new HashMap();
				options.put(XMLResource.OPTION_ENCODING, System.getProperty("file.encoding")); //$NON-NLS-1$
				xmiResource.save(options);
				xmiResource.unload();
			} catch (IOException e) {
				exception = new ModelReaderException(AcceleoUML14MofMessages.getString("ModelReader.SaveIOFailure", new Object[] { xmiURI.toFileString(), e.getMessage(), }), true); //$NON-NLS-1$
			}
		} else {
			exception = new ModelReaderException(AcceleoUML14MofMessages.getString("ModelReader.SaveRootFailure", new Object[] { xmiURI.toFileString(), }), true); //$NON-NLS-1$
		}
		if (exception == null && report.length() > 0) {
			exception = new ModelReaderException(AcceleoUML14MofMessages.getString("ModelReader.ReaderWarning", new Object[] { xmiPath, }) + ": \n" + report, false); //$NON-NLS-1$ //$NON-NLS-2$
		}
		if (exception != null) {
			throw exception;
		}
	}

	private EObject mdr2emf(Factories emfFactories, StringBuffer report) throws FactoryException {
		MDRepository repository = new MDRepository();
		UmlPackage umlPackage = repository.readModel(xmiLocation);
		ModelManagementPackage modelManagementPackage = umlPackage.getModelManagement();
		Model model = (Model) (modelManagementPackage.getModel().refAllOfType().iterator().next());
		EObject emfRoot = mdr2emfCreateObjects(model, emfFactories, report);
		mdr2emfFeatures(model, emfRoot, report);
		mdr2emf.clear();
		repository.clear();
		return emfRoot;
	}

	private EObject mdr2emfCreateObjects(RefFeatured mdrParent, Factories emfFactories, StringBuffer report) throws FactoryException {
		EObject emfParent = (EObject) mdr2emf.get(mdrParent);
		if (emfParent == null) {
			String metaObjectName = (String) mdrParent.refMetaObject().refGetValue("name"); //$NON-NLS-1$
			emfParent = emfFactories.create(metaObjectName);
			Iterator it = emfParent.eClass().getEAllReferences().iterator();
			while (it.hasNext()) {
				EReference eReference = (EReference) it.next();
				if (eReference.isContainment()) {
					Object mdrObject = mdrParent.refGetValue(eReference.getName());
					if (mdrObject != null) {
						if (mdrObject instanceof Collection) {
							for (Iterator i = ((Collection) mdrObject).iterator(); i.hasNext();) {
								RefFeatured mdrChild = (RefFeatured) i.next();
								EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report);
								EFactory.eAdd(emfParent, eReference.getName(), emfChild);
							}
						} else if (mdrObject instanceof Object[]) {
							Object[] tab = (Object[]) mdrObject;
							for (int i = 0; i < tab.length; i++) {
								RefFeatured mdrChild = (RefFeatured) tab[i];
								EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report);
								EFactory.eAdd(emfParent, eReference.getName(), emfChild);
							}
						} else if (mdrObject instanceof RefFeatured) {
							RefFeatured mdrChild = (RefFeatured) mdrObject;
							EObject emfChild = mdr2emfCreateObjects(mdrChild, emfFactories, report);
							EFactory.eSet(emfParent, eReference.getName(), emfChild);
						} else {
							report.append(AcceleoUML14MofMessages.getString("ModelReader.UnknownType", new Object[] { mdrObject.getClass().getName(), })); //$NON-NLS-1$
							report.append('\n');
						}
					}
				}
			}
			mdr2emf.put(mdrParent, emfParent);
		}
		return emfParent;
	}

	private Map mdr2emf = new HashMap();

	private void mdr2emfFeatures(RefFeatured mdrParent, EObject emfParent, StringBuffer report) throws FactoryException {
		// Attributes
		Iterator it = emfParent.eClass().getEAllAttributes().iterator();
		while (it.hasNext()) {
			EAttribute eAttribute = (EAttribute) it.next();
			mdr2emfFeature(mdrParent, emfParent, eAttribute, report);
		}
		// References
		it = emfParent.eClass().getEAllReferences().iterator();
		while (it.hasNext()) {
			EReference eReference = (EReference) it.next();
			if (!eReference.isContainment()) {
				mdr2emfFeature(mdrParent, emfParent, eReference, report);
			} else {
				Object mdrObject = mdrParent.refGetValue(eReference.getName());
				if (mdrObject != null) {
					if (mdrObject instanceof Collection) {
						for (Iterator i = ((Collection) mdrObject).iterator(); i.hasNext();) {
							RefFeatured mdrChild = (RefFeatured) i.next();
							EObject emfChild = (EObject) mdr2emf.get(mdrChild);
							mdr2emfFeatures(mdrChild, emfChild, report);
						}
					} else if (mdrObject instanceof Object[]) {
						Object[] tab = (Object[]) mdrObject;
						for (int i = 0; i < tab.length; i++) {
							RefFeatured mdrChild = (RefFeatured) tab[i];
							EObject emfChild = (EObject) mdr2emf.get(mdrChild);
							mdr2emfFeatures(mdrChild, emfChild, report);
						}
					} else if (mdrObject instanceof RefFeatured) {
						RefFeatured mdrChild = (RefFeatured) mdrObject;
						EObject emfChild = (EObject) mdr2emf.get(mdrChild);
						mdr2emfFeatures(mdrChild, emfChild, report);
					} else {
						report.append(AcceleoUML14MofMessages.getString("ModelReader.UnknownType", new Object[] { mdrObject.getClass().getName(), })); //$NON-NLS-1$
						report.append('\n');
					}
				}
			}
		}
	}

	private void mdr2emfFeature(RefFeatured mdrParent, EObject emfParent, EStructuralFeature feature, StringBuffer report) throws FactoryException {
		Object mdrChild;
		try {
			mdrChild = mdrParent.refGetValue(feature.getName());
		} catch (Exception e) {
			mdrChild = null;
		}
		mdr2emfFeature(mdrChild, mdrParent, emfParent, feature, report);
	}

	private void mdr2emfFeature(Object mdrChild, RefFeatured mdrParent, EObject emfParent, EStructuralFeature feature, StringBuffer report) throws FactoryException {
		if (mdrChild != null) {
			if (mdrChild instanceof Collection) {
				for (Iterator it = ((Collection) mdrChild).iterator(); it.hasNext();) {
					mdr2emfFeature(it.next(), mdrParent, emfParent, feature, report);
				}
			} else if (mdrChild instanceof Object[]) {
				Object[] tab = (Object[]) mdrChild;
				for (int i = 0; i < tab.length; i++) {
					mdr2emfFeature(tab[i], mdrParent, emfParent, feature, report);
				}
			} else if (mdrChild instanceof RefFeatured) {
				EObject emfChild = (EObject) mdr2emf.get(mdrChild);
				EFactory.eAdd(emfParent, feature.getName(), emfChild);
			} else if (mdrChild instanceof Integer) {
				EFactory.eAdd(emfParent, feature.getName(), new Long(((Integer) mdrChild).longValue()));
			} else if (mdrChild instanceof String || mdrChild instanceof Long || mdrChild instanceof Double || mdrChild instanceof Boolean) {
				EFactory.eAdd(emfParent, feature.getName(), mdrChild);
			} else if (mdrChild instanceof RefEnum) {
				RefEnum refEnum = (RefEnum) mdrChild;
				EFactory.eSet(emfParent, feature.getName(), refEnum.toString(), AcceleoUml14MofPlugin.class.getClassLoader());
			} else {
				report.append(AcceleoUML14MofMessages.getString("ModelReader.UnknownType", new Object[] { mdrChild.getClass().getName(), })); //$NON-NLS-1$
				report.append('\n');
			}
		}
	}

}