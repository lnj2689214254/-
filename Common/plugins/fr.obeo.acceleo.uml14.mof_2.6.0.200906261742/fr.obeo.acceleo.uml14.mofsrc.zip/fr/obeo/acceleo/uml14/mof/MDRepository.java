/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.uml14.mof;

import org.andromda.repositories.mdr.MDRepositoryFacade;
import org.omg.uml.UmlPackage;

/**
 * Encapsulates a MDR repository facade.
 * 
 * @author www.obeo.fr
 * 
 */
public class MDRepository {

	/**
	 * The MDR repository facade.
	 */
	protected MDRepositoryFacade repository;

	/**
	 * Constructor.
	 */
	public MDRepository() {
		repository = new MDRepositoryFacade();
		repository.open();
	}

	/**
	 * Reads a MDR model and returns the root element.
	 * 
	 * @param xmiLocation
	 *            is the MDR xmi file location
	 * @return the root element
	 */
	public UmlPackage readModel(String xmiLocation) {
		if (xmiLocation.startsWith("/")) { //$NON-NLS-1$
			xmiLocation = '/' + xmiLocation;
		}
		repository.readModel(new String[] { "file:/" + xmiLocation }, null); //$NON-NLS-1$
		UmlPackage umlPackage = (UmlPackage) repository.getModel().getModel();
		return umlPackage;
	}

	/**
	 * It clears the repository facade.
	 */
	public void clear() {
		repository.clear();
	}

}
