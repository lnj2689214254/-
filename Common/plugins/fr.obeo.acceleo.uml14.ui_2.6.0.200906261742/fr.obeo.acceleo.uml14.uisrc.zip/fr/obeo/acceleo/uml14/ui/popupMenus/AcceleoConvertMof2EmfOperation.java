/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.uml14.ui.popupMenus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.uml14.ui.AcceleoUml14UiPlugin;

/**
 * The operation which convert the current selected xmi from MOF to EMF.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoConvertMof2EmfOperation extends WorkspaceModifyOperation {

	/**
	 * Uml14 EMF file extension.
	 */
	protected static final String UML14_EXTENSION = "uml14"; //$NON-NLS-1$

	/**
	 * Selected xmi file.
	 */
	protected IFile file;

	/**
	 * Path of the new xmi. If it's null, the new file will have the same path
	 * as the MDR xmi but with the file extension "uml14".
	 */
	protected String resultPath;

	/**
	 * Constructor. The new file will have the same path as the MDR xmi but with
	 * the file extension "uml14".
	 * 
	 * @param file
	 *            is the selected xmi file
	 */
	public AcceleoConvertMof2EmfOperation(IFile file) {
		super();
		this.file = file;
		this.resultPath = null;
	}

	/**
	 * Constructor.
	 * 
	 * @param file
	 *            is the selected xmi file
	 * @param resultPath
	 *            is the path of the new xmi
	 */
	public AcceleoConvertMof2EmfOperation(IFile file, String resultPath) {
		super();
		this.file = file;
		this.resultPath = resultPath;
	}

	/* (non-Javadoc) */
	protected void execute(IProgressMonitor progressMonitor) throws CoreException {
		file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
		try {
			final String xmiLocation = file.getLocation().toString();
			final String resultPath = (this.resultPath != null) ? this.resultPath : new Path(xmiLocation).removeFileExtension().addFileExtension(UML14_EXTENSION).toString();
			Resources.getContainerOrCreateFolder(ResourcesPlugin.getWorkspace().getRoot(), new Path(resultPath).removeLastSegments(1), progressMonitor);
			Thread.currentThread().setContextClassLoader(AcceleoUml14UiPlugin.getMDClassLoader());
			// Remark : "loadClass + newInstance + getMethod + invoke" to
			// resolve class loader problems for MDR
			Class type = AcceleoUml14UiPlugin.getMDClassLoader().loadClass("fr.obeo.acceleo.uml14.mof.ModelReader"); //$NON-NLS-1$
			Object instance = type.newInstance();
			Method method = type.getMethod("loadMdrUml14", new Class[] { String.class }); //$NON-NLS-1$
			method.invoke(instance, new Object[] { xmiLocation });
			method = type.getMethod("saveAsEmfUml14", new Class[] { String.class }); //$NON-NLS-1$
			method.invoke(instance, new Object[] { resultPath });
		} catch (Throwable e) {
			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			if (e.getClass().getName().equals("fr.obeo.acceleo.uml14.mof.ModelReaderException")) { //$NON-NLS-1$
				// Remark : "loadClass + newInstance + getMethod + invoke" to
				// resolve class loader problems for MDR
				boolean blocking = true;
				try {
					Class type = Thread.currentThread().getContextClassLoader().loadClass("fr.obeo.acceleo.uml14.mof.ModelReaderException"); //$NON-NLS-1$
					Method method = type.getMethod("isBlocking", new Class[] {}); //$NON-NLS-1$
					blocking = !"false".equals(method.invoke(e, new Object[] {}).toString()); //$NON-NLS-1$
				} catch (Exception exception) {
					blocking = true;
				}
				AcceleoUml14UiPlugin.getDefault().log(e, blocking);
			} else {
				AcceleoUml14UiPlugin.getDefault().log(e, true);
			}
		} finally {
			Thread.currentThread().setContextClassLoader(oldClassLoader);
			file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		}
	}

}
