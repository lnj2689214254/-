/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.uml14.ui.popupMenus;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.uml14.ui.AcceleoUML14UIMessages;
import fr.obeo.acceleo.uml14.ui.AcceleoUml14UiPlugin;

/**
 * The action which convert the current selected xmi from MOF to EMF.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoConvertMof2EmfAction implements IObjectActionDelegate {

	/**
	 * Selected xmi file.
	 */
	protected ISelection selection;

	/**
	 * Constructor.
	 */
	public AcceleoConvertMof2EmfAction() {
		super();
	}

	/* (non-Javadoc) */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	/* (non-Javadoc) */
	public void run(IAction action) {
		try {
			IFile file = (IFile) ((StructuredSelection) selection).getFirstElement();
			AcceleoConvertMof2EmfOperation operation = new AcceleoConvertMof2EmfOperation(file);
			PlatformUI.getWorkbench().getProgressService().run(false, false, operation);
		} catch (InvocationTargetException e) {
			AcceleoUml14UiPlugin.getDefault().log(e, true);
		} catch (InterruptedException e) {
			AcceleoUml14UiPlugin.getDefault().log(AcceleoUML14UIMessages.getString("InterruptedOperation"), true); //$NON-NLS-1$
		}
	}

	/* (non-Javadoc) */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

}
