/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.uml14.ui.popupMenus;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.jaxen.JaxenException;
import org.jdom.Element;

import fr.obeo.acceleo.bridge.IXmiLoader;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.uml14.ui.AcceleoUml14UiPlugin;

/**
 * Specific andromda loader for XMI 1.X/UML14.
 * 
 * @author www.obeo.fr
 * 
 */
public class SpecificUml14XmiLoader implements IXmiLoader {

	private static final String umlExtension = "uml14"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public boolean validate(IFile file) {
		return true;
	}

	/* (non-Javadoc) */
	public void convert(IFile file, String resultPath, IProgressMonitor progressMonitor) throws CoreException {
		file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
		try {
			final String xmiLocation = file.getLocation().toString();
			if (resultPath == null) {
				resultPath = new Path(xmiLocation).removeFileExtension().addFileExtension(umlExtension).toString();
			}
			Resources.getContainerOrCreateFolder(ResourcesPlugin.getWorkspace().getRoot(), new Path(resultPath).removeLastSegments(1), progressMonitor);
			AcceleoConvertMof2EmfOperation operation = new AcceleoConvertMof2EmfOperation(file, resultPath);
			operation.run(progressMonitor);
		} catch (Throwable e) {
			if (e instanceof InvocationTargetException) {
				e = ((InvocationTargetException) e).getTargetException();
			}
			boolean blocking = true;
			if (e.getClass().getName().equals("fr.obeo.acceleo.bridge.ModelReaderException")) { //$NON-NLS-1$
				// Remark : "loadClass + newInstance + getMethod + invoke" to
				// resolve class loader problems for MDR
				try {
					Class type = Thread.currentThread().getContextClassLoader().loadClass("fr.obeo.acceleo.bridge.ModelReaderException"); //$NON-NLS-1$
					Method method = type.getMethod("isBlocking", new Class[] {}); //$NON-NLS-1$
					blocking = !"false".equals(method.invoke(e, new Object[] {}).toString()); //$NON-NLS-1$
				} catch (Exception exception) {
					blocking = true;
				}
			}
			throw new CoreException(new Status((blocking) ? IStatus.ERROR : IStatus.WARNING, AcceleoUml14UiPlugin.getDefault().getID(), IStatus.OK, e.getMessage(), e));
		} finally {
			Thread.currentThread().setContextClassLoader(oldClassLoader);
			file.getParent().refreshLocal(IResource.DEPTH_ONE, progressMonitor);
		}
	}

	/* (non-Javadoc) */
	public boolean hasInputTextChanged() {
		return false;
	}

	/* (non-Javadoc) */
	public String changeInputText(String input) {
		return input;
	}

	/* (non-Javadoc) */
	public boolean hasInputXmlChanged() {
		return true;
	}

	/* (non-Javadoc) */
	public void changeInputXml(Element input) throws JaxenException {
	}

	/* (non-Javadoc) */
	public String[] badStrings() {
		return new String[] {};
	}

}
