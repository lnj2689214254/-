/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.uml14.ui;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.Path;
import org.eclipse.help.internal.appserver.PluginClassLoaderWrapper;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import fr.obeo.acceleo.tools.ui.resources.AcceleoUIPlugin;

/**
 * The main plugin class to be used in the desktop.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoUml14UiPlugin extends AcceleoUIPlugin {

	/* (non-Javadoc) */
	public String getID() {
		return "fr.obeo.acceleo.uml14.ui"; //$NON-NLS-1$
	}

	/**
	 * The shared instance.
	 */
	private static AcceleoUml14UiPlugin plugin;

	/**
	 * Resource bundle.
	 */
	private ResourceBundle resourceBundle;

	/**
	 * The constructor.
	 */
	public AcceleoUml14UiPlugin() {
		super();
		plugin = this;
	}

	/* (non-Javadoc) */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/* (non-Javadoc) */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
		resourceBundle = null;
	}

	/**
	 * @return the shared instance
	 */
	public static AcceleoUml14UiPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 * 
	 * @param key
	 *            identifies the string
	 * @return the string from the plugin's resource bundle, or 'key' if not
	 *         found
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = AcceleoUml14UiPlugin.getDefault().getResourceBundle();
		try {
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle.
	 * 
	 * @return the plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		try {
			if (resourceBundle == null)
				resourceBundle = ResourceBundle.getBundle("fr.obeo.acceleo.uml14.ui.AcceleoUml14UiPluginResources"); //$NON-NLS-1$
		} catch (MissingResourceException x) {
			resourceBundle = null;
		}
		return resourceBundle;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            is a plug-in relative path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin("fr.obeo.acceleo.uml14.ui", path); //$NON-NLS-1$
	}

	/**
	 * Plugins to put in the MDR class loader.
	 */
	private static final String[] classLoaderWrappers = { "org.eclipse.ant.core", "org.eclipse.emf.ecore", "org.eclipse.emf.ecore.xmi", "fr.obeo.acceleo.tools", "fr.obeo.acceleo.uml14", //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
			"fr.obeo.acceleo.uml14.mof", "fr.obeo.acceleo.uml14.ui", "fr.obeo.acceleo.ecore" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

	/**
	 * Gets the MDR class loader.
	 * 
	 * @return the MDR class loader
	 * @throws MalformedURLException
	 */
	public static ClassLoader getMDClassLoader() throws MalformedURLException {
		if (classLoader == null) {
			List URLs = new ArrayList();
			for (int i = 0; i < classLoaderWrappers.length; i++) {
				String id = classLoaderWrappers[i];
				URLs.addAll(Arrays.asList(new PluginClassLoaderWrapper(id).getURLs()));
			}
			String location = new Path(System.getProperty("java.home")).toString() + "/lib/rt.jar"; //$NON-NLS-1$ //$NON-NLS-2$
			if (location.startsWith("/")) { //$NON-NLS-1$
				location = '/' + location;
			}
			URLs.add(new URL("file:/" + location)); //$NON-NLS-1$
			classLoader = new URLClassLoader((URL[]) URLs.toArray(new URL[URLs.size()]), AcceleoUml14UiPlugin.class.getClassLoader());
		}
		return classLoader;
	}

	private static ClassLoader classLoader;

}
