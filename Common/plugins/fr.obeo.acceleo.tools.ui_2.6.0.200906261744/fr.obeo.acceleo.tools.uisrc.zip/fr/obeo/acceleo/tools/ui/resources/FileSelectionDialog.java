/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.resources;

import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.ui.AcceleoToolsUIMessages;

import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.CheckStateChangedEvent;
import org.eclipse.jface.viewers.CheckboxTreeViewer;
import org.eclipse.jface.viewers.ICheckStateListener;
import org.eclipse.jface.viewers.IOpenListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.OpenEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.SelectionDialog;
import org.eclipse.ui.internal.ide.IIDEHelpContextIds;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.osgi.framework.Bundle;

/**
 * A standard file selection dialog.
 * 
 * @author www.obeo.fr
 * 
 */
public class FileSelectionDialog extends SelectionDialog {

	private final static String MODULE_EXTENSION_ID = "fr.obeo.acceleo.gen.module"; //$NON-NLS-1$

	/**
	 * The selection group.
	 */
	private CheckboxTreeAndListGroup checkboxGroup;

	/**
	 * The widget to enable the new file path.
	 */
	private Button newFilePathCheck;

	/**
	 * The widget to type the new file path.
	 */
	private Text newFilePathText;

	/**
	 * The widget to browse the workspace.
	 */
	private Button newFilePathButton;

	/**
	 * The length of the selection.
	 */
	private int multiplicity;

	/**
	 * The extensions.
	 */
	private String[] extensions;

	/**
	 * Indicates if the module's resources are included.
	 */
	private boolean includePlugins;

	// Constants
	private final static int SELECTION_WIDGET_WIDTH = 400;

	private final static int SELECTION_WIDGET_HEIGHT = 300;

	/**
	 * Constructor.
	 * 
	 * @param shell
	 *            is the parent shell
	 * @param message
	 *            is the message to be displayed
	 * @param multiplicity
	 *            is the length of the selection
	 * @param extensions
	 *            is a table of extensions
	 * @param includePlugins
	 *            indicates if the module's resources are included
	 */
	public FileSelectionDialog(Shell shell, String message, int multiplicity, String[] extensions, boolean includePlugins) {
		super(shell);
		setTitle("File Selection"); //$NON-NLS-1$
		setMessage((message != null) ? message : ""); //$NON-NLS-1$
		setShellStyle(getShellStyle() | SWT.RESIZE);
		this.multiplicity = multiplicity;
		this.extensions = extensions;
		this.includePlugins = includePlugins;
	}

	/* (non-Javadoc) */
	public void setInitialSelections(Object[] selectedElements) {
		List result = new ArrayList();
		for (int i = 0; i < selectedElements.length; i++) {
			IPath path = (IPath) selectedElements[i];
			if (path.segmentCount() >= 2) {
				IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(path);
				if (resource != null && resource.exists()) {
					result.add(resource);
				} else {
					Bundle bundle = Platform.getBundle(path.segment(0));
					if (bundle != null) {
						Enumeration entries = bundle.findEntries(path.removeFirstSegments(1).removeLastSegments(1).toString(), path.lastSegment(), false);
						if (entries != null && entries.hasMoreElements()) {
							result.add(path);
						}
					}
				}
			}
		}
		super.setInitialSelections(result.toArray());
	}

	/* (non-Javadoc) */
	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		PlatformUI.getWorkbench().getHelpSystem().setHelp(shell, IIDEHelpContextIds.RESOURCE_SELECTION_DIALOG);
	}

	/* (non-Javadoc) */
	public void create() {
		super.create();
		checkboxGroup.addCheckStateListener(new ICheckStateListener() {
			public void checkStateChanged(CheckStateChangedEvent event) {
				List items = getAllCheckedListItems();
				getOkButton().setEnabled((items.size() == multiplicity) || (multiplicity == -1 && items.size() > 0));
			}
		});
		if (getInitialElementSelections().isEmpty()) {
			getOkButton().setEnabled(false);
		} else {
			Iterator it = getInitialElementSelections().iterator();
			while (it.hasNext()) {
				Object currentElement = it.next();
				if (currentElement instanceof IFile) {
					checkboxGroup.initialCheckListItem(currentElement);
					checkboxGroup.getTreeViewer().setSelection(new StructuredSelection(((IFile) currentElement).getParent()), true);
				} else if (currentElement instanceof IPath) {
					if (((IPath) currentElement).segmentCount() > 0) {
						Bundle bundle = Platform.getBundle(((IPath) currentElement).segment(0));
						if (bundle != null) {
							checkboxGroup.initialCheckListItem(currentElement);
							checkboxGroup.getTreeViewer().setSelection(new StructuredSelection(bundle), true);
						}
					}
				} else {
					checkboxGroup.initialCheckTreeItem(currentElement);
				}
			}
		}
		checkboxGroup.getTreeViewer().addOpenListener(new IOpenListener() {
			public void open(OpenEvent event) {
				ISelection selection = event.getSelection();
				if (!selection.isEmpty() && selection instanceof StructuredSelection) {
					checkboxGroup.getTreeViewer().expandToLevel(((StructuredSelection) selection).getFirstElement(), CheckboxTreeViewer.ALL_LEVELS);
				}
			}
		});
	}

	/* (non-Javadoc) */
	protected Control createDialogArea(Composite parent) {
		Composite composite = (Composite) super.createDialogArea(parent);
		createMessageArea(composite);
		AcceleoWorkbenchLabelProvider treeLabelProvider = new AcceleoWorkbenchLabelProvider();
		AcceleoWorkbenchLabelProvider listLabelProvider = new AcceleoWorkbenchLabelProvider();
		checkboxGroup = new CheckboxTreeAndListGroup(composite, ResourcesPlugin.getWorkspace().getRoot(), getContentProvider(IResource.FOLDER | IResource.PROJECT | IResource.ROOT), treeLabelProvider,
				getContentProvider(IResource.FILE), listLabelProvider, SWT.NONE, SELECTION_WIDGET_WIDTH, SELECTION_WIDGET_HEIGHT);
		composite.addControlListener(new ControlListener() {
			public void controlMoved(ControlEvent e) {
			}

			public void controlResized(ControlEvent e) {
				TableColumn[] columns = checkboxGroup.getListTable().getColumns();
				for (int i = 0; i < columns.length; i++) {
					columns[i].pack();
				}
			}
		});

		Composite newComposite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		layout.marginHeight = convertVerticalDLUsToPixels(IDialogConstants.VERTICAL_MARGIN);
		layout.marginWidth = convertHorizontalDLUsToPixels(IDialogConstants.HORIZONTAL_MARGIN);
		layout.verticalSpacing = convertVerticalDLUsToPixels(IDialogConstants.VERTICAL_SPACING);
		layout.horizontalSpacing = convertHorizontalDLUsToPixels(IDialogConstants.HORIZONTAL_SPACING);
		newComposite.setLayout(layout);
		newComposite.setLayoutData(new GridData(GridData.FILL_BOTH));
		newFilePathCheck = new Button(newComposite, SWT.CHECK);
		newFilePathCheck.setText(AcceleoToolsUIMessages.getString("FileSelectionDialog.FileLabel") + ':'); //$NON-NLS-1$
		newFilePathCheck.setSelection(false);
		newFilePathCheck.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
			}

			public void widgetSelected(SelectionEvent e) {
				newFilePathText.setEnabled(newFilePathCheck.getSelection());
				newFilePathButton.setEnabled(newFilePathCheck.getSelection());
				List items = getAllCheckedListItems();
				getOkButton().setEnabled((items.size() == multiplicity) || (multiplicity == -1 && items.size() > 0));
			}
		});
		newFilePathText = new Text(newComposite, SWT.BORDER);
		GridData data = new GridData(GridData.GRAB_HORIZONTAL | GridData.GRAB_VERTICAL);
		data.heightHint = newFilePathText.getLineHeight();
		data.widthHint = newFilePathText.getLineHeight() * 30;
		newFilePathText.setLayoutData(data);
		newFilePathText.setText(""); //$NON-NLS-1$
		newFilePathText.setEditable(false);
		newFilePathText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				List items = getAllCheckedListItems();
				getOkButton().setEnabled((items.size() == multiplicity) || (multiplicity == -1 && items.size() > 0));
			}
		});
		newFilePathText.setEnabled(false);
		newFilePathButton = new Button(newComposite, SWT.PUSH);
		newFilePathButton.setText(AcceleoToolsUIMessages.getString("FileSelectionDialog.BrowseButtonLabel")); //$NON-NLS-1$
		newFilePathButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				newFilePathButtonPressed();
			}
		});
		newFilePathButton.setFont(parent.getFont());
		newFilePathButton.setLayoutData(new GridData());
		newFilePathButton.setEnabled(false);
		return composite;
	}

	private void newFilePathButtonPressed() {
		NewFileDialog folderDialog;
		if (newFilePathText.getText() != null && newFilePathText.getText().trim().length() > 0) {
			IPath path = new Path(newFilePathText.getText().trim());
			folderDialog = new NewFileDialog(path.lastSegment());
			IResource resource = Resources.findResource(path.removeLastSegments(1));
			if (resource != null) {
				folderDialog.setInitialSelections(new Object[] { resource });
			}
		} else {
			folderDialog = new NewFileDialog("file." + ((extensions.length > 0 && !"*".equals(extensions[0])) ? extensions[0] : "txt")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		}
		if (folderDialog.open() == Window.OK && folderDialog.getFirstResult() instanceof IContainer) {
			newFilePathText.setText(((IContainer) folderDialog.getFirstResult()).getFullPath().append(folderDialog.getNewFileName()).toString());
		}
	}

	/**
	 * Returns the content provider.
	 * 
	 * @param resourceType
	 *            is the type of the resource
	 * @return the content provider
	 */
	private ITreeContentProvider getContentProvider(final int resourceType) {
		return new WorkbenchContentProvider() {
			public Object[] getChildren(Object o) {
				if (resourceType != IResource.FILE && o instanceof IExtensionRegistry) {
					IExtensionRegistry registry = (IExtensionRegistry) o;
					Set result = new TreeSet(new Comparator() {
						public int compare(Object arg0, Object arg1) {
							Bundle bundle0 = (Bundle) arg0;
							Bundle bundle1 = (Bundle) arg1;
							if (bundle0 != null && bundle0.getSymbolicName() != null && bundle1 != null && bundle1.getSymbolicName() != null) {
								return bundle0.getSymbolicName().compareTo(bundle1.getSymbolicName());
							} else {
								return -1;
							}
						}
					});
					IExtensionPoint extensionPoint = registry.getExtensionPoint(MODULE_EXTENSION_ID);
					if (extensionPoint != null) {
						IExtension[] extensions = extensionPoint.getExtensions();
						for (int i = 0; i < extensions.length; i++) {
							IExtension extension = extensions[i];
							Bundle bundle = Platform.getBundle(extension.getNamespaceIdentifier());
							if (!result.contains(bundle)) {
								result.add(bundle);
							}
						}
					}
					return result.toArray();
				} else if (resourceType == IResource.FILE && o instanceof Bundle) {
					Bundle bundle = (Bundle) o;
					List result = new ArrayList();
					for (int j = 0; j < extensions.length; j++) {
						if ("*".equals(extensions[j])) { //$NON-NLS-1$
							result.clear();
							Enumeration enumeration = bundle.findEntries("/", "*", true); //$NON-NLS-1$ //$NON-NLS-2$
							while (enumeration != null && enumeration.hasMoreElements()) {
								Object child = enumeration.nextElement();
								if (child instanceof URL) {
									result.add(new Path(bundle.getSymbolicName()).append(((URL) child).getPath()));
								}
							}
							break;
						} else {
							Enumeration enumeration = bundle.findEntries("/", "*." + extensions[j], true); //$NON-NLS-1$ //$NON-NLS-2$
							while (enumeration != null && enumeration.hasMoreElements()) {
								Object child = enumeration.nextElement();
								if (child instanceof URL) {
									result.add(new Path(bundle.getSymbolicName()).append(((URL) child).getPath()));
								}
							}
						}
					}
					return result.toArray();
				} else if (resourceType == IResource.FILE && o instanceof IPath) {
					return new Object[0];
				} else if (o instanceof IContainer) {
					IResource[] members = null;
					try {
						members = ((IContainer) o).members();
					} catch (CoreException e) {
						return new Object[0];
					}
					ArrayList results = new ArrayList();
					for (int i = 0; i < members.length; i++) {
						if ((members[i].getType() & resourceType) > 0 && isSignificant(members[i])) {
							if (members[i] instanceof IFile) {
								String extension = members[i].getFileExtension();
								if (extension == null) {
									extension = ""; //$NON-NLS-1$
								}
								for (int j = 0; j < extensions.length; j++) {
									if ("*".equals(extensions[j]) || extension.equals(extensions[j])) { //$NON-NLS-1$
										results.add(members[i]);
										break;
									}
								}
							} else if (members[i] instanceof IContainer && countMembers((IContainer) members[i]) > 0) {
								results.add(members[i]);
							}
						}
					}
					if (includePlugins && o instanceof IWorkspaceRoot) {
						IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint(MODULE_EXTENSION_ID);
						if (extensionPoint != null) {
							IExtension[] extensions = extensionPoint.getExtensions();
							if (extensions.length > 0) {
								results.add(Platform.getExtensionRegistry());
							}
						}
					}
					return results.toArray();
				} else if (o instanceof List) {
					List result = new ArrayList();
					Iterator it = ((List) o).iterator();
					while (it.hasNext()) {
						Object element = it.next();
						if (element instanceof IContainer) {
							if (((IContainer) element).isAccessible() && countMembers((IContainer) element) > 0) {
								result.add(element);
							}
						} else {
							result.add(element);
						}
					}
					return result.toArray();
				} else {
					return new Object[0];
				}
			}

			/* (non-Javadoc) */
			public Object getParent(Object element) {
				if (element instanceof IPath && ((IPath) element).segmentCount() > 0) {
					Bundle bundle = Platform.getBundle(((IPath) element).segment(0));
					if (bundle != null) {
						return bundle;
					}
				} else if (element instanceof Bundle) {
					return Platform.getExtensionRegistry();
				}
				return super.getParent(element);
			}

		};
	}

	private int countMembers(IContainer container) {
		try {
			IResource[] members = container.members();
			int result = 0;
			for (int i = 0; i < members.length; i++) {
				if (isSignificant(members[i])) {
					if (members[i] instanceof IFile) {
						String extension = members[i].getFileExtension();
						if (extension == null) {
							extension = ""; //$NON-NLS-1$
						}
						for (int j = 0; j < extensions.length; j++) {
							if ("*".equals(extensions[j]) || extension.equals(extensions[j])) { //$NON-NLS-1$
								result++;
								break;
							}
						}
					} else if (members[i] instanceof IContainer) {
						result += countMembers((IContainer) members[i]);
					}
				}
			}
			return result;
		} catch (CoreException e) {
			return 0;
		}
	}

	private boolean isSignificant(IResource resource) {
		return !(resource instanceof IFolder && (resource.equals(Resources.getOutputFolder(resource.getProject())) || resource.getName().startsWith("."))); //$NON-NLS-1$
	}

	/* (non-Javadoc) */
	protected void okPressed() {
		setResult(getAllCheckedListItems());
		super.okPressed();
	}

	private List getAllCheckedListItems() {
		List items = new ArrayList();
		Iterator resultEnum = checkboxGroup.getAllCheckedListItems();
		while (resultEnum.hasNext()) {
			Object member = resultEnum.next();
			if (member instanceof IFile) {
				items.add(((IFile) member).getFullPath());
			} else if (member instanceof IPath) {
				items.add((IPath) member);
			}
		}
		if (newFilePathCheck.getSelection() && newFilePathText.getText() != null && newFilePathText.getText().trim().length() > 0) {
			items.add(new Path(newFilePathText.getText().trim()));
		}
		return items;
	}

}