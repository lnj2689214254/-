/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.resources;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jdt.internal.ui.jarpackager.JarFileExportOperation;
import org.eclipse.jdt.ui.jarpackager.IJarExportRunnable;
import org.eclipse.jdt.ui.jarpackager.JarPackageData;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import fr.obeo.acceleo.tools.AcceleoToolsMessages;
import fr.obeo.acceleo.tools.AcceleoToolsPlugin;

/**
 * It helps to create jar files.
 * 
 * @author www.obeo.fr
 * 
 */
public class JarFactory {

	/**
	 * Creates a jar file for a folder.
	 * 
	 * @param rootFolder
	 *            is the folder
	 * @param jarPath
	 *            is the file to create
	 */
	public static void createJar(final IPath rootFolder, final IPath jarPath) {
		if (PlatformUI.isWorkbenchRunning() && PlatformUI.getWorkbench() != null && PlatformUI.getWorkbench().getDisplay() != null && !PlatformUI.getWorkbench().getDisplay().isDisposed()) {
			PlatformUI.getWorkbench().getDisplay().syncExec(new Runnable() {
				public void run() {
					Shell shell = new Shell();
					try {
						JarPackageData fJarPackage = JarFactory.createPackageData(rootFolder, jarPath);
						if (fJarPackage != null) {
							IJarExportRunnable exportOperation = new JarFileExportOperation(fJarPackage, shell);
							try {
								PlatformUI.getWorkbench().getProgressService().run(false, false, exportOperation);
							} catch (InterruptedException e) {
								AcceleoToolsPlugin.getDefault().log(AcceleoToolsMessages.getString("JarFactory.InterruptedAction"), true); //$NON-NLS-1$
								return;
							} catch (InvocationTargetException ex) {
								if (ex.getTargetException() != null) {
									AcceleoToolsPlugin.getDefault().log(ex.getTargetException(), true);
									return;
								}
							}
							IStatus status = exportOperation.getStatus();
							if (!status.isOK()) {
								AcceleoToolsPlugin.getDefault().log(status);
							}
						} else {
							AcceleoToolsPlugin.getDefault().log(AcceleoToolsMessages.getString("JarFactory.CreationFailed", new Object[] { jarPath.toString() }), true); //$NON-NLS-1$
						}
					} finally {
						shell.dispose();
					}
				}
			});
		}
	}

	/**
	 * Creates the model for a jar package.
	 * <p>
	 * Default properties :
	 * <li>Use source folder hierarchy</li>
	 * <li>Build if needed</li>
	 * <li>Class files are exported</li>
	 * <li>Java files are not exported</li>
	 * <li>Jar is compressed</li>
	 * <li>Overwrite if needed</li>
	 * 
	 * @param rootFolder
	 *            is the folder
	 * @param jarPath
	 *            is the file to create
	 * @return the model for a jar package
	 */
	protected static JarPackageData createPackageData(IPath rootFolder, IPath jarPath) {
		JarPackageData fJarPackage = new JarPackageData();
		IPath jarLocationPath = ResourcesPlugin.getWorkspace().getRoot().getFile(jarPath).getLocation();
		File jarFile = jarLocationPath.toFile();
		if (jarFile.exists() && (jarFile.isDirectory() || !jarFile.canWrite()))
			return null;
		fJarPackage.setJarLocation(jarLocationPath);
		fJarPackage.setUseSourceFolderHierarchy(true);
		fJarPackage.setBuildIfNeeded(true);
		fJarPackage.setExportClassFiles(true);
		fJarPackage.setExportJavaFiles(false);
		fJarPackage.setCompress(true);
		fJarPackage.setOverwrite(true);
		Object[] elements = getElements(fr.obeo.acceleo.tools.resources.Resources.findResource(rootFolder)).toArray();
		if (elements.length == 0)
			return null;
		fJarPackage.setElements(elements);
		return fJarPackage;
	}

	/**
	 * Gets the resources to be put in the jar file.
	 * 
	 * @param resource
	 *            is the container
	 * @return the list of the resources
	 */
	protected static List getElements(IResource resource) {
		List elements = new ArrayList();
		if (resource != null) {
			switch (resource.getType()) {
			case IResource.FOLDER:
				IFolder folder = (IFolder) resource;
				IResource[] resources;
				try {
					resources = folder.members();
				} catch (CoreException e) {
					AcceleoToolsPlugin.getDefault().log(e, true);
					resources = new IResource[] {};
				}
				for (int i = 0; i < resources.length; i++) {
					elements.addAll(getElements(resources[i]));
				}
				break;
			case IResource.FILE:
				IFile file = (IFile) resource;
				elements.add(file);
				break;
			}
		}
		return elements;
	}

}
