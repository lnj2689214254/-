/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.resources;

import java.util.ArrayList;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import fr.obeo.acceleo.tools.ui.AcceleoToolsUIMessages;

/**
 * A standard folder selection dialog.
 * 
 * @author www.obeo.fr
 * 
 */
public class FolderSelectionDialog extends fr.obeo.acceleo.tools.ui.resources.compatibility.FolderSelectionDialog {

	/**
	 * Constructor.
	 * 
	 * @param message
	 *            is the message
	 */
	public FolderSelectionDialog(String message) {
		super(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), WorkbenchLabelProvider.getDecoratingWorkbenchLabelProvider(), getContentProvider(IResource.PROJECT | IResource.FOLDER));
		setAllowMultiple(false);
		setTitle(AcceleoToolsUIMessages.getString("FolderSelectionDialog.Title")); //$NON-NLS-1$
		setMessage((message != null) ? message : ""); //$NON-NLS-1$
		setInput(ResourcesPlugin.getWorkspace().getRoot());
	}

	/* (non-Javadoc) */
	protected Control createDialogArea(Composite parent) {
		Control result = super.createDialogArea(parent);
		if (getTreeViewer() != null) {
			getTreeViewer().collapseAll();
		}
		return result;
	}

	/**
	 * Returns the content provider.
	 * 
	 * @param resourceType
	 *            is the type of the resource
	 * @return the content provider
	 */
	protected static ITreeContentProvider getContentProvider(final int resourceType) {
		return new WorkbenchContentProvider() {
			public Object[] getChildren(Object parent) {
				if (parent instanceof IContainer) {
					IResource[] members = null;
					try {
						members = ((IContainer) parent).members();
					} catch (CoreException e) {
						return new Object[0];
					}
					ArrayList results = new ArrayList();
					for (int i = 0; i < members.length; i++) {
						if ((members[i].getType() & resourceType) > 0) {
							results.add(members[i]);
						}
					}
					return results.toArray();
				}
				if (parent instanceof ArrayList) {
					return ((ArrayList) parent).toArray();
				}
				return new Object[0];
			}
		};
	}

}
