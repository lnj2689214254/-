/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.resources;

import fr.obeo.acceleo.tools.AcceleoToolsPlugin;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.pde.core.build.IBuild;
import org.eclipse.pde.core.build.IBuildEntry;
import org.eclipse.pde.core.plugin.IPlugin;
import org.eclipse.pde.core.plugin.IPluginBase;
import org.eclipse.pde.core.plugin.IPluginImport;
import org.eclipse.pde.core.plugin.IPluginReference;
import org.eclipse.pde.internal.core.WorkspaceModelManager;
import org.eclipse.pde.internal.core.build.WorkspaceBuildModel;
import org.eclipse.pde.internal.core.plugin.WorkspacePluginModel;
import org.eclipse.pde.internal.core.util.CoreUtility;

/**
 * It helps to use workspace resources.
 * 
 * @author www.obeo.fr
 * 
 */
public class Resources {

	/**
	 * Creates a new plugin project resource in the workspace. If there is an
	 * existing project, it is modified. The java nature and the plugin nature
	 * are set.
	 * 
	 * @param projectName
	 *            is the name of the new project
	 * @param pluginsID
	 *            are required plugins ID
	 * @param monitor
	 *            is the progress monitor
	 * @return the new project resource
	 * @throws CoreException
	 */
	public static IProject createPluginProject(String projectName, String[] pluginsID, IProgressMonitor monitor) throws CoreException {
		// Create the project
		IProject project = fr.obeo.acceleo.tools.resources.Resources.createJavaProject(true, projectName, monitor).getProject();
		// Convert to plugin
		convertProject(project, projectName, pluginsID, monitor);
		return project;
	}

	private static void convertProject(IProject project, String projectName, String[] pluginsID, IProgressMonitor monitor) throws CoreException {
		CoreUtility.addNatureToProject(project, "org.eclipse.pde.PluginNature", monitor); //$NON-NLS-1$
		if (!WorkspaceModelManager.isPluginProject(project))
			createManifestFile(project.getFile("plugin.xml"), pluginsID, monitor); //$NON-NLS-1$
		IFile buildFile = project.getFile("build.properties"); //$NON-NLS-1$
		if (!buildFile.exists()) {
			WorkspaceBuildModel model = new WorkspaceBuildModel(buildFile);
			createSourceOutputBuildEntries(model, projectName);
			IBuild build = model.getBuild(true);
			IBuildEntry entry = model.getFactory().createEntry("bin.includes"); //$NON-NLS-1$
			if (project.getFile("plugin.xml").exists()) { //$NON-NLS-1$
				entry.addToken("plugin.xml"); //$NON-NLS-1$
			}
			if (project.getFile("META-INF/MANIFEST.MF").exists()) { //$NON-NLS-1$
				entry.addToken("META-INF/"); //$NON-NLS-1$
				entry.addToken("."); //$NON-NLS-1$
			}
			// add the plugin.properties empty file
			if (!project.getFile("plugin.properties").exists()) { //$NON-NLS-1$
				fr.obeo.acceleo.tools.resources.Resources.createFile(project, new Path("plugin.properties"), "", monitor); //$NON-NLS-1$ //$NON-NLS-2$
			}
			entry.addToken("plugin.properties"); //$NON-NLS-1$
			if (entry.getTokens().length > 0) {
				build.add(entry);
			}
			model.save();
		}
	}

	private static void createSourceOutputBuildEntries(WorkspaceBuildModel model, String projectName) throws CoreException {
		String srcFolder = "src"; //$NON-NLS-1$
		String libraryName = "."; //$NON-NLS-1$
		// SOURCE.<LIBRARY_NAME>
		IBuildEntry entry = model.getFactory().createEntry("source." + libraryName); //$NON-NLS-1$
		entry.addToken(new Path(srcFolder).addTrailingSeparator().toString());
		model.getBuild().add(entry);

		// OUTPUT.<LIBRARY_NAME>
		entry = model.getFactory().createEntry("output." + libraryName); //$NON-NLS-1$
		String outputFolder = "bin"; //$NON-NLS-1$
		entry.addToken(new Path(outputFolder).addTrailingSeparator().toString());
		model.getBuild().add(entry);
	}

	private static void createManifestFile(IFile file, String[] pluginsID, IProgressMonitor monitor) throws CoreException {
		WorkspacePluginModel model = new WorkspacePluginModel(file, false);
		model.load();
		IPlugin plugin = model.getPlugin();
		plugin.setSchemaVersion("3.0"); //$NON-NLS-1$
		plugin.setId(file.getProject().getName());
		plugin.setName(createInitialName(plugin.getId()));
		plugin.setVersion("1.0.0"); //$NON-NLS-1$
		IPluginBase pluginBase = model.getPluginBase();
		IPluginReference[] dependencies = getDependencies(pluginsID);
		for (int i = 0; i < dependencies.length; i++) {
			IPluginReference ref = dependencies[i];
			IPluginImport pluginImport = model.getPluginFactory().createImport();
			pluginImport.setId(ref.getId());
			pluginImport.setVersion(ref.getVersion());
			pluginImport.setMatch(ref.getMatch());
			pluginBase.add(pluginImport);
		}
		model.save();
		AcceleoPluginConverter.convertToOSGIFormat(file.getProject(), "3.0", null, new SubProgressMonitor(monitor, 1)); //$NON-NLS-1$
		file.delete(true, monitor);
	}

	private static String createInitialName(String id) {
		int loc = id.lastIndexOf('.');
		if (loc == -1) {
			return id;
		}
		StringBuffer buffer = new StringBuffer(id.substring(loc + 1));
		buffer.setCharAt(0, Character.toUpperCase(buffer.charAt(0)));
		return buffer.toString();
	}

	private static IPluginReference[] getDependencies(String[] pluginsID) {
		ArrayList result = new ArrayList();
		Class type;
		try {
			type = Platform.getBundle("org.eclipse.pde.ui").loadClass("org.eclipse.pde.ui.templates.PluginReference");//$NON-NLS-1$ //$NON-NLS-2$
		} catch (ClassNotFoundException e) {
			try {
				type = Platform.getBundle("org.eclipse.pde.ui").loadClass("org.eclipse.pde.internal.ui.wizards.templates.PluginReference");//$NON-NLS-1$ //$NON-NLS-2$
			} catch (ClassNotFoundException e1) {
				type = null;
			}
		}
		try {
			for (int i = 0; i < pluginsID.length; i++) {
				result.add(type.getDeclaredConstructor(new Class[] { String.class, String.class, int.class }).newInstance(new Object[] { pluginsID[i], null, new Integer(0), }));
			}
			return (IPluginReference[]) result.toArray(new IPluginReference[result.size()]);
		} catch (IllegalArgumentException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		} catch (SecurityException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		} catch (InstantiationException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		} catch (IllegalAccessException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		} catch (InvocationTargetException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		} catch (NoSuchMethodException e) {
			AcceleoToolsPlugin.getDefault().log(e, true);
		}
		return null;
	}

}
