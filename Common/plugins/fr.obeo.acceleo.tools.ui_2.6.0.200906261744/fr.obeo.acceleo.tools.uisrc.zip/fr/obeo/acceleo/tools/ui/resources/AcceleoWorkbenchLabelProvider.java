/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.resources;

import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.model.WorkbenchLabelProvider;
import org.osgi.framework.Bundle;

import fr.obeo.acceleo.tools.ui.AcceleoToolsUIMessages;
import fr.obeo.acceleo.tools.ui.AcceleoToolsUiPlugin;

/**
 * A workbench label provider to add registry, bundle, and path support.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoWorkbenchLabelProvider implements ILabelProvider {

	private static final Image registryImage = AcceleoToolsUiPlugin.getImageDescriptor("icons/plugins/registry.gif").createImage(); //$NON-NLS-1$

	private static final Image bundleImage = AcceleoToolsUiPlugin.getImageDescriptor("icons/plugins/bundle.gif").createImage(); //$NON-NLS-1$

	private static final Image fileImage = AcceleoToolsUiPlugin.getImageDescriptor("icons/plugins/file.gif").createImage(); //$NON-NLS-1$

	private ILabelProvider workbenchLabelProvider;

	/**
	 * Constructor.
	 */
	public AcceleoWorkbenchLabelProvider() {
		this.workbenchLabelProvider = WorkbenchLabelProvider.getDecoratingWorkbenchLabelProvider();
	}

	/* (non-Javadoc) */
	public Image getImage(Object element) {
		if (workbenchLabelProvider.getImage(element) != null) {
			return workbenchLabelProvider.getImage(element);
		} else if (element instanceof IExtensionRegistry) {
			return registryImage;
		} else if (element instanceof Bundle) {
			return bundleImage;
		} else if (element instanceof IPath) {
			return fileImage;
		} else {
			return null;
		}
	}

	/* (non-Javadoc) */
	public String getText(Object element) {
		if (element instanceof IExtensionRegistry) {
			return AcceleoToolsUIMessages.getString("AcceleoWorkbenchLabelProvider.AllPlugins"); //$NON-NLS-1$
		} else if (element instanceof Bundle) {
			return ((Bundle) element).getSymbolicName();
		} else if (element instanceof IPath) {
			return ((IPath) element).toString();
		} else {
			if (workbenchLabelProvider.getText(element) != null) {
				return workbenchLabelProvider.getText(element);
			} else {
				return "UNKNOWN"; //$NON-NLS-1$
			}
		}
	}

	/* (non-Javadoc) */
	public void addListener(ILabelProviderListener arg0) {
		workbenchLabelProvider.addListener(arg0);
	}

	/* (non-Javadoc) */
	public void dispose() {
		workbenchLabelProvider.dispose();
	}

	/* (non-Javadoc) */
	public boolean isLabelProperty(Object arg0, String arg1) {
		return workbenchLabelProvider.isLabelProperty(arg0, arg1);
	}

	/* (non-Javadoc) */
	public void removeListener(ILabelProviderListener arg0) {
		workbenchLabelProvider.removeListener(arg0);
	}

}
