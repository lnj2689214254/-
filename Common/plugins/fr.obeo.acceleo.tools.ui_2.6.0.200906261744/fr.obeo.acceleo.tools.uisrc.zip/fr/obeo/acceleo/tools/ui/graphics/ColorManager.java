/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.graphics;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

/**
 * The color manager.
 * 
 * @author www.obeo.fr
 * 
 */
public class ColorManager {

	/**
	 * Created colors.
	 */
	protected Map fColorTable = new HashMap(10);

	/**
	 * Constructor.
	 */
	public ColorManager() {
	}

	/**
	 * Gets the color for the given description (Red, Green, Blue).
	 * 
	 * @param rgb
	 *            is the description of color
	 * @return the color
	 */
	public Color getColor(RGB rgb) {
		Color color = (Color) fColorTable.get(rgb);
		if (color == null) {
			color = new Color(Display.getCurrent(), rgb);
			fColorTable.put(rgb, color);
		}
		return color;
	}

	/**
	 * It disposes color manager.
	 */
	public void dispose() {
		Iterator e = fColorTable.values().iterator();
		while (e.hasNext())
			((Color) e.next()).dispose();
		fColorTable.clear();
	}

	/**
	 * Gets a string representation of a RGB color.
	 * 
	 * @param rgb
	 *            is the descriptions of colors in terms of the primary additive
	 *            color model (red, green and blue)
	 * @return a string representation of a RGB color
	 */
	public static String fromRGBToString(RGB rgb) {
		if (rgb == null)
			return ""; //$NON-NLS-1$
		return Integer.toString(rgb.red) + ',' + Integer.toString(rgb.green) + ',' + Integer.toString(rgb.blue);
	}

	/**
	 * Gets a string representation of a RGB background color and a RGB
	 * foreground color.
	 * 
	 * @param background
	 *            is a RGB background color
	 * @param foreground
	 *            is a RGB foreground color
	 * @return a string representation of the RGB colors
	 */
	public static String fromBackgroundForegroundRGBToString(RGB background, RGB foreground) {
		String res = "COLOR - "; //$NON-NLS-1$
		if (background != null)
			res += fromRGBToString(background);
		res += " - "; //$NON-NLS-1$
		if (foreground != null)
			res += fromRGBToString(foreground);
		return res;
	}

	/**
	 * Creates a RGB color from a string representation.
	 * 
	 * @param s
	 *            is a string representation of a RGB color
	 * @param defaultColor
	 *            is the RGB color to be returned if there is a problem
	 * @return a RGB color from a string representation
	 */
	public static RGB fromStringToRGB(String s, RGB defaultColor) {
		if (s == null)
			return defaultColor;
		s = s.trim();
		if (s.length() == 0)
			return defaultColor;
		StringTokenizer st = new StringTokenizer(s, ","); //$NON-NLS-1$
		if (st.countTokens() == 3) {
			return new RGB(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()));
		} else {
			return defaultColor;
		}
	}

	/**
	 * Creates, from a string representation, a RGB background color and a RGB
	 * foreground color.
	 * 
	 * @param s
	 *            is a string representation of the background and the
	 *            foreground color
	 * @return a table RGB[2] that contains a background color and a foreground
	 *         color
	 */
	public static RGB[] fromStringToBackgroundForegroundRGB(String s) {
		StringTokenizer st = new StringTokenizer(s, "-"); //$NON-NLS-1$
		if (st.countTokens() == 3) {
			// Ignore first token : COLOR
			st.nextToken();
			RGB[] res = new RGB[2];
			res[0] = fromStringToBackgroundRGB(st.nextToken());
			res[1] = fromStringToForegroundRGB(st.nextToken());
			return res;
		} else {
			return new RGB[] { DEFAULT_BACKGROUND_RGB, DEFAULT_FOREGROUND_RGB };
		}
	}

	/**
	 * Creates a RGB background color from a string representation.
	 * 
	 * @param s
	 *            is a string representation of the background color
	 * @return the background color
	 */
	public static RGB fromStringToBackgroundRGB(String s) {
		return fromStringToRGB(s, DEFAULT_BACKGROUND_RGB);
	}

	/**
	 * Creates a RGB foreground color from a string representation.
	 * 
	 * @param s
	 *            is a string representation of the foreground color
	 * @return the foreground color
	 */
	public static RGB fromStringToForegroundRGB(String s) {
		return fromStringToRGB(s, DEFAULT_FOREGROUND_RGB);
	}

	/**
	 * Default background RGB : white.
	 */
	public static RGB DEFAULT_BACKGROUND_RGB = new RGB(255, 255, 255);

	/**
	 * Default foreground RGB : black.
	 */
	public static RGB DEFAULT_FOREGROUND_RGB = new RGB(0, 0, 0);

}
