/*******************************************************************************
 * Copyright (c) 2006-2008 Obeo.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Obeo - initial API and implementation
 *******************************************************************************/
package fr.obeo.acceleo.tools.ui.graphics;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;

/**
 * Useful methods for EMF adapter factories handling.
 * 
 * @author Cedric Brun <a href="mailto:cedric.brun@obeo.fr">cedric.brun@obeo.fr</a>
 */
public final class AdapterUtils {

	private AdapterUtils() {
		// prevents instantiation.
	}

	/**
	 * Returns a factory built with all the {@link AdapterFactory} instances
	 * available in the global registry.
	 * 
	 * @returna factory built with all the {@link AdapterFactory} instances
	 *          available in the global registry.
	 */
	public static AdapterFactory findAdapterFactory() {
		AdapterFactory adapterFactory = null;
		if (adapterFactory == null)
			return createAdapterFactory();
		return adapterFactory;
	}

	/**
	 * 
	 * @return an adapter factory made of all the adapter factories declared in
	 *         the registry.
	 */
	protected static ComposedAdapterFactory createAdapterFactory() {
		List factories = new ArrayList();
		factories.add(new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE));
		fillItemProviderFactories(factories);
		return new ComposedAdapterFactory(factories);
	}

	/**
	 * Add a few usefull factories.
	 * 
	 * @param factories
	 *            current list of factories.
	 */
	protected static void fillItemProviderFactories(List factories) {
		factories.add(new ResourceItemProviderAdapterFactory());
		factories.add(new ReflectiveItemProviderAdapterFactory());
	}

	/**
	 * Returnq the adapter factory for the given {@link EObject} or
	 * <code>null</code> if it cannot be found.
	 * 
	 * @param eObj
	 *            {@link EObject} we seek the {@link AdapterFactory} for.
	 * @return Specific {@link AdapterFactory} adapted to the {@link EObject},
	 *         <code>null</code> if it cannot be found. *
	 * @deprecated please use the method with no parameters.
	 */
	public static AdapterFactory findAdapterFactory(EObject eObj) {
		return findAdapterFactory();
	}

	/**
	 * Returnq the adapter factory for the given {@link EClassifier} or
	 * <code>null</code> if it cannot be found.
	 * 
	 * @param eClass
	 *            {@link EClassifier} we seek the {@link AdapterFactory} for.
	 * @return Specific {@link AdapterFactory} adapted to the
	 *         {@link EClassifier}, <code>null</code> if it cannot be found.
	 * @deprecated please use the method with no parameters.
	 */
	public static AdapterFactory findAdapterFactory(EClassifier eClass) {
		return findAdapterFactory();
	}

}