/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.views;

import java.io.PrintStream;

import org.eclipse.ui.console.ConsolePlugin;
import org.eclipse.ui.console.IConsole;
import org.eclipse.ui.console.IConsoleManager;
import org.eclipse.ui.console.MessageConsole;

import fr.obeo.acceleo.tools.AcceleoToolsMessages;

/**
 * Console for the acceleo tools.
 * 
 * @author www.obeo.fr
 */
public class AcceleoConsole {

	/**
	 * @return default instance
	 */
	public static AcceleoConsole getDefault() {
		if (instance == null) {
			instance = new AcceleoConsole();
		}
		return instance;
	}

	private static AcceleoConsole instance = null;

	/**
	 * The console that displays messages.
	 */
	protected MessageConsole console;

	/**
	 * The message stream connected to this console.
	 */
	protected PrintStream stream;

	/**
	 * Constructor.
	 */
	private AcceleoConsole() {
		console = new MessageConsole(AcceleoToolsMessages.getString("AcceleoConsole.Title"), null); //$NON-NLS-1$
		IConsoleManager manager = ConsolePlugin.getDefault().getConsoleManager();
		manager.addConsoles(new IConsole[] { console });
		stream = new PrintStream(console.newMessageStream());
	}

	/**
	 * Opens the console view.
	 */
	public void show() {
		IConsoleManager manager = ConsolePlugin.getDefault().getConsoleManager();
		manager.showConsoleView(console);
	}

	/**
	 * Indicates if the console can be shown.
	 */
	public static boolean canShow() {
		return ConsolePlugin.getDefault() != null && ConsolePlugin.getDefault().getConsoleManager() != null;
	}

	/**
	 * This console will be the default stream for the System.out and the
	 * System.err instructions.
	 */
	public void asDefaultForSystemOut() {
		System.setOut(stream);
		System.setErr(stream);
	}

}
