/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui.graphics;

import org.eclipse.jface.resource.CompositeImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;

/**
 * An image descriptor that synthesize an image from 2 images to simulate the
 * effect of custom drawing.
 * 
 * @author www.obeo.fr
 * 
 */
public class CompositeImage extends CompositeImageDescriptor {

	/**
	 * Image at the back.
	 */
	private ImageData back;

	/**
	 * Image at the top.
	 */
	private ImageData top;

	/**
	 * Constructor.
	 * 
	 * @param back
	 *            is the image at the back
	 * @param top
	 *            is the image at the top
	 */
	public CompositeImage(ImageData back, ImageData top) {
		this.back = back;
		this.top = top;
	}

	/* (non-Javadoc) */
	protected void drawCompositeImage(int i, int j) {
		drawImage(back, 0, 0);
		drawImage(top, 3, 4);
	}

	/* (non-Javadoc) */
	protected Point getSize() {
		return new Point(back.width, back.height);
	}

	/**
	 * Synthesizes an image from a back image and a top image.
	 * 
	 * @param back
	 *            is the image at the back
	 * @param top
	 *            is the image at the top
	 * @return the new image
	 */
	public static Image compose(Image back, Image top) {
		CompositeImage overlay = new CompositeImage(back.getImageData(), top.getImageData());
		return overlay.createImage();
	}

}