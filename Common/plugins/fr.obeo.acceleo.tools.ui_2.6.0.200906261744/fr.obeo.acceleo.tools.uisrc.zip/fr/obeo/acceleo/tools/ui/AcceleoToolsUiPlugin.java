/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.tools.ui;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import fr.obeo.acceleo.tools.ui.resources.AcceleoUIPlugin;
import fr.obeo.acceleo.tools.ui.views.log.SharedImages;

/**
 * The main plugin class to be used in the desktop.
 * 
 * @author www.obeo.fr
 * 
 */
public class AcceleoToolsUiPlugin extends AcceleoUIPlugin {

	/* (non-Javadoc) */
	public String getID() {
		return "fr.obeo.acceleo.tools.ui"; //$NON-NLS-1$
	}

	/**
	 * The shared instance.
	 */
	private static AcceleoToolsUiPlugin plugin;

	/**
	 * Resource bundle.
	 */
	private ResourceBundle resourceBundle;

	/**
	 * The constructor.
	 */
	public AcceleoToolsUiPlugin() {
		super();
		plugin = this;
	}

	/* (non-Javadoc) */
	public void start(BundleContext context) throws Exception {
		super.start(context);
	}

	/* (non-Javadoc) */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		plugin = null;
		resourceBundle = null;
	}

	/**
	 * @return the shared instance
	 */
	public static AcceleoToolsUiPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the string from the plugin's resource bundle, or 'key' if not
	 * found.
	 * 
	 * @param key
	 *            identifies the string
	 * @return the string from the plugin's resource bundle, or 'key' if not
	 *         found
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = AcceleoToolsUiPlugin.getDefault().getResourceBundle();
		try {
			return (bundle != null) ? bundle.getString(key) : key;
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * Returns the plugin's resource bundle.
	 * 
	 * @return the plugin's resource bundle
	 */
	public ResourceBundle getResourceBundle() {
		try {
			if (resourceBundle == null)
				resourceBundle = ResourceBundle.getBundle("fr.obeo.acceleo.tools.ui.AcceleoToolsUiPluginResources"); //$NON-NLS-1$
		} catch (MissingResourceException x) {
			resourceBundle = null;
		}
		return resourceBundle;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            is a plug-in relative path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin("fr.obeo.acceleo.tools.ui", path); //$NON-NLS-1$
	}

	// TODO
	protected void initializeImageRegistry(ImageRegistry registry) {
		registry.put(SharedImages.DESC_PREV_EVENT, getImageDescriptor(SharedImages.DESC_PREV_EVENT));
		registry.put(SharedImages.DESC_NEXT_EVENT, getImageDescriptor(SharedImages.DESC_NEXT_EVENT));

		registry.put(SharedImages.DESC_ERROR_ST_OBJ, getImageDescriptor(SharedImages.DESC_ERROR_ST_OBJ));
		registry.put(SharedImages.DESC_ERROR_STACK_OBJ, getImageDescriptor(SharedImages.DESC_ERROR_STACK_OBJ));
		registry.put(SharedImages.DESC_INFO_ST_OBJ, getImageDescriptor(SharedImages.DESC_INFO_ST_OBJ));
		registry.put(SharedImages.DESC_OK_ST_OBJ, getImageDescriptor(SharedImages.DESC_OK_ST_OBJ));
		registry.put(SharedImages.DESC_WARNING_ST_OBJ, getImageDescriptor(SharedImages.DESC_WARNING_ST_OBJ));
		registry.put(SharedImages.DESC_HIERARCHICAL_LAYOUT_OBJ, getImageDescriptor(SharedImages.DESC_HIERARCHICAL_LAYOUT_OBJ));

		registry.put(SharedImages.DESC_CLEAR, getImageDescriptor(SharedImages.DESC_CLEAR));
		registry.put(SharedImages.DESC_CLEAR_DISABLED, getImageDescriptor(SharedImages.DESC_CLEAR_DISABLED));
		registry.put(SharedImages.DESC_REMOVE_LOG, getImageDescriptor(SharedImages.DESC_REMOVE_LOG));
		registry.put(SharedImages.DESC_REMOVE_LOG_DISABLED, getImageDescriptor(SharedImages.DESC_REMOVE_LOG_DISABLED));
		registry.put(SharedImages.DESC_EXPORT, getImageDescriptor(SharedImages.DESC_EXPORT));
		registry.put(SharedImages.DESC_EXPORT_DISABLED, getImageDescriptor(SharedImages.DESC_EXPORT_DISABLED));
		registry.put(SharedImages.DESC_FILTER, getImageDescriptor(SharedImages.DESC_FILTER));
		registry.put(SharedImages.DESC_FILTER_DISABLED, getImageDescriptor(SharedImages.DESC_FILTER_DISABLED));
		registry.put(SharedImages.DESC_IMPORT, getImageDescriptor(SharedImages.DESC_IMPORT));
		registry.put(SharedImages.DESC_IMPORT_DISABLED, getImageDescriptor(SharedImages.DESC_IMPORT_DISABLED));
		registry.put(SharedImages.DESC_OPEN_LOG, getImageDescriptor(SharedImages.DESC_OPEN_LOG));
		registry.put(SharedImages.DESC_OPEN_LOG_DISABLED, getImageDescriptor(SharedImages.DESC_OPEN_LOG_DISABLED));
		registry.put(SharedImages.DESC_PROPERTIES, getImageDescriptor(SharedImages.DESC_PROPERTIES));
		registry.put(SharedImages.DESC_PROPERTIES_DISABLED, getImageDescriptor(SharedImages.DESC_PROPERTIES_DISABLED));
		registry.put(SharedImages.DESC_READ_LOG, getImageDescriptor(SharedImages.DESC_READ_LOG));
		registry.put(SharedImages.DESC_READ_LOG_DISABLED, getImageDescriptor(SharedImages.DESC_READ_LOG_DISABLED));
	}
}
