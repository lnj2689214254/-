/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.impl.ClearImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Iterator;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

/**
 * A representation of the model object '<em><b>Clear</b></em>'. It erases
 * recursively the content of all the files in a container of the workspace. The
 * files become empty. The files and the folders are not deleted to keep the
 * synchronization with the team view.
 * 
 * @author www.obeo.fr
 * 
 */
public class CClear extends ClearImpl implements CObject {

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getDocumentation());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			IContainer container = cchain.getFile().getProject().getWorkspace().getRoot();
			Iterator resources = getResources().iterator();
			while (resources.hasNext()) {
				Data data = (Data) resources.next();
				if (data instanceof CFolder || data instanceof CModelSet) {
					IFolder folder = container.getFolder(new Path(((File) data).getPath()));
					clear(folder, monitor);
				} else if (data instanceof CModel || data instanceof CLog || data instanceof CCustomFile) {
					IFile file = container.getFile(new Path(((File) data).getPath()));
					clear(file, monitor);
				}
			}
		}
	}

	private void clear(IContainer container, IProgressMonitor monitor) throws CoreException {
		if (container != null && container.exists()) {
			IResource[] members = container.members();
			for (int i = 0; i < members.length; i++) {
				IResource resource = members[i];
				if (resource instanceof IFile) {
					clear((IFile) resource, monitor);
				} else if (resource instanceof IContainer) {
					clear((IContainer) resource, monitor);
				}
			}
		}
	}

	private void clear(IFile file, IProgressMonitor monitor) throws CoreException {
		if (file != null && file.exists()) {
			InputStream contents = new ByteArrayInputStream("".getBytes()); //$NON-NLS-1$
			file.setContents(contents, true, true, monitor);
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 0;
	}

}
