/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.ModelSet;
import fr.obeo.acceleo.chain.impl.ConvertXmiImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.chain.tools.ChainLog;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.resources.Resources;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;

/**
 * A representation of the model object '<em><b>ConvertXmi</b></em>'. It
 * converts a xmi from MOF to EMF.
 * 
 * @author www.obeo.fr
 * 
 */
public class CConvertXmi extends ConvertXmiImpl implements CObject {

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getDocumentation());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
			IContainer container = cchain.getFile().getProject().getWorkspace().getRoot();
			List mofList = new ArrayList();
			if (getMof() instanceof ModelSet) {
				IContainer mofSet = Resources.getContainer(container, new Path(getMof().getPath()), monitor);
				if (mofSet != null && mofSet.exists()) {
					IFile[] files = Resources.members(mofSet);
					for (int i = 0; i < files.length; i++) {
						IFile file = files[i];
						mofList.add(file.getFullPath().toString());
					}
				} else {
					report.append(AcceleoChainMessages.getString("MissingFolder", new Object[] { getMof().getPath(), })); //$NON-NLS-1$
				}
			} else if (getMof() != null) {
				mofList.add(getMof().getPath());
			}
			Iterator mofIt = mofList.iterator();
			while (mofIt.hasNext()) {
				String mofPath = (String) mofIt.next();
				IFile mof = container.getFile(new Path(mofPath));
				if (!mof.exists()) {
					report.append(AcceleoChainMessages.getString("CConvertXmi.UnresolvedMofModel", new Object[] { mofPath, })); //$NON-NLS-1$
				} else if (getEmf().getPath().trim().length() == 0) {
					report.append(AcceleoChainMessages.getString("CConvertXmi.InvalidEMFModel")); //$NON-NLS-1$
				} else {
					String emfPath;
					if (getEmf() instanceof ModelSet) {
						emfPath = new Path(getEmf().getPath()).append(mof.getName()).toString();
					} else {
						emfPath = getEmf().getPath();
					}
					if (Platform.getBundle("fr.obeo.acceleo.bridge.ui") != null) { //$NON-NLS-1$
						try {
							try {
								Class type = Platform.getBundle("fr.obeo.acceleo.bridge.ui").loadClass("fr.obeo.acceleo.bridge.ui.popupMenus.AcceleoConvertMof2EmfOperation");//$NON-NLS-1$ //$NON-NLS-2$
								Object instance = type.getConstructor(new Class[] { IFile.class, String.class }).newInstance(new Object[] { mof, emfPath });
								Method method = type.getMethod("run", new Class[] { IProgressMonitor.class }); //$NON-NLS-1$
								method.invoke(instance, new Object[] { monitor });
								IFile generated = Resources.findFile(new Path(emfPath));
								if (generated != null) {
									List files = new ArrayList();
									files.add(generated);
									cchain.addGeneratedFiles(files);
								}
							} catch (ClassNotFoundException e) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							}
						} catch (Exception e) {
							try {
								Class type = Platform.getBundle("fr.obeo.acceleo.bridge.ui").loadClass("fr.obeo.acceleo.bridge.ui.AcceleoBridgeUiPlugin"); //$NON-NLS-1$ //$NON-NLS-2$
								Method method = type.getDeclaredMethod("getDefault", null); //$NON-NLS-1$
								Object instance = method.invoke(null, null);
								Method methodLog = type.getMethod("log", new Class[] { Throwable.class, boolean.class }); //$NON-NLS-1$
								methodLog.invoke(instance, new Object[] { e, Boolean.TRUE });
							} catch (ClassNotFoundException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							} catch (IllegalArgumentException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							} catch (IllegalAccessException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							} catch (InvocationTargetException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							} catch (SecurityException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							} catch (NoSuchMethodException bridgeException) {
								report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
							}
						}
					} else {
						report.append(AcceleoChainMessages.getString("CConvertXmi.BridgeFeatureNotAvailable")); //$NON-NLS-1$
					}
				}
			}
			ChainLog.report(cchain, this, report, monitor, mode);
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 0;
	}

}
