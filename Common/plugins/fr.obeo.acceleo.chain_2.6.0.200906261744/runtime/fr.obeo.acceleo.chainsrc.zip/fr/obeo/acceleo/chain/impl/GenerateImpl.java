/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Folder;
import fr.obeo.acceleo.chain.Generate;
import fr.obeo.acceleo.chain.Generator;
import fr.obeo.acceleo.chain.Metamodel;
import fr.obeo.acceleo.chain.Model;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Generate</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.GenerateImpl#getModel <em>Model</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.GenerateImpl#getMetamodel <em>Metamodel</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.GenerateImpl#getGenerator <em>Generator</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.GenerateImpl#getFolder <em>Folder</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class GenerateImpl extends ActionImpl implements Generate {
	/**
	 * The cached value of the '{@link #getModel() <em>Model</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getModel()
	 * @generated
	 * @ordered
	 */
	protected Model model = null;

	/**
	 * The cached value of the '{@link #getMetamodel() <em>Metamodel</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getMetamodel()
	 * @generated
	 * @ordered
	 */
	protected Metamodel metamodel = null;

	/**
	 * The cached value of the '{@link #getGenerator() <em>Generator</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getGenerator()
	 * @generated
	 * @ordered
	 */
	protected Generator generator = null;

	/**
	 * The cached value of the '{@link #getFolder() <em>Folder</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getFolder()
	 * @generated
	 * @ordered
	 */
	protected Folder folder = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected GenerateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.GENERATE;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model getModel() {
		if (model != null && model.eIsProxy()) {
			InternalEObject oldModel = (InternalEObject) model;
			model = (Model) eResolveProxy(oldModel);
			if (model != oldModel) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.GENERATE__MODEL, oldModel, model));
			}
		}
		return model;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model basicGetModel() {
		return model;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setModel(Model newModel) {
		Model oldModel = model;
		model = newModel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.GENERATE__MODEL, oldModel, model));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Metamodel getMetamodel() {
		if (metamodel != null && metamodel.eIsProxy()) {
			InternalEObject oldMetamodel = (InternalEObject) metamodel;
			metamodel = (Metamodel) eResolveProxy(oldMetamodel);
			if (metamodel != oldMetamodel) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.GENERATE__METAMODEL, oldMetamodel, metamodel));
			}
		}
		return metamodel;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Metamodel basicGetMetamodel() {
		return metamodel;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setMetamodel(Metamodel newMetamodel) {
		Metamodel oldMetamodel = metamodel;
		metamodel = newMetamodel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.GENERATE__METAMODEL, oldMetamodel, metamodel));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Generator getGenerator() {
		if (generator != null && generator.eIsProxy()) {
			InternalEObject oldGenerator = (InternalEObject) generator;
			generator = (Generator) eResolveProxy(oldGenerator);
			if (generator != oldGenerator) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.GENERATE__GENERATOR, oldGenerator, generator));
			}
		}
		return generator;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Generator basicGetGenerator() {
		return generator;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setGenerator(Generator newGenerator) {
		Generator oldGenerator = generator;
		generator = newGenerator;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.GENERATE__GENERATOR, oldGenerator, generator));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Folder getFolder() {
		if (folder != null && folder.eIsProxy()) {
			InternalEObject oldFolder = (InternalEObject) folder;
			folder = (Folder) eResolveProxy(oldFolder);
			if (folder != oldFolder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.GENERATE__FOLDER, oldFolder, folder));
			}
		}
		return folder;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Folder basicGetFolder() {
		return folder;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setFolder(Folder newFolder) {
		Folder oldFolder = folder;
		folder = newFolder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.GENERATE__FOLDER, oldFolder, folder));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.GENERATE__MODEL:
			if (resolve)
				return getModel();
			return basicGetModel();
		case ChainPackage.GENERATE__METAMODEL:
			if (resolve)
				return getMetamodel();
			return basicGetMetamodel();
		case ChainPackage.GENERATE__GENERATOR:
			if (resolve)
				return getGenerator();
			return basicGetGenerator();
		case ChainPackage.GENERATE__FOLDER:
			if (resolve)
				return getFolder();
			return basicGetFolder();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.GENERATE__MODEL:
			setModel((Model) newValue);
			return;
		case ChainPackage.GENERATE__METAMODEL:
			setMetamodel((Metamodel) newValue);
			return;
		case ChainPackage.GENERATE__GENERATOR:
			setGenerator((Generator) newValue);
			return;
		case ChainPackage.GENERATE__FOLDER:
			setFolder((Folder) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.GENERATE__MODEL:
			setModel((Model) null);
			return;
		case ChainPackage.GENERATE__METAMODEL:
			setMetamodel((Metamodel) null);
			return;
		case ChainPackage.GENERATE__GENERATOR:
			setGenerator((Generator) null);
			return;
		case ChainPackage.GENERATE__FOLDER:
			setFolder((Folder) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.GENERATE__MODEL:
			return model != null;
		case ChainPackage.GENERATE__METAMODEL:
			return metamodel != null;
		case ChainPackage.GENERATE__GENERATOR:
			return generator != null;
		case ChainPackage.GENERATE__FOLDER:
			return folder != null;
		}
		return super.eIsSet(featureID);
	}

} // GenerateImpl
