/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Repository</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.Repository#getDocumentation <em>Documentation</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Repository#getMembers <em>Members</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Repository#getFiles <em>Files</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getRepository()
 * @model
 * @generated
 */
public interface Repository extends EObject {
	/**
	 * Returns the value of the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Documentation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Documentation</em>' attribute.
	 * @see #setDocumentation(String)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getRepository_Documentation()
	 * @model
	 * @generated
	 */
	String getDocumentation();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Repository#getDocumentation <em>Documentation</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Documentation</em>' attribute.
	 * @see #getDocumentation()
	 * @generated
	 */
	void setDocumentation(String value);

	/**
	 * Returns the value of the '<em><b>Members</b></em>' containment
	 * reference list. The list contents are of type
	 * {@link fr.obeo.acceleo.chain.Repository}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Members</em>' containment reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Members</em>' containment reference
	 *         list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getRepository_Members()
	 * @model type="fr.obeo.acceleo.chain.Repository" containment="true"
	 * @generated
	 */
	EList getMembers();

	/**
	 * Returns the value of the '<em><b>Files</b></em>' containment
	 * reference list. The list contents are of type
	 * {@link fr.obeo.acceleo.chain.File}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Files</em>' containment reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Files</em>' containment reference list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getRepository_Files()
	 * @model type="fr.obeo.acceleo.chain.File" containment="true"
	 * @generated
	 */
	EList getFiles();

} // Repository
