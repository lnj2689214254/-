/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Model Set</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.ModelSet#getExtensions <em>Extensions</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getModelSet()
 * @model
 * @generated
 */
public interface ModelSet extends Model {
	/**
	 * Returns the value of the '<em><b>Extensions</b></em>' attribute
	 * list. The list contents are of type {@link java.lang.String}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extensions</em>' attribute list isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Extensions</em>' attribute list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getModelSet_Extensions()
	 * @model type="java.lang.String"
	 * @generated
	 */
	EList getExtensions();

} // ModelSet
