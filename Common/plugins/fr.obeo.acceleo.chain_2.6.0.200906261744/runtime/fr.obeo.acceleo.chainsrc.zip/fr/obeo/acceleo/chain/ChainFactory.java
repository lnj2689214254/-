/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc --> The <b>Factory</b> for the model. It provides a
 * create method for each non-abstract class of the model. <!-- end-user-doc -->
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage
 * @generated
 */
public interface ChainFactory extends EFactory {
	/**
	 * The singleton instance of the factory. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	ChainFactory eINSTANCE = fr.obeo.acceleo.chain.impl.ChainFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Chain</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Chain</em>'.
	 * @generated
	 */
	Chain createChain();

	/**
	 * Returns a new object of class '<em>Repository</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Repository</em>'.
	 * @generated
	 */
	Repository createRepository();

	/**
	 * Returns a new object of class '<em>Action Set</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Action Set</em>'.
	 * @generated
	 */
	ActionSet createActionSet();

	/**
	 * Returns a new object of class '<em>Generate</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Generate</em>'.
	 * @generated
	 */
	Generate createGenerate();

	/**
	 * Returns a new object of class '<em>Convert Xmi</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Convert Xmi</em>'.
	 * @generated
	 */
	ConvertXmi createConvertXmi();

	/**
	 * Returns a new object of class '<em>Backup</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Backup</em>'.
	 * @generated
	 */
	Backup createBackup();

	/**
	 * Returns a new object of class '<em>Clear</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Clear</em>'.
	 * @generated
	 */
	Clear createClear();

	/**
	 * Returns a new object of class '<em>Remove</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Remove</em>'.
	 * @generated
	 */
	Remove createRemove();

	/**
	 * Returns a new object of class '<em>Call</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Call</em>'.
	 * @generated
	 */
	ChainCall createChainCall();

	/**
	 * Returns a new object of class '<em>Custom Action</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Custom Action</em>'.
	 * @generated
	 */
	CustomAction createCustomAction();

	/**
	 * Returns a new object of class '<em>Model</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Model</em>'.
	 * @generated
	 */
	Model createModel();

	/**
	 * Returns a new object of class '<em>Model Set</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Model Set</em>'.
	 * @generated
	 */
	ModelSet createModelSet();

	/**
	 * Returns a new object of class '<em>Folder</em>'. <!-- begin-user-doc
	 * --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Folder</em>'.
	 * @generated
	 */
	Folder createFolder();

	/**
	 * Returns a new object of class '<em>Log</em>'. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Log</em>'.
	 * @generated
	 */
	Log createLog();

	/**
	 * Returns a new object of class '<em>Emf Metamodel</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Emf Metamodel</em>'.
	 * @generated
	 */
	EmfMetamodel createEmfMetamodel();

	/**
	 * Returns a new object of class '<em>Generator</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Generator</em>'.
	 * @generated
	 */
	Generator createGenerator();

	/**
	 * Returns a new object of class '<em>Custom File</em>'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return a new object of class '<em>Custom File</em>'.
	 * @generated
	 */
	CustomFile createCustomFile();

	/**
	 * Returns the package supported by this factory. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the package supported by this factory.
	 * @generated
	 */
	ChainPackage getChainPackage();

} // ChainFactory
