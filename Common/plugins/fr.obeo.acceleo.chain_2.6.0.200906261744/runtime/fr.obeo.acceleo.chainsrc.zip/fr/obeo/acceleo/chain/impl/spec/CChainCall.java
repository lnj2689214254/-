/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.Repository;
import fr.obeo.acceleo.chain.impl.ChainCallImpl;
import fr.obeo.acceleo.chain.tools.CLoaderUtils;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.strings.TextSearch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;

/**
 * A representation of the model object '<em><b>ChainCall</b></em>'.
 * 
 * @author www.obeo.fr
 * 
 */
public class CChainCall extends ChainCallImpl implements CObject {

	/* (non-Javadoc) */
	public Chain getChain() {
		Chain result = super.getChain();
		if (result == null) {
			if (tempChain == null) {
				if (getChainPath() != null && getChainPath().length() > 0) {
					final IFile calledIFile = Resources.findFile(new Path(getChainPath()));
					if (calledIFile != null) {
						final URI chainURI = Resources.createPlatformResourceURI(calledIFile.getFullPath().toString());
						tempChain = CLoaderUtils.getCChainForChainURI(chainURI);
					} else {
						final java.io.File calledFile = AcceleoModuleProvider.getDefault().getFile(new Path(getChainPath()));
						if (calledFile != null) {
							final URI chainURI = URI.createFileURI(calledFile.getAbsolutePath());
							tempChain = CLoaderUtils.getCChainForChainURI(chainURI);
						}
					}
				}
			}
			result = tempChain;
		}
		return result;
	}

	private Chain tempChain = null;

	/* (non-Javadoc) */
	public void setChainPath(String newChainPath) {
		super.setChainPath(newChainPath);
		tempChain = null;
	}

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getChainPath());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (getChain() instanceof CChain) {
			final Repository repository = ((CChain) getChain()).getRepository();
			if (repository != null) {
				final String[] parametersPatterns = (String[]) ((CChain) getChain()).getParametersPatterns().toArray(new String[((CChain) getChain()).getParametersPatterns().size()]);
				final String[] argumentsPatterns = (String[]) getArgumentsPatterns().toArray(new String[getArgumentsPatterns().size()]);
				final File[] parametersFiles = (File[]) ((CChain) getChain()).getParametersFiles().toArray(new File[((CChain) getChain()).getParametersFiles().size()]);
				final File[] argumentsFiles = (File[]) getArgumentsFiles().toArray(new File[getArgumentsFiles().size()]);
				if (parametersPatterns.length == argumentsPatterns.length && parametersFiles.length == argumentsFiles.length) {
					final List undo = applyArgumentsPatterns(parametersPatterns, argumentsPatterns, repository);
					applyArgumentsFiles(parametersFiles, argumentsFiles, repository);
					try {
						((CChain) getChain()).launch(cchain, genFilter, monitor, mode);
					} finally {
						undoArguments(undo.iterator(), repository);
					}
				} else {
					final String cchainPath = cchain.getFile() != null ? cchain.getFile().getFullPath().toString() : ""; //$NON-NLS-1$
					AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("CChainCall.InvalidParameters", new Object[] { cchainPath, }), true); //$NON-NLS-1$
				}
			}
		} else {
			AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("CChainCall.UnresolvedChain", new Object[] { getChainPath(), }), true); //$NON-NLS-1$
		}
	}

	private List applyArgumentsPatterns(String[] parametersPatterns, String[] argumentsPatterns, Repository repository) {
		final List undo = new ArrayList();
		final Iterator files = repository.getFiles().iterator();
		while (files.hasNext()) {
			final File file = (File) files.next();
			String path = file.getPath();
			undo.add(path);
			if (path != null) {
				for (int i = 0; i < parametersPatterns.length; i++) {
					path = TextSearch.getDefaultSearch().replaceAllIn(path, parametersPatterns[i], argumentsPatterns[i], 0, path.length(), null);
				}
				file.setPath(path);
			}
		}
		final Iterator members = repository.getMembers().iterator();
		while (members.hasNext()) {
			undo.addAll(applyArgumentsPatterns(parametersPatterns, argumentsPatterns, (Repository) members.next()));
		}
		return undo;
	}

	private void applyArgumentsFiles(File[] parametersFiles, File[] argumentsFiles, Repository repository) {
		for (int i = 0; i < parametersFiles.length; i++) {
			parametersFiles[i].setPath(argumentsFiles[i].getPath());
		}
	}

	private void undoArguments(Iterator undo, Repository repository) {
		final Iterator files = repository.getFiles().iterator();
		while (files.hasNext()) {
			final File file = (File) files.next();
			file.setPath((String) undo.next());
		}
		final Iterator members = repository.getMembers().iterator();
		while (members.hasNext()) {
			undoArguments(undo, (Repository) members.next());
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		if (getChain() instanceof CChain) {
			final Repository repository = ((CChain) getChain()).getRepository();
			if (repository != null) {
				final String[] parametersPatterns = (String[]) ((CChain) getChain()).getParametersPatterns().toArray(new String[((CChain) getChain()).getParametersPatterns().size()]);
				final String[] argumentsPatterns = (String[]) getArgumentsPatterns().toArray(new String[getArgumentsPatterns().size()]);
				final File[] parametersFiles = (File[]) ((CChain) getChain()).getParametersFiles().toArray(new File[((CChain) getChain()).getParametersFiles().size()]);
				final File[] argumentsFiles = (File[]) getArgumentsFiles().toArray(new File[getArgumentsFiles().size()]);
				if (parametersPatterns.length == argumentsPatterns.length && parametersFiles.length == argumentsFiles.length) {
					final List undo = applyArgumentsPatterns(parametersPatterns, argumentsPatterns, repository);
					applyArgumentsFiles(parametersFiles, argumentsFiles, repository);
					try {
						return ((CChain) getChain()).totalWork();
					} finally {
						undoArguments(undo.iterator(), repository);
					}
				}
			}
		}
		return 0;
	}

}
