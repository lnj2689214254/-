/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EObject;
import org.osgi.framework.Bundle;

/**
 * A generation filter for the precondition point.
 * 
 * @author www.obeo.fr
 * 
 */
public class PreConditionGenFilter implements IGenFilter {

	/**
	 * The identifier of the internal extension point specifying the
	 * implementation to use for chain preconditions.
	 */
	private static final String CHAIN_PRECONDITION_EXTENSION_ID = "fr.obeo.acceleo.chain.precondition"; //$NON-NLS-1$

	/**
	 * The parent generation filter.
	 */
	private IGenFilter parent;

	/**
	 * The path of the files to generate.
	 */
	private List filesPathToGenerate;

	/**
	 * @param cchain
	 *            is the root element of the chain file
	 * @param parent
	 *            is the parent generation filter
	 * @param monitor
	 *            is the progress monitor
	 * @param mode
	 *            is the run mode, ILaunchManager.RUN_MODE or
	 *            ILaunchManager.DEBUG_MODE
	 */
	public PreConditionGenFilter(CChain cchain, IGenFilter parent, IProgressMonitor monitor, LaunchManager mode) {
		super();
		this.parent = parent;
		this.filesPathToGenerate = filesPathToGenerate(cchain, parent, monitor, mode);
	}

	private List filesPathToGenerate(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) {
		IExtensionRegistry registry = Platform.getExtensionRegistry();
		IExtensionPoint extensionPoint = registry.getExtensionPoint(CHAIN_PRECONDITION_EXTENSION_ID);
		if (extensionPoint == null || extensionPoint.getExtensions().length == 0) {
			return null;
		} else {
			List filesPathToGenerate = new ArrayList();
			Bundle theBundle = null;
			IExtension[] extensions = extensionPoint.getExtensions();
			for (int i = 0; i < extensions.length; i++) {
				IExtension extension = extensions[i];
				IConfigurationElement[] members = extension.getConfigurationElements();
				for (int j = 0; j < members.length; j++) {
					IConfigurationElement member = members[j];
					String conditionClass = member.getAttribute("implementation"); //$NON-NLS-1$
					theBundle = Platform.getBundle(member.getNamespace());
					if (conditionClass != null) {
						try {
							Class c = theBundle.loadClass(conditionClass);
							Object instance = c.newInstance();
							if (instance instanceof IChainPreCondition) {
								IChainPreCondition chainPreCondition = (IChainPreCondition) instance;
								List filesToGenerate = chainPreCondition.evaluate(cchain, parent, monitor, mode);
								for (Iterator iter = filesToGenerate.iterator(); iter.hasNext();) {
									Object next = iter.next();
									if (next instanceof IFile) {
										IFile iFile = (IFile) next;
										filesPathToGenerate.add(iFile.getFullPath());
									}
								}
							}
						} catch (ClassNotFoundException e) {
							AcceleoEcoreGenPlugin.getDefault().log(e, true);
						} catch (InstantiationException e) {
							AcceleoEcoreGenPlugin.getDefault().log(e, true);
						} catch (IllegalAccessException e) {
							AcceleoEcoreGenPlugin.getDefault().log(e, true);
						}
					}
				}
			}
			return filesPathToGenerate;
		}
	}

	/* (non-Javadoc) */
	public boolean filter(File script, IFile targetFile, EObject object) throws CoreException {
		return parent.filter(script, targetFile, object) && (filesPathToGenerate == null || filesPathToGenerate.contains(targetFile.getFullPath()));
	}

}
