/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.ConvertXmi;
import fr.obeo.acceleo.chain.Model;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Convert Xmi</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.ConvertXmiImpl#getMof <em>Mof</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ConvertXmiImpl#getEmf <em>Emf</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class ConvertXmiImpl extends ActionImpl implements ConvertXmi {
	/**
	 * The cached value of the '{@link #getMof() <em>Mof</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getMof()
	 * @generated
	 * @ordered
	 */
	protected Model mof = null;

	/**
	 * The cached value of the '{@link #getEmf() <em>Emf</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getEmf()
	 * @generated
	 * @ordered
	 */
	protected Model emf = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected ConvertXmiImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.CONVERT_XMI;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model getMof() {
		if (mof != null && mof.eIsProxy()) {
			InternalEObject oldMof = (InternalEObject) mof;
			mof = (Model) eResolveProxy(oldMof);
			if (mof != oldMof) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.CONVERT_XMI__MOF, oldMof, mof));
			}
		}
		return mof;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model basicGetMof() {
		return mof;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setMof(Model newMof) {
		Model oldMof = mof;
		mof = newMof;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CONVERT_XMI__MOF, oldMof, mof));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model getEmf() {
		if (emf != null && emf.eIsProxy()) {
			InternalEObject oldEmf = (InternalEObject) emf;
			emf = (Model) eResolveProxy(oldEmf);
			if (emf != oldEmf) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.CONVERT_XMI__EMF, oldEmf, emf));
			}
		}
		return emf;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Model basicGetEmf() {
		return emf;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setEmf(Model newEmf) {
		Model oldEmf = emf;
		emf = newEmf;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CONVERT_XMI__EMF, oldEmf, emf));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.CONVERT_XMI__MOF:
			if (resolve)
				return getMof();
			return basicGetMof();
		case ChainPackage.CONVERT_XMI__EMF:
			if (resolve)
				return getEmf();
			return basicGetEmf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.CONVERT_XMI__MOF:
			setMof((Model) newValue);
			return;
		case ChainPackage.CONVERT_XMI__EMF:
			setEmf((Model) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.CONVERT_XMI__MOF:
			setMof((Model) null);
			return;
		case ChainPackage.CONVERT_XMI__EMF:
			setEmf((Model) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.CONVERT_XMI__MOF:
			return mof != null;
		case ChainPackage.CONVERT_XMI__EMF:
			return emf != null;
		}
		return super.eIsSet(featureID);
	}

} // ConvertXmiImpl
