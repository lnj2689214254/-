/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Convert Xmi</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.ConvertXmi#getMof <em>Mof</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.ConvertXmi#getEmf <em>Emf</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getConvertXmi()
 * @model
 * @generated
 */
public interface ConvertXmi extends Action {
	/**
	 * Returns the value of the '<em><b>Mof</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mof</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Mof</em>' reference.
	 * @see #setMof(Model)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getConvertXmi_Mof()
	 * @model required="true"
	 * @generated
	 */
	Model getMof();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.ConvertXmi#getMof <em>Mof</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Mof</em>' reference.
	 * @see #getMof()
	 * @generated
	 */
	void setMof(Model value);

	/**
	 * Returns the value of the '<em><b>Emf</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Emf</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Emf</em>' reference.
	 * @see #setEmf(Model)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getConvertXmi_Emf()
	 * @model required="true"
	 * @generated
	 */
	Model getEmf();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.ConvertXmi#getEmf <em>Emf</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Emf</em>' reference.
	 * @see #getEmf()
	 * @generated
	 */
	void setEmf(Model value);

} // ConvertXmi
