/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainCall;
import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.File;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Call</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainCallImpl#getChain <em>Chain</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainCallImpl#getChainPath <em>Chain Path</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainCallImpl#getArgumentsPatterns <em>Arguments Patterns</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainCallImpl#getArgumentsFiles <em>Arguments Files</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class ChainCallImpl extends ActionImpl implements ChainCall {
	/**
	 * The cached value of the '{@link #getChain() <em>Chain</em>}' reference.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getChain()
	 * @generated
	 * @ordered
	 */
	protected Chain chain = null;

	/**
	 * The default value of the '{@link #getChainPath() <em>Chain Path</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getChainPath()
	 * @generated
	 * @ordered
	 */
	protected static final String CHAIN_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getChainPath() <em>Chain Path</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getChainPath()
	 * @generated
	 * @ordered
	 */
	protected String chainPath = CHAIN_PATH_EDEFAULT;

	/**
	 * The cached value of the '{@link #getArgumentsPatterns() <em>Arguments Patterns</em>}'
	 * attribute list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getArgumentsPatterns()
	 * @generated
	 * @ordered
	 */
	protected EList argumentsPatterns = null;

	/**
	 * The cached value of the '{@link #getArgumentsFiles() <em>Arguments Files</em>}'
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getArgumentsFiles()
	 * @generated
	 * @ordered
	 */
	protected EList argumentsFiles = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected ChainCallImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.CHAIN_CALL;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Chain getChain() {
		if (chain != null && chain.eIsProxy()) {
			InternalEObject oldChain = (InternalEObject) chain;
			chain = (Chain) eResolveProxy(oldChain);
			if (chain != oldChain) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.CHAIN_CALL__CHAIN, oldChain, chain));
			}
		}
		return chain;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Chain basicGetChain() {
		return chain;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setChain(Chain newChain) {
		Chain oldChain = chain;
		chain = newChain;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN_CALL__CHAIN, oldChain, chain));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getChainPath() {
		return chainPath;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setChainPath(String newChainPath) {
		String oldChainPath = chainPath;
		chainPath = newChainPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN_CALL__CHAIN_PATH, oldChainPath, chainPath));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getArgumentsPatterns() {
		if (argumentsPatterns == null) {
			argumentsPatterns = new EDataTypeUniqueEList(String.class, this, ChainPackage.CHAIN_CALL__ARGUMENTS_PATTERNS);
		}
		return argumentsPatterns;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getArgumentsFiles() {
		if (argumentsFiles == null) {
			argumentsFiles = new EObjectResolvingEList(File.class, this, ChainPackage.CHAIN_CALL__ARGUMENTS_FILES);
		}
		return argumentsFiles;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.CHAIN_CALL__CHAIN:
			if (resolve)
				return getChain();
			return basicGetChain();
		case ChainPackage.CHAIN_CALL__CHAIN_PATH:
			return getChainPath();
		case ChainPackage.CHAIN_CALL__ARGUMENTS_PATTERNS:
			return getArgumentsPatterns();
		case ChainPackage.CHAIN_CALL__ARGUMENTS_FILES:
			return getArgumentsFiles();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.CHAIN_CALL__CHAIN:
			setChain((Chain) newValue);
			return;
		case ChainPackage.CHAIN_CALL__CHAIN_PATH:
			setChainPath((String) newValue);
			return;
		case ChainPackage.CHAIN_CALL__ARGUMENTS_PATTERNS:
			getArgumentsPatterns().clear();
			getArgumentsPatterns().addAll((Collection) newValue);
			return;
		case ChainPackage.CHAIN_CALL__ARGUMENTS_FILES:
			getArgumentsFiles().clear();
			getArgumentsFiles().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.CHAIN_CALL__CHAIN:
			setChain((Chain) null);
			return;
		case ChainPackage.CHAIN_CALL__CHAIN_PATH:
			setChainPath(CHAIN_PATH_EDEFAULT);
			return;
		case ChainPackage.CHAIN_CALL__ARGUMENTS_PATTERNS:
			getArgumentsPatterns().clear();
			return;
		case ChainPackage.CHAIN_CALL__ARGUMENTS_FILES:
			getArgumentsFiles().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.CHAIN_CALL__CHAIN:
			return chain != null;
		case ChainPackage.CHAIN_CALL__CHAIN_PATH:
			return CHAIN_PATH_EDEFAULT == null ? chainPath != null : !CHAIN_PATH_EDEFAULT.equals(chainPath);
		case ChainPackage.CHAIN_CALL__ARGUMENTS_PATTERNS:
			return argumentsPatterns != null && !argumentsPatterns.isEmpty();
		case ChainPackage.CHAIN_CALL__ARGUMENTS_FILES:
			return argumentsFiles != null && !argumentsFiles.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (chainPath: ");
		result.append(chainPath);
		result.append(", argumentsPatterns: ");
		result.append(argumentsPatterns);
		result.append(')');
		return result.toString();
	}

} // ChainCallImpl
