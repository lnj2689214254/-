/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Log;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Log</b></em>'. <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public class LogImpl extends FileImpl implements Log {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected LogImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.LOG;
	}

} // LogImpl
