/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Clear</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.Clear#getResources <em>Resources</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getClear()
 * @model
 * @generated
 */
public interface Clear extends Action {
	/**
	 * Returns the value of the '<em><b>Resources</b></em>' reference list.
	 * The list contents are of type {@link fr.obeo.acceleo.chain.Data}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Resources</em>' reference list isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Resources</em>' reference list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getClear_Resources()
	 * @model type="fr.obeo.acceleo.chain.Data" required="true"
	 * @generated
	 */
	EList getResources();

} // Clear
