/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Emf Metamodel</b></em>'. <!-- end-user-doc -->
 * 
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getEmfMetamodel()
 * @model
 * @generated
 */
public interface EmfMetamodel extends Metamodel {
} // EmfMetamodel
