/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Generate</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.Generate#getModel <em>Model</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Generate#getMetamodel <em>Metamodel</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Generate#getGenerator <em>Generator</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Generate#getFolder <em>Folder</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerate()
 * @model
 * @generated
 */
public interface Generate extends Action {
	/**
	 * Returns the value of the '<em><b>Model</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Model</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Model</em>' reference.
	 * @see #setModel(Model)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerate_Model()
	 * @model required="true"
	 * @generated
	 */
	Model getModel();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Generate#getModel <em>Model</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Model</em>' reference.
	 * @see #getModel()
	 * @generated
	 */
	void setModel(Model value);

	/**
	 * Returns the value of the '<em><b>Metamodel</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Metamodel</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Metamodel</em>' reference.
	 * @see #setMetamodel(Metamodel)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerate_Metamodel()
	 * @model required="true"
	 * @generated
	 */
	Metamodel getMetamodel();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Generate#getMetamodel <em>Metamodel</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Metamodel</em>' reference.
	 * @see #getMetamodel()
	 * @generated
	 */
	void setMetamodel(Metamodel value);

	/**
	 * Returns the value of the '<em><b>Generator</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Generator</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Generator</em>' reference.
	 * @see #setGenerator(Generator)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerate_Generator()
	 * @model
	 * @generated
	 */
	Generator getGenerator();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Generate#getGenerator <em>Generator</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Generator</em>' reference.
	 * @see #getGenerator()
	 * @generated
	 */
	void setGenerator(Generator value);

	/**
	 * Returns the value of the '<em><b>Folder</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Folder</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Folder</em>' reference.
	 * @see #setFolder(Folder)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerate_Folder()
	 * @model required="true"
	 * @generated
	 */
	Folder getFolder();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Generate#getFolder
	 * <em>Folder</em>}' reference. <!-- begin-user-doc --> <!-- end-user-doc
	 * -->
	 * 
	 * @param value
	 *            the new value of the '<em>Folder</em>' reference.
	 * @see #getFolder()
	 * @generated
	 */
	void setFolder(Folder value);

} // Generate
