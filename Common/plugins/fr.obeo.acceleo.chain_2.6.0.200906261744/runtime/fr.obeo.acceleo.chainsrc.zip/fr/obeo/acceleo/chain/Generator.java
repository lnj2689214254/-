/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Generator</b></em>'. <!-- end-user-doc -->
 * 
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getGenerator()
 * @model
 * @generated
 */
public interface Generator extends File {
} // Generator
