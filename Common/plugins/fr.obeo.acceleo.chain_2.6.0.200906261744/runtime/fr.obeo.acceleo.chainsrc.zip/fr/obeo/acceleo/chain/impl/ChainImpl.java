/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.Repository;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Chain</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#getDocumentation <em>Documentation</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#getRepository <em>Repository</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#getActions <em>Actions</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#getParametersPatterns <em>Parameters Patterns</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#getParametersFiles <em>Parameters Files</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.ChainImpl#isKeepModelInMemory <em>Keep Model In Memory</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class ChainImpl extends EObjectImpl implements Chain {
	/**
	 * The default value of the '{@link #getDocumentation() <em>Documentation</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getDocumentation()
	 * @generated
	 * @ordered
	 */
	protected static final String DOCUMENTATION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDocumentation() <em>Documentation</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getDocumentation()
	 * @generated
	 * @ordered
	 */
	protected String documentation = DOCUMENTATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRepository() <em>Repository</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getRepository()
	 * @generated
	 * @ordered
	 */
	protected Repository repository = null;

	/**
	 * The cached value of the '{@link #getActions() <em>Actions</em>}'
	 * containment reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getActions()
	 * @generated
	 * @ordered
	 */
	protected EList actions = null;

	/**
	 * The cached value of the '{@link #getParametersPatterns() <em>Parameters Patterns</em>}'
	 * attribute list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getParametersPatterns()
	 * @generated
	 * @ordered
	 */
	protected EList parametersPatterns = null;

	/**
	 * The cached value of the '{@link #getParametersFiles() <em>Parameters Files</em>}'
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getParametersFiles()
	 * @generated
	 * @ordered
	 */
	protected EList parametersFiles = null;

	/**
	 * The default value of the '{@link #isKeepModelInMemory() <em>Keep Model In Memory</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isKeepModelInMemory()
	 * @generated
	 * @ordered
	 */
	protected static final boolean KEEP_MODEL_IN_MEMORY_EDEFAULT = true;

	/**
	 * The cached value of the '{@link #isKeepModelInMemory() <em>Keep Model In Memory</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #isKeepModelInMemory()
	 * @generated
	 * @ordered
	 */
	protected boolean keepModelInMemory = KEEP_MODEL_IN_MEMORY_EDEFAULT;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected ChainImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.CHAIN;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String getDocumentation() {
		return documentation;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setDocumentation(String newDocumentation) {
		String oldDocumentation = documentation;
		documentation = newDocumentation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN__DOCUMENTATION, oldDocumentation, documentation));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Repository getRepository() {
		return repository;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain basicSetRepository(Repository newRepository, NotificationChain msgs) {
		Repository oldRepository = repository;
		repository = newRepository;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN__REPOSITORY, oldRepository, newRepository);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setRepository(Repository newRepository) {
		if (newRepository != repository) {
			NotificationChain msgs = null;
			if (repository != null)
				msgs = ((InternalEObject) repository).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ChainPackage.CHAIN__REPOSITORY, null, msgs);
			if (newRepository != null)
				msgs = ((InternalEObject) newRepository).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ChainPackage.CHAIN__REPOSITORY, null, msgs);
			msgs = basicSetRepository(newRepository, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN__REPOSITORY, newRepository, newRepository));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getActions() {
		if (actions == null) {
			actions = new EObjectContainmentEList(ActionSet.class, this, ChainPackage.CHAIN__ACTIONS);
		}
		return actions;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getParametersPatterns() {
		if (parametersPatterns == null) {
			parametersPatterns = new EDataTypeUniqueEList(String.class, this, ChainPackage.CHAIN__PARAMETERS_PATTERNS);
		}
		return parametersPatterns;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getParametersFiles() {
		if (parametersFiles == null) {
			parametersFiles = new EObjectResolvingEList(File.class, this, ChainPackage.CHAIN__PARAMETERS_FILES);
		}
		return parametersFiles;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean isKeepModelInMemory() {
		return keepModelInMemory;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setKeepModelInMemory(boolean newKeepModelInMemory) {
		boolean oldKeepModelInMemory = keepModelInMemory;
		keepModelInMemory = newKeepModelInMemory;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.CHAIN__KEEP_MODEL_IN_MEMORY, oldKeepModelInMemory, keepModelInMemory));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ChainPackage.CHAIN__REPOSITORY:
			return basicSetRepository(null, msgs);
		case ChainPackage.CHAIN__ACTIONS:
			return ((InternalEList) getActions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.CHAIN__DOCUMENTATION:
			return getDocumentation();
		case ChainPackage.CHAIN__REPOSITORY:
			return getRepository();
		case ChainPackage.CHAIN__ACTIONS:
			return getActions();
		case ChainPackage.CHAIN__PARAMETERS_PATTERNS:
			return getParametersPatterns();
		case ChainPackage.CHAIN__PARAMETERS_FILES:
			return getParametersFiles();
		case ChainPackage.CHAIN__KEEP_MODEL_IN_MEMORY:
			return isKeepModelInMemory() ? Boolean.TRUE : Boolean.FALSE;
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.CHAIN__DOCUMENTATION:
			setDocumentation((String) newValue);
			return;
		case ChainPackage.CHAIN__REPOSITORY:
			setRepository((Repository) newValue);
			return;
		case ChainPackage.CHAIN__ACTIONS:
			getActions().clear();
			getActions().addAll((Collection) newValue);
			return;
		case ChainPackage.CHAIN__PARAMETERS_PATTERNS:
			getParametersPatterns().clear();
			getParametersPatterns().addAll((Collection) newValue);
			return;
		case ChainPackage.CHAIN__PARAMETERS_FILES:
			getParametersFiles().clear();
			getParametersFiles().addAll((Collection) newValue);
			return;
		case ChainPackage.CHAIN__KEEP_MODEL_IN_MEMORY:
			setKeepModelInMemory(((Boolean) newValue).booleanValue());
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.CHAIN__DOCUMENTATION:
			setDocumentation(DOCUMENTATION_EDEFAULT);
			return;
		case ChainPackage.CHAIN__REPOSITORY:
			setRepository((Repository) null);
			return;
		case ChainPackage.CHAIN__ACTIONS:
			getActions().clear();
			return;
		case ChainPackage.CHAIN__PARAMETERS_PATTERNS:
			getParametersPatterns().clear();
			return;
		case ChainPackage.CHAIN__PARAMETERS_FILES:
			getParametersFiles().clear();
			return;
		case ChainPackage.CHAIN__KEEP_MODEL_IN_MEMORY:
			setKeepModelInMemory(KEEP_MODEL_IN_MEMORY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.CHAIN__DOCUMENTATION:
			return DOCUMENTATION_EDEFAULT == null ? documentation != null : !DOCUMENTATION_EDEFAULT.equals(documentation);
		case ChainPackage.CHAIN__REPOSITORY:
			return repository != null;
		case ChainPackage.CHAIN__ACTIONS:
			return actions != null && !actions.isEmpty();
		case ChainPackage.CHAIN__PARAMETERS_PATTERNS:
			return parametersPatterns != null && !parametersPatterns.isEmpty();
		case ChainPackage.CHAIN__PARAMETERS_FILES:
			return parametersFiles != null && !parametersFiles.isEmpty();
		case ChainPackage.CHAIN__KEEP_MODEL_IN_MEMORY:
			return keepModelInMemory != KEEP_MODEL_IN_MEMORY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (documentation: ");
		result.append(documentation);
		result.append(", parametersPatterns: ");
		result.append(parametersPatterns);
		result.append(", keepModelInMemory: ");
		result.append(keepModelInMemory);
		result.append(')');
		return result.toString();
	}

} // ChainImpl
