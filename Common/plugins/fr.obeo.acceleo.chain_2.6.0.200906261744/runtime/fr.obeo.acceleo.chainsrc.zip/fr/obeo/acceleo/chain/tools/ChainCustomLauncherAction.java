/*
 * Copyright (c) 2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */
package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchManager;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.impl.spec.CCustomFile;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

/**
 * A custom action to invoke an Eclipse launch configuration, stored in a
 * <code>.launch</code> file.
 * 
 * @author www.obeo.fr
 */
public class ChainCustomLauncherAction implements IChainCustomAction {

	/* (non-Javadoc) */
	public void run(Data[] resources, CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (resources.length != 1) {
			String errMsg = AcceleoChainMessages.getString("ChainCustomLauncherAction.IllegalResourceCount"); //$NON-NLS-1$
			AcceleoEcoreGenPlugin.getDefault().log(errMsg, true);
			return;
		}

		if (!(resources[0] instanceof CCustomFile)) {
			String errMsg = AcceleoChainMessages.getString("ChainCustomLauncherAction.InvalidResource"); //$NON-NLS-1$
			AcceleoEcoreGenPlugin.getDefault().log(errMsg, true);
			return;
		}

		IPath path = new Path(((CCustomFile) resources[0]).getPath());
		IFile launchFile = ResourcesPlugin.getWorkspace().getRoot().getFile(path);
		if (launchFile != null && launchFile.exists() && launchFile.getLocation() != null) {
			runLauncher(launchFile, monitor);
		} else {
			String errMsg = AcceleoChainMessages.getString("ChainCustomLauncherAction.MissingInputFile", new Object[] { path.toString() }); //$NON-NLS-1$
			AcceleoEcoreGenPlugin.getDefault().log(errMsg, true);
		}
	}

	/**
	 * The actual invocation of the launch configuration.
	 */
	private void runLauncher(IFile launcherFile, IProgressMonitor monitor) throws CoreException {
		ILaunchManager lm = DebugPlugin.getDefault().getLaunchManager();
		ILaunchConfiguration config = lm.getLaunchConfiguration(launcherFile);
		config.launch(ILaunchManager.RUN_MODE, monitor);
	}
}
