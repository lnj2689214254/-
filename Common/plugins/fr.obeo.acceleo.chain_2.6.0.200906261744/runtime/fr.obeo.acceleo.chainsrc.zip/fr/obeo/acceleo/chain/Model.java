/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Model</b></em>'. <!-- end-user-doc -->
 * 
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getModel()
 * @model
 * @generated
 */
public interface Model extends File, Data {
} // Model
