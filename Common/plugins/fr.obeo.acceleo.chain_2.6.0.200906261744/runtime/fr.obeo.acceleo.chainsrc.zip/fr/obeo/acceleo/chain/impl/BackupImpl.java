/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import fr.obeo.acceleo.chain.Backup;
import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Folder;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Backup</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.BackupImpl#getFolder <em>Folder</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.BackupImpl#getBackup <em>Backup</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class BackupImpl extends ActionImpl implements Backup {
	/**
	 * The cached value of the '{@link #getFolder() <em>Folder</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getFolder()
	 * @generated
	 * @ordered
	 */
	protected Folder folder = null;

	/**
	 * The cached value of the '{@link #getBackup() <em>Backup</em>}'
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getBackup()
	 * @generated
	 * @ordered
	 */
	protected EList backup = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected BackupImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.BACKUP;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Folder getFolder() {
		if (folder != null && folder.eIsProxy()) {
			InternalEObject oldFolder = (InternalEObject) folder;
			folder = (Folder) eResolveProxy(oldFolder);
			if (folder != oldFolder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ChainPackage.BACKUP__FOLDER, oldFolder, folder));
			}
		}
		return folder;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Folder basicGetFolder() {
		return folder;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void setFolder(Folder newFolder) {
		Folder oldFolder = folder;
		folder = newFolder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ChainPackage.BACKUP__FOLDER, oldFolder, folder));
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getBackup() {
		if (backup == null) {
			backup = new EObjectResolvingEList(Folder.class, this, ChainPackage.BACKUP__BACKUP);
		}
		return backup;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.BACKUP__FOLDER:
			if (resolve)
				return getFolder();
			return basicGetFolder();
		case ChainPackage.BACKUP__BACKUP:
			return getBackup();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.BACKUP__FOLDER:
			setFolder((Folder) newValue);
			return;
		case ChainPackage.BACKUP__BACKUP:
			getBackup().clear();
			getBackup().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.BACKUP__FOLDER:
			setFolder((Folder) null);
			return;
		case ChainPackage.BACKUP__BACKUP:
			getBackup().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.BACKUP__FOLDER:
			return folder != null;
		case ChainPackage.BACKUP__BACKUP:
			return backup != null && !backup.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} // BackupImpl
