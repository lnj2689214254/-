/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Custom File</b></em>'. <!-- end-user-doc -->
 * 
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getCustomFile()
 * @model
 * @generated
 */
public interface CustomFile extends File, Data {
} // CustomFile
