/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.CustomFile;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Custom File</b></em>'. <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public class CustomFileImpl extends FileImpl implements CustomFile {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected CustomFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.CUSTOM_FILE;
	}

} // CustomFileImpl
