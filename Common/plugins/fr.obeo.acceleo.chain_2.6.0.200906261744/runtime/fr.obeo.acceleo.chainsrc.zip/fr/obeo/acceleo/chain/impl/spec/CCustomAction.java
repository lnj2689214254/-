/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.CustomActionIDs;
import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.impl.CustomActionImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.chain.tools.IChainCustomAction;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.util.Iterator;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

/**
 * A representation of the model object '<em><b>CustomAction</b></em>'.
 * 
 * @author www.obeo.fr
 * 
 */
public class CCustomAction extends CustomActionImpl implements CObject {

	/**
	 * The identifier of the internal extension point specifying the
	 * implementation to use for custom action.
	 */
	public static final String CHAIN_CUSTOM_EXTENSION_ID = "fr.obeo.acceleo.chain.custom"; //$NON-NLS-1$

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getDocumentation());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		IExtensionRegistry registry = Platform.getExtensionRegistry();
		IExtensionPoint extensionPoint = registry.getExtensionPoint(CHAIN_CUSTOM_EXTENSION_ID);
		if (extensionPoint == null || extensionPoint.getExtensions().length == 0) {
			AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("UnresolvedExtensionPoint", new Object[] { CHAIN_CUSTOM_EXTENSION_ID, }), true); //$NON-NLS-1$
		} else {
			if (getID() != null) {
				Iterator it = getID().iterator();
				while (it.hasNext()) {
					String next = ((CustomActionIDs) it.next()).getLiteral();
					boolean ok = false;
					Bundle theBundle = null;
					IExtension[] extensions = extensionPoint.getExtensions();
					for (int i = 0; !ok && i < extensions.length; i++) {
						IExtension extension = extensions[i];
						IConfigurationElement[] members = extension.getConfigurationElements();
						for (int j = 0; !ok && j < members.length; j++) {
							IConfigurationElement member = members[j];
							String id = member.getAttribute("customId"); //$NON-NLS-1$
							if (id != null && id.equals(next)) {
								String action = member.getAttribute("actionClass"); //$NON-NLS-1$
								theBundle = Platform.getBundle(member.getNamespace());
								if (action != null) {
									try {
										Class c = theBundle.loadClass(action);
										Object instance = c.newInstance();
										if (instance instanceof IChainCustomAction) {
											IChainCustomAction customAction = (IChainCustomAction) instance;
											customAction.run((Data[]) getResources().toArray(new Data[getResources().size()]), cchain, genFilter, monitor, mode);
											ok = true;
										}
									} catch (ClassNotFoundException e) {
										AcceleoEcoreGenPlugin.getDefault().log(e, true);
									} catch (InstantiationException e) {
										AcceleoEcoreGenPlugin.getDefault().log(e, true);
									} catch (IllegalAccessException e) {
										AcceleoEcoreGenPlugin.getDefault().log(e, true);
									}
								} else {
									AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("CCustomAction.ClassError", new Object[] { next, }), true); //$NON-NLS-1$
								}
							}
						}
					}
					if (!ok) {
						final String message = getDocumentation() != null && getDocumentation().length() > 0 ? '(' + getDocumentation() + ')' : ""; //$NON-NLS-1$

						AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("CCustomAction.Invalid", new Object[] { next, message, }), true); //$NON-NLS-1$
					}
				}
			}
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 0;
	}

}
