/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Chain</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.Chain#getDocumentation <em>Documentation</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Chain#getRepository <em>Repository</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Chain#getActions <em>Actions</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Chain#getParametersPatterns <em>Parameters Patterns</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Chain#getParametersFiles <em>Parameters Files</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Chain#isKeepModelInMemory <em>Keep Model In Memory</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getChain()
 * @model
 * @generated
 */
public interface Chain extends EObject {
	/**
	 * Returns the value of the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Documentation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Documentation</em>' attribute.
	 * @see #setDocumentation(String)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_Documentation()
	 * @model
	 * @generated
	 */
	String getDocumentation();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Chain#getDocumentation <em>Documentation</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Documentation</em>' attribute.
	 * @see #getDocumentation()
	 * @generated
	 */
	void setDocumentation(String value);

	/**
	 * Returns the value of the '<em><b>Repository</b></em>' containment
	 * reference. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Repository</em>' containment reference
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Repository</em>' containment reference.
	 * @see #setRepository(Repository)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_Repository()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Repository getRepository();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Chain#getRepository <em>Repository</em>}'
	 * containment reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Repository</em>' containment
	 *            reference.
	 * @see #getRepository()
	 * @generated
	 */
	void setRepository(Repository value);

	/**
	 * Returns the value of the '<em><b>Actions</b></em>' containment
	 * reference list. The list contents are of type
	 * {@link fr.obeo.acceleo.chain.ActionSet}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Actions</em>' containment reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Actions</em>' containment reference
	 *         list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_Actions()
	 * @model type="fr.obeo.acceleo.chain.ActionSet" containment="true"
	 * @generated
	 */
	EList getActions();

	/**
	 * Returns the value of the '<em><b>Parameters Patterns</b></em>'
	 * attribute list. The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters Patterns</em>' attribute list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Parameters Patterns</em>' attribute
	 *         list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_ParametersPatterns()
	 * @model type="java.lang.String"
	 * @generated
	 */
	EList getParametersPatterns();

	/**
	 * Returns the value of the '<em><b>Parameters Files</b></em>'
	 * reference list. The list contents are of type
	 * {@link fr.obeo.acceleo.chain.File}. <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameters Files</em>' reference list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Parameters Files</em>' reference list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_ParametersFiles()
	 * @model type="fr.obeo.acceleo.chain.File"
	 * @generated
	 */
	EList getParametersFiles();

	/**
	 * Returns the value of the '<em><b>Keep Model In Memory</b></em>'
	 * attribute. The default value is <code>"true"</code>. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Keep Model In Memory</em>' attribute isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Keep Model In Memory</em>' attribute.
	 * @see #setKeepModelInMemory(boolean)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChain_KeepModelInMemory()
	 * @model default="true"
	 * @generated
	 */
	boolean isKeepModelInMemory();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Chain#isKeepModelInMemory <em>Keep Model In Memory</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Keep Model In Memory</em>'
	 *            attribute.
	 * @see #isKeepModelInMemory()
	 * @generated
	 */
	void setKeepModelInMemory(boolean value);

} // Chain
