/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Generator;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Generator</b></em>'. <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public class GeneratorImpl extends FileImpl implements Generator {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected GeneratorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.GENERATOR;
	}

} // GeneratorImpl
