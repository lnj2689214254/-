/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.util;

import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;

import fr.obeo.acceleo.chain.Action;
import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Backup;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainCall;
import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Clear;
import fr.obeo.acceleo.chain.ConvertXmi;
import fr.obeo.acceleo.chain.CustomAction;
import fr.obeo.acceleo.chain.CustomFile;
import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.EmfMetamodel;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.Folder;
import fr.obeo.acceleo.chain.Generate;
import fr.obeo.acceleo.chain.Generator;
import fr.obeo.acceleo.chain.Log;
import fr.obeo.acceleo.chain.Metamodel;
import fr.obeo.acceleo.chain.Model;
import fr.obeo.acceleo.chain.ModelSet;
import fr.obeo.acceleo.chain.Remove;
import fr.obeo.acceleo.chain.Repository;

/**
 * <!-- begin-user-doc --> The <b>Switch</b> for the model's inheritance
 * hierarchy. It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object and proceeding up the
 * inheritance hierarchy until a non-null result is returned, which is the
 * result of the switch. <!-- end-user-doc -->
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage
 * @generated
 */
public class ChainSwitch {
	/**
	 * The cached model package <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected static ChainPackage modelPackage;

	/**
	 * Creates an instance of the switch. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	public ChainSwitch() {
		if (modelPackage == null) {
			modelPackage = ChainPackage.eINSTANCE;
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one
	 * returns a non null result; it yields that result. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the first non-null result returned by a <code>caseXXX</code>
	 *         call.
	 * @generated
	 */
	public Object doSwitch(EObject theEObject) {
		return doSwitch(theEObject.eClass(), theEObject);
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one
	 * returns a non null result; it yields that result. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the first non-null result returned by a <code>caseXXX</code>
	 *         call.
	 * @generated
	 */
	protected Object doSwitch(EClass theEClass, EObject theEObject) {
		if (theEClass.eContainer() == modelPackage) {
			return doSwitch(theEClass.getClassifierID(), theEObject);
		} else {
			List eSuperTypes = theEClass.getESuperTypes();
			return eSuperTypes.isEmpty() ? defaultCase(theEObject) : doSwitch((EClass) eSuperTypes.get(0), theEObject);
		}
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one
	 * returns a non null result; it yields that result. <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @return the first non-null result returned by a <code>caseXXX</code>
	 *         call.
	 * @generated
	 */
	protected Object doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ChainPackage.CHAIN: {
			Chain chain = (Chain) theEObject;
			Object result = caseChain(chain);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.REPOSITORY: {
			Repository repository = (Repository) theEObject;
			Object result = caseRepository(repository);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.ACTION_SET: {
			ActionSet actionSet = (ActionSet) theEObject;
			Object result = caseActionSet(actionSet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.ACTION: {
			Action action = (Action) theEObject;
			Object result = caseAction(action);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.GENERATE: {
			Generate generate = (Generate) theEObject;
			Object result = caseGenerate(generate);
			if (result == null)
				result = caseAction(generate);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.CONVERT_XMI: {
			ConvertXmi convertXmi = (ConvertXmi) theEObject;
			Object result = caseConvertXmi(convertXmi);
			if (result == null)
				result = caseAction(convertXmi);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.BACKUP: {
			Backup backup = (Backup) theEObject;
			Object result = caseBackup(backup);
			if (result == null)
				result = caseAction(backup);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.CLEAR: {
			Clear clear = (Clear) theEObject;
			Object result = caseClear(clear);
			if (result == null)
				result = caseAction(clear);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.REMOVE: {
			Remove remove = (Remove) theEObject;
			Object result = caseRemove(remove);
			if (result == null)
				result = caseAction(remove);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.CHAIN_CALL: {
			ChainCall chainCall = (ChainCall) theEObject;
			Object result = caseChainCall(chainCall);
			if (result == null)
				result = caseAction(chainCall);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.CUSTOM_ACTION: {
			CustomAction customAction = (CustomAction) theEObject;
			Object result = caseCustomAction(customAction);
			if (result == null)
				result = caseAction(customAction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.DATA: {
			Data data = (Data) theEObject;
			Object result = caseData(data);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.FILE: {
			File file = (File) theEObject;
			Object result = caseFile(file);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.MODEL: {
			Model model = (Model) theEObject;
			Object result = caseModel(model);
			if (result == null)
				result = caseFile(model);
			if (result == null)
				result = caseData(model);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.MODEL_SET: {
			ModelSet modelSet = (ModelSet) theEObject;
			Object result = caseModelSet(modelSet);
			if (result == null)
				result = caseModel(modelSet);
			if (result == null)
				result = caseFile(modelSet);
			if (result == null)
				result = caseData(modelSet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.FOLDER: {
			Folder folder = (Folder) theEObject;
			Object result = caseFolder(folder);
			if (result == null)
				result = caseFile(folder);
			if (result == null)
				result = caseData(folder);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.LOG: {
			Log log = (Log) theEObject;
			Object result = caseLog(log);
			if (result == null)
				result = caseFile(log);
			if (result == null)
				result = caseData(log);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.METAMODEL: {
			Metamodel metamodel = (Metamodel) theEObject;
			Object result = caseMetamodel(metamodel);
			if (result == null)
				result = caseFile(metamodel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.EMF_METAMODEL: {
			EmfMetamodel emfMetamodel = (EmfMetamodel) theEObject;
			Object result = caseEmfMetamodel(emfMetamodel);
			if (result == null)
				result = caseMetamodel(emfMetamodel);
			if (result == null)
				result = caseFile(emfMetamodel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.GENERATOR: {
			Generator generator = (Generator) theEObject;
			Object result = caseGenerator(generator);
			if (result == null)
				result = caseFile(generator);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ChainPackage.CUSTOM_FILE: {
			CustomFile customFile = (CustomFile) theEObject;
			Object result = caseCustomFile(customFile);
			if (result == null)
				result = caseFile(customFile);
			if (result == null)
				result = caseData(customFile);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Chain</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Chain</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseChain(Chain object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Repository</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Repository</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRepository(Repository object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Action Set</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Action Set</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseActionSet(ActionSet object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Action</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseAction(Action object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Generate</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Generate</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseGenerate(Generate object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Convert Xmi</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Convert Xmi</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseConvertXmi(ConvertXmi object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Backup</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Backup</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseBackup(Backup object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Clear</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Clear</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseClear(Clear object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Remove</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Remove</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseRemove(Remove object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Call</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Call</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseChainCall(ChainCall object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Custom Action</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Custom Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseCustomAction(CustomAction object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Data</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseData(Data object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>File</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFile(File object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Model</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseModel(Model object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Model Set</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Model Set</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseModelSet(ModelSet object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Folder</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Folder</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseFolder(Folder object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Log</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Log</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseLog(Log object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Metamodel</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Metamodel</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseMetamodel(Metamodel object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Emf Metamodel</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Emf Metamodel</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseEmfMetamodel(EmfMetamodel object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Generator</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Generator</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseGenerator(Generator object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>Custom File</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>Custom File</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public Object caseCustomFile(CustomFile object) {
		return null;
	}

	/**
	 * Returns the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc --> This implementation returns null; returning a
	 * non-null result will terminate the switch, but this is the last case
	 * anyway. <!-- end-user-doc -->
	 * 
	 * @param object
	 *            the target of the switch.
	 * @return the result of interpretting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	public Object defaultCase(EObject object) {
		return null;
	}

} // ChainSwitch
