/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.impl.spec.CFolder;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * A custom action to initialize a project.
 * 
 * @author www.obeo.fr
 */
public class ChainCustomInitAction implements IChainCustomAction {

	/* (non-Javadoc) */
	public void run(Data[] resources, CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			if (resources.length == 2) {
				IPath input = null;
				IPath output = null;
				for (int i = 0; i < resources.length; i++) {
					Data data = resources[i];
					if (data instanceof CFolder) {
						if (i == 0) {
							input = new Path(((CFolder) data).getPath());
						} else if (i == 1) {
							output = new Path(((CFolder) data).getPath());
						}
					}
				}
				if (input != null && output != null) {
					java.io.File inputFile = null;
					// first look into the workspace
					IResource fileFromWorkspace = ResourcesPlugin.getWorkspace().getRoot().getFile(input);
					if (fileFromWorkspace == null || !fileFromWorkspace.exists() || !fileFromWorkspace.isAccessible())
						fileFromWorkspace = ResourcesPlugin.getWorkspace().getRoot().getFolder(input);
					if (fileFromWorkspace != null && fileFromWorkspace.exists() && fileFromWorkspace.getLocation() != null)
						inputFile = fileFromWorkspace.getLocation().toFile();
					// if the file does not exist in the workspace, look into
					// the plugins
					if (inputFile == null)
						inputFile = AcceleoModuleProvider.getDefault().getFile(input);
					if (inputFile != null && inputFile.exists() && inputFile.isDirectory()) {
						IFolder outputFolder = Resources.getOrCreateFolder(ResourcesPlugin.getWorkspace().getRoot(), output, monitor);
						try {
							copyFiles(inputFile, outputFolder.getLocation().toFile());
						} catch (IOException e) {
							AcceleoEcoreGenPlugin.getDefault().log(e, true);
						}
						outputFolder.refreshLocal(IResource.DEPTH_INFINITE, monitor);
					} else {
						AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainCustomInitAction.MissingInputFolder", new Object[] { input.toString(), }), true); //$NON-NLS-1$
					}
				} else {
					AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainCustomInitAction.InvalidResource"), true); //$NON-NLS-1$
				}
			} else {
				AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainCustomInitAction.IllegalResourceCount"), true); //$NON-NLS-1$
			}
		}
	}

	private void copyFiles(File src, File dest) throws IOException {
		if (!src.exists()) {
			return;
		}
		if (src.isDirectory()) {
			dest.mkdirs();
			String list[] = src.list();
			for (int i = 0; i < list.length; i++) {
				copyFiles(new File(src, list[i]), new File(dest, list[i]));
			}
		} else {
			copyFile(src, dest);
		}
	}

	private void copyFile(File src, File dest) throws FileNotFoundException, IOException {
		if (dest.exists()) {
			return;
		}

		// this part comes from org.apache.tools.ant.util.FileUtils
		FileInputStream in = null;
		FileOutputStream out = null;
		try {
			in = new FileInputStream(src);
			out = new FileOutputStream(dest);

			byte[] buffer = new byte[8 * 1024];
			int count = 0;
			do {
				out.write(buffer, 0, count);
				count = in.read(buffer, 0, buffer.length);
			} while (count != -1);
		} finally {
			if (out != null) {
				out.close();
			}
			if (in != null) {
				in.close();
			}
		}
	}

}
