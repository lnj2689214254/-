/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.impl.ChainImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.chain.tools.IPostGeneration;
import fr.obeo.acceleo.chain.tools.PreConditionGenFilter;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.phantom.ChainPhantomProvider;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.resources.Resources;
import fr.obeo.acceleo.tools.ui.views.AcceleoConsole;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

/**
 * A representation of the model object '<em><b>Chain</b></em>'.
 * 
 * @author www.obeo.fr
 * 
 */
public class CChain extends ChainImpl implements CObject {

	/**
	 * The identifier of the extension point used to custom the ending of the
	 * generation.
	 */
	private static final String POST_GENERATION_EXTENSION_ID = "fr.obeo.acceleo.chain.postGeneration"; //$NON-NLS-1$

	/**
	 * The corresponding 'chain' file in the workspace.
	 */
	protected IFile file = null;

	/**
	 * The generated files.
	 */
	protected List generatedFiles = new ArrayList();

	/**
	 * the post generation action of the chain
	 */
	private IPostGeneration postGeneration = null;

	/**
	 * @return the corresponding 'chain' file in the workspace
	 */
	public IFile getFile() {
		return this.file;
	}

	/**
	 * @param file
	 *            is the corresponding 'chain' file in the workspace
	 */
	public void setFile(IFile file) {
		this.file = file;
	}

	/**
	 * Add generated files.
	 * 
	 * @param files
	 *            are the new generated files
	 */
	public void addGeneratedFiles(List files) {
		generatedFiles.addAll(files);
	}

	/**
	 * It runs the tasks specified on this element of the 'chain' model.
	 * 
	 * @param genFilter
	 *            is the generation filter
	 * @param monitor
	 *            is the progress monitor
	 * @param mode
	 *            is the run mode, ILaunchManager.RUN_MODE or
	 *            ILaunchManager.DEBUG_MODE
	 * @throws CoreException
	 */
	public void launch(IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getFile());
		}
		try {
			launchSub(genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	private void launchSub(IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		AcceleoConsole.getDefault().asDefaultForSystemOut();
		if (mode.getMode() == LaunchManager.PREVIEW_MODE) {
			if (file != null) {
				final IContainer targetBackup = Resources.getContainer(file.getProject(), new Path(CGenerate.PHANTOM_PREVIEW_FOLDER_BACKUP), monitor);
				if (targetBackup.isAccessible()) {
					targetBackup.delete(true, monitor);
				}
				final IContainer target = Resources.getContainer(file.getProject(), new Path(CGenerate.PHANTOM_PREVIEW_FOLDER_GENERATED), monitor);
				if (target.isAccessible()) {
					target.delete(true, monitor);
				}
			}
		} else {
			ChainPhantomProvider.getDefault().clearForUpdate(file);
			genFilter = new PreConditionGenFilter(this, genFilter, monitor, mode);
		}
		// Chain actions
		generatedFiles.clear();
		postGeneration = null;
		mode.setMonitor(monitor);
		try {
			final Iterator actions = getActions().iterator();
			while (actions.hasNext()) {
				final CObject action = (CObject) actions.next();
				action.launch(this, genFilter, monitor, mode);
			}
			if (getPostGenerationAction() != null) {
				getPostGenerationAction().postProcessing(monitor);
			}
		} finally {
			CGenerate.clearModelContext();
			mode.setMonitor(null);
			ChainPhantomProvider.getDefault().update(getFile(), (IFile[]) generatedFiles.toArray(new IFile[generatedFiles.size()]), monitor);
		}
	}

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		final Iterator actions = getActions().iterator();
		while (actions.hasNext()) {
			final CObject action = (CObject) actions.next();
			action.launch(cchain, genFilter, monitor, mode);
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		int totalWork = 0;
		final Iterator actions = getActions().iterator();
		while (actions.hasNext()) {
			final CObject action = (CObject) actions.next();
			totalWork += action.totalWork();
		}
		return totalWork;
	}

	/**
	 * @return the post generation action of the chain
	 */
	public IPostGeneration getPostGenerationAction() {
		if (postGeneration == null) {
			final IExtensionRegistry registry = Platform.getExtensionRegistry();
			final IExtensionPoint extensionPoint = registry.getExtensionPoint(POST_GENERATION_EXTENSION_ID);
			if (extensionPoint == null) {
				AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("UnresolvedExtensionPoint", new Object[] { POST_GENERATION_EXTENSION_ID, }), true); //$NON-NLS-1$
			} else {
				String theClass = null;
				int thePriority = -1;
				Bundle theBundle = null;
				final IExtension[] extensions = extensionPoint.getExtensions();
				for (int i = 0; i < extensions.length; i++) {
					final IExtension extension = extensions[i];
					final IConfigurationElement[] members = extension.getConfigurationElements();
					for (int j = 0; j < members.length; j++) {
						final IConfigurationElement member = members[j];
						final String clazz = member.getAttribute("class"); //$NON-NLS-1$
						final String priority = member.getAttribute("priority"); //$NON-NLS-1$
						if (clazz != null && (thePriority == -1 || priority != null && Integer.parseInt(priority) > thePriority)) {
							theClass = clazz;
							if (priority != null) {
								thePriority = Integer.parseInt(priority);
							} else {
								thePriority = 0;
							}
							theBundle = Platform.getBundle(member.getNamespace());
							if (theBundle == null) {
								theBundle = AcceleoEcoreGenPlugin.getDefault().getBundle();
							}
						}
					}
				}
				if (theClass != null) {
					try {
						final Class c = theBundle.loadClass(theClass);
						final Object instance = c.newInstance();
						if (instance instanceof IPostGeneration) {
							postGeneration = (IPostGeneration) instance;
						}
					} catch (final ClassNotFoundException e) {
						AcceleoEcoreGenPlugin.getDefault().log(e, true);
					} catch (final InstantiationException e) {
						AcceleoEcoreGenPlugin.getDefault().log(e, true);
					} catch (final IllegalAccessException e) {
						AcceleoEcoreGenPlugin.getDefault().log(e, true);
					}
				}
			}
		}
		return postGeneration;
	}

}
