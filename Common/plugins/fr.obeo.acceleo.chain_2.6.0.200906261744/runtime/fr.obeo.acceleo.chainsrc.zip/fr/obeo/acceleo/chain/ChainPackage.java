/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc --> The <b>Package</b> for the model. It contains
 * accessors for the meta objects to represent
 * <ul>
 * <li>each class,</li>
 * <li>each feature of each class,</li>
 * <li>each enum,</li>
 * <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * 
 * @see fr.obeo.acceleo.chain.ChainFactory
 * @model kind="package"
 * @generated
 */
public interface ChainPackage extends EPackage {
	/**
	 * The package name. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNAME = "chain"; //$NON-NLS-1$

	/**
	 * The package namespace URI. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNS_URI = "http://www.obeo.fr/acceleo/chain"; //$NON-NLS-1$

	/**
	 * The package namespace name. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	String eNS_PREFIX = "chain"; //$NON-NLS-1$

	/**
	 * The singleton instance of the package. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	ChainPackage eINSTANCE = fr.obeo.acceleo.chain.impl.ChainPackageImpl.init();

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ChainImpl <em>Chain</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ChainImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getChain()
	 * @generated
	 */
	int CHAIN = 0;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__DOCUMENTATION = 0;

	/**
	 * The feature id for the '<em><b>Repository</b></em>' containment
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__REPOSITORY = 1;

	/**
	 * The feature id for the '<em><b>Actions</b></em>' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__ACTIONS = 2;

	/**
	 * The feature id for the '<em><b>Parameters Patterns</b></em>'
	 * attribute list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__PARAMETERS_PATTERNS = 3;

	/**
	 * The feature id for the '<em><b>Parameters Files</b></em>' reference
	 * list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__PARAMETERS_FILES = 4;

	/**
	 * The feature id for the '<em><b>Keep Model In Memory</b></em>'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN__KEEP_MODEL_IN_MEMORY = 5;

	/**
	 * The number of structural features of the '<em>Chain</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.RepositoryImpl <em>Repository</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.RepositoryImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getRepository()
	 * @generated
	 */
	int REPOSITORY = 1;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REPOSITORY__DOCUMENTATION = 0;

	/**
	 * The feature id for the '<em><b>Members</b></em>' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REPOSITORY__MEMBERS = 1;

	/**
	 * The feature id for the '<em><b>Files</b></em>' containment reference
	 * list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REPOSITORY__FILES = 2;

	/**
	 * The number of structural features of the '<em>Repository</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REPOSITORY_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ActionSetImpl <em>Action Set</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ActionSetImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getActionSet()
	 * @generated
	 */
	int ACTION_SET = 2;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION_SET__DOCUMENTATION = 0;

	/**
	 * The feature id for the '<em><b>Actions</b></em>' containment
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION_SET__ACTIONS = 1;

	/**
	 * The number of structural features of the '<em>Action Set</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION_SET_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ActionImpl <em>Action</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ActionImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getAction()
	 * @generated
	 */
	int ACTION = 3;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION__DOCUMENTATION = 0;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION__LOG = 1;

	/**
	 * The number of structural features of the '<em>Action</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int ACTION_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.GenerateImpl <em>Generate</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.GenerateImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getGenerate()
	 * @generated
	 */
	int GENERATE = 4;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Model</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__MODEL = ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Metamodel</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__METAMODEL = ACTION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Generator</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__GENERATOR = ACTION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Folder</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE__FOLDER = ACTION_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Generate</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATE_FEATURE_COUNT = ACTION_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ConvertXmiImpl <em>Convert Xmi</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ConvertXmiImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getConvertXmi()
	 * @generated
	 */
	int CONVERT_XMI = 5;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONVERT_XMI__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONVERT_XMI__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Mof</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONVERT_XMI__MOF = ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Emf</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONVERT_XMI__EMF = ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Convert Xmi</em>'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CONVERT_XMI_FEATURE_COUNT = ACTION_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.BackupImpl <em>Backup</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.BackupImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getBackup()
	 * @generated
	 */
	int BACKUP = 6;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BACKUP__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BACKUP__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Folder</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BACKUP__FOLDER = ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Backup</b></em>' reference list. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BACKUP__BACKUP = ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Backup</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int BACKUP_FEATURE_COUNT = ACTION_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ClearImpl <em>Clear</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ClearImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getClear()
	 * @generated
	 */
	int CLEAR = 7;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CLEAR__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CLEAR__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CLEAR__RESOURCES = ACTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Clear</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CLEAR_FEATURE_COUNT = ACTION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.RemoveImpl <em>Remove</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.RemoveImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getRemove()
	 * @generated
	 */
	int REMOVE = 8;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REMOVE__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REMOVE__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REMOVE__RESOURCES = ACTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Remove</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int REMOVE_FEATURE_COUNT = ACTION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ChainCallImpl <em>Call</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ChainCallImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getChainCall()
	 * @generated
	 */
	int CHAIN_CALL = 9;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>Chain</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__CHAIN = ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Chain Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__CHAIN_PATH = ACTION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Arguments Patterns</b></em>'
	 * attribute list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__ARGUMENTS_PATTERNS = ACTION_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Arguments Files</b></em>' reference
	 * list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL__ARGUMENTS_FILES = ACTION_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Call</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CHAIN_CALL_FEATURE_COUNT = ACTION_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.CustomActionImpl <em>Custom Action</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.CustomActionImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomAction()
	 * @generated
	 */
	int CUSTOM_ACTION = 10;

	/**
	 * The feature id for the '<em><b>Documentation</b></em>' attribute.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_ACTION__DOCUMENTATION = ACTION__DOCUMENTATION;

	/**
	 * The feature id for the '<em><b>Log</b></em>' reference. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_ACTION__LOG = ACTION__LOG;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_ACTION__ID = ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Resources</b></em>' reference list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_ACTION__RESOURCES = ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Custom Action</em>'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_ACTION_FEATURE_COUNT = ACTION_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.DataImpl <em>Data</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.DataImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getData()
	 * @generated
	 */
	int DATA = 11;

	/**
	 * The number of structural features of the '<em>Data</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int DATA_FEATURE_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.FileImpl <em>File</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.FileImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getFile()
	 * @generated
	 */
	int FILE = 12;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FILE__PATH = 0;

	/**
	 * The number of structural features of the '<em>File</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FILE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ModelImpl <em>Model</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ModelImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getModel()
	 * @generated
	 */
	int MODEL = 13;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODEL__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Model</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODEL_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.ModelSetImpl <em>Model Set</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.ModelSetImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getModelSet()
	 * @generated
	 */
	int MODEL_SET = 14;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODEL_SET__PATH = MODEL__PATH;

	/**
	 * The feature id for the '<em><b>Extensions</b></em>' attribute list.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODEL_SET__EXTENSIONS = MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Model Set</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int MODEL_SET_FEATURE_COUNT = MODEL_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.FolderImpl <em>Folder</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.FolderImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getFolder()
	 * @generated
	 */
	int FOLDER = 15;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FOLDER__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Folder</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int FOLDER_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.LogImpl <em>Log</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.LogImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getLog()
	 * @generated
	 */
	int LOG = 16;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int LOG__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Log</em>' class. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int LOG_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.MetamodelImpl <em>Metamodel</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.MetamodelImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getMetamodel()
	 * @generated
	 */
	int METAMODEL = 17;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int METAMODEL__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Metamodel</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int METAMODEL_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.EmfMetamodelImpl <em>Emf Metamodel</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.EmfMetamodelImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getEmfMetamodel()
	 * @generated
	 */
	int EMF_METAMODEL = 18;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EMF_METAMODEL__PATH = METAMODEL__PATH;

	/**
	 * The number of structural features of the '<em>Emf Metamodel</em>'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int EMF_METAMODEL_FEATURE_COUNT = METAMODEL_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.GeneratorImpl <em>Generator</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.GeneratorImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getGenerator()
	 * @generated
	 */
	int GENERATOR = 19;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATOR__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Generator</em>' class.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int GENERATOR_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.impl.CustomFileImpl <em>Custom File</em>}'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.impl.CustomFileImpl
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomFile()
	 * @generated
	 */
	int CUSTOM_FILE = 20;

	/**
	 * The feature id for the '<em><b>Path</b></em>' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_FILE__PATH = FILE__PATH;

	/**
	 * The number of structural features of the '<em>Custom File</em>'
	 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 * @ordered
	 */
	int CUSTOM_FILE_FEATURE_COUNT = FILE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.obeo.acceleo.chain.CustomActionIDs <em>Custom Action IDs</em>}'
	 * enum. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see fr.obeo.acceleo.chain.CustomActionIDs
	 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomActionIDs()
	 * @generated
	 */
	int CUSTOM_ACTION_IDS = 21;

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Chain <em>Chain</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Chain</em>'.
	 * @see fr.obeo.acceleo.chain.Chain
	 * @generated
	 */
	EClass getChain();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.Chain#getDocumentation <em>Documentation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Documentation</em>'.
	 * @see fr.obeo.acceleo.chain.Chain#getDocumentation()
	 * @see #getChain()
	 * @generated
	 */
	EAttribute getChain_Documentation();

	/**
	 * Returns the meta object for the containment reference '{@link fr.obeo.acceleo.chain.Chain#getRepository <em>Repository</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference '<em>Repository</em>'.
	 * @see fr.obeo.acceleo.chain.Chain#getRepository()
	 * @see #getChain()
	 * @generated
	 */
	EReference getChain_Repository();

	/**
	 * Returns the meta object for the containment reference list '
	 * {@link fr.obeo.acceleo.chain.Chain#getActions <em>Actions</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '
	 *         <em>Actions</em>'.
	 * @see fr.obeo.acceleo.chain.Chain#getActions()
	 * @see #getChain()
	 * @generated
	 */
	EReference getChain_Actions();

	/**
	 * Returns the meta object for the attribute list '{@link fr.obeo.acceleo.chain.Chain#getParametersPatterns <em>Parameters Patterns</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute list '<em>Parameters Patterns</em>'.
	 * @see fr.obeo.acceleo.chain.Chain#getParametersPatterns()
	 * @see #getChain()
	 * @generated
	 */
	EAttribute getChain_ParametersPatterns();

	/**
	 * Returns the meta object for the reference list '
	 * {@link fr.obeo.acceleo.chain.Chain#getParametersFiles
	 * <em>Parameters Files</em>}'. <!-- begin-user-doc --> <!-- end-user-doc
	 * -->
	 * 
	 * @return the meta object for the reference list '<em>Parameters Files</em> '.
	 * @see fr.obeo.acceleo.chain.Chain#getParametersFiles()
	 * @see #getChain()
	 * @generated
	 */
	EReference getChain_ParametersFiles();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.Chain#isKeepModelInMemory <em>Keep Model In Memory</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Keep Model In Memory</em>'.
	 * @see fr.obeo.acceleo.chain.Chain#isKeepModelInMemory()
	 * @see #getChain()
	 * @generated
	 */
	EAttribute getChain_KeepModelInMemory();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.Repository <em>Repository</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Repository</em>'.
	 * @see fr.obeo.acceleo.chain.Repository
	 * @generated
	 */
	EClass getRepository();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.Repository#getDocumentation <em>Documentation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Documentation</em>'.
	 * @see fr.obeo.acceleo.chain.Repository#getDocumentation()
	 * @see #getRepository()
	 * @generated
	 */
	EAttribute getRepository_Documentation();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.obeo.acceleo.chain.Repository#getMembers <em>Members</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Members</em>'.
	 * @see fr.obeo.acceleo.chain.Repository#getMembers()
	 * @see #getRepository()
	 * @generated
	 */
	EReference getRepository_Members();

	/**
	 * Returns the meta object for the containment reference list '
	 * {@link fr.obeo.acceleo.chain.Repository#getFiles <em>Files</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '
	 *         <em>Files</em>'.
	 * @see fr.obeo.acceleo.chain.Repository#getFiles()
	 * @see #getRepository()
	 * @generated
	 */
	EReference getRepository_Files();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.ActionSet <em>Action Set</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Action Set</em>'.
	 * @see fr.obeo.acceleo.chain.ActionSet
	 * @generated
	 */
	EClass getActionSet();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.ActionSet#getDocumentation <em>Documentation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Documentation</em>'.
	 * @see fr.obeo.acceleo.chain.ActionSet#getDocumentation()
	 * @see #getActionSet()
	 * @generated
	 */
	EAttribute getActionSet_Documentation();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.obeo.acceleo.chain.ActionSet#getActions <em>Actions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the containment reference list '<em>Actions</em>'.
	 * @see fr.obeo.acceleo.chain.ActionSet#getActions()
	 * @see #getActionSet()
	 * @generated
	 */
	EReference getActionSet_Actions();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Action <em>Action</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Action</em>'.
	 * @see fr.obeo.acceleo.chain.Action
	 * @generated
	 */
	EClass getAction();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.Action#getDocumentation <em>Documentation</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Documentation</em>'.
	 * @see fr.obeo.acceleo.chain.Action#getDocumentation()
	 * @see #getAction()
	 * @generated
	 */
	EAttribute getAction_Documentation();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.Action#getLog <em>Log</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Log</em>'.
	 * @see fr.obeo.acceleo.chain.Action#getLog()
	 * @see #getAction()
	 * @generated
	 */
	EReference getAction_Log();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Generate <em>Generate</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Generate</em>'.
	 * @see fr.obeo.acceleo.chain.Generate
	 * @generated
	 */
	EClass getGenerate();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.Generate#getModel <em>Model</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Model</em>'.
	 * @see fr.obeo.acceleo.chain.Generate#getModel()
	 * @see #getGenerate()
	 * @generated
	 */
	EReference getGenerate_Model();

	/**
	 * Returns the meta object for the reference '{@link fr.obeo.acceleo.chain.Generate#getMetamodel <em>Metamodel</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Metamodel</em>'.
	 * @see fr.obeo.acceleo.chain.Generate#getMetamodel()
	 * @see #getGenerate()
	 * @generated
	 */
	EReference getGenerate_Metamodel();

	/**
	 * Returns the meta object for the reference '{@link fr.obeo.acceleo.chain.Generate#getGenerator <em>Generator</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Generator</em>'.
	 * @see fr.obeo.acceleo.chain.Generate#getGenerator()
	 * @see #getGenerate()
	 * @generated
	 */
	EReference getGenerate_Generator();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.Generate#getFolder <em>Folder</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Folder</em>'.
	 * @see fr.obeo.acceleo.chain.Generate#getFolder()
	 * @see #getGenerate()
	 * @generated
	 */
	EReference getGenerate_Folder();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.ConvertXmi <em>Convert Xmi</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Convert Xmi</em>'.
	 * @see fr.obeo.acceleo.chain.ConvertXmi
	 * @generated
	 */
	EClass getConvertXmi();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.ConvertXmi#getMof <em>Mof</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Mof</em>'.
	 * @see fr.obeo.acceleo.chain.ConvertXmi#getMof()
	 * @see #getConvertXmi()
	 * @generated
	 */
	EReference getConvertXmi_Mof();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.ConvertXmi#getEmf <em>Emf</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Emf</em>'.
	 * @see fr.obeo.acceleo.chain.ConvertXmi#getEmf()
	 * @see #getConvertXmi()
	 * @generated
	 */
	EReference getConvertXmi_Emf();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Backup <em>Backup</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Backup</em>'.
	 * @see fr.obeo.acceleo.chain.Backup
	 * @generated
	 */
	EClass getBackup();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.Backup#getFolder <em>Folder</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Folder</em>'.
	 * @see fr.obeo.acceleo.chain.Backup#getFolder()
	 * @see #getBackup()
	 * @generated
	 */
	EReference getBackup_Folder();

	/**
	 * Returns the meta object for the reference list '
	 * {@link fr.obeo.acceleo.chain.Backup#getBackup <em>Backup</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Backup</em>'.
	 * @see fr.obeo.acceleo.chain.Backup#getBackup()
	 * @see #getBackup()
	 * @generated
	 */
	EReference getBackup_Backup();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Clear <em>Clear</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Clear</em>'.
	 * @see fr.obeo.acceleo.chain.Clear
	 * @generated
	 */
	EClass getClear();

	/**
	 * Returns the meta object for the reference list '{@link fr.obeo.acceleo.chain.Clear#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Resources</em>'.
	 * @see fr.obeo.acceleo.chain.Clear#getResources()
	 * @see #getClear()
	 * @generated
	 */
	EReference getClear_Resources();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Remove <em>Remove</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Remove</em>'.
	 * @see fr.obeo.acceleo.chain.Remove
	 * @generated
	 */
	EClass getRemove();

	/**
	 * Returns the meta object for the reference list '{@link fr.obeo.acceleo.chain.Remove#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Resources</em>'.
	 * @see fr.obeo.acceleo.chain.Remove#getResources()
	 * @see #getRemove()
	 * @generated
	 */
	EReference getRemove_Resources();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.ChainCall <em>Call</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Call</em>'.
	 * @see fr.obeo.acceleo.chain.ChainCall
	 * @generated
	 */
	EClass getChainCall();

	/**
	 * Returns the meta object for the reference '
	 * {@link fr.obeo.acceleo.chain.ChainCall#getChain <em>Chain</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference '<em>Chain</em>'.
	 * @see fr.obeo.acceleo.chain.ChainCall#getChain()
	 * @see #getChainCall()
	 * @generated
	 */
	EReference getChainCall_Chain();

	/**
	 * Returns the meta object for the attribute '{@link fr.obeo.acceleo.chain.ChainCall#getChainPath <em>Chain Path</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Chain Path</em>'.
	 * @see fr.obeo.acceleo.chain.ChainCall#getChainPath()
	 * @see #getChainCall()
	 * @generated
	 */
	EAttribute getChainCall_ChainPath();

	/**
	 * Returns the meta object for the attribute list '{@link fr.obeo.acceleo.chain.ChainCall#getArgumentsPatterns <em>Arguments Patterns</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute list '<em>Arguments Patterns</em>'.
	 * @see fr.obeo.acceleo.chain.ChainCall#getArgumentsPatterns()
	 * @see #getChainCall()
	 * @generated
	 */
	EAttribute getChainCall_ArgumentsPatterns();

	/**
	 * Returns the meta object for the reference list '{@link fr.obeo.acceleo.chain.ChainCall#getArgumentsFiles <em>Arguments Files</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Arguments Files</em>'.
	 * @see fr.obeo.acceleo.chain.ChainCall#getArgumentsFiles()
	 * @see #getChainCall()
	 * @generated
	 */
	EReference getChainCall_ArgumentsFiles();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.CustomAction <em>Custom Action</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Custom Action</em>'.
	 * @see fr.obeo.acceleo.chain.CustomAction
	 * @generated
	 */
	EClass getCustomAction();

	/**
	 * Returns the meta object for the attribute list '
	 * {@link fr.obeo.acceleo.chain.CustomAction#getID <em>ID</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute list '<em>ID</em>'.
	 * @see fr.obeo.acceleo.chain.CustomAction#getID()
	 * @see #getCustomAction()
	 * @generated
	 */
	EAttribute getCustomAction_ID();

	/**
	 * Returns the meta object for the reference list '{@link fr.obeo.acceleo.chain.CustomAction#getResources <em>Resources</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the reference list '<em>Resources</em>'.
	 * @see fr.obeo.acceleo.chain.CustomAction#getResources()
	 * @see #getCustomAction()
	 * @generated
	 */
	EReference getCustomAction_Resources();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Data <em>Data</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Data</em>'.
	 * @see fr.obeo.acceleo.chain.Data
	 * @generated
	 */
	EClass getData();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.File <em>File</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>File</em>'.
	 * @see fr.obeo.acceleo.chain.File
	 * @generated
	 */
	EClass getFile();

	/**
	 * Returns the meta object for the attribute '
	 * {@link fr.obeo.acceleo.chain.File#getPath <em>Path</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute '<em>Path</em>'.
	 * @see fr.obeo.acceleo.chain.File#getPath()
	 * @see #getFile()
	 * @generated
	 */
	EAttribute getFile_Path();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Model <em>Model</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Model</em>'.
	 * @see fr.obeo.acceleo.chain.Model
	 * @generated
	 */
	EClass getModel();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.ModelSet <em>Model Set</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Model Set</em>'.
	 * @see fr.obeo.acceleo.chain.ModelSet
	 * @generated
	 */
	EClass getModelSet();

	/**
	 * Returns the meta object for the attribute list '{@link fr.obeo.acceleo.chain.ModelSet#getExtensions <em>Extensions</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for the attribute list '<em>Extensions</em>'.
	 * @see fr.obeo.acceleo.chain.ModelSet#getExtensions()
	 * @see #getModelSet()
	 * @generated
	 */
	EAttribute getModelSet_Extensions();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Folder <em>Folder</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Folder</em>'.
	 * @see fr.obeo.acceleo.chain.Folder
	 * @generated
	 */
	EClass getFolder();

	/**
	 * Returns the meta object for class '{@link fr.obeo.acceleo.chain.Log <em>Log</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Log</em>'.
	 * @see fr.obeo.acceleo.chain.Log
	 * @generated
	 */
	EClass getLog();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.Metamodel <em>Metamodel</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Metamodel</em>'.
	 * @see fr.obeo.acceleo.chain.Metamodel
	 * @generated
	 */
	EClass getMetamodel();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.EmfMetamodel <em>Emf Metamodel</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Emf Metamodel</em>'.
	 * @see fr.obeo.acceleo.chain.EmfMetamodel
	 * @generated
	 */
	EClass getEmfMetamodel();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.Generator <em>Generator</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Generator</em>'.
	 * @see fr.obeo.acceleo.chain.Generator
	 * @generated
	 */
	EClass getGenerator();

	/**
	 * Returns the meta object for class '
	 * {@link fr.obeo.acceleo.chain.CustomFile <em>Custom File</em>}'. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for class '<em>Custom File</em>'.
	 * @see fr.obeo.acceleo.chain.CustomFile
	 * @generated
	 */
	EClass getCustomFile();

	/**
	 * Returns the meta object for enum '{@link fr.obeo.acceleo.chain.CustomActionIDs <em>Custom Action IDs</em>}'.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the meta object for enum '<em>Custom Action IDs</em>'.
	 * @see fr.obeo.acceleo.chain.CustomActionIDs
	 * @generated
	 */
	EEnum getCustomActionIDs();

	/**
	 * Returns the factory that creates the instances of the model. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ChainFactory getChainFactory();

	/**
	 * <!-- begin-user-doc --> Defines literals for the meta objects that
	 * represent
	 * <ul>
	 * <li>each class,</li>
	 * <li>each feature of each class,</li>
	 * <li>each enum,</li>
	 * <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ChainImpl <em>Chain</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ChainImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getChain()
		 * @generated
		 */
		EClass CHAIN = eINSTANCE.getChain();

		/**
		 * The meta object literal for the '<em><b>Documentation</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CHAIN__DOCUMENTATION = eINSTANCE.getChain_Documentation();

		/**
		 * The meta object literal for the '<em><b>Repository</b></em>'
		 * containment reference feature. <!-- begin-user-doc --> <!--
		 * end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CHAIN__REPOSITORY = eINSTANCE.getChain_Repository();

		/**
		 * The meta object literal for the '<em><b>Actions</b></em>'
		 * containment reference list feature. <!-- begin-user-doc --> <!--
		 * end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CHAIN__ACTIONS = eINSTANCE.getChain_Actions();

		/**
		 * The meta object literal for the '<em><b>Parameters Patterns</b></em>'
		 * attribute list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CHAIN__PARAMETERS_PATTERNS = eINSTANCE.getChain_ParametersPatterns();

		/**
		 * The meta object literal for the '<em><b>Parameters Files</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CHAIN__PARAMETERS_FILES = eINSTANCE.getChain_ParametersFiles();

		/**
		 * The meta object literal for the '<em><b>Keep Model In Memory</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CHAIN__KEEP_MODEL_IN_MEMORY = eINSTANCE.getChain_KeepModelInMemory();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.RepositoryImpl <em>Repository</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.RepositoryImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getRepository()
		 * @generated
		 */
		EClass REPOSITORY = eINSTANCE.getRepository();

		/**
		 * The meta object literal for the '<em><b>Documentation</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute REPOSITORY__DOCUMENTATION = eINSTANCE.getRepository_Documentation();

		/**
		 * The meta object literal for the '<em><b>Members</b></em>'
		 * containment reference list feature. <!-- begin-user-doc --> <!--
		 * end-user-doc -->
		 * 
		 * @generated
		 */
		EReference REPOSITORY__MEMBERS = eINSTANCE.getRepository_Members();

		/**
		 * The meta object literal for the '<em><b>Files</b></em>'
		 * containment reference list feature. <!-- begin-user-doc --> <!--
		 * end-user-doc -->
		 * 
		 * @generated
		 */
		EReference REPOSITORY__FILES = eINSTANCE.getRepository_Files();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ActionSetImpl <em>Action Set</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ActionSetImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getActionSet()
		 * @generated
		 */
		EClass ACTION_SET = eINSTANCE.getActionSet();

		/**
		 * The meta object literal for the '<em><b>Documentation</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute ACTION_SET__DOCUMENTATION = eINSTANCE.getActionSet_Documentation();

		/**
		 * The meta object literal for the '<em><b>Actions</b></em>'
		 * containment reference list feature. <!-- begin-user-doc --> <!--
		 * end-user-doc -->
		 * 
		 * @generated
		 */
		EReference ACTION_SET__ACTIONS = eINSTANCE.getActionSet_Actions();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ActionImpl <em>Action</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ActionImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getAction()
		 * @generated
		 */
		EClass ACTION = eINSTANCE.getAction();

		/**
		 * The meta object literal for the '<em><b>Documentation</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute ACTION__DOCUMENTATION = eINSTANCE.getAction_Documentation();

		/**
		 * The meta object literal for the '<em><b>Log</b></em>' reference
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference ACTION__LOG = eINSTANCE.getAction_Log();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.GenerateImpl <em>Generate</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.GenerateImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getGenerate()
		 * @generated
		 */
		EClass GENERATE = eINSTANCE.getGenerate();

		/**
		 * The meta object literal for the '<em><b>Model</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERATE__MODEL = eINSTANCE.getGenerate_Model();

		/**
		 * The meta object literal for the '<em><b>Metamodel</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERATE__METAMODEL = eINSTANCE.getGenerate_Metamodel();

		/**
		 * The meta object literal for the '<em><b>Generator</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERATE__GENERATOR = eINSTANCE.getGenerate_Generator();

		/**
		 * The meta object literal for the '<em><b>Folder</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference GENERATE__FOLDER = eINSTANCE.getGenerate_Folder();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ConvertXmiImpl <em>Convert Xmi</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ConvertXmiImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getConvertXmi()
		 * @generated
		 */
		EClass CONVERT_XMI = eINSTANCE.getConvertXmi();

		/**
		 * The meta object literal for the '<em><b>Mof</b></em>' reference
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CONVERT_XMI__MOF = eINSTANCE.getConvertXmi_Mof();

		/**
		 * The meta object literal for the '<em><b>Emf</b></em>' reference
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CONVERT_XMI__EMF = eINSTANCE.getConvertXmi_Emf();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.BackupImpl <em>Backup</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.BackupImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getBackup()
		 * @generated
		 */
		EClass BACKUP = eINSTANCE.getBackup();

		/**
		 * The meta object literal for the '<em><b>Folder</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference BACKUP__FOLDER = eINSTANCE.getBackup_Folder();

		/**
		 * The meta object literal for the '<em><b>Backup</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference BACKUP__BACKUP = eINSTANCE.getBackup_Backup();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ClearImpl <em>Clear</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ClearImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getClear()
		 * @generated
		 */
		EClass CLEAR = eINSTANCE.getClear();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CLEAR__RESOURCES = eINSTANCE.getClear_Resources();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.RemoveImpl <em>Remove</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.RemoveImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getRemove()
		 * @generated
		 */
		EClass REMOVE = eINSTANCE.getRemove();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference REMOVE__RESOURCES = eINSTANCE.getRemove_Resources();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ChainCallImpl <em>Call</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ChainCallImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getChainCall()
		 * @generated
		 */
		EClass CHAIN_CALL = eINSTANCE.getChainCall();

		/**
		 * The meta object literal for the '<em><b>Chain</b></em>'
		 * reference feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CHAIN_CALL__CHAIN = eINSTANCE.getChainCall_Chain();

		/**
		 * The meta object literal for the '<em><b>Chain Path</b></em>'
		 * attribute feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CHAIN_CALL__CHAIN_PATH = eINSTANCE.getChainCall_ChainPath();

		/**
		 * The meta object literal for the '<em><b>Arguments Patterns</b></em>'
		 * attribute list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CHAIN_CALL__ARGUMENTS_PATTERNS = eINSTANCE.getChainCall_ArgumentsPatterns();

		/**
		 * The meta object literal for the '<em><b>Arguments Files</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CHAIN_CALL__ARGUMENTS_FILES = eINSTANCE.getChainCall_ArgumentsFiles();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.CustomActionImpl <em>Custom Action</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.CustomActionImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomAction()
		 * @generated
		 */
		EClass CUSTOM_ACTION = eINSTANCE.getCustomAction();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute
		 * list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute CUSTOM_ACTION__ID = eINSTANCE.getCustomAction_ID();

		/**
		 * The meta object literal for the '<em><b>Resources</b></em>'
		 * reference list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EReference CUSTOM_ACTION__RESOURCES = eINSTANCE.getCustomAction_Resources();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.DataImpl <em>Data</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.DataImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getData()
		 * @generated
		 */
		EClass DATA = eINSTANCE.getData();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.FileImpl <em>File</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.FileImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getFile()
		 * @generated
		 */
		EClass FILE = eINSTANCE.getFile();

		/**
		 * The meta object literal for the '<em><b>Path</b></em>' attribute
		 * feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute FILE__PATH = eINSTANCE.getFile_Path();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ModelImpl <em>Model</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ModelImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getModel()
		 * @generated
		 */
		EClass MODEL = eINSTANCE.getModel();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.ModelSetImpl <em>Model Set</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.ModelSetImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getModelSet()
		 * @generated
		 */
		EClass MODEL_SET = eINSTANCE.getModelSet();

		/**
		 * The meta object literal for the '<em><b>Extensions</b></em>'
		 * attribute list feature. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @generated
		 */
		EAttribute MODEL_SET__EXTENSIONS = eINSTANCE.getModelSet_Extensions();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.FolderImpl <em>Folder</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.FolderImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getFolder()
		 * @generated
		 */
		EClass FOLDER = eINSTANCE.getFolder();

		/**
		 * The meta object literal for the '
		 * {@link fr.obeo.acceleo.chain.impl.LogImpl <em>Log</em>}' class. <!--
		 * begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.LogImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getLog()
		 * @generated
		 */
		EClass LOG = eINSTANCE.getLog();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.MetamodelImpl <em>Metamodel</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.MetamodelImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getMetamodel()
		 * @generated
		 */
		EClass METAMODEL = eINSTANCE.getMetamodel();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.EmfMetamodelImpl <em>Emf Metamodel</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.EmfMetamodelImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getEmfMetamodel()
		 * @generated
		 */
		EClass EMF_METAMODEL = eINSTANCE.getEmfMetamodel();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.GeneratorImpl <em>Generator</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.GeneratorImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getGenerator()
		 * @generated
		 */
		EClass GENERATOR = eINSTANCE.getGenerator();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.impl.CustomFileImpl <em>Custom File</em>}'
		 * class. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.impl.CustomFileImpl
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomFile()
		 * @generated
		 */
		EClass CUSTOM_FILE = eINSTANCE.getCustomFile();

		/**
		 * The meta object literal for the '{@link fr.obeo.acceleo.chain.CustomActionIDs <em>Custom Action IDs</em>}'
		 * enum. <!-- begin-user-doc --> <!-- end-user-doc -->
		 * 
		 * @see fr.obeo.acceleo.chain.CustomActionIDs
		 * @see fr.obeo.acceleo.chain.impl.ChainPackageImpl#getCustomActionIDs()
		 * @generated
		 */
		EEnum CUSTOM_ACTION_IDS = eINSTANCE.getCustomActionIDs();

	}

} // ChainPackage
