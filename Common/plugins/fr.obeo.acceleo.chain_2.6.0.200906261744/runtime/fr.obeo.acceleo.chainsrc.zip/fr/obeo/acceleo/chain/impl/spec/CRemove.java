/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.impl.RemoveImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.util.Iterator;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

/**
 * A representation of the model object '<em><b>Remove</b></em>'. The files
 * and the folders are deleted.
 * 
 * @author www.obeo.fr
 * 
 */
public class CRemove extends RemoveImpl implements CObject {

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getDocumentation());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			IContainer container = cchain.getFile().getProject().getWorkspace().getRoot();
			Iterator resources = getResources().iterator();
			while (resources.hasNext()) {
				Data data = (Data) resources.next();
				if (data instanceof CFolder || data instanceof CModelSet) {
					IFolder folder = container.getFolder(new Path(((File) data).getPath()));
					folder.delete(true, monitor);
				} else if (data instanceof CModel || data instanceof CLog || data instanceof CCustomFile) {
					IFile file = container.getFile(new Path(((File) data).getPath()));
					file.delete(true, monitor);
				}
			}
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 0;
	}

}
