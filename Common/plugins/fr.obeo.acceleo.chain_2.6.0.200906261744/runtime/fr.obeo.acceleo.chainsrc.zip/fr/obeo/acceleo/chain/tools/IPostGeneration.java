/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

/**
 * A post generation action.
 * 
 * @author www.obeo.fr
 */
public interface IPostGeneration {

	/**
	 * This method is called at the end of each file generation, when we have to
	 * create a new file.
	 * 
	 * @param target
	 *            is the target container
	 * @param path
	 *            is the path of the file to create
	 * @param content
	 *            is the content of the file to create
	 * @param monitor
	 *            is the monitor
	 * @throws CoreException
	 */
	public void postFileGeneration(IContainer target, IPath path, StringBuffer content, IProgressMonitor monitor) throws CoreException;

	/**
	 * This method is called at the end of a CGenerate action.
	 * 
	 * @param monitor
	 *            is the monitor
	 */
	public void postProcessing(IProgressMonitor monitor);

}
