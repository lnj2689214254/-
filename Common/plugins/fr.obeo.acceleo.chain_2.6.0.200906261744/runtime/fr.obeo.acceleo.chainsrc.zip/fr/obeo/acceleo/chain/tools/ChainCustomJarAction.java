/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.File;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.impl.spec.CCustomFile;
import fr.obeo.acceleo.chain.impl.spec.CFolder;
import fr.obeo.acceleo.chain.impl.spec.CLog;
import fr.obeo.acceleo.chain.impl.spec.CModel;
import fr.obeo.acceleo.chain.impl.spec.CModelSet;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.ui.resources.JarFactory;

/**
 * A custom action to make a jar file.
 * 
 * @author www.obeo.fr
 */
public class ChainCustomJarAction implements IChainCustomAction {

	/* (non-Javadoc) */
	public void run(Data[] resources, CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			if (resources.length == 2) {
				IPath rootFolder = null;
				IPath jar = null;
				for (int i = 0; i < resources.length; i++) {
					Data data = resources[i];
					if (data instanceof CFolder || data instanceof CModelSet) {
						rootFolder = new Path(((File) data).getPath());
					} else if (data instanceof CModel || data instanceof CLog || data instanceof CCustomFile) {
						jar = new Path(((File) data).getPath());
					}
				}
				if (rootFolder != null && jar != null) {
					JarFactory.createJar(rootFolder, jar);
				} else {
					AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainCustomJarAction.InvalidResource"), true); //$NON-NLS-1$
				}
			} else {
				AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainCustomJarAction.IllegalResourceCount"), true); //$NON-NLS-1$
			}
		}
	}

}
