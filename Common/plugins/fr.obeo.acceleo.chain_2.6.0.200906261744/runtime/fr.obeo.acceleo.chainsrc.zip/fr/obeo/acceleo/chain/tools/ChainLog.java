/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Action;
import fr.obeo.acceleo.chain.Log;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.AcceleoToolsPlugin;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * This is used to report errors for the chain files.
 * 
 * @author www.obeo.fr
 * 
 */
public class ChainLog {

	/**
	 * Reports an error in the log file.
	 * 
	 * @param cchain
	 *            is the root element of the chain file
	 * @param action
	 *            is the current action of the chain file
	 * @param report
	 *            is the text to report
	 * @param monitor
	 *            is the monitor
	 * @param mode
	 *            is the run mode, RUN_MODE or DEBUG_MODE
	 * @throws CoreException
	 */
	public static void report(CChain cchain, Action action, StringBuffer report, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (report.length() > 0) {
			Log log = action.getLog();
			String displayAction = (action.getDocumentation() != null) ? " [" + action.getDocumentation() + ']' : ""; //$NON-NLS-1$ //$NON-NLS-2$
			if (log != null && log.getPath() != null && log.getPath().length() > 0) {
				if (mode.getMode() == LaunchManager.DEBUG_MODE) {
					AcceleoToolsPlugin.getDefault().log(AcceleoChainMessages.getString("ChainLog.CreatedLog", new Object[] { log.getPath(), displayAction, }), false); //$NON-NLS-1$
				}
				Resources.appendFile(ResourcesPlugin.getWorkspace().getRoot(), new Path(log.getPath()), report.toString(), monitor);
			} else {
				String chainFullPath = cchain.getFile().getFullPath().toString();
				AcceleoToolsPlugin.getDefault().log(AcceleoChainMessages.getString("ChainLog.MissingLog", new Object[] { chainFullPath, displayAction, }), false); //$NON-NLS-1$
			}
		}
	}

}
