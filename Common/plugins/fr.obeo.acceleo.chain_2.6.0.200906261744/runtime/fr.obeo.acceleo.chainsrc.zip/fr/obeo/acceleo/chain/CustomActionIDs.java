/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.util.AbstractEnumerator;

import fr.obeo.acceleo.chain.impl.spec.CCustomAction;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;

/**
 * <!-- begin-user-doc --> A representation of the literals of the enumeration '
 * <em><b>Custom Action IDs</b></em>', and utility methods for working with
 * them. <!-- end-user-doc -->
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getCustomActionIDs()
 * @model
 * @generated
 */
public final class CustomActionIDs extends AbstractEnumerator {
	/**
	 * An array of all the '<em><b>Custom Action IDs</b></em>' enumerators.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	private static final CustomActionIDs[] VALUES_ARRAY = initCustomActionIDs();

	/**
	 * @not-generated
	 */
	private static CustomActionIDs[] initCustomActionIDs() {
		List result = new ArrayList();
		IExtensionRegistry registry = Platform.getExtensionRegistry();
		IExtensionPoint extensionPoint = registry.getExtensionPoint(CCustomAction.CHAIN_CUSTOM_EXTENSION_ID);
		if (extensionPoint == null || extensionPoint.getExtensions().length == 0) {
			AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("UnresolvedExtensionPoint", new Object[] { CCustomAction.CHAIN_CUSTOM_EXTENSION_ID, }), true); //$NON-NLS-1$
		} else {
			IExtension[] extensions = extensionPoint.getExtensions();
			for (int i = 0; i < extensions.length; i++) {
				IExtension extension = extensions[i];
				IConfigurationElement[] members = extension.getConfigurationElements();
				for (int j = 0; j < members.length; j++) {
					IConfigurationElement member = members[j];
					String id = member.getAttribute("customId"); //$NON-NLS-1$
					if (id != null) {
						result.add(new CustomActionIDs(result.size(), id, id));
					}
				}
			}
		}
		return (CustomActionIDs[]) result.toArray(new CustomActionIDs[result.size()]);
	}

	/**
	 * A public read-only list of all the '<em><b>Custom Action IDs</b></em>'
	 * enumerators. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Custom Action IDs</b></em>' literal with the
	 * specified literal value. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public static CustomActionIDs get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CustomActionIDs result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Custom Action IDs</b></em>' literal with the
	 * specified name. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public static CustomActionIDs getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			CustomActionIDs result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Custom Action IDs</b></em>' literal with the
	 * specified integer value. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public static CustomActionIDs get(int value) {
		if (value < VALUES_ARRAY.length) {
			return VALUES_ARRAY[value];
		} else {
			return null;
		}
	}

	/**
	 * Only this class can construct instances. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	private CustomActionIDs(int value, String name, String literal) {
		super(value, name, literal);
	}

} // CustomActionIDs
