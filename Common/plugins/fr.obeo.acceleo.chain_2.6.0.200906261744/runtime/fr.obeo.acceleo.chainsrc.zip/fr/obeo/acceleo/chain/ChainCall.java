/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Call</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.ChainCall#getChain <em>Chain</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.ChainCall#getChainPath <em>Chain Path</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.ChainCall#getArgumentsPatterns <em>Arguments Patterns</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.ChainCall#getArgumentsFiles <em>Arguments Files</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getChainCall()
 * @model
 * @generated
 */
public interface ChainCall extends Action {
	/**
	 * Returns the value of the '<em><b>Chain</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Chain</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Chain</em>' reference.
	 * @see #setChain(Chain)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChainCall_Chain()
	 * @model required="true"
	 * @generated
	 * @deprecated
	 */
	Chain getChain();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.ChainCall#getChain <em>Chain</em>}'
	 * reference. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Chain</em>' reference.
	 * @see #getChain()
	 * @generated
	 */
	void setChain(Chain value);

	/**
	 * Returns the value of the '<em><b>Chain Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Chain Path</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Chain Path</em>' attribute.
	 * @see #setChainPath(String)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChainCall_ChainPath()
	 * @model
	 * @generated
	 */
	String getChainPath();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.ChainCall#getChainPath <em>Chain Path</em>}'
	 * attribute. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @param value
	 *            the new value of the '<em>Chain Path</em>' attribute.
	 * @see #getChainPath()
	 * @generated
	 */
	void setChainPath(String value);

	/**
	 * Returns the value of the '<em><b>Arguments Patterns</b></em>'
	 * attribute list. The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Arguments Patterns</em>' attribute list
	 * isn't clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Arguments Patterns</em>' attribute
	 *         list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChainCall_ArgumentsPatterns()
	 * @model type="java.lang.String"
	 * @generated
	 */
	EList getArgumentsPatterns();

	/**
	 * Returns the value of the '<em><b>Arguments Files</b></em>' reference
	 * list. The list contents are of type {@link fr.obeo.acceleo.chain.File}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Arguments Files</em>' reference list isn't
	 * clear, there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Arguments Files</em>' reference list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getChainCall_ArgumentsFiles()
	 * @model type="fr.obeo.acceleo.chain.File"
	 * @generated
	 */
	EList getArgumentsFiles();

} // ChainCall
