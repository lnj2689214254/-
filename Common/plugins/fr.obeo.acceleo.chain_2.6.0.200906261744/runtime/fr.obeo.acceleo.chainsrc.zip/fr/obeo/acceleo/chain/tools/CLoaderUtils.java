/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * It helps to load a 'chain' model.
 * 
 * @author www.obeo.fr
 * 
 */
public class CLoaderUtils {

	/**
	 * It creates and loads a persistent 'chain' resource for a 'chain' file in
	 * the workspace.
	 * 
	 * @param chainFile
	 *            is the file
	 * @return the persistent 'chain' resource, or null if an error occurs
	 */
	public static CChain getCChainForChainFile(IFile chainFile) {
		if (chainFile == null)
			return null;
		URI chainURI = Resources.createPlatformResourceURI(chainFile.getFullPath().toString());
		CChain chain = getCChainForChainURI(chainURI);
		if (chain != null)
			chain.setFile(chainFile);
		return chain;
	}

	public static CChain getCChainForChainURI(URI chainURI) {
		try {
			Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
			reg.getExtensionToFactoryMap().put("chain", new XMIResourceFactoryImpl()); //$NON-NLS-1$
			ResourceSet resourceSet = new ResourceSetImpl();
			Resource resource = resourceSet.getResource(chainURI, true);
			// EcoreUtil.resolveAll(resourceSet);
			CChain chain = (CChain) ((resource.getContents().size() > 0) ? resource.getContents().get(0) : null);
			return (CChain) ETools.validate(chain, true, AcceleoChainMessages.getString("ValidationNeeded", new Object[] { chainURI.toString(), })); //$NON-NLS-1$
		} catch (Exception e) {
			return null;
		}
	}

}
