/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.tools;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import fr.obeo.acceleo.chain.Data;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

/**
 * A custom action in a chain.
 * 
 * @author www.obeo.fr
 */
public interface IChainCustomAction {

	/**
	 * Runs the custom action.
	 * 
	 * @param resources
	 *            are the resources
	 * @param cchain
	 *            is the root element of the chain file
	 * @param genFilter
	 *            is the generation filter
	 * @param monitor
	 *            is the progress monitor
	 * @param mode
	 *            is the run mode, ILaunchManager.RUN_MODE or
	 *            ILaunchManager.DEBUG_MODE
	 * @throws CoreException
	 */
	public void run(Data[] resources, CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException;

}
