/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Log</b></em>'. <!-- end-user-doc -->
 * 
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getLog()
 * @model
 * @generated
 */
public interface Log extends File, Data {
} // Log
