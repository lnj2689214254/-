/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.runner;

import java.io.File;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPlatformRunnable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EObject;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.tools.CLoaderUtils;
import fr.obeo.acceleo.gen.AcceleoEcoreGenPlugin;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.resources.Resources;

/**
 * Platform runnables represent executable entry points into plug-ins. This
 * class can be used to launch a chain file outside of eclipse.
 * <p>
 * The command to launch all chain files : java -cp startup.jar
 * org.eclipse.core.launcher.Main -application fr.obeo.acceleo.chain.launch
 * -data [workspace-directory]
 * <p>
 * The command to launch one chain file : java -cp startup.jar
 * org.eclipse.core.launcher.Main -application fr.obeo.acceleo.chain.launch
 * -data [workspace-directory] -chain [chain-file]
 * <p>
 * 
 * @author www.obeo.fr
 * 
 */
public class ChainRunner implements IPlatformRunnable {

	/* (non-Javadoc) */
	public Object run(Object args) throws Exception {
		try {
			final String[] arguments = (String[]) args;
			final IWorkspace workspace = ResourcesPlugin.getWorkspace();
			IWorkspaceRunnable runnable = new IWorkspaceRunnable() {
				public void run(IProgressMonitor monitor) throws CoreException {
					try {
						String chainFilename = null;
						for (int index = 0; index < arguments.length && arguments[index].startsWith("-"); ++index) { //$NON-NLS-1$
							if (arguments[index].equalsIgnoreCase("-chain")) { //$NON-NLS-1$
								chainFilename = arguments[++index];
							}
						}
						monitor.beginTask(AcceleoChainMessages.getString("ChainRunner.Task.RefreshingWorkspace"), 1); //$NON-NLS-1$
						workspace.getRoot().refreshLocal(IResource.DEPTH_INFINITE, monitor);
						if (chainFilename != null) {
							monitor.beginTask(AcceleoChainMessages.getString("ChainRunner.Task.LaunchingChain", new Object[] { chainFilename, }), 1); //$NON-NLS-1$
							System.out.println(AcceleoChainMessages.getString("ChainRunner.Task.LaunchingChain", new Object[] { chainFilename, })); //$NON-NLS-1$
							IFile chainFile = ResourcesPlugin.getWorkspace().getRoot().getFile(new Path(chainFilename));
							launch(monitor, chainFile);
						} else {
							IProject[] projects = workspace.getRoot().getProjects();
							for (int i = 0; i < projects.length; i++) {
								IProject project = projects[i];
								if (project.isAccessible()) {
									IFile[] chainFiles = Resources.members(project, new String[] { "chain" }); //$NON-NLS-1$
									monitor.beginTask(AcceleoChainMessages.getString("ChainRunner.Task.LaunchingProjectChains", new Object[] { project.getName(), }), chainFiles.length); //$NON-NLS-1$
									System.out.println(AcceleoChainMessages.getString("ChainRunner.Task.LaunchingProjectChains", new Object[] { project.getName(), })); //$NON-NLS-1$
									for (int j = 0; j < chainFiles.length; j++) {
										launch(monitor, chainFiles[j]);
									}
								}
							}
						}
					} finally {
						monitor.done();
					}
				}

				private void launch(IProgressMonitor monitor, IFile chainFile) {
					CChain chain = (chainFile.isAccessible()) ? CLoaderUtils.getCChainForChainFile(chainFile) : null;
					if (chain != null) {
						try {
							IGenFilter genFilter = new IGenFilter() {
								public boolean filter(File script, IFile targetFile, EObject object) throws CoreException {
									return true;
								}
							};
							chain.launch(genFilter, monitor, LaunchManager.create("run", true)); //$NON-NLS-1$
						} catch (CoreException e) {
							System.out.println(AcceleoChainMessages.getString("ChainRunner.ChainException", new Object[] { chainFile.getFullPath().toString(), })); //$NON-NLS-1$
							e.printStackTrace();
							AcceleoEcoreGenPlugin.getDefault().log(e, true);
						}
					} else {
						System.out.println(AcceleoChainMessages.getString("ChainRunner.MissingChain", new Object[] { chainFile.getFullPath().toString(), })); //$NON-NLS-1$
						AcceleoEcoreGenPlugin.getDefault().log(AcceleoChainMessages.getString("ChainRunner.MissingChain", new Object[] { chainFile.getFullPath().toString(), }), true); //$NON-NLS-1$
					}
					monitor.worked(1);
				}
			};
			workspace.run(runnable, new NullProgressMonitor());
			return IPlatformRunnable.EXIT_OK;
		} catch (CoreException e) {
			printUsage();
			e.printStackTrace();
			AcceleoEcoreGenPlugin.getDefault().log(e, false);
			return new Integer(1);
		}
	}

	private void printUsage() {
		final StringBuffer usage = new StringBuffer();
		usage.append(AcceleoChainMessages.getString("ChainRunner.Usage")); //$NON-NLS-1$
		usage.append('\n');
		usage.append("  [-data] <"); //$NON-NLS-1$
		usage.append(AcceleoChainMessages.getString("ChainRunner.Workspace")); //$NON-NLS-1$
		usage.append("> \n"); //$NON-NLS-1$
		usage.append("  ([-chain] <"); //$NON-NLS-1$
		usage.append(AcceleoChainMessages.getString("ChainRunner.Chain")); //$NON-NLS-1$
		usage.append(">)?\n"); //$NON-NLS-1$
		usage.append(AcceleoChainMessages.getString("ChainRunner.Example")); //$NON-NLS-1$
		usage.append('\n');
		usage.append("  launch -chain myProject.chain"); //$NON-NLS-1$
		System.out.println(usage.toString());
	}

}
