/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.Folder;
import fr.obeo.acceleo.chain.impl.BackupImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.chain.tools.ChainLog;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.tools.resources.Resources;

import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;

/**
 * A representation of the model object '<em><b>Backup</b></em>'. It makes
 * a backup for folders.
 * 
 * @author www.obeo.fr
 * 
 */
public class CBackup extends BackupImpl implements CObject {

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			TemplateElement.getProfiler().start(getDocumentation());
		}
		try {
			launchSub(cchain, genFilter, monitor, mode);
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	public void launchSub(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.getMode() != LaunchManager.PREVIEW_MODE && mode.getMode() != LaunchManager.PHANTOM_MODE) {
			StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
			IContainer container = cchain.getFile().getProject().getWorkspace().getRoot();
			IFolder folder = container.getFolder(new Path(getFolder().getPath()));
			if (!folder.exists()) {
				report.append(AcceleoChainMessages.getString("MissingFolder", new Object[] { getFolder().getPath(), })); //$NON-NLS-1$
			} else {
				List list = getBackup();
				for (int i = list.size() - 1; i >= 0; i--) {
					if (getFolder().getPath().equals(((Folder) list.get(i)).getPath())) {
						report.append(AcceleoChainMessages.getString("CBackup.FolderFound", new Object[] { getFolder().getPath(), })); //$NON-NLS-1$
						break;
					}
				}
				if (report.length() == 0) {
					for (int i = list.size() - 1; i >= 0; i--) {
						String targetPath = ((Folder) list.get(i)).getPath();
						if (targetPath.trim().length() > 0) {
							IContainer target = Resources.getContainer(container, new Path(targetPath), monitor);
							if (target instanceof IFolder && target.isAccessible()) {
								target.delete(true, monitor);
								if (i == 0) {
									folder.copy(new Path(targetPath), true, monitor);
								} else {
									String sourcePath = ((Folder) list.get(i - 1)).getPath();
									if (sourcePath.trim().length() > 0) {
										IFolder source = container.getFolder(new Path(sourcePath));
										if (source.exists()) {
											source.copy(new Path(targetPath), true, monitor);
										}
									}
								}
							}
						}
					}
				}
			}
			ChainLog.report(cchain, this, report, monitor, mode);
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 0;
	}

}
