/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.impl.ActionSetImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;

import java.util.Iterator;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;

/**
 * A representation of the model object '<em><b>Action Set</b></em>'.
 * 
 * @author www.obeo.fr
 * 
 */
public class CActionSet extends ActionSetImpl implements CObject {

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		if (mode.isProfiling()) {
			if (getDocumentation() != null) {
				TemplateElement.getProfiler().start(getDocumentation());
			} else {
				TemplateElement.getProfiler().start(""); //$NON-NLS-1$
			}
		}
		try {
			final Iterator actions = getActions().iterator();
			while (actions.hasNext()) {
				if (monitor.isCanceled()) {
					throw new OperationCanceledException();
				}
				final CObject action = (CObject) actions.next();
				action.launch(cchain, genFilter, monitor, mode);
			}
		} finally {
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().stop();
			}
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		int totalWork = 0;
		final Iterator actions = getActions().iterator();
		while (actions.hasNext()) {
			final CObject action = (CObject) actions.next();
			totalWork += action.totalWork();
		}
		return totalWork;
	}

}
