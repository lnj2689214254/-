/*
 * Copyright (c) 2005-2008 Obeo
 * 
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Obeo - initial API and implementation
 */

package fr.obeo.acceleo.chain.impl.spec;

import fr.obeo.acceleo.chain.AcceleoChainMessages;
import fr.obeo.acceleo.chain.ModelSet;
import fr.obeo.acceleo.chain.impl.GenerateImpl;
import fr.obeo.acceleo.chain.tools.CObject;
import fr.obeo.acceleo.chain.tools.ChainLog;
import fr.obeo.acceleo.chain.tools.IPostGeneration;
import fr.obeo.acceleo.ecore.factories.FactoryException;
import fr.obeo.acceleo.ecore.tools.ELoaderUtils;
import fr.obeo.acceleo.ecore.tools.ETools;
import fr.obeo.acceleo.gen.IGenFilter;
import fr.obeo.acceleo.gen.phantom.PhantomResources;
import fr.obeo.acceleo.gen.phantom.SyncPhantom;
import fr.obeo.acceleo.gen.template.Template;
import fr.obeo.acceleo.gen.template.TemplateElement;
import fr.obeo.acceleo.gen.template.TemplateSyntaxExceptions;
import fr.obeo.acceleo.gen.template.eval.ENode;
import fr.obeo.acceleo.gen.template.eval.ENodeException;
import fr.obeo.acceleo.gen.template.eval.LaunchManager;
import fr.obeo.acceleo.gen.template.eval.merge.MergeTools;
import fr.obeo.acceleo.gen.template.scripts.AbstractScript;
import fr.obeo.acceleo.gen.template.scripts.EmptyScript;
import fr.obeo.acceleo.gen.template.scripts.IScript;
import fr.obeo.acceleo.gen.template.scripts.SpecificScript;
import fr.obeo.acceleo.tools.classloaders.AcceleoClassLoader;
import fr.obeo.acceleo.tools.plugins.AcceleoModuleProvider;
import fr.obeo.acceleo.tools.resources.FileContentMap;
import fr.obeo.acceleo.tools.resources.Resources;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EObject;

/**
 * A representation of the model object '<em><b>Generate</b></em>'. It
 * generates files for a model and a script.
 * 
 * @author www.obeo.fr
 * 
 */
public class CGenerate extends GenerateImpl implements CObject {

	/**
	 * Preview backup folder.
	 */
	public static final String PHANTOM_PREVIEW_FOLDER_BACKUP = PhantomResources.getRootName() + "/preview/backup"; //$NON-NLS-1$

	/**
	 * Preview generated folder.
	 */
	public static final String PHANTOM_PREVIEW_FOLDER_GENERATED = PhantomResources.getRootName() + "/preview/generated"; //$NON-NLS-1$

	/**
	 * Clears the context.
	 */
	public static void clearModelContext() {
		modelContext.clear();
	}

	private static FileContentMap modelContext = new FileContentMap();

	/**
	 * Cache size to get models more quickly.
	 */
	private final static int MODEL_CACHE_SIZE = 5;

	/**
	 * Clears the global context.
	 */
	public static void clearGlobalModelContext() {
		globalModelContext.clear();
	}

	private static FileContentMap globalModelContext = new FileContentMap(MODEL_CACHE_SIZE);

	/* (non-Javadoc) */
	public void launch(CChain cchain, IGenFilter genFilter, IProgressMonitor monitor, LaunchManager mode) throws CoreException {
		final StringBuffer report = new StringBuffer(""); //$NON-NLS-1$
		final IContainer container = ResourcesPlugin.getWorkspace().getRoot();
		try {
			if (!ETools.validateURI(getMetamodel().getPath(), false)) {
				report.append(AcceleoChainMessages.getString("CGenerate.MissingMetamodel", new Object[] { getMetamodel().getPath(), })); //$NON-NLS-1$
				report.append('\n');
			} else {
				final List modelList = new ArrayList();
				if (getModel() instanceof ModelSet) {
					final IContainer modelSet = Resources.getContainer(container, new Path(getModel().getPath()), monitor);
					if (modelSet != null && modelSet.exists()) {
						IFile[] files;
						if (((ModelSet) getModel()).getExtensions().size() > 0) {
							files = Resources.members(modelSet, (String[]) ((ModelSet) getModel()).getExtensions().toArray(new String[((ModelSet) getModel()).getExtensions().size()]));
						} else {
							files = Resources.members(modelSet);
						}
						for (int i = 0; i < files.length; i++) {
							final IFile file = files[i];
							modelList.add(file.getFullPath().toString());
						}
					} else {
						report.append(AcceleoChainMessages.getString("MissingFolder", new Object[] { getModel().getPath(), })); //$NON-NLS-1$
						report.append('\n');
					}
				} else if (getModel() != null) {
					modelList.add(getModel().getPath());
				}
				final Iterator modelIt = modelList.iterator();
				while (modelIt.hasNext()) {
					final String modelPath = (String) modelIt.next();
					final IFile model = container.getFile(new Path(modelPath));
					if (!model.exists()) {
						report.append(AcceleoChainMessages.getString("CGenerate.MissingModel", new Object[] { modelPath, })); //$NON-NLS-1$
						report.append('\n');
					} else {
						monitor.subTask(AcceleoChainMessages.getString("CGenerate.Task.OpeningModel", new Object[] { modelPath, })); //$NON-NLS-1$
						EObject object;
						if (mode.isProfiling()) {
							TemplateElement.getProfiler().start(modelPath);
						}
						try {
							if (ETools.validateURI(getMetamodel().getPath(), true) || Resources.findFile(new Path(getMetamodel().getPath())) == null) {
								FileContentMap map;
								if (cchain.isKeepModelInMemory()) {
									map = globalModelContext;
								} else {
									map = modelContext;
								}
								object = (EObject) map.get(model);
								if (object == null) {
									String specificResourceFactoryExtension;
									if (getMetamodel() != null && getMetamodel().getPath() != null && getMetamodel().getPath().indexOf("http://www.eclipse.org/uml2") > -1) { //$NON-NLS-1$
										specificResourceFactoryExtension = "uml"; //$NON-NLS-1$
									} else {
										specificResourceFactoryExtension = null;
									}
									object = ETools.loadXMI(modelPath, specificResourceFactoryExtension);
									map.put(model, object);
								}
							} else {
								object = (EObject) modelContext.get(model);
								if (object == null) {
									ELoaderUtils.initModelFactories(model, CGenerate.class.getClassLoader());
									object = ETools.loadXMI(modelPath);
									modelContext.put(model, object);
								}
							}
						} finally {
							if (mode.isProfiling()) {
								TemplateElement.getProfiler().stop();
							}
						}
						AcceleoClassLoader.setPreferredLoader(object);
						try {
							IScript aScript;
							if (mode.isProfiling()) {
								TemplateElement.getProfiler().start("Initialization : " + getGenerator().getPath());
							}
							try {
								final AbstractScript defaultGenSettings = createDefaultScript();
								aScript = defaultGenSettings;
								if (getGenerator() != null && getGenerator().getPath() != null && getGenerator().getPath().length() > 0) {
									final File script = AcceleoModuleProvider.getDefault().getFile(new Path(getGenerator().getPath()));
									if (script == null || !script.exists()) {
										report.append(AcceleoChainMessages.getString("CGenerate.MissingTemplate", new Object[] { getGenerator().getPath(), })); //$NON-NLS-1$
										report.append('\n');
									} else {
										final File chainFile = cchain.getFile() != null ? cchain.getFile().getLocation().toFile() : null;
										aScript = new SpecificScript(script, chainFile, null);
										aScript.reset();
										aScript.addImport(defaultGenSettings);
										defaultGenSettings.setSpecific(aScript);
									}
								}
							} finally {
								if (mode.isProfiling()) {
									TemplateElement.getProfiler().stop();
								}
							}
							if (aScript.isDefault() || aScript.isSpecific()) {
								IContainer targetBackup;
								IContainer targetGenerated;
								IContainer target;
								if (mode.getMode() == LaunchManager.PREVIEW_MODE) {
									final IFile chainFile = cchain.getFile();
									final IProject project = chainFile != null ? chainFile.getProject() : container.getProject();
									targetBackup = Resources.getContainerOrCreateFolder(project, new Path(PHANTOM_PREVIEW_FOLDER_BACKUP).append(getFolder().getPath()), monitor);
									targetGenerated = Resources.getContainerOrCreateFolder(project, new Path(PHANTOM_PREVIEW_FOLDER_GENERATED).append(getFolder().getPath()), monitor);
									target = Resources.getContainer(container, new Path(getFolder().getPath()), monitor);
								} else {
									targetBackup = null;
									targetGenerated = null;
									if (mode.getMode() == LaunchManager.PHANTOM_MODE) {
										target = Resources.getContainer(container, new Path(getFolder().getPath()), monitor);
									} else {
										target = Resources.getContainerOrCreateFolder(container, new Path(getFolder().getPath()), monitor);
									}
								}
								if (mode.isProfiling()) {
									TemplateElement.getProfiler().start(aScript);
								}
								final List files;
								try {
									files = generate(modelPath, cchain, genFilter, aScript, target, targetBackup, targetGenerated, object, true, report, monitor, mode);
								} finally {
									if (mode.isProfiling()) {
										TemplateElement.getProfiler().stop();
									}
								}
								cchain.addGeneratedFiles(files);
							} else {
								report.append(AcceleoChainMessages.getString("CGenerate.UnresolvedTemplate")); //$NON-NLS-1$
								report.append('\n');
							}
						} finally {
							AcceleoClassLoader.setPreferredLoader(null);
						}
					}
				}
			}
		} catch (final TemplateSyntaxExceptions e) {
			report.append(e.getMessage());
		} catch (final FactoryException e) {
			report.append(e.getMessage());
		} catch (final ENodeException e) {
			report.append(e.getMessage());
		}
		if (mode.getMode() != LaunchManager.PHANTOM_MODE) {
			ChainLog.report(cchain, this, report, monitor, mode);
		}
		monitor.worked(10);
	}

	private AbstractScript createDefaultScript() {
		return new EmptyScript();
	}

	private List generate(String modelPath, CChain cchain, IGenFilter genFilter, IScript aScript, IContainer target, IContainer targetBackup, IContainer targetGenerated, EObject object,
			boolean recursive, StringBuffer report, IProgressMonitor monitor, LaunchManager mode) throws FactoryException, ENodeException, CoreException {
		if (monitor.isCanceled()) {
			throw new OperationCanceledException();
		}
		final List result = new ArrayList();
		if (aScript.isGenerated(object)) {
			IPath path = null;
			if (mode.isProfiling()) {
				TemplateElement.getProfiler().start("File=\"...\""); //$NON-NLS-1$
			}
			try {
				path = aScript.getFilePath(object, true);
			} finally {
				if (mode.isProfiling()) {
					TemplateElement.getProfiler().stop();
				}
			}
			// path != null => Generate file
			if (path != null) {
				if (genFilter.filter(aScript.getFile(), target.getFile(path), object)) {
					monitor.subTask(AcceleoChainMessages.getString("CGenerate.Task.Generate", new Object[] { target.getFile(path).getFullPath().toString(), })); //$NON-NLS-1$
					if (mode.getMode() == LaunchManager.DEBUG_MODE) {
						System.out.println(AcceleoChainMessages.getString("CGenerate.Task.Generate", new Object[] { target.getFile(path).getFullPath().toString(), })); //$NON-NLS-1$
					}
					final long startTime = System.currentTimeMillis();
					final ENode eval = evaluate(aScript, object, mode);
					if (eval.log().hasError()) {
						report.append("-> "); //$NON-NLS-1$
						report.append(AcceleoChainMessages.getString("CGenerate.ErrorReport", new Object[] { path, })); //$NON-NLS-1$
						report.append('\n');
						report.append(eval.log().toString());
						report.append('\n');
					}
					final StringBuffer buffer = new StringBuffer(eval.asString());
					final StringBuffer oldBuffer = Resources.getFileContent(target.getFile(path), false);
					if (oldBuffer.length() > 0) {
						String lostCode = MergeTools.merge(target.getFile(path), buffer, oldBuffer, MergeTools.DEFAULT_USER_BEGIN, MergeTools.DEFAULT_USER_END);
						if (lostCode.length() > 0) {
							lostCode = '[' + AcceleoChainMessages.getString("CGenerate.LostCode") + "] " + new Date().toString() + '\n' + lostCode + '\n'; //$NON-NLS-1$ //$NON-NLS-2$
							if (mode.getMode() == LaunchManager.PREVIEW_MODE) {
								Resources.appendFile(targetGenerated, path.addFileExtension(MergeTools.LOST_FILE_EXTENSION), lostCode, monitor).setDerived(true);
							} else if (mode.getMode() != LaunchManager.PHANTOM_MODE) {
								Resources.appendFile(target, path.addFileExtension(MergeTools.LOST_FILE_EXTENSION), lostCode, monitor).setDerived(true);
							}
						}
					}
					if (mode.getMode() == LaunchManager.PREVIEW_MODE) {
						if (targetBackup != null) {
							Resources.createFile(targetBackup, path, oldBuffer.toString(), monitor);
						}
						final IFile generated = Resources.createFile(targetGenerated, path, buffer.toString(), monitor);
						result.add(generated);
					} else {
						IFile generated;
						if (mode.getMode() == LaunchManager.PHANTOM_MODE) {
							generated = target.getFile(path);
						} else {
							final IPostGeneration postGeneration = cchain.getPostGenerationAction();
							if (postGeneration != null) {
								postGeneration.postFileGeneration(target, path, buffer, monitor);
								generated = target.getFile(path);
							} else {
								generated = Resources.createFile(target, path, buffer.toString(), monitor);
							}
						}
						final long endTime = System.currentTimeMillis();
						SyncPhantom.createPhantomExtensionPoint(generated, ResourcesPlugin.getWorkspace().getRoot().getFile(new Path(modelPath)), aScript.getFile(), target, cchain.getFile(), eval,
								endTime - startTime, monitor);
						result.add(generated);
					}
				} else if (target.getFile(path).exists()) {
					final List files = new ArrayList();
					files.add(target.getFile(path));
					cchain.addGeneratedFiles(files);
				}
			}
		}
		if (recursive) {
			result.addAll(generateSub(modelPath, cchain, genFilter, aScript, target, targetBackup, targetGenerated, object, report, monitor, mode));
		}
		return result;
	}

	private List generateSub(String modelPath, CChain cchain, IGenFilter genFilter, IScript aScript, IContainer target, IContainer targetBackup, IContainer targetGenerated, EObject object,
			StringBuffer report, IProgressMonitor monitor, LaunchManager mode) throws FactoryException, ENodeException, CoreException {
		final List result = new ArrayList();
		final Iterator contents = object.eContents().iterator();
		while (contents.hasNext()) {
			final EObject content = (EObject) contents.next();
			result.addAll(generate(modelPath, cchain, genFilter, aScript, target, targetBackup, targetGenerated, content, true, report, monitor, mode));
		}
		return result;
	}

	private ENode evaluate(IScript aScript, EObject object, LaunchManager mode) throws FactoryException, ENodeException {
		final Template template = aScript.getRootTemplate(object, true);
		if (template != null) {
			final boolean withComment = aScript.isDefault() || !aScript.hasFileTemplate();
			if (withComment) {
				return template.evaluateWithComment(object, mode);
			} else {
				return template.evaluate(object, mode);
			}
		} else {
			return new ENode(ENode.EMPTY, object, Template.EMPTY, mode.isSynchronize());
		}
	}

	/* (non-Javadoc) */
	public int totalWork() {
		return 10;
	}

}
