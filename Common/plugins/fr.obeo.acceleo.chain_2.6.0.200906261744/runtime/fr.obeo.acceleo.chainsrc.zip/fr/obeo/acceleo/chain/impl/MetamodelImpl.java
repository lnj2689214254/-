/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Metamodel;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Metamodel</b></em>'. <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public abstract class MetamodelImpl extends FileImpl implements Metamodel {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected MetamodelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.METAMODEL;
	}

} // MetamodelImpl
