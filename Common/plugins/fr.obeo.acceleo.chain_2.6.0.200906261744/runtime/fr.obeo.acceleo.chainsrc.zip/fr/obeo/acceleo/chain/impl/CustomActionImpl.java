/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.CustomAction;
import fr.obeo.acceleo.chain.CustomActionIDs;
import fr.obeo.acceleo.chain.Data;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Custom Action</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.impl.CustomActionImpl#getID <em>ID</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.impl.CustomActionImpl#getResources <em>Resources</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class CustomActionImpl extends ActionImpl implements CustomAction {
	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute. <!--
	 * begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected EList id = null;

	/**
	 * The cached value of the '{@link #getResources() <em>Resources</em>}'
	 * reference list. <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @see #getResources()
	 * @generated
	 * @ordered
	 */
	protected EList resources = null;

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected CustomActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.CUSTOM_ACTION;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getID() {
		if (id == null) {
			id = new EDataTypeUniqueEList(CustomActionIDs.class, this, ChainPackage.CUSTOM_ACTION__ID);
		}
		return id;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EList getResources() {
		if (resources == null) {
			resources = new EObjectResolvingEList(Data.class, this, ChainPackage.CUSTOM_ACTION__RESOURCES);
		}
		return resources;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ChainPackage.CUSTOM_ACTION__ID:
			return getID();
		case ChainPackage.CUSTOM_ACTION__RESOURCES:
			return getResources();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ChainPackage.CUSTOM_ACTION__ID:
			getID().clear();
			getID().addAll((Collection) newValue);
			return;
		case ChainPackage.CUSTOM_ACTION__RESOURCES:
			getResources().clear();
			getResources().addAll((Collection) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
		case ChainPackage.CUSTOM_ACTION__ID:
			getID().clear();
			return;
		case ChainPackage.CUSTOM_ACTION__RESOURCES:
			getResources().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ChainPackage.CUSTOM_ACTION__ID:
			return id != null && !id.isEmpty();
		case ChainPackage.CUSTOM_ACTION__RESOURCES:
			return resources != null && !resources.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (ID: ");
		result.append(id);
		result.append(')');
		return result.toString();
	}

} // CustomActionImpl
