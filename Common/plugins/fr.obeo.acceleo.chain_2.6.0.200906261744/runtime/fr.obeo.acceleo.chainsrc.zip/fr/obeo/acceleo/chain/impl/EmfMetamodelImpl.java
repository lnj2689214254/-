/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;

import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.EmfMetamodel;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>Emf Metamodel</b></em>'. <!-- end-user-doc -->
 * <p>
 * </p>
 * 
 * @generated
 */
public class EmfMetamodelImpl extends MetamodelImpl implements EmfMetamodel {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EmfMetamodelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	protected EClass eStaticClass() {
		return ChainPackage.Literals.EMF_METAMODEL;
	}

} // EmfMetamodelImpl
