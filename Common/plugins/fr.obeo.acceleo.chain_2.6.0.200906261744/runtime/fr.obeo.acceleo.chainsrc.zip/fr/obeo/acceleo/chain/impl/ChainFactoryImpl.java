/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.eclipse.emf.ecore.plugin.EcorePlugin;

import fr.obeo.acceleo.chain.ActionSet;
import fr.obeo.acceleo.chain.Backup;
import fr.obeo.acceleo.chain.Chain;
import fr.obeo.acceleo.chain.ChainCall;
import fr.obeo.acceleo.chain.ChainFactory;
import fr.obeo.acceleo.chain.ChainPackage;
import fr.obeo.acceleo.chain.Clear;
import fr.obeo.acceleo.chain.ConvertXmi;
import fr.obeo.acceleo.chain.CustomAction;
import fr.obeo.acceleo.chain.CustomActionIDs;
import fr.obeo.acceleo.chain.CustomFile;
import fr.obeo.acceleo.chain.EmfMetamodel;
import fr.obeo.acceleo.chain.Folder;
import fr.obeo.acceleo.chain.Generate;
import fr.obeo.acceleo.chain.Generator;
import fr.obeo.acceleo.chain.Log;
import fr.obeo.acceleo.chain.Model;
import fr.obeo.acceleo.chain.ModelSet;
import fr.obeo.acceleo.chain.Remove;
import fr.obeo.acceleo.chain.Repository;
import fr.obeo.acceleo.chain.impl.spec.CActionSet;
import fr.obeo.acceleo.chain.impl.spec.CBackup;
import fr.obeo.acceleo.chain.impl.spec.CChain;
import fr.obeo.acceleo.chain.impl.spec.CChainCall;
import fr.obeo.acceleo.chain.impl.spec.CClear;
import fr.obeo.acceleo.chain.impl.spec.CConvertXmi;
import fr.obeo.acceleo.chain.impl.spec.CCustomAction;
import fr.obeo.acceleo.chain.impl.spec.CCustomFile;
import fr.obeo.acceleo.chain.impl.spec.CEmfMetamodel;
import fr.obeo.acceleo.chain.impl.spec.CFolder;
import fr.obeo.acceleo.chain.impl.spec.CGenerate;
import fr.obeo.acceleo.chain.impl.spec.CGenerator;
import fr.obeo.acceleo.chain.impl.spec.CLog;
import fr.obeo.acceleo.chain.impl.spec.CModel;
import fr.obeo.acceleo.chain.impl.spec.CModelSet;
import fr.obeo.acceleo.chain.impl.spec.CRemove;
import fr.obeo.acceleo.chain.impl.spec.CRepository;

/**
 * <!-- begin-user-doc --> An implementation of the model <b>Factory</b>. <!--
 * end-user-doc -->
 * 
 * @generated
 */
public class ChainFactoryImpl extends EFactoryImpl implements ChainFactory {
	/**
	 * Creates the default factory implementation. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	public static ChainFactory init() {
		try {
			ChainFactory theChainFactory = (ChainFactory) EPackage.Registry.INSTANCE.getEFactory("http://www.obeo.fr/acceleo/chain");
			if (theChainFactory != null) {
				return theChainFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ChainFactoryImpl();
	}

	/**
	 * Creates an instance of the factory. <!-- begin-user-doc --> <!--
	 * end-user-doc -->
	 * 
	 * @generated
	 */
	public ChainFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ChainPackage.CHAIN:
			return createChain();
		case ChainPackage.REPOSITORY:
			return createRepository();
		case ChainPackage.ACTION_SET:
			return createActionSet();
		case ChainPackage.GENERATE:
			return createGenerate();
		case ChainPackage.CONVERT_XMI:
			return createConvertXmi();
		case ChainPackage.BACKUP:
			return createBackup();
		case ChainPackage.CLEAR:
			return createClear();
		case ChainPackage.REMOVE:
			return createRemove();
		case ChainPackage.CHAIN_CALL:
			return createChainCall();
		case ChainPackage.CUSTOM_ACTION:
			return createCustomAction();
		case ChainPackage.MODEL:
			return createModel();
		case ChainPackage.MODEL_SET:
			return createModelSet();
		case ChainPackage.FOLDER:
			return createFolder();
		case ChainPackage.LOG:
			return createLog();
		case ChainPackage.EMF_METAMODEL:
			return createEmfMetamodel();
		case ChainPackage.GENERATOR:
			return createGenerator();
		case ChainPackage.CUSTOM_FILE:
			return createCustomFile();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case ChainPackage.CUSTOM_ACTION_IDS:
			return createCustomActionIDsFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case ChainPackage.CUSTOM_ACTION_IDS:
			return convertCustomActionIDsToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Chain createChain() {
		ChainImpl chain = new CChain();
		return chain;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Repository createRepository() {
		RepositoryImpl repository = new CRepository();
		return repository;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public ActionSet createActionSet() {
		ActionSetImpl actionSet = new CActionSet();
		return actionSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Generate createGenerate() {
		GenerateImpl generate = new CGenerate();
		return generate;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public ConvertXmi createConvertXmi() {
		ConvertXmiImpl convertXmi = new CConvertXmi();
		return convertXmi;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Backup createBackup() {
		BackupImpl backup = new CBackup();
		return backup;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Clear createClear() {
		ClearImpl clear = new CClear();
		return clear;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Remove createRemove() {
		RemoveImpl remove = new CRemove();
		return remove;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public ChainCall createChainCall() {
		ChainCallImpl chainCall = new CChainCall();
		return chainCall;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public CustomAction createCustomAction() {
		CustomActionImpl customAction = new CCustomAction();
		return customAction;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Model createModel() {
		ModelImpl model = new CModel();
		return model;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public ModelSet createModelSet() {
		ModelSetImpl modelSet = new CModelSet();
		return modelSet;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Folder createFolder() {
		FolderImpl folder = new CFolder();
		return folder;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Log createLog() {
		LogImpl log = new CLog();
		return log;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public EmfMetamodel createEmfMetamodel() {
		EmfMetamodelImpl emfMetamodel = new CEmfMetamodel();
		return emfMetamodel;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public Generator createGenerator() {
		GeneratorImpl generator = new CGenerator();
		return generator;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @not-generated
	 */
	public CustomFile createCustomFile() {
		CustomFileImpl customFile = new CCustomFile();
		return customFile;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public CustomActionIDs createCustomActionIDsFromString(EDataType eDataType, String initialValue) {
		CustomActionIDs result = CustomActionIDs.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public String convertCustomActionIDsToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @generated
	 */
	public ChainPackage getChainPackage() {
		return (ChainPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * 
	 * @deprecated
	 * @generated
	 */
	public static ChainPackage getPackage() {
		return ChainPackage.eINSTANCE;
	}

} // ChainFactoryImpl
