/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package fr.obeo.acceleo.chain;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc --> A representation of the model object '
 * <em><b>Backup</b></em>'. <!-- end-user-doc -->
 * 
 * <p>
 * The following features are supported:
 * <ul>
 * <li>{@link fr.obeo.acceleo.chain.Backup#getFolder <em>Folder</em>}</li>
 * <li>{@link fr.obeo.acceleo.chain.Backup#getBackup <em>Backup</em>}</li>
 * </ul>
 * </p>
 * 
 * @see fr.obeo.acceleo.chain.ChainPackage#getBackup()
 * @model
 * @generated
 */
public interface Backup extends Action {
	/**
	 * Returns the value of the '<em><b>Folder</b></em>' reference. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Folder</em>' reference isn't clear, there
	 * really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Folder</em>' reference.
	 * @see #setFolder(Folder)
	 * @see fr.obeo.acceleo.chain.ChainPackage#getBackup_Folder()
	 * @model required="true"
	 * @generated
	 */
	Folder getFolder();

	/**
	 * Sets the value of the '{@link fr.obeo.acceleo.chain.Backup#getFolder
	 * <em>Folder</em>}' reference. <!-- begin-user-doc --> <!-- end-user-doc
	 * -->
	 * 
	 * @param value
	 *            the new value of the '<em>Folder</em>' reference.
	 * @see #getFolder()
	 * @generated
	 */
	void setFolder(Folder value);

	/**
	 * Returns the value of the '<em><b>Backup</b></em>' reference list.
	 * The list contents are of type {@link fr.obeo.acceleo.chain.Folder}. <!--
	 * begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Backup</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * 
	 * @return the value of the '<em>Backup</em>' reference list.
	 * @see fr.obeo.acceleo.chain.ChainPackage#getBackup_Backup()
	 * @model type="fr.obeo.acceleo.chain.Folder" required="true"
	 * @generated
	 */
	EList getBackup();

} // Backup
